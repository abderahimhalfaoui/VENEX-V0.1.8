## 0.1.8

General Digital Environment Mastery — additive; with no coordinator passed to `VenexAssistant` behaviour is exactly V0.1.7.

- Environment model (`env/`): elements with stable ids, roles, input fields, screen states (normal/dialog/loading/permission/login/CAPTCHA/opaque/unreadable),
  constraints, conflicts, explicit unknowns and confidence; screen diffing; symbolic target resolution.
- Structured goals (`goal/`): deterministic Arabic/English interpreter; slots are explicit/inferred/missing/referenced-but-absent; missing pieces become questions.
- Safety (`safety/ApprovalPolicy.kt`): risk classification from the real control label (payments blocked); owner approval bound to
  operation + goal + content + app + account + target + control + data; single use, expiring.
- Verification (`verify/EvidenceVerifier.kt`): VERIFIED only with observed evidence; absence is not evidence on dialogs/loading screens.
- Adaptive execution (`adaptive/`): idempotent element-level plans, state monitor, bounded recovery that never repeats a sensitive press,
  resumable task state (no text kept after completion), coordinator mapping to the existing `TaskReport`.
- Experience memory (`memory/`): button-name hints only, after repeated verified success; local; expiring; secret-guarded; forgettable.
- Integration: optional `adaptive` in `VenexAssistant`; `ExecutionEngine.executeStep`; extra `UiNode` fields (all defaulted);
  accessibility service fills hierarchy/state; `AppContainer` wires everything. Version 0.1.8 (code 8).
- 128 new core tests (353 total, all passing in the JVM harness). Not built with Gradle, no APK, not run on a device: see `docs/V0.1.8_REPORT.md`.

## 0.1.7

- Drawer rebuilt with the standard Material drawer (ModalNavigationDrawer). It slides in from the right, dims the
  screen, and closes on back, on tapping outside, or after an action. The previous manual offset approach
  left the screen partly shifted and clipped.

## 0.1.6

- Drawer opens from the right edge and pushes the screen to the left (positioned with translationX, not affected by RTL).
- Real chat history: each conversation is saved on the device with its first question as the title.
  Tap a conversation to reopen it; the X removes it. The list can be searched.
- "الوسائط" and "المستندات" are shown as "قريباً" until implemented.
- Settings gear icon redrawn as a real gear.
- Gemini added to the cloud presets (OpenAI-compatible endpoint). Not yet tested on a device: use "اختبار الاتصال".

## 0.1.5

- Drawer: the menu button stays top-right and the drawer now slides in from the right edge, pushing the screen left.
  The cause was the whole screen being laid out right-to-left, which mirrored the drawer offsets.
- AI settings rebuilt as a professional screen: header with back button, active-mode card, source selector,
  grouped section cards (on-device, cloud, server), accessibility status, preferences (marked "soon"), about.
  All existing actions are kept (import, load, test, activate, cloud and server configuration).

## 0.1.4

- Accessibility notice removed from the chat screen; its status and enable button now live in AI settings.
- Send button appears next to the input when there is text or an attachment (the microphone is hidden then).
- Microphone: real speech-to-text (Android SpeechRecognizer, Arabic), with runtime permission RECORD_AUDIO.
- "+" button: attach images, PDF and text files. Text files are read (first 16 KB) and sent with the message.
  Images and PDFs are attached by name only: their content is not read yet.
- Top-left button: turns the floating VENEX bubble on or off (drawn with the accessibility overlay; no extra
  permission). Tapping the bubble opens VENEX. It needs the accessibility service to be enabled.

# CHANGELOG

## V0.1.3 (versionCode 3) — إصلاح الاستدلال المحلي والهوية البصرية

سبب الإصدار: فشل V0.1.2 على هاتف حقيقي مع Qwen3-1.7B-Q4_K_M (يُحمَّل لكن الاستدلال يفشل، ويظهر «think»، وتُقطع الإجابة).
التفاصيل والأدلة وحدود التحقق: [`docs/V0.1.3_REPORT.md`](docs/V0.1.3_REPORT.md).

### إصلاحات
- **Qwen3 / وضع التفكير**: يُضاف إلى الطلب كتلة تفكير فارغة لقوالب Qwen3 (`finalize_prompt` في `venex_llm.cpp`)؛ مُنقٍّ للمخرجات (`ModelOutputSanitizer`) يزيل `<think>…</think>` والكتل غير المغلقة ورموز التحكم قبل التحليل واختبار الاستدلال.
- **الرد المقطوع**: المحرك يُبلغ `truncated` عند بلوغ حد الرموز، و`LlamaCppRuntime` يحوّله إلى فشل `INVALID_RESPONSE` بدل عرضه كجواب. ميزانية اختبار الاستدلال ثابتة (`PROBE_MAX_TOKENS = 48`) ومشتركة بين المسارين.
- **حالة النموذج في الشاشة**: سطر واحد صادق (`OnDeviceSnapshot.readiness`): «محمّل» ≠ «اجتاز الاختبار» ≠ «مفعّل» ≠ «يعمل».
- **«افتح يوتيوب وابحث عن …»**: هدف جديد `SearchInAppGoal` ← يخطّط فتح رابط نتائج البحث ← تحقّق من ظهور نص البحث؛ تطبيقات بلا خدمة بحث معروفة تُرفض بسبب واضح. اسم «يوتيوب/youtube» يُحلّ كتطبيق مثبّت.
- **حقل مفتاح API** يستخدم فعلياً لوحة مفاتيح كلمات المرور (الوثائق ذكرته في V0.1.2 ولم تكن الشيفرة تفعله).
- **اختبارات `ModelIntegrationTest`** (4 إخفاقات في CI عند V0.1.2): حُوِّلت إلى `runBlocking`. *التشخيص فرضية غير مؤكَّدة؛ لم يتوفر سجل CI.*
- **CI**: `pipefail` لكل الخطوات (كان `cmd | tee` يخفي فشل البناء/الاختبار)، واشتراط عبارة نجاح اختبار المحرك الأصلي، وفحص `versionName/versionCode` داخل الـ APK، وفحوص محتوى الـ APK من ملف بدل أنبوب.

### هوية
- الشعار الرسمي كما أُرسل (بلا إعادة تصميم): أيقونة التطبيق بكل الكثافات (مستديرة/قديمة)، أيقونة تكيفية (خلفية `#3CCFA1` + الطائر شفاف)، طبقة أحادية للثيم (أندرويد 13+)، شاشة البداية (قبل 12 وبعدها)، ورأس المحادثة. استُبدلت الأيقونة المتجهية القديمة.

### اختبارات
- core: 207 ← 225 (+14 `RegressionV013Test`، +4 في `OnDeviceControllerTest`). app (JVM، غلاف JNI): 13 ← 14. اختبار المحرك الأصلي على الحاسوب: فحوص 9–11 جديدة (قالب Qwen3، علم القطع).

### لم يتغير
رؤية VENEX وقائمة النوايا المغلقة وسياسة السلامة والمخطِّط والمحرك والتحقق؛ النموذج مطفأ افتراضياً ولا يرى إلا ما لا تفهمه القواعد؛ لا نموذج ولا مفتاح داخل الـ APK أو Git.

### غير منفَّذ / مفتوح
- ذاكرة المحادثة وأسئلة المتابعة للنموذج المحلي (ميزة جديدة؛ المحرك يمسح الذاكرة المؤقتة في كل طلب).
- لم يُبنَ APK ولم يُجرَّب على جهاز ولم يُشغَّل Qwen3 حقيقي هنا (انظر التقرير).

## V0.1.2
الذكاء الهجين: استدلال GGUF على الجهاز (llama.cpp عبر JNI) + وضع سحابي بمفتاح المالك (Android Keystore) + بقاء وضع الخادم. انظر `docs/ON_DEVICE_AI_REPORT.md`.

## V0.1.1
نماذج محلية اختيارية عبر خادم (Ollama / OpenAI-متوافق) واختبارا اتصال واستدلال.
