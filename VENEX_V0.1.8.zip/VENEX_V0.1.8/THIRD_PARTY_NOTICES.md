# Third-party notices

## llama.cpp / ggml (on-device inference engine, V0.1.2)

- Project: https://github.com/ggml-org/llama.cpp (includes the ggml tensor library)
- Pinned release: tag `b12627`, commit `225a5345bbb0e0c70859af5441ba922beb666fcf` (see `third_party/llama.cpp.version`)
- License: MIT. The full license text is in `app/src/main/assets/licenses/llama.cpp-LICENSE.txt` and is shipped inside the APK.
- How it is used: the source is **not** vendored in this repository. `scripts/fetch-llama-cpp.sh` fetches the pinned commit at build time and verifies the commit hash. It is compiled with the Android NDK into native libraries (`libllama.so`, `libggml*.so`) that are packaged in the APK.
- Model files (`.gguf`) are **not** part of this project. A model you choose has its own license, which you must check yourself.

## Libraries declared in `gradle/libs.versions.toml`

AndroidX, Jetpack Compose, Kotlin and kotlinx-coroutines are used under the Apache License 2.0. JUnit is used under the Eclipse Public License 1.0 (tests only).
