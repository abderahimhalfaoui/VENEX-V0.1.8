package com.venex.core

import com.venex.core.intent.AiInterpretation
import com.venex.core.intent.AiProvider
import com.venex.core.intent.LayeredIntentParser
import com.venex.core.intent.RuleBasedIntentParser
import com.venex.core.model.CalculateGoal
import com.venex.core.model.MathOp
import com.venex.core.model.NavTarget
import com.venex.core.model.NavigateGoal
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.RestrictedCategory
import com.venex.core.model.RestrictedGoal
import com.venex.core.model.ScrollDirection
import com.venex.core.model.ScrollGoal
import com.venex.core.model.UnknownGoal
import kotlinx.coroutines.test.runTest
import java.math.BigDecimal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertTrue

class IntentParserTest {

    private val rules = RuleBasedIntentParser()
    private val layered = LayeredIntentParser()

    @Test
    fun `canonical example opens calculator and multiplies`() = runTest {
        val g = layered.parse("افتح تطبيق الآلة الحاسبة واحسب 125 × 8")
        assertIs<CalculateGoal>(g)
        assertEquals(BigDecimal("125"), g.left)
        assertEquals(MathOp.MULTIPLY, g.op)
        assertEquals(BigDecimal("8"), g.right)
        assertEquals(0, BigDecimal("1000").compareTo(g.expected()))
    }

    @Test
    fun `arabic-indic digits and word operators`() {
        val g = rules.parseSync("احسب ١٢٥ ضرب ٨")
        assertIs<CalculateGoal>(g)
        assertEquals(BigDecimal("125"), g.left)
        assertEquals(MathOp.MULTIPLY, g.op)

        val add = rules.parseSync("٣ زائد ٤")
        assertIs<CalculateGoal>(add)
        assertEquals(MathOp.ADD, add.op)

        val sub = rules.parseSync("10 ناقص 4")
        assertIs<CalculateGoal>(sub)
        assertEquals(MathOp.SUBTRACT, sub.op)

        val div = rules.parseSync("20 مقسوم على 4")
        assertIs<CalculateGoal>(div)
        assertEquals(MathOp.DIVIDE, div.op)
    }

    @Test
    fun `symbol operators and decimals`() {
        assertEquals(MathOp.DIVIDE, (rules.parseSync("10 ÷ 4") as CalculateGoal).op)
        assertEquals(MathOp.MULTIPLY, (rules.parseSync("125x8") as CalculateGoal).op)
        val d = rules.parseSync("2.5 + 1") as CalculateGoal
        assertEquals(BigDecimal("2.5"), d.left)
    }

    @Test
    fun `division by zero has no expected value`() {
        val g = rules.parseSync("5 ÷ 0") as CalculateGoal
        assertEquals(null, g.expected())
    }

    @Test
    fun `open app strips filler words`() {
        assertEquals("الكاميرا", (rules.parseSync("افتح الكاميرا") as OpenAppGoal).appName)
        assertEquals("الكاميرا", (rules.parseSync("افتح تطبيق الكاميرا") as OpenAppGoal).appName)
        assertEquals("camera", (rules.parseSync("open camera") as OpenAppGoal).appName)
    }

    @Test
    fun `navigation and scroll`() {
        assertEquals(NavTarget.HOME, (rules.parseSync("اذهب إلى الشاشة الرئيسية") as NavigateGoal).target)
        assertEquals(NavTarget.BACK, (rules.parseSync("ارجع") as NavigateGoal).target)
        assertEquals(ScrollDirection.DOWN, (rules.parseSync("انزل") as ScrollGoal).direction)
        assertEquals(ScrollDirection.UP, (rules.parseSync("مرر للأعلى") as ScrollGoal).direction)
    }

    @Test
    fun `gibberish is unknown`() {
        assertIs<UnknownGoal>(rules.parseSync("blah blah"))
        assertIs<UnknownGoal>(rules.parseSync("   "))
    }

    @Test
    fun `send post delete and pay are restricted`() = runTest {
        assertEquals(RestrictedCategory.SEND, (layered.parse("أرسل رسالة لأحمد") as RestrictedGoal).category)
        assertEquals(RestrictedCategory.SEND, (layered.parse("افتح واتساب وارسل لأحمد مرحبا") as RestrictedGoal).category)
        assertEquals(RestrictedCategory.POST, (layered.parse("انشر هذه الصورة") as RestrictedGoal).category)
        assertEquals(RestrictedCategory.DELETE, (layered.parse("احذف الصور") as RestrictedGoal).category)
        assertEquals(RestrictedCategory.PAYMENT, (layered.parse("ادفع الفاتورة") as RestrictedGoal).category)
        assertEquals(RestrictedCategory.PAYMENT, (layered.parse("buy this item") as RestrictedGoal).category)
    }

    @Test
    fun `harmless commands are not restricted`() = runTest {
        assertIs<OpenAppGoal>(layered.parse("افتح الكاميرا"))
        assertIs<CalculateGoal>(layered.parse("احسب 3 + 4"))
    }

    // ---- AI provider seam ----

    private class FakeAi(private val answer: AiInterpretation?, private val boom: Boolean = false) : AiProvider {
        override val name = "fake"
        var calls = 0
        override suspend fun interpret(text: String): AiInterpretation? {
            calls++
            if (boom) error("network down")
            return answer
        }
    }

    @Test
    fun `ai is consulted only when rules fail`() = runTest {
        val ai = FakeAi(AiInterpretation("open_app", mapOf("app" to "الكاميرا")))
        val parser = LayeredIntentParser(ai = ai)
        assertIs<CalculateGoal>(parser.parse("احسب 1 + 1"))
        assertEquals(0, ai.calls)
        val g = parser.parse("ممكن تطلع لي الكاميرا")
        assertIs<OpenAppGoal>(g)
        assertEquals(1, ai.calls)
    }

    @Test
    fun `ai cannot bypass restricted detection`() = runTest {
        val ai = FakeAi(AiInterpretation("open_app", mapOf("app" to "المعرض")))
        val g = LayeredIntentParser(ai = ai).parse("احذف كل الصور")
        assertIs<RestrictedGoal>(g)
        assertEquals(0, ai.calls)
    }

    @Test
    fun `ai failure or invalid output degrades to unknown`() = runTest {
        assertIs<UnknownGoal>(LayeredIntentParser(ai = FakeAi(null, boom = true)).parse("شيء غير مفهوم"))
        assertIs<UnknownGoal>(
            LayeredIntentParser(ai = FakeAi(AiInterpretation("hack_the_planet"))).parse("شيء غير مفهوم")
        )
        assertIs<UnknownGoal>(
            LayeredIntentParser(ai = FakeAi(AiInterpretation("calculate", mapOf("left" to "x")))).parse("شيء غير مفهوم")
        )
    }

    @Test
    fun `ai calculate suggestion is converted`() = runTest {
        val ai = FakeAi(AiInterpretation("calculate", mapOf("left" to "6", "op" to "multiply", "right" to "7")))
        val g = LayeredIntentParser(ai = ai).parse("كم ستة في سبعة")
        assertIs<CalculateGoal>(g)
        assertTrue(g.expected()!!.compareTo(BigDecimal("42")) == 0)
    }
}
