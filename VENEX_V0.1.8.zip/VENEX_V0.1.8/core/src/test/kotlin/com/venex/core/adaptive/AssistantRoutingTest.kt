package com.venex.core.adaptive

import com.venex.core.VenexAssistant
import com.venex.core.engine.DenyAllConfirmations
import com.venex.core.goal.GoalFamily
import com.venex.core.goal.Slot
import com.venex.core.goal.SlotName
import com.venex.core.goal.SlotStatus
import com.venex.core.intent.LayeredIntentParser
import com.venex.core.model.AdaptiveGoal
import com.venex.core.model.TaskStatus
import com.venex.core.planner.TaskPlanner
import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** V0.1.8 — the assistant facade: the adaptive layer is opt-in and leaves everything V0.1.7 did alone. */
class AssistantRoutingTest {

    private fun assistant(h: Harness, adaptive: Boolean) = VenexAssistant(
        LayeredIntentParser(), TaskPlanner(), h.fx.device, h.audit, DenyAllConfirmations, settleDelayMs = 0,
        adaptive = if (adaptive) h.coordinator else null
    )

    @Test
    fun withoutACoordinatorTheAssistantIsTheV017One() = runTest {
        val h = Harness()
        val a = assistant(h, adaptive = false)
        val plan = a.plan("افتح شبكة وانشر \"مرحبا\"")
        assertTrue(plan.goal !is AdaptiveGoal, "the adaptive goal type never appears without a coordinator")
        val report = a.run(plan)
        assertTrue(report.status != TaskStatus.SUCCESS)
        assertTrue(h.fx.posts.isEmpty())
        assertTrue(h.approvals.requests.isEmpty())
    }

    @Test
    fun whatV017HandledStillGoesTheV017Way() = runTest {
        for (command in listOf("افتح شبكة", "ما الساعة؟", "احسب 125 × 8", "افتح يوتيوب وابحث عن قرآن")) {
            val plain = assistant(Harness(), false).plan(command)
            val withAdaptive = assistant(Harness(), true).plan(command)
            assertEquals(plain.blockedReason, withAdaptive.blockedReason, command)
            assertEquals(plain.steps.map { it.id }, withAdaptive.steps.map { it.id }, "same steps for: $command")
            assertEquals(plain.goal::class, withAdaptive.goal::class, command)
        }
    }

    @Test
    fun whatV017COULDNOTDoIsNowOfferedToTheAdaptiveLayer() = runTest {
        // "read the screen" was an unknown command in V0.1.7 (checked against the baseline); now it is understood.
        assertTrue(assistant(Harness(), false).plan("اقرأ الشاشة").blockedReason != null)
        val plan = assistant(Harness(), true).plan("اقرأ الشاشة")
        assertNull(plan.blockedReason)
        assertIs<AdaptiveGoal>(plan.goal)
    }

    @Test
    fun theOwnersExampleRunsThroughTheAdaptivePathAndNeedsApproval() = runTest {
        val h = Harness()
        val a = assistant(h, adaptive = true)
        val plan = a.plan("افتح شبكة وانشر \"مرحبا من VENEX\"")
        assertNull(plan.blockedReason)
        assertIs<AdaptiveGoal>(plan.goal)
        assertTrue(plan.steps.isNotEmpty(), "the plan is shown to the owner before anything runs")
        assertTrue(h.fx.device.log.isEmpty(), "planning acts on nothing")
        val report = a.run(plan)
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(1, h.approvals.requests.size)
        assertEquals(listOf("مرحبا من VENEX"), h.fx.posts)
    }

    @Test
    fun aMissingPieceIsAQuestionAndNothingRuns() = runTest {
        val h = Harness()
        val a = assistant(h, adaptive = true)
        val report = a.handle("افتح شبكة وانشر")
        assertEquals(TaskStatus.NOT_EXECUTED, report.status)
        assertTrue(report.summary.isNotBlank())
        assertTrue(h.fx.device.log.none { it.startsWith("click:") || it.startsWith("type:") })
        assertTrue(h.fx.posts.isEmpty())
    }

    @Test
    fun aPaymentIsRefusedAndNeverReachesTheAdaptiveRunner() = runTest {
        val h = Harness()
        val a = assistant(h, adaptive = true)
        val plan = a.plan("ادفع الفاتورة الآن")
        assertNotNull(plan.blockedReason)
        val report = a.run(plan)
        assertTrue(report.status != TaskStatus.SUCCESS)
        assertTrue(h.approvals.requests.isEmpty(), "a payment is not even offered for approval")
        assertTrue(h.fx.device.log.none { it.startsWith("click:") })
    }

    @Test
    fun theResumePhraseIsOnlyHeardWhenATaskIsWaiting() = runTest {
        val h = Harness(Fixtures(startIn = "feed"))
        val a = assistant(h, adaptive = true)
        val none = a.plan("استأنف")
        assertFalse((none.goal as? AdaptiveGoal)?.resume == true, "nothing to resume: the word is an ordinary command")

        h.store.save(
            TaskState(
                "t-old", GoalFamily.CREATE_POST,
                listOf(Slot(SlotName.APP, "شبكة", SlotStatus.EXPLICIT), Slot(SlotName.TEXT, "نص", SlotStatus.EXPLICIT)),
                SOCIAL, TaskPhase.PAUSED, mapOf("open" to StepMark.DONE), null, 1, 2
            )
        )
        val plan = a.plan("استأنف")
        val goal = plan.goal
        assertIs<AdaptiveGoal>(goal)
        assertTrue(goal.resume)
    }
}
