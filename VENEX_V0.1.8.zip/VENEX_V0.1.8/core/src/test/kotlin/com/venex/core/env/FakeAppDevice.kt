package com.venex.core.env

import com.venex.core.device.ActionResult
import com.venex.core.device.AppResolution
import com.venex.core.device.Bounds
import com.venex.core.device.Channel
import com.venex.core.device.DeviceController
import com.venex.core.device.InstalledApp
import com.venex.core.device.ScreenSnapshot
import com.venex.core.device.SelectorMatcher
import com.venex.core.device.UiNode
import com.venex.core.model.GlobalKey
import com.venex.core.model.ScrollDirection
import com.venex.core.model.Selector

/** Builds a snapshot node list in pre-order, computing depth and parentIndex like the Accessibility service does. */
class TreeBuilder {
    val nodes = ArrayList<UiNode>()

    fun add(
        parent: Int = -1,
        text: String? = null,
        cd: String? = null,
        id: String? = null,
        cls: String? = null,
        clickable: Boolean = false,
        editable: Boolean = false,
        scrollable: Boolean = false,
        password: Boolean = false,
        enabled: Boolean = true,
        hint: Boolean = false,
        focused: Boolean = false,
        checkable: Boolean = false,
        checked: Boolean = false,
        bounds: Bounds? = Bounds(0, 0, 100, 40)
    ): Int {
        val depth = if (parent < 0) 0 else nodes[parent].depth + 1
        nodes += UiNode(
            text = text, contentDescription = cd, viewId = id, className = cls, clickable = clickable, editable = editable,
            scrollable = scrollable, password = password, enabled = enabled, bounds = bounds, checkable = checkable,
            checked = checked, focused = focused, showingHint = hint, depth = depth, parentIndex = parent
        )
        return nodes.size - 1
    }
}

fun tree(block: TreeBuilder.() -> Unit): List<UiNode> = TreeBuilder().apply(block).nodes

fun flat(vararg nodes: UiNode): List<UiNode> = nodes.toList()

/** One screen of a scripted fake application. [clicks] maps a visible label to what pressing it does. */
class FakeScreen(
    val pkg: String,
    val build: (FakeAppDevice) -> List<UiNode>,
    val clicks: Map<String, (FakeAppDevice) -> Unit> = emptyMap(),
    val onBack: ((FakeAppDevice) -> Unit)? = null
)

/**
 * A scripted, device-independent application used to test the generic environment machinery. Nothing in it is
 * specific to one app: screens, transitions and text fields are plain data, so the same code paths run that run
 * against a real phone (snapshot, click by selector, type text).
 */
class FakeAppDevice(
    val apps: List<InstalledApp> = emptyList(),
    var caps: Set<Channel> = setOf(Channel.INTENT, Channel.DEEP_LINK, Channel.ACCESSIBILITY),
    val screens: MutableMap<String, FakeScreen> = mutableMapOf(),
    var current: String? = null,
    /** package -> screen shown when the app is launched. */
    val launchScreens: Map<String, String> = emptyMap()
) : DeviceController {

    val log = mutableListOf<String>()
    val typed = mutableMapOf<String, String>()
    val vars = mutableMapOf<String, Any?>()
    var snapshotCalls = 0
    var snapshotThrows = false
    var blind = false // snapshot() returns null even though Accessibility is "on"
    var failClicks = false // every click reports failure
    var swallowClicks = false // clicks report success but nothing happens
    var failTyping = false
    var onBeforeSnapshot: ((FakeAppDevice) -> Unit)? = null
    var clockAdvance: ((Long) -> Unit)? = null
    var msPerOp = 100L

    val screen: FakeScreen? get() = current?.let { screens[it] }

    fun goto(name: String) {
        current = name
    }

    override fun capabilities(): Set<Channel> = caps

    override suspend fun resolveApp(query: String): AppResolution {
        val q = query.trim().lowercase()
        val hits = apps.filter { it.label.lowercase() == q || it.label.lowercase().contains(q) || it.packageName.lowercase() == q }
        return when (hits.size) {
            0 -> AppResolution.NotFound
            1 -> AppResolution.Found(hits[0])
            else -> hits.firstOrNull { it.label.lowercase() == q }?.let { AppResolution.Found(it) } ?: AppResolution.Ambiguous(hits)
        }
    }

    override suspend fun launchApp(app: InstalledApp): ActionResult {
        tick()
        log += "launch:${app.packageName}"
        val target = launchScreens[app.packageName] ?: return ActionResult.fail("لا شاشة لـ ${app.packageName}")
        current = target
        return ActionResult.ok("فُتح ${app.label}")
    }

    override suspend fun openDeepLink(uri: String): ActionResult {
        tick()
        log += "link:$uri"
        return ActionResult.ok("فُتح $uri")
    }

    override suspend fun snapshot(): ScreenSnapshot? {
        snapshotCalls++
        if (snapshotThrows) throw IllegalStateException("boom")
        onBeforeSnapshot?.invoke(this)
        if (blind) return null
        val s = screen ?: return null
        return ScreenSnapshot(s.pkg, s.build(this))
    }

    override suspend fun click(selector: Selector): ActionResult {
        tick()
        val s = screen ?: return ActionResult.fail("لا شاشة")
        val node = SelectorMatcher.findBest(s.build(this), selector) ?: return ActionResult.fail("لم يُعثر على «${selector.describe()}»")
        if (!node.enabled) return ActionResult.fail("العنصر معطّل")
        val label = node.text ?: node.contentDescription ?: node.viewId ?: "?"
        log += "click:$label"
        if (failClicks) return ActionResult.fail("رفض النظام النقر")
        if (!swallowClicks) s.clicks[label]?.invoke(this)
        return ActionResult.ok("نُقر «$label»")
    }

    override suspend fun typeText(selector: Selector?, text: String): ActionResult {
        tick()
        val s = screen ?: return ActionResult.fail("لا شاشة")
        val nodes = s.build(this)
        val node = if (selector != null) SelectorMatcher.findBest(nodes, selector)
        else nodes.firstOrNull { it.editable && !it.password && it.enabled }
        if (node == null || !node.editable) return ActionResult.fail("لا حقل مناسب")
        if (node.password) return ActionResult.fail("حقل كلمة مرور")
        if (failTyping) return ActionResult.fail("تعذّرت الكتابة")
        val key = node.viewId ?: node.contentDescription ?: node.text ?: "field"
        typed[key] = text
        log += "type:$key"
        return ActionResult.ok("كُتب النص")
    }

    override suspend fun scroll(direction: ScrollDirection): ActionResult {
        tick()
        log += "scroll:$direction"
        vars["scrolls"] = ((vars["scrolls"] as? Int) ?: 0) + 1
        return ActionResult.ok("تمرير")
    }

    override suspend fun press(key: GlobalKey): ActionResult {
        tick()
        log += "press:$key"
        if (key == GlobalKey.BACK) screen?.onBack?.invoke(this)
        return ActionResult.ok("ضغط $key")
    }

    private fun tick() {
        clockAdvance?.invoke(msPerOp)
    }

    fun clicksOf(label: String): Int = log.count { it == "click:$label" }
}

/** A manual clock for deterministic tests. */
class TestClock(var now: Long = 1_000_000L) : () -> Long {
    override fun invoke(): Long = now
    fun advance(ms: Long) {
        now += ms
    }
}

val SAMPLE_APPS = listOf(
    InstalledApp("المفكرة", "com.example.notes"),
    InstalledApp("شبكة", "com.example.social"),
    InstalledApp("متجر", "com.example.shop"),
    InstalledApp("رسائل", "com.example.chat")
)
