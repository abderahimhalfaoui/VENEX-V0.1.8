package com.venex.core

import com.venex.core.audit.AuditLevel
import com.venex.core.audit.AuditLog
import com.venex.core.device.InstalledApp
import com.venex.core.engine.ConfirmationHandler
import com.venex.core.engine.DenyAllConfirmations
import com.venex.core.engine.ExecutionEngine
import com.venex.core.intent.LayeredIntentParser
import com.venex.core.model.Action
import com.venex.core.model.CalculateGoal
import com.venex.core.model.GlobalKey
import com.venex.core.model.MathOp
import com.venex.core.model.Plan
import com.venex.core.model.Selector
import com.venex.core.model.Step
import com.venex.core.model.StepStatus
import com.venex.core.model.TaskStatus
import com.venex.core.planner.TaskPlanner
import kotlinx.coroutines.test.runTest
import java.math.BigDecimal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class EngineTest {

    private val audit = AuditLog()

    private fun assistant(device: FakeCalculatorDevice, confirm: ConfirmationHandler = DenyAllConfirmations) =
        VenexAssistant(LayeredIntentParser(), TaskPlanner(), device, audit, confirm, settleDelayMs = 0)

    private val example = "افتح تطبيق الآلة الحاسبة واحسب 125 × 8"

    @Test
    fun `canonical example succeeds with verified result`() = runTest {
        val device = FakeCalculatorDevice()
        val report = assistant(device).handle(example)

        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(listOf("com.fake.calculator"), device.launched)
        assertEquals(listOf("C", "1", "2", "5", "×", "8", "="), device.clicked)
        assertEquals(StepStatus.VERIFIED, report.steps.last().status)
        assertTrue(report.summary.contains("1000"), report.summary)
        assertTrue(audit.entries().any { it.level == AuditLevel.EVIDENCE })
    }

    @Test
    fun `other operations and rounding are verified`() = runTest {
        // 7 − 9 = −2 (negative result produced by the calculator) and 1 ÷ 3 (non-terminating).
        for (cmd in listOf("احسب 10 ÷ 4", "احسب 7 ناقص 9", "احسب 1 ÷ 3", "احسب 2 + 6")) {
            val report = assistant(FakeCalculatorDevice()).handle(cmd)
            assertEquals(TaskStatus.SUCCESS, report.status, "$cmd -> ${report.summary}")
        }
    }

    @Test
    fun `wrong calculator result is reported as failure not success`() = runTest {
        val device = FakeCalculatorDevice(corruptEquals = true)
        val report = assistant(device).handle(example)
        assertEquals(TaskStatus.FAILED, report.status)
        assertTrue(report.summary.contains("فشل التحقق"), report.summary)
    }

    @Test
    fun `without accessibility the app opens but success is never claimed`() = runTest {
        val device = FakeCalculatorDevice(accessibility = false)
        val report = assistant(device).handle(example)
        assertEquals(TaskStatus.FAILED, report.status)
        assertTrue(report.summary.contains("Accessibility"), report.summary)
        assertEquals(listOf("com.fake.calculator"), device.launched)
        assertTrue(device.clicked.isEmpty())
        // The open step ran but could not be verified.
        assertEquals(StepStatus.EXECUTED_UNVERIFIED, report.steps.first().status)
    }

    @Test
    fun `missing app fails and dependents are skipped without touching the device`() = runTest {
        val device = FakeCalculatorDevice(apps = listOf(InstalledApp("الكاميرا", "com.fake.camera", true)))
        val report = assistant(device).handle(example)
        assertEquals(TaskStatus.FAILED, report.status)
        assertTrue(device.launched.isEmpty())
        assertTrue(device.clicked.isEmpty())
        assertEquals(StepStatus.FAILED, report.steps.first().status)
        assertTrue(report.steps.drop(1).all { it.status == StepStatus.SKIPPED })
    }

    @Test
    fun `ambiguous app asks the user instead of guessing`() = runTest {
        val device = FakeCalculatorDevice(
            apps = listOf(
                InstalledApp("Calculator", "com.a.calculator", false),
                InstalledApp("Calculator", "com.b.calculator", false)
            )
        )
        val report = assistant(device).handle(example)
        assertEquals(TaskStatus.FAILED, report.status)
        assertTrue(report.steps.first().message.contains("حدّد"), report.steps.first().message)
        assertTrue(device.launched.isEmpty())
    }

    @Test
    fun `missing key aborts remaining steps`() = runTest {
        val device = FakeCalculatorDevice(missingKeys = setOf("×"))
        val report = assistant(device).handle(example)
        assertEquals(TaskStatus.FAILED, report.status)
        assertEquals(StepStatus.FAILED, report.steps.first { it.stepId == "op" }.status)
        assertEquals(StepStatus.SKIPPED, report.steps.first { it.stepId == "equals" }.status)
        assertEquals(StepStatus.SKIPPED, report.steps.first { it.stepId == "read" }.status)
    }

    @Test
    fun `optional clear key missing does not block the task`() = runTest {
        val device = FakeCalculatorDevice(missingKeys = setOf("C"))
        val report = assistant(device).handle(example)
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(StepStatus.FAILED, report.steps.first { it.stepId == "clear" }.status)
    }

    @Test
    fun `captcha stops the task and nothing is clicked`() = runTest {
        val device = FakeCalculatorDevice(captcha = true)
        val report = assistant(device).handle(example)
        assertEquals(TaskStatus.FAILED, report.status)
        assertTrue(device.clicked.isEmpty())
        assertTrue(report.summary.contains("CAPTCHA"), report.summary)
    }

    @Test
    fun `restricted command is never executed`() = runTest {
        val device = FakeCalculatorDevice()
        val report = assistant(device).handle("افتح الكاميرا وارسل الصورة لأحمد")
        assertEquals(TaskStatus.NOT_EXECUTED, report.status)
        assertTrue(device.launched.isEmpty())
        assertTrue(device.pressed.isEmpty())
    }

    @Test
    fun `unknown command is not executed`() = runTest {
        val report = assistant(FakeCalculatorDevice()).handle("blah")
        assertEquals(TaskStatus.NOT_EXECUTED, report.status)
    }

    @Test
    fun `result equal to an operand without a result field is unverified`() = runTest {
        // 125 × 1 = 125; with no id marking the result node, the typed input is indistinguishable.
        val device = FakeCalculatorDevice(resultViewId = "com.fake.calc:id/anonymous")
        val report = assistant(device).handle("احسب 125 × 1")
        assertEquals(TaskStatus.UNVERIFIED, report.status, report.summary)
    }

    @Test
    fun `result equal to an operand is verified when the result node is identifiable`() = runTest {
        val report = assistant(FakeCalculatorDevice()).handle("احسب 125 × 1")
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
    }

    // ---- confirmation gate ----

    private val backPlan = Plan(
        goal = CalculateGoal(BigDecimal.ONE, MathOp.ADD, BigDecimal.ONE, "x"),
        steps = listOf(
            Step("guarded", "خطوة تتطلب موافقة", Action.Press(GlobalKey.BACK), needsConfirmation = true),
            Step("after", "خطوة تالية", Action.Press(GlobalKey.HOME), dependsOn = listOf("guarded"))
        )
    )

    @Test
    fun `declined confirmation cancels the step and its dependents`() = runTest {
        val device = FakeCalculatorDevice()
        val report = ExecutionEngine(device, audit, DenyAllConfirmations, 0).execute(backPlan)
        assertEquals(TaskStatus.CANCELLED, report.status)
        assertTrue(device.pressed.isEmpty())
        assertEquals(StepStatus.CANCELLED_BY_USER, report.steps[0].status)
        assertEquals(StepStatus.SKIPPED, report.steps[1].status)
    }

    @Test
    fun `approved confirmation runs the step but cannot claim verification`() = runTest {
        val device = FakeCalculatorDevice()
        val engine = ExecutionEngine(device, audit, ConfirmationHandler { true }, 0)
        val report = engine.execute(backPlan)
        assertEquals(listOf(GlobalKey.BACK, GlobalKey.HOME), device.pressed)
        assertEquals(TaskStatus.UNVERIFIED, report.status)
    }

    // ---- plan validation & safety at action level ----

    @Test
    fun `cyclic or dangling dependencies are rejected before running`() = runTest {
        val device = FakeCalculatorDevice()
        val goal = CalculateGoal(BigDecimal.ONE, MathOp.ADD, BigDecimal.ONE, "x")
        val cyclic = Plan(
            goal,
            listOf(
                Step("a", "a", Action.Press(GlobalKey.BACK), dependsOn = listOf("b")),
                Step("b", "b", Action.Press(GlobalKey.BACK), dependsOn = listOf("a"))
            )
        )
        assertEquals(TaskStatus.FAILED, ExecutionEngine(device, audit, DenyAllConfirmations, 0).execute(cyclic).status)

        val dangling = Plan(goal, listOf(Step("a", "a", Action.Press(GlobalKey.BACK), dependsOn = listOf("zzz"))))
        assertEquals(TaskStatus.FAILED, ExecutionEngine(device, audit, DenyAllConfirmations, 0).execute(dangling).status)
        assertTrue(device.pressed.isEmpty())
    }

    @Test
    fun `typing into a password field is denied`() = runTest {
        val device = FakeCalculatorDevice(includePasswordField = true)
        val goal = CalculateGoal(BigDecimal.ONE, MathOp.ADD, BigDecimal.ONE, "x")
        val plan = Plan(goal, listOf(Step("t", "كتابة", Action.TypeText(null, "secret"))))
        val report = ExecutionEngine(device, audit, DenyAllConfirmations, 0).execute(plan)
        assertEquals(TaskStatus.FAILED, report.status)
        assertTrue(device.typedTexts.isEmpty())
    }

    @Test
    fun `only allow-listed link schemes are opened`() = runTest {
        val device = FakeCalculatorDevice()
        val goal = CalculateGoal(BigDecimal.ONE, MathOp.ADD, BigDecimal.ONE, "x")
        val bad = Plan(goal, listOf(Step("l", "رابط", Action.OpenDeepLink("intent://evil#Intent;end"))))
        assertEquals(TaskStatus.FAILED, ExecutionEngine(device, audit, DenyAllConfirmations, 0).execute(bad).status)
        assertTrue(device.deepLinks.isEmpty())

        val good = Plan(goal, listOf(Step("l", "رابط", Action.OpenDeepLink("https://example.com"))))
        ExecutionEngine(device, audit, DenyAllConfirmations, 0).execute(good)
        assertEquals(listOf("https://example.com"), device.deepLinks)
    }

    @Test
    fun `typed text never appears in the audit log`() = runTest {
        val device = FakeCalculatorDevice()
        val goal = CalculateGoal(BigDecimal.ONE, MathOp.ADD, BigDecimal.ONE, "x")
        val plan = Plan(goal, listOf(Step("t", "كتابة", Action.TypeText(Selector(listOf("x")), "hunter2-secret"))))
        ExecutionEngine(device, audit, DenyAllConfirmations, 0).execute(plan)
        assertTrue(audit.entries().none { (it.message + it.evidence.orEmpty()).contains("hunter2-secret") })
    }

    @Test
    fun `progress callback receives every step`() = runTest {
        val seen = mutableListOf<String>()
        val device = FakeCalculatorDevice()
        val plan = TaskPlanner().plan(CalculateGoal(BigDecimal("2"), MathOp.ADD, BigDecimal("3"), "x"))
        ExecutionEngine(device, audit, DenyAllConfirmations, 0) { seen += it.stepId }.execute(plan)
        assertEquals(plan.steps.map { it.id }, seen)
    }
}
