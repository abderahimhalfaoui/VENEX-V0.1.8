package com.venex.core.ai

import com.venex.core.FakeCalculatorDevice
import com.venex.core.audit.AuditLog
import com.venex.core.engine.DenyAllConfirmations
import com.venex.core.engine.ExecutionEngine
import com.venex.core.intent.AiProvider
import com.venex.core.intent.IntentSource
import com.venex.core.intent.LayeredIntentParser
import com.venex.core.intent.NoAiProvider
import com.venex.core.intent.RuleBasedIntentParser
import com.venex.core.model.CalculateGoal
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.Plan
import com.venex.core.model.RestrictedGoal
import com.venex.core.model.TaskStatus
import com.venex.core.model.UnknownGoal
import com.venex.core.planner.TaskPlanner
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertTrue

/**
 * End-to-end: a real local HTTP model -> ModelIntentProvider -> LayeredIntentParser -> TaskPlanner
 * -> ExecutionEngine on the simulated calculator device.
 */
/*
 * These tests talk to a real local HTTP server through LayeredIntentParser, which applies a wall-clock
 * timeout (withTimeoutOrNull). They therefore run in real time (runBlocking): inside runTest the timeout is
 * driven by virtual time while the HTTP call runs on a real thread, so the outcome can depend on scheduling
 * (V0.1.2 CI reported four failures here that did not reproduce locally).
 */
class ModelIntegrationTest {

    private fun modelParser(server: FakeModelServer, timeoutMs: Long = 5_000): Pair<LayeredIntentParser, ModelIntentProvider> {
        val reg = ProviderRegistry()
        val provider = ModelIntentProvider(reg.get(ProviderType.OLLAMA), ConnectionSpec(server.baseUrl, 3_000), "llama3")
        return LayeredIntentParser(ai = provider, aiTimeoutMs = timeoutMs) to provider
    }

    private suspend fun run(parser: LayeredIntentParser, device: FakeCalculatorDevice, text: String): Pair<IntentSource, TaskStatus> {
        val audit = AuditLog()
        val parsed = parser.parseWithSource(text)
        val plan: Plan = TaskPlanner().plan(parsed.goal)
        val report = ExecutionEngine(device, audit, DenyAllConfirmations, settleDelayMs = 0).execute(plan)
        return parsed.source to report.status
    }

    @Test
    fun `model interprets an open app command and the model really decides`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("""{"intent":"open_app","app":"الكاميرا"}"""))
            val (parser, _) = modelParser(s)
            val parsed = parser.parseWithSource("ممكن تطلع لي الكاميرا")
            assertEquals(IntentSource.MODEL, parsed.source)
            assertEquals("الكاميرا", (parsed.goal as OpenAppGoal).appName)
            // The user's words were sent to the model as data inside the delimiters.
            assertTrue(s.requests.single().body.contains("ممكن تطلع لي الكاميرا"))
        }
    }

    @Test
    fun `model interprets a calculation written in words and the engine verifies it`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed(
                "POST", "/api/chat", 200,
                Replies.ollamaChat("""Sure. {"intent":"calculate","left":"125","op":"multiply","right":"8"}""")
            )
            val (parser, _) = modelParser(s)
            val device = FakeCalculatorDevice()
            val (source, status) = run(parser, device, "احسب مئة وخمسة وعشرين في ثمانية")
            assertEquals(IntentSource.MODEL, source)
            assertEquals(TaskStatus.SUCCESS, status)
            assertEquals(listOf("1", "2", "5", "×", "8", "="), device.clicked.drop(1))
        }
    }

    @Test
    fun `the canonical example still uses the rules and never calls the model`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            val (parser, _) = modelParser(s)
            val (source, status) = run(parser, FakeCalculatorDevice(), "افتح تطبيق الآلة الحاسبة واحسب 125 × 8")
            assertEquals(IntentSource.RULES, source)
            assertEquals(TaskStatus.SUCCESS, status)
            assertEquals(0, s.requests.size)
        }
    }

    @Test
    fun `model cannot create an unsupported goal`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("""{"intent":"delete_all_photos"}"""))
            val (parser, _) = modelParser(s)
            val device = FakeCalculatorDevice()
            val (source, status) = run(parser, device, "نظف لي الهاتف من كل شيء")
            assertEquals(IntentSource.NONE, source)
            assertIs<UnknownGoal>(parser.parse("نظف لي الهاتف من كل شيء"))
            assertEquals(TaskStatus.NOT_EXECUTED, status)
            assertTrue(device.launched.isEmpty())
        }
    }

    @Test
    fun `restricted commands are blocked before any model is consulted`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("""{"intent":"open_app","app":"واتساب"}"""))
            val (parser, _) = modelParser(s)
            val parsed = parser.parseWithSource("احذف كل الصور")
            assertEquals(IntentSource.RESTRICTED_RULE, parsed.source)
            assertIs<RestrictedGoal>(parsed.goal)
            assertEquals(0, s.requests.size, "the model must not even see a restricted request")
        }
    }

    @Test
    fun `a model suggestion to send a message is refused even when phrased as open app`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("""{"intent":"open_app","app":"ارسل رسالة لأحمد"}"""))
            val (parser, _) = modelParser(s)
            val parsed = parser.parseWithSource("لأحمد مرحبا")
            assertEquals(IntentSource.NONE, parsed.source)
            assertIs<UnknownGoal>(parsed.goal)
        }
    }

    @Test
    fun `safety policy still stops a captcha screen even if the model suggested the action`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("""{"intent":"calculate","left":"1","op":"add","right":"1"}"""))
            val (parser, _) = modelParser(s)
            val device = FakeCalculatorDevice(captcha = true)
            val (source, status) = run(parser, device, "كم يساوي واحد زائد الواحد")
            assertEquals(IntentSource.MODEL, source)
            assertEquals(TaskStatus.FAILED, status)
            assertTrue(device.clicked.isEmpty())
        }
    }

    @Test
    fun `model failure falls back safely to the rule parser`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 500, "crash")
            val (parser, _) = modelParser(s)
            val parsed = parser.parseWithSource("افتح الكاميرا")
            assertEquals(IntentSource.RULES, parsed.source, "rules handle this before the model is needed")
            val unknown = parser.parseWithSource("شيء غامض جداً")
            assertEquals(IntentSource.NONE, unknown.source)
        }
    }

    @Test
    fun `slow model is cut off by the parser timeout and the rules still answer`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("""{"intent":"scroll","direction":"down"}"""), delayMs = 1_500)
            val (parser, _) = modelParser(s, timeoutMs = 200)
            // Not understood by the rules, so the model is consulted and times out.
            val parsed = parser.parseWithSource("ما هو الطقس اليوم")
            assertEquals(IntentSource.NONE, parsed.source)
        }
    }

    @Test
    fun `model unreachable falls back and never blocks the rules`() = runBlocking<Unit> {
        val port = FakeModelServer().use { it.port }
        val reg = ProviderRegistry()
        val provider = ModelIntentProvider(reg.get(ProviderType.OLLAMA), ConnectionSpec("http://127.0.0.1:$port", 500), "m")
        val parser = LayeredIntentParser(ai = provider)
        assertEquals(IntentSource.RULES, parser.parseWithSource("احسب 2 + 3").source)
        assertEquals(IntentSource.NONE, parser.parseWithSource("ماذا تفعل الآن").source)
    }

    @Test
    fun `without any model the assistant works exactly as before`() = runBlocking<Unit> {
        val parser = LayeredIntentParser(RuleBasedIntentParser(), NoAiProvider)
        val device = FakeCalculatorDevice()
        val (source, status) = run(parser, device, "افتح تطبيق الآلة الحاسبة واحسب 125 × 8")
        assertEquals(IntentSource.RULES, source)
        assertEquals(TaskStatus.SUCCESS, status)
    }

    @Test
    fun `active provider from the settings is the one that parses commands`() = runBlocking<Unit> {
        FakeModelServer().use { s ->
            s.fixed("GET", "/api/tags", 200, Replies.OLLAMA_TAGS)
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"))
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"))
            val reg = ProviderRegistry()
            val store = object : AiSettingsStore {
                var v: StoredAiSettings? = null
                override fun read() = v
                override fun write(settings: StoredAiSettings?) {
                    v = settings
                }
            }
            val controller = AiSettingsController(store, reg, ConnectionTester(reg), InferenceTester(reg), ModelCatalog(reg))
            controller.saveConfig(ProviderType.OLLAMA, s.baseUrl, "llama3")
            controller.testInference()
            controller.enable()

            val delegating: AiProvider = DelegatingAiProvider { controller.activeIntentProvider() }
            val parser = LayeredIntentParser(ai = delegating)
            s.route("POST", "/api/chat") { _ ->
                FakeModelServer.Reply(200, Replies.ollamaChat("""{"intent":"navigate","target":"home"}"""))
            }
            val parsed = parser.parseWithSource("اذهب للبيت بعيداً عن هذا كله")
            assertEquals(IntentSource.MODEL, parsed.source)
            assertIs<com.venex.core.model.NavigateGoal>(parsed.goal)

            controller.disable()
            assertIs<UnknownGoal>(parser.parse("اذهب للبيت بعيداً عن هذا كله"))
        }
    }

    @Test
    fun `calculator goal from the model still goes through the planner with the expected value`() {
        val goal = CalculateGoal(java.math.BigDecimal("125"), com.venex.core.model.MathOp.MULTIPLY, java.math.BigDecimal("8"), "x")
        assertEquals(0, java.math.BigDecimal("1000").compareTo(goal.expected()!!))
        assertTrue(TaskPlanner().plan(goal).steps.isNotEmpty())
    }
}
