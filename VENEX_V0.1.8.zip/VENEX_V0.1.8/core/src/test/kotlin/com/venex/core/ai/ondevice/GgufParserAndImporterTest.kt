package com.venex.core.ai.ondevice

import com.venex.core.ai.FailureKind
import com.venex.core.ai.ProviderResult
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.test.runTest
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

class GgufParserTest {
    private fun parse(b: ByteArray) = GgufParser.parse(ByteArrayInputStream(b))

    @Test
    fun `valid header is summarised and big arrays are skipped`() {
        val r = assertIs<GgufParseResult.Ok>(parse(GgufBuilder.valid().build()))
        assertEquals("llama", r.summary.architecture)
        assertEquals("tiny-test", r.summary.name)
        assertEquals(15, r.summary.fileType)
        assertEquals("Q4_K_M", r.summary.quantization)
        assertEquals(4096L, r.summary.trainedContextLength)
        assertEquals(3, r.summary.version)
        assertEquals(10L, r.summary.tensorCount)
    }

    @Test
    fun `wrong magic is rejected with a clear reason`() {
        val r = assertIs<GgufParseResult.Invalid>(parse(GgufBuilder.valid().build(magic = "GGML".toByteArray())))
        assertTrue(r.reason.contains("GGUF"))
    }

    @Test
    fun `a text or random file is not a model`() {
        assertIs<GgufParseResult.Invalid>(parse("hello, this is not a model at all".toByteArray()))
        assertIs<GgufParseResult.Invalid>(parse(ByteArray(0)))
    }

    @Test
    fun `unsupported version is rejected`() {
        assertIs<GgufParseResult.Invalid>(parse(GgufBuilder.valid().build(version = 1)))
        assertIs<GgufParseResult.Invalid>(parse(GgufBuilder.valid().build(version = 99)))
    }

    @Test
    fun `truncated header is reported as truncated, not as a crash`() {
        val full = GgufBuilder.valid().build()
        for (cut in listOf(3, 10, 20, full.size / 2, full.size - 1)) {
            val r = assertIs<GgufParseResult.Invalid>(parse(full.copyOf(cut)), "cut=$cut")
            assertTrue(r.reason.isNotBlank())
        }
    }

    @Test
    fun `absurd counts and lengths are refused without allocating`() {
        assertIs<GgufParseResult.Invalid>(parse(GgufBuilder.valid().build(declaredKv = 5_000_000_000L)))
        assertIs<GgufParseResult.Invalid>(parse(GgufBuilder.valid().build(tensors = Long.MAX_VALUE)))
        // A key whose declared length is 2^60.
        val evil = java.nio.ByteBuffer.allocate(8).order(java.nio.ByteOrder.LITTLE_ENDIAN).putLong(1L shl 60).array()
        assertIs<GgufParseResult.Invalid>(parse(GgufBuilder().rawKv(evil).build()))
    }

    @Test
    fun `missing architecture is invalid`() {
        assertIs<GgufParseResult.Invalid>(parse(GgufBuilder().string("general.name", "x").build()))
    }

    @Test
    fun `unknown value type is invalid`() {
        val key = "weird.key".toByteArray()
        val bb = java.nio.ByteBuffer.allocate(8 + key.size + 4).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        bb.putLong(key.size.toLong()).put(key).putInt(77)
        assertIs<GgufParseResult.Invalid>(parse(GgufBuilder.valid().rawKv(bb.array()).build()))
    }

    @Test
    fun `unknown file type code is shown as a code, not guessed`() {
        val r = assertIs<GgufParseResult.Ok>(parse(GgufBuilder.valid(fileType = 4242).build()))
        assertEquals("type 4242", r.summary.quantization)
    }
}

class StreamImporterTest {
    private fun sha(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    @Test
    fun `copy succeeds, reports progress, returns sha256, leaves no part file`() = runTest {
        val dir = tempDir()
        try {
            val data = ByteArray(3_000_000) { (it % 251).toByte() }
            var last = 0L
            val r = StreamImporter.copy(ByteArrayInputStream(data), data.size.toLong(), dir, "m.gguf", { 1L shl 40 }) { c, _ -> last = c }
            val ok = assertIs<ProviderResult.Ok<ImportedModel>>(r)
            assertEquals(data.size.toLong(), ok.value.sizeBytes)
            assertEquals(sha(data), ok.value.sha256)
            assertEquals(data.size.toLong(), last)
            assertTrue(File(dir, "m.gguf").isFile)
            assertFalse(File(dir, "m.gguf.part").exists())
            assertEquals(data.toList(), File(dir, "m.gguf").readBytes().toList())
        } finally { dir.deleteRecursively() }
    }

    @Test
    fun `insufficient free space fails before writing anything`() = runTest {
        val dir = tempDir()
        try {
            val r = StreamImporter.copy(ByteArrayInputStream(ByteArray(10)), 5L shl 30, dir, "m.gguf", { 1L shl 20 }) { _, _ -> }
            assertEquals(FailureKind.NO_SPACE, assertIs<ProviderResult.Err>(r).failure.kind)
            assertEquals(0, dir.listFiles()!!.size)
        } finally { dir.deleteRecursively() }
    }

    @Test
    fun `cancellation mid copy removes the partial file and keeps the old model`() = runTest {
        val dir = tempDir()
        try {
            File(dir, "m.gguf").writeText("previous")
            val gate = CompletableDeferred<Unit>()
            val reading = CompletableDeferred<Unit>()
            val slow = object : InputStream() {
                var n = 0
                override fun read(): Int = throw UnsupportedOperationException()
                override fun read(b: ByteArray): Int {
                    if (n++ == 0) { b.fill(1, 0, 1000); return 1000 }
                    reading.complete(Unit)
                    kotlinx.coroutines.runBlocking { gate.await() }
                    b.fill(1, 0, 1000); return 1000
                }
            }
            val job = async(Dispatchers.Default) { StreamImporter.copy(slow, null, dir, "m.gguf", { 1L shl 40 }) { _, _ -> } }
            reading.await()
            job.cancel()
            gate.complete(Unit)
            job.join()
            assertTrue(job.isCancelled)
            assertFalse(File(dir, "m.gguf.part").exists())
            assertEquals("previous", File(dir, "m.gguf").readText())
        } finally { dir.deleteRecursively() }
    }

    @Test
    fun `size mismatch is an error and nothing is committed`() = runTest {
        val dir = tempDir()
        try {
            val r = StreamImporter.copy(ByteArrayInputStream(ByteArray(100)), 200L, dir, "m.gguf", { 1L shl 40 }) { _, _ -> }
            assertEquals(FailureKind.FILE_ACCESS, assertIs<ProviderResult.Err>(r).failure.kind)
            assertFalse(File(dir, "m.gguf").exists())
            assertFalse(File(dir, "m.gguf.part").exists())
        } finally { dir.deleteRecursively() }
    }

    @Test
    fun `read error mid copy is reported and cleaned up`() = runTest {
        val dir = tempDir()
        try {
            val broken = object : InputStream() {
                var n = 0
                override fun read(): Int = throw IOException()
                override fun read(b: ByteArray): Int { if (n++ == 0) return 10; throw IOException("boom") }
            }
            val r = StreamImporter.copy(broken, null, dir, "m.gguf", { 1L shl 40 }) { _, _ -> }
            assertEquals(FailureKind.FILE_ACCESS, assertIs<ProviderResult.Err>(r).failure.kind)
            assertEquals(0, dir.listFiles()!!.size)
        } finally { dir.deleteRecursively() }
    }

    @Test
    fun `empty source is invalid`() = runTest {
        val dir = tempDir()
        try {
            val r = StreamImporter.copy(ByteArrayInputStream(ByteArray(0)), null, dir, "m.gguf", { 1L shl 40 }) { _, _ -> }
            assertEquals(FailureKind.INVALID_MODEL_FILE, assertIs<ProviderResult.Err>(r).failure.kind)
        } finally { dir.deleteRecursively() }
    }
}

class MemoryGuardTest {
    private val gb = 1L shl 30

    @Test
    fun `plenty of memory passes`() {
        assertEquals(MemoryGuard.Verdict.Ok, MemoryGuard.check(1 * gb, MemorySample(3 * gb, 6 * gb, false)))
    }

    @Test
    fun `clearly too little memory is refused with a number the user can act on`() {
        val v = assertIs<MemoryGuard.Verdict.Refuse>(MemoryGuard.check(4 * gb, MemorySample(1 * gb, 6 * gb, false)))
        assertTrue(v.message.contains("MB"))
    }

    @Test
    fun `unknown memory only warns, low-memory flag only warns`() {
        assertIs<MemoryGuard.Verdict.Warn>(MemoryGuard.check(1 * gb, null))
        assertIs<MemoryGuard.Verdict.Warn>(MemoryGuard.check(1 * gb, MemorySample(3 * gb, 6 * gb, true)))
    }
}

class GgufFileNameTest {
    @Test
    fun `only single gguf files are accepted by name`() {
        assertNull(GgufFileName.problem("qwen2.5-1.5b-instruct-q4_k_m.gguf"))
        assertNull(GgufFileName.problem("Model (1).GGUF"))
        assertTrue(GgufFileName.problem("model.bin")!!.contains(".gguf"))
        assertTrue(GgufFileName.problem("model.gguf.part")!!.contains(".gguf"))
        assertTrue(GgufFileName.problem("big-00001-of-00003.gguf")!!.contains("مجزّأ"))
    }
}
