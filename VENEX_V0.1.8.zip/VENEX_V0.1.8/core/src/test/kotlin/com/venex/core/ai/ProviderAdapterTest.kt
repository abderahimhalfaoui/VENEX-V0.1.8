package com.venex.core.ai

import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertTrue

/** Protocol-level tests of the two adapters, over real sockets. */
class ProviderAdapterTest {

    private val openai = OpenAiCompatibleProvider()
    private val ollama = OllamaProvider()

    private fun spec(server: FakeModelServer, timeoutMs: Int = 3_000, bearer: String? = null) =
        ConnectionSpec(server.baseUrl, timeoutMs, bearer)

    // ---------------- OpenAI-compatible: model list ----------------

    @Test
    fun `openai lists models from v1 models`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, Replies.OPENAI_MODELS)
            val r = openai.listModels(spec(s))
            val ok = okOf(r)
            assertEquals(listOf("qwen2.5-7b-instruct", "llama3"), ok.value.map { it.id })
        }
    }

    @Test
    fun `openai empty model list is a valid answer not an error`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, """{"data":[]}""")
            val ok = okOf(openai.listModels(spec(s)))
            assertTrue(ok.value.isEmpty())
        }
    }

    @Test
    fun `openai base url ending in v1 does not produce v1 v1`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, Replies.OPENAI_MODELS)
            okOf(openai.listModels(ConnectionSpec("${s.baseUrl}/v1", 3_000)))
            assertEquals(1, s.count("GET", "/v1/models"))
        }
    }

    @Test
    fun `bearer token is sent only when provided`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, Replies.OPENAI_MODELS)
            openai.listModels(spec(s, bearer = "tok-123"))
            openai.listModels(spec(s))
            assertEquals("Bearer tok-123", s.requests[0].authorization)
            assertEquals(null, s.requests[1].authorization)
        }
    }

    @Test
    fun `openai 401 is reported as unauthorized`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 401, """{"error":"bad key"}""")
            val err = assertIs<ProviderResult.Err>(openai.listModels(spec(s)))
            assertEquals(FailureKind.UNAUTHORIZED, err.failure.kind)
            assertTrue(!err.failure.message.contains("bad key"), "server error body must not reach the user")
        }
    }

    @Test
    fun `openai 500 is an http error`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 500, "boom")
            assertEquals(FailureKind.HTTP_ERROR, assertIs<ProviderResult.Err>(openai.listModels(spec(s))).failure.kind)
        }
    }

    @Test
    fun `openai html reply is an invalid response`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, "<html>hello</html>")
            assertEquals(FailureKind.INVALID_RESPONSE, assertIs<ProviderResult.Err>(openai.listModels(spec(s))).failure.kind)
        }
    }

    @Test
    fun `slow server triggers timeout`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, Replies.OPENAI_MODELS, delayMs = 1_500)
            val err = assertIs<ProviderResult.Err>(openai.listModels(spec(s, timeoutMs = 300)))
            assertEquals(FailureKind.TIMEOUT, err.failure.kind)
        }
    }

    @Test
    fun `closed port is unreachable`() = runTest {
        val port = FakeModelServer().use { it.port }
        val err = assertIs<ProviderResult.Err>(openai.listModels(ConnectionSpec("http://127.0.0.1:$port", 2_000)))
        assertEquals(FailureKind.UNREACHABLE, err.failure.kind)
    }

    // ---------------- OpenAI-compatible: completion ----------------

    @Test
    fun `openai completion sends the prompt and returns the reply`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/v1/chat/completions", 200, Replies.openAiChat("الجزائر", model = "llama3"))
            val ok = okOf(
                openai.complete(spec(s), "llama3", ChatPrompt("sys", "مرحبا بالعالم"))
            )
            assertEquals("الجزائر", ok.value.text)
            assertEquals("llama3", ok.value.servedModel)
            val sent = s.requests.single()
            assertTrue(sent.body.contains("\"model\":\"llama3\""))
            assertTrue(sent.body.contains("مرحبا بالعالم"), "user text must be sent as UTF-8 JSON")
            assertTrue(sent.body.contains("\"temperature\":0"))
            assertTrue(sent.body.contains("\"stream\":false"))
        }
    }

    @Test
    fun `openai empty content is an empty response`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/v1/chat/completions", 200, Replies.openAiChat("   "))
            assertEquals(FailureKind.EMPTY_RESPONSE, assertIs<ProviderResult.Err>(openai.complete(spec(s), "m", ChatPrompt("s", "u"))).failure.kind)
        }
    }

    @Test
    fun `openai reply without choices is invalid`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/v1/chat/completions", 200, """{"error":{"message":"model overloaded"}}""")
            assertEquals(FailureKind.INVALID_RESPONSE, assertIs<ProviderResult.Err>(openai.complete(spec(s), "m", ChatPrompt("s", "u"))).failure.kind)
        }
    }

    @Test
    fun `openai 404 on chat is reported as model or path not found`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/v1/chat/completions", 404, """{"error":"model not loaded"}""")
            assertEquals(FailureKind.MODEL_NOT_FOUND, assertIs<ProviderResult.Err>(openai.complete(spec(s), "ghost", ChatPrompt("s", "u"))).failure.kind)
        }
    }

    // ---------------- Ollama ----------------

    @Test
    fun `ollama lists models from api tags`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/api/tags", 200, Replies.OLLAMA_TAGS)
            val ok = okOf(ollama.listModels(spec(s)))
            assertEquals(listOf("llama3:latest", "qwen2.5:7b"), ok.value.map { it.id })
        }
    }

    @Test
    fun `server without ollama api is detected as wrong provider`() = runTest {
        FakeModelServer().use { s ->
            // Only an OpenAI-style server is running: /api/tags does not exist.
            s.fixed("GET", "/v1/models", 200, Replies.OPENAI_MODELS)
            assertEquals(FailureKind.WRONG_PROVIDER, assertIs<ProviderResult.Err>(ollama.listModels(spec(s))).failure.kind)
        }
    }

    @Test
    fun `ollama completion uses api chat with stream disabled`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"))
            val ok = okOf(ollama.complete(spec(s), "llama3:latest", ChatPrompt("s", "u", maxTokens = 32)))
            assertEquals("الجزائر", ok.value.text)
            assertEquals("llama3:latest", ok.value.servedModel)
            val sent = s.requests.single()
            assertTrue(sent.body.contains("\"stream\":false"))
            assertTrue(sent.body.contains("\"num_predict\":32"))
        }
    }

    @Test
    fun `ollama 404 on chat means the model is not pulled`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 404, """{"error":"model 'x' not found"}""")
            assertEquals(FailureKind.MODEL_NOT_FOUND, assertIs<ProviderResult.Err>(ollama.complete(spec(s), "x", ChatPrompt("s", "u"))).failure.kind)
        }
    }

    @Test
    fun `ollama reply without message is invalid and blank content is empty`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, """{"model":"m","done":true}""")
            assertEquals(FailureKind.INVALID_RESPONSE, assertIs<ProviderResult.Err>(ollama.complete(spec(s), "m", ChatPrompt("s", "u"))).failure.kind)
        }
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat(""))
            assertEquals(FailureKind.EMPTY_RESPONSE, assertIs<ProviderResult.Err>(ollama.complete(spec(s), "m", ChatPrompt("s", "u"))).failure.kind)
        }
    }

    // ---------------- Registry and endpoint rules ----------------

    @Test
    fun `registry returns the adapter for each type and can be replaced`() {
        val reg = ProviderRegistry()
        assertEquals(ProviderType.OLLAMA, reg.get(ProviderType.OLLAMA).type)
        assertEquals(ProviderType.OPENAI_COMPATIBLE, reg.get(ProviderType.OPENAI_COMPATIBLE).type)
    }

    @Test
    fun `endpoint rules accept http and https and normalize the trailing slash`() {
        val ok = assertIs<EndpointRules.Result.Ok>(EndpointRules.validate("  http://127.0.0.1:11434/  "))
        assertEquals("http://127.0.0.1:11434", ok.endpoint.baseUrl)
        assertTrue(ok.endpoint.loopbackOnly)
        assertTrue(ok.endpoint.warnings.isEmpty())
        assertIs<EndpointRules.Result.Ok>(EndpointRules.validate("https://pc.local:8443"))
    }

    @Test
    fun `endpoint rules reject bad schemes credentials queries and empty input`() {
        assertIs<EndpointRules.Result.Rejected>(EndpointRules.validate(""))
        assertIs<EndpointRules.Result.Rejected>(EndpointRules.validate("ftp://127.0.0.1"))
        assertIs<EndpointRules.Result.Rejected>(EndpointRules.validate("127.0.0.1:11434"))
        assertIs<EndpointRules.Result.Rejected>(EndpointRules.validate("http://user:secret@127.0.0.1:11434"))
        assertIs<EndpointRules.Result.Rejected>(EndpointRules.validate("http://127.0.0.1:11434?key=abc"))
        assertIs<EndpointRules.Result.Rejected>(EndpointRules.validate("http://127.0.0.1:99999"))
    }

    @Test
    fun `lan address gets security warnings and is not treated as loopback`() {
        val ok = assertIs<EndpointRules.Result.Ok>(EndpointRules.validate("http://192.168.1.20:11434"))
        assertTrue(!ok.endpoint.loopbackOnly)
        assertEquals(2, ok.endpoint.warnings.size)
    }

    @Test
    fun `json reply is parsed and secret-free errors never echo the body`() {
        val err = assertIs<ProviderResult.Err>(Http.invalid<Any>("x"))
        assertEquals("x", err.failure.message)
    }
}

/** Typed access to an Ok result; reified checks cannot take generic arguments directly. */
@Suppress("UNCHECKED_CAST")
internal fun <T> okOf(r: ProviderResult<T>): ProviderResult.Ok<T> =
    assertIs<ProviderResult.Ok<*>>(r) as ProviderResult.Ok<T>
