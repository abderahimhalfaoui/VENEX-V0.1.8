package com.venex.core.ai

import com.venex.core.intent.AiInterpretation
import java.math.BigDecimal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

class MiniJsonTest {

    @Test
    fun `parses nested objects arrays escapes and numbers as BigDecimal`() {
        val v = MiniJson.parse("""{"a":[1,2.5,-3e2],"b":{"c":"x\"y\nا"},"t":true,"n":null}""") as Map<*, *>
        assertEquals(listOf(BigDecimal("1"), BigDecimal("2.5"), BigDecimal("-3e2")), v["a"])
        assertEquals("x\"y\nا", (v["b"] as Map<*, *>)["c"])
        assertEquals(true, v["t"])
        assertNull(v["n"])
    }

    @Test
    fun `rejects malformed input`() {
        for (bad in listOf("{", "{\"a\":}", "[1,]", "{\"a\" 1}", "tru", "01x", "\"unterminated", "{} trailing")) {
            assertFailsWith<MiniJson.JsonException>(bad) { MiniJson.parse(bad) }
        }
    }

    @Test
    fun `rejects control characters and runaway nesting`() {
        assertFailsWith<MiniJson.JsonException> { MiniJson.parse("\"a\u0001b\"") }
        assertFailsWith<MiniJson.JsonException> { MiniJson.parse("[".repeat(40) + "]".repeat(40)) }
    }

    @Test
    fun `firstObject finds the object inside prose and code fences`() {
        val text = "Sure! Here it is:\n```json\n{\"intent\":\"scroll\",\"direction\":\"up\"}\n```\nThanks"
        assertEquals("scroll", MiniJson.firstObject(text)!!["intent"])
    }

    @Test
    fun `firstObject skips broken braces and returns the first valid object`() {
        assertEquals("ok", MiniJson.firstObject("{broken} then {\"x\":\"ok\"}")!!["x"])
        assertNull(MiniJson.firstObject("no json here"))
    }

    @Test
    fun `encode produces parseable json for unicode and quotes`() {
        val s = MiniJson.encode(mapOf("q" to "قل \"مرحبا\"\n", "n" to 3))
        val back = MiniJson.parse(s) as Map<*, *>
        assertEquals("قل \"مرحبا\"\n", back["q"])
        assertEquals(BigDecimal("3"), back["n"])
    }
}

class ModelReplyParserTest {

    @Test
    fun `valid open app reply becomes an interpretation`() {
        val r = ModelReplyParser.parse("""{"intent":"open_app","app":"الكاميرا"}""")
        assertEquals(AiInterpretation("open_app", mapOf("app" to "الكاميرا")), r)
    }

    @Test
    fun `reply with prose before and after is accepted`() {
        val r = ModelReplyParser.parse("""Here you go: {"intent":"navigate","target":"back"} hope it helps""")
        assertEquals(AiInterpretation("navigate", mapOf("target" to "back")), r)
    }

    @Test
    fun `calculate accepts numeric strings and numbers and rejects bad operators`() {
        val a = ModelReplyParser.parse("""{"intent":"calculate","left":"125","op":"multiply","right":8}""")
        assertEquals(AiInterpretation("calculate", mapOf("left" to "125", "op" to "multiply", "right" to "8")), a)
        assertNull(ModelReplyParser.parse("""{"intent":"calculate","left":"1","op":"power","right":"2"}"""))
        assertNull(ModelReplyParser.parse("""{"intent":"calculate","left":"1","op":"add"}"""))
    }

    @Test
    fun `negative and absurdly large numbers are refused`() {
        assertNull(ModelReplyParser.parse("""{"intent":"calculate","left":"-5","op":"add","right":"1"}"""))
        assertNull(ModelReplyParser.parse("""{"intent":"calculate","left":"1e999999999","op":"add","right":"1"}"""))
        assertNull(ModelReplyParser.parse("""{"intent":"calculate","left":"99999999999999999","op":"add","right":"1"}"""))
    }

    @Test
    fun `unsupported and unknown intents are refused`() {
        assertNull(ModelReplyParser.parse("""{"intent":"unsupported"}"""))
        assertNull(ModelReplyParser.parse("""{"intent":"delete_all_photos"}"""))
        assertNull(ModelReplyParser.parse("""{"intent":"run_shell","cmd":"rm -rf /"}"""))
    }

    @Test
    fun `invalid json and non-json replies are refused`() {
        assertNull(ModelReplyParser.parse("""{"intent":"open_app","app":"""))
        assertNull(ModelReplyParser.parse("I think you want the camera."))
        assertNull(ModelReplyParser.parse(""))
    }

    @Test
    fun `open app is screened for restricted words even inside the model's own output`() {
        assertNull(ModelReplyParser.parse("""{"intent":"open_app","app":"ارسل الصورة لأحمد"}"""))
        assertNull(ModelReplyParser.parse("""{"intent":"open_app","app":"x"}"""))
        assertNull(ModelReplyParser.parse("""{"intent":"open_app","app":"line\nbreak"}"""))
    }

    @Test
    fun `missing fields are refused`() {
        assertNull(ModelReplyParser.parse("""{"intent":"navigate"}"""))
        assertNull(ModelReplyParser.parse("""{"intent":"scroll","direction":"sideways"}"""))
        assertNull(ModelReplyParser.parse("""{"app":"الكاميرا"}"""))
    }

    @Test
    fun `assertIs is usable on parsed results`() {
        okOf(ProviderResult.Ok(Completion("x", null), 1))
        assertTrue(true)
    }
}
