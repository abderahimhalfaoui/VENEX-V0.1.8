package com.venex.core

import com.venex.core.intent.AiInterpretation
import com.venex.core.ai.ModelOutputSanitizer
import com.venex.core.ai.ModelReplyParser
import com.venex.core.device.AppResolution
import com.venex.core.device.AppResolver
import com.venex.core.device.InstalledApp
import com.venex.core.engine.DenyAllConfirmations
import com.venex.core.engine.ExecutionEngine
import com.venex.core.intent.IntentSource
import com.venex.core.intent.LayeredIntentParser
import com.venex.core.intent.RuleBasedIntentParser
import com.venex.core.model.Action
import com.venex.core.model.Expectation
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.Plan
import com.venex.core.model.SearchInAppGoal
import com.venex.core.model.TaskStatus
import com.venex.core.planner.SearchServices
import com.venex.core.planner.TaskPlanner
import com.venex.core.audit.AuditLog
import kotlinx.coroutines.runBlocking
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * Regression tests for the failures seen in the V0.1.2 phone trial:
 *  - reasoning text ("think") leaking into replies and being parsed or counted as an answer;
 *  - "open YouTube and search for a song" failing because the whole sentence became the app name;
 *  - YouTube not resolved as an installed app.
 */
class RegressionV013Test {

    // ------------------------------------------------------------ reasoning text never counts as an answer

    @Test
    fun `reasoning block is removed and only the visible answer remains`() {
        assertEquals("الجزائر", ModelOutputSanitizer.clean("<think>The user asks about Algeria.</think>الجزائر"))
        assertEquals("الجزائر", ModelOutputSanitizer.clean("<think>\n\n</think>\n\nالجزائر"))
        assertEquals("الجزائر", ModelOutputSanitizer.clean("الجزائر<|im_end|>"))
    }

    @Test
    fun `reasoning that contains the expected word does not produce an answer`() {
        assertEquals("", ModelOutputSanitizer.clean("<think>the capital is الجزائر, Algiers</think>"))
    }

    @Test
    fun `unclosed reasoning block drops everything after it`() {
        assertEquals("", ModelOutputSanitizer.clean("<think>Alg"))
        assertEquals("مرحبا", ModelOutputSanitizer.clean("مرحبا <think>still thinking about"))
    }

    @Test
    fun `reply parser ignores braces inside reasoning and parses the real object`() {
        val reply = "<think>maybe {\"intent\":\"scroll\",\"direction\":\"up\"} or not</think>{\"intent\":\"navigate\",\"target\":\"home\"}"
        assertEquals(AiInterpretation("navigate", mapOf("target" to "home")), ModelReplyParser.parse(reply))
    }

    @Test
    fun `reply that is only reasoning is not an intent`() {
        assertNull(ModelReplyParser.parse("<think>{\"intent\":\"navigate\",\"target\":\"home\"}</think>"))
    }

    // ------------------------------------------------------------ "open X and search Y"

    @Test
    fun `open youtube and search is split into app and query, not one app name`() {
        val parser = RuleBasedIntentParser()
        val g = parser.parseSync("افتح يوتيوب وابحث عن أغنية")
        assertIs<SearchInAppGoal>(g)
        assertEquals("يوتيوب", g.appName)
        assertEquals("أغنية", g.query) // the user's own spelling, not the normalized "اغنيه"
    }

    @Test
    fun `the search text keeps the words as typed`() {
        val parser = RuleBasedIntentParser()
        val en = parser.parseSync("Open YouTube and search for Lofi Music!")
        assertIs<SearchInAppGoal>(en)
        assertEquals("Lofi Music", en.query)
        val ar = parser.parseSync("افتح يوتيوب وابحث عن قرآن كريم من فضلك")
        assertIs<SearchInAppGoal>(ar)
        assertEquals("قرآن كريم", ar.query)
        val q = parser.parseSync("افتح يوتيوب وابحث عن إنشاد؟")
        assertIs<SearchInAppGoal>(q)
        assertEquals("إنشاد", q.query)
        // and that exact text, URL-encoded, is what the plan opens
        val uri = (TaskPlanner().plan(ar).steps.single().action as Action.OpenDeepLink).uri
        assertEquals("https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode("قرآن كريم", "UTF-8"), uri)
    }

    @Test
    fun `english and polite variants are split too`() {
        val parser = RuleBasedIntentParser()
        val g = parser.parseSync("open YouTube and search for lofi music")
        assertIs<SearchInAppGoal>(g)
        assertEquals("youtube", g.appName)
        assertEquals("lofi music", g.query)
        assertIs<SearchInAppGoal>(parser.parseSync("افتح تطبيق يوتيوب و ابحث عن قرآن من فضلك"))
    }

    @Test
    fun `plain open commands are unchanged`() {
        val parser = RuleBasedIntentParser()
        assertEquals(OpenAppGoal("الكاميرا", "افتح الكاميرا"), parser.parseSync("افتح الكاميرا"))
        assertEquals(OpenAppGoal("يوتيوب", "افتح يوتيوب"), parser.parseSync("افتح يوتيوب"))
    }

    @Test
    fun `the search command never reaches the model`() = runBlocking {
        val parser = LayeredIntentParser(RuleBasedIntentParser(), object : com.venex.core.intent.AiProvider {
            override val name = "must-not-be-called"
            override suspend fun interpret(text: String): AiInterpretation? = error("model must not be consulted")
        })
        assertEquals(IntentSource.RULES, parser.parseWithSource("افتح يوتيوب وابحث عن أغنية").source)
    }

    @Test
    fun `youtube is resolved as an installed app for its arabic and english names`() {
        val apps = listOf(
            InstalledApp("YouTube", "com.google.android.youtube"),
            InstalledApp("Camera", "com.android.camera", isSystem = true)
        )
        val r1 = AppResolver(apps).resolve("يوتيوب")
        val r2 = AppResolver(apps).resolve("YouTube")
        assertIs<AppResolution.Found>(r1)
        assertEquals("com.google.android.youtube", r1.app.packageName)
        assertIs<AppResolution.Found>(r2)
    }

    @Test
    fun `search step opens an https results address with the query encoded`() {
        val plan = TaskPlanner().plan(SearchInAppGoal("يوتيوب", "اغنيه", "raw"))
        assertEquals(1, plan.steps.size)
        val step = plan.steps.single()
        val action = assertIs<Action.OpenDeepLink>(step.action)
        assertTrue(action.uri.startsWith("https://www.youtube.com/results?search_query="), action.uri)
        assertTrue(!action.uri.contains(" "), "spaces must be encoded")
        assertEquals(Expectation.ScreenContainsText("اغنيه"), step.expectation)
    }

    @Test
    fun `search in an app without a known address is refused honestly, not faked`() {
        assertNull(SearchServices.forApp("واتساب"))
        val plan: Plan = TaskPlanner().plan(SearchInAppGoal("واتساب", "احمد", "raw"))
        assertTrue(plan.steps.isEmpty())
        assertTrue(plan.blockedReason!!.contains("غير مدعوم"), plan.blockedReason)
    }

    @Test
    fun `search reports success only when the query is visible on screen`() = runBlocking {
        // The step is OpenDeepLink; the verifier decides from the screen, not from the intent having been sent.
        val plan = TaskPlanner().plan(SearchInAppGoal("يوتيوب", "اغنيه", "raw"))
        val device = FakeCalculatorDevice()
        val report = ExecutionEngine(device, AuditLog(), DenyAllConfirmations, settleDelayMs = 0).execute(plan)
        assertEquals(1, device.deepLinks.size)
        // The fake screen does not show the query, so the honest result is NOT a success.
        assertTrue(report.status != TaskStatus.SUCCESS, "must not claim success without evidence: ${report.status}")
    }
}
