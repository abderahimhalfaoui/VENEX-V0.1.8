package com.venex.core.adaptive

import com.venex.core.device.InstalledApp
import com.venex.core.env.Confidence
import com.venex.core.env.EnvironmentObserver
import com.venex.core.env.EnvironmentUnderstandingEngine
import com.venex.core.env.FakeAppDevice
import com.venex.core.env.FakeScreen
import com.venex.core.env.TargetSpec
import com.venex.core.env.TestClock
import com.venex.core.env.tree
import com.venex.core.goal.Interpretation
import com.venex.core.goal.Slot
import com.venex.core.goal.SlotName
import com.venex.core.goal.SlotStatus
import com.venex.core.goal.GoalFamily
import com.venex.core.model.StepStatus
import com.venex.core.model.TaskStatus
import com.venex.core.safety.ActionRiskClassifier
import com.venex.core.safety.ApprovalBinding
import com.venex.core.safety.ApprovalGate
import com.venex.core.safety.ApprovalLedger
import com.venex.core.safety.ApprovalOutcome
import com.venex.core.safety.ApprovalRequests
import com.venex.core.safety.RiskLevel
import com.venex.core.safety.SensitiveCategory
import com.venex.core.verify.Check
import com.venex.core.verify.CheckResult
import com.venex.core.verify.EvidenceInput
import com.venex.core.verify.EvidenceVerdict
import com.venex.core.verify.EvidenceVerifier
import com.venex.core.verify.VerificationCondition
import kotlinx.coroutines.test.runTest
import java.io.File
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** V0.1.8 — category I (Safety) and the approval / evidence rules the mission names as non-negotiable. */
class AdaptiveSafetyTest {

    private fun binding(
        op: String = "POST", goal: String = "g1", content: String? = "نص", app: String? = SOCIAL, account: String? = null,
        target: String? = "t", control: String? = "نشر", data: String = "نص من 2 حرفاً"
    ) = ApprovalBinding(op, goal, ApprovalBinding.digestOf(content), app, account, target, control, data)

    private fun request(b: ApprovalBinding) = com.venex.core.safety.ApprovalRequest(b, "s", emptyList())

    // ---------------------------------------------------------------- approval is bound to the operation

    @Test
    fun changingAnyBoundElementNeedsANewApproval() {
        val ledger = ApprovalLedger(TestClock())
        val base = binding()
        val variants = listOf(
            base.copy(operation = "SEND"), base.copy(goalFingerprint = "g2"), binding(content = "نص آخر"), base.copy(appPackage = CHAT),
            base.copy(account = "other@x"), base.copy(target = "someone else"), base.copy(control = "إرسال"), base.copy(dataSummary = "نص من 9 حرفاً")
        )
        for (v in variants) {
            ledger.grant(base)
            assertFalse(ledger.consume(v), "a grant for one operation must not satisfy another: $v")
            ledger.revokeAll()
        }
        ledger.grant(base)
        assertTrue(ledger.consume(base.copy()), "an identical binding is the same operation")
    }

    @Test
    fun anApprovalIsSingleUseAndExpires() {
        val clock = TestClock()
        val ledger = ApprovalLedger(clock, ttlMs = 1_000)
        ledger.grant(binding())
        assertTrue(ledger.consume(binding()))
        assertFalse(ledger.consume(binding()), "no replay: a second send needs a second approval")
        ledger.grant(binding())
        clock.advance(1_001)
        assertFalse(ledger.consume(binding()), "an old approval is worthless")
    }

    @Test
    fun theGateAsksTheOwnerUnlessAMatchingGrantExists_andNoIsFinal() = runTest {
        var asked = 0
        val ledger = ApprovalLedger(TestClock())
        val gate = ApprovalGate({ asked++; false }, ledger)
        assertEquals(ApprovalOutcome.Denied, gate.authorize(request(binding())))
        assertEquals(1, asked)
        ledger.grant(binding())
        assertIs<ApprovalOutcome.Approved>(gate.authorize(request(binding())))
        assertEquals(1, asked, "a matching unexpired grant is used instead of asking again")
    }

    @Test
    fun theRequestShownToTheOwnerStatesEveryBoundElement_andUnknownsAsUnknown() {
        val r = ApprovalRequests.build(
            setOf(SensitiveCategory.SEND), "fp", "مرحبا", "com.example.chat", "رسائل", null, "أحمد (ظاهر على الشاشة)", "إرسال"
        )
        val text = r.lines.joinToString("\n")
        for (needle in listOf("إرسال", "رسائل", "الحساب: غير معروف", "أحمد", "مرحبا")) assertTrue(text.contains(needle), "missing '$needle' in:\n$text")
        assertNull(r.binding.account)
        assertNotEquals(r.binding.key(), ApprovalRequests.build(setOf(SensitiveCategory.SEND), "fp", "مرحبا!", "com.example.chat", "رسائل", null, "أحمد (ظاهر على الشاشة)", "إرسال").binding.key())
    }

    // ---------------------------------------------------------------- risk is judged by the real control

    @Test
    fun riskFollowsTheRealLabelOfTheControl() {
        fun level(l: String) = ActionRiskClassifier.assessLabel(l).level
        assertEquals(RiskLevel.BLOCKED, level("Pay now"))
        assertEquals(RiskLevel.BLOCKED, level("اشتري الآن"))
        assertEquals(RiskLevel.BLOCKED, level("Place order"))
        assertEquals(RiskLevel.HIGH, level("Send"))
        assertEquals(RiskLevel.HIGH, level("إرسال"))
        assertEquals(RiskLevel.HIGH, level("نشر"))
        assertEquals(RiskLevel.HIGH, level("Delete"))
        assertEquals(RiskLevel.HIGH, level("حذف"))
        // harmless controls stay harmless, including ones that only OPEN an editor
        assertEquals(RiskLevel.LOW, level("Cancel"))
        assertEquals(RiskLevel.LOW, level("Create post"))
        assertEquals(RiskLevel.LOW, level("منشور جديد"))
        assertEquals(RiskLevel.LOW, level("About"))
        assertEquals(RiskLevel.LOW, level("حول"))
        assertEquals(RiskLevel.LOW, level("Settings"))
    }

    @Test
    fun aControlThatLooksLikeAPaymentIsNeverPressed_whateverTheOwnerSaid() = runTest {
        val device = FakeAppDevice(
            apps = listOf(InstalledApp("متجر", "com.example.shop")),
            screens = mutableMapOf(
                "cart" to FakeScreen("com.example.shop", {
                    tree {
                        val r = add(cls = "android.widget.FrameLayout")
                        add(r, text = "Continue — Pay now", cls = "android.widget.Button", clickable = true)
                    }
                }, clicks = mapOf("Continue — Pay now" to { d -> d.vars["charged"] = true })),
            ),
            current = "cart"
        )
        val approvals = RecordingApprovals(true)
        val clock = TestClock()
        val c = AdaptiveCoordinator(device, com.venex.core.audit.AuditLog(clock), approvals, selfPackage = SELF, clock = clock, settleDelayMs = 0)
        val goal = (c.interpret("اضغط على \"Continue\"") as Interpretation.Ready).goal
        val report = c.run(goal)
        assertEquals(TaskStatus.FAILED, report.status)
        assertTrue(report.summary.contains("دفع"))
        assertNull(device.vars["charged"])
        assertEquals(0, device.clicksOf("Continue — Pay now"))
        assertTrue(approvals.requests.isEmpty(), "a blocked operation is not even offered for approval")
    }

    @Test
    fun nothingIsEverTypedIntoAPasswordField() = runTest {
        val fx = Fixtures(startIn = "login")
        val h = Harness(fx)
        val r = h.coordinator.interpret("اكتب \"abc123\"")
        assertIs<Interpretation.Ready>(r)
        val report = h.coordinator.run(r.goal)
        assertTrue(report.status != TaskStatus.SUCCESS)
        assertTrue(fx.device.typed.keys.none { it.contains("password") })
    }

    // ---------------------------------------------------------------- privacy of what the owner wrote

    @Test
    fun theOwnersTextNeverAppearsInTheAuditLog() = runTest {
        val secretText = "نص-سري-للمالك-12345"
        val h = Harness()
        val report = h.coordinator.run((h.coordinator.interpret("افتح شبكة وانشر \"$secretText\"") as Interpretation.Ready).goal)
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        val dump = h.audit.entries().joinToString("\n") { it.message + " " + (it.evidence ?: "") }
        assertFalse(dump.contains(secretText), "the audit log must hold lengths, not content:\n$dump")
        assertTrue(report.steps.none { it.message.contains(secretText) && it.stepId != "submit" }, "step messages carry no content except evidence about the post")
    }

    @Test
    fun aFinishedTaskKeepsNoTextOnDisk() = runTest {
        val file = File.createTempFile("venex-task", ".jsonl").also { it.deleteOnExit() }
        val store = FileTaskStateStore(file)
        val h = Harness(store = store)
        val report = h.coordinator.run((h.coordinator.interpret("افتح شبكة وانشر \"محتوى-لا-يبقى\"") as Interpretation.Ready).goal)
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        val last = file.readLines().last()
        assertFalse(last.contains("محتوى-لا-يبقى"), "the last stored state of a finished task has no content: $last")
        assertTrue(last.contains("\"DONE\""))
    }

    // ---------------------------------------------------------------- a paused task never repeats a sensitive press

    private fun pausedPostState(store: TaskStateStore, mark: StepMark): String {
        val slots = listOf(
            Slot(SlotName.APP, "شبكة", SlotStatus.EXPLICIT), Slot(SlotName.TEXT, "نص معلّق", SlotStatus.EXPLICIT)
        )
        val st = TaskState(
            "t-old", GoalFamily.CREATE_POST, slots, SOCIAL, TaskPhase.PAUSED,
            mapOf("open" to StepMark.DONE, "compose" to StepMark.DONE, "type" to StepMark.DONE, "submit" to mark), null, 1, 2
        )
        store.save(st)
        return st.taskId
    }

    @Test
    fun resumeAfterACrashInTheMiddleOfASend_withNoSignOfIt_asksInsteadOfPressingAgain() = runTest {
        val h = Harness(Fixtures(startIn = "composer"))
        h.fx.device.typed["$SOCIAL:id/compose_body"] = "نص معلّق"
        pausedPostState(h.store, StepMark.SENSITIVE_STARTED)
        val report = h.coordinator.resume()
        assertEquals(TaskStatus.UNVERIFIED, report.status, report.summary)
        assertTrue(report.summary.contains("لن أكرّرها"))
        assertEquals(0, h.fx.device.clicksOf("نشر"))
        assertTrue(h.fx.posts.isEmpty())
        assertTrue(h.approvals.requests.isEmpty())
    }

    @Test
    fun resumeAfterACrashInTheMiddleOfASend_whenThePostIsVisible_confirmsWithoutPressing() = runTest {
        val h = Harness(Fixtures(posts = mutableListOf("نص معلّق"), startIn = "feed"))
        pausedPostState(h.store, StepMark.SENSITIVE_STARTED)
        val report = h.coordinator.resume()
        assertEquals(0, h.fx.device.clicksOf("نشر"))
        assertEquals(1, h.fx.posts.size, "not posted a second time")
        assertTrue(report.steps.any { it.stepId == "submit" && it.status != StepStatus.FAILED })
        assertTrue(h.approvals.requests.isEmpty())
    }

    @Test
    fun anOldApprovalCannotBeReusedByALaterTask() = runTest {
        val approvals = RecordingApprovals(true)
        val h = Harness(Fixtures(startIn = "composer"), approvals)
        val g = (h.coordinator.interpret("انشر \"أول\"") as Interpretation.Ready).goal
        assertEquals(TaskStatus.SUCCESS, h.coordinator.run(g).status)
        h.fx.device.goto("composer")
        val g2 = (h.coordinator.interpret("انشر \"أول\"") as Interpretation.Ready).goal
        assertEquals(TaskStatus.SUCCESS, h.coordinator.run(g2).status)
        assertEquals(2, approvals.requests.size, "the same words a second time are a second operation and are asked again")
        assertEquals(2, h.fx.posts.size)
    }

    // ---------------------------------------------------------------- evidence rules

    private fun modelOf(device: FakeAppDevice) = kotlinx.coroutines.runBlocking {
        val clock = TestClock()
        EnvironmentUnderstandingEngine(EnvironmentObserver(device, clock), clock).refresh().model
    }

    @Test
    fun absenceIsNotEvidenceWhileTheScreenIsADialog() {
        val fx = Fixtures(startIn = "confirm")
        val m = modelOf(fx.device)
        val spec = TargetSpec("فاتورة", labels = listOf("فاتورة"))
        val r = EvidenceVerifier.verify(
            listOf(Check(VerificationCondition.ElementAbsent(spec, asOutcome = true))),
            EvidenceInput(true, true, null, m, null, true, NOTES)
        )
        assertEquals(CheckResult.UNKNOWN, r.evidence.single().result)
        assertTrue(r.verdict != EvidenceVerdict.VERIFIED)
    }

    @Test
    fun absenceOnAnOrdinaryScreenIsEvidence() {
        val fx = Fixtures(notes = mutableListOf("قائمة"), startIn = "notes")
        val m = modelOf(fx.device)
        val spec = TargetSpec("فاتورة", labels = listOf("فاتورة"))
        val r = EvidenceVerifier.verify(
            listOf(Check(VerificationCondition.ElementAbsent(spec, asOutcome = true))),
            EvidenceInput(true, true, null, m, null, true, NOTES)
        )
        assertEquals(EvidenceVerdict.VERIFIED, r.verdict)
    }

    @Test
    fun aClickThatDidNothingIsNotEvidence() {
        val fx = Fixtures(startIn = "notes")
        val m = modelOf(fx.device)
        val r = EvidenceVerifier.verify(
            listOf(Check(VerificationCondition.StateChanged)),
            EvidenceInput(commandSent = true, actionExecuted = true, before = m, after = m, diff = com.venex.core.env.ScreenDiffer.diff(m, m), stable = true, launchedPackage = NOTES)
        )
        assertTrue(r.verdict == EvidenceVerdict.FAILED || r.verdict == EvidenceVerdict.UNVERIFIED)
        assertTrue(Confidence.HIGH.rank > Confidence.LOW.rank)
    }
}
