package com.venex.core

import com.venex.core.audit.AuditLevel
import com.venex.core.audit.AuditLog
import com.venex.core.audit.AuditSink
import com.venex.core.device.Channel
import com.venex.core.device.ChannelRouter
import com.venex.core.device.ScreenSnapshot
import com.venex.core.device.SelectorMatcher
import com.venex.core.device.Route
import com.venex.core.device.UiNode
import com.venex.core.model.Action
import com.venex.core.model.Expectation
import com.venex.core.model.RestrictedCategory
import com.venex.core.model.RestrictedGoal
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.Selector
import com.venex.core.safety.SafetyDecision
import com.venex.core.safety.SafetyPolicy
import com.venex.core.verify.Verification
import com.venex.core.verify.VerificationContext
import com.venex.core.verify.Verifier
import java.math.BigDecimal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

class VerifierSafetyTest {

    private val ctx = VerificationContext("com.fake.calculator")

    // ---- Verifier ----

    @Test
    fun `parseNumber handles separators arabic digits and signs`() {
        assertEquals(BigDecimal("1000"), Verifier.parseNumber("1,000"))
        assertEquals(BigDecimal("1000"), Verifier.parseNumber("= ١٠٠٠"))
        assertEquals(BigDecimal("-5"), Verifier.parseNumber("\u22125"))
        assertEquals(BigDecimal("2.5"), Verifier.parseNumber("2.5"))
        assertNull(Verifier.parseNumber("125×8"))
        assertNull(Verifier.parseNumber("abc"))
        assertNull(Verifier.parseNumber(""))
    }

    @Test
    fun `null snapshot is unverifiable never verified`() {
        val v = Verifier.verify(Expectation.OpenedAppInForeground, null, ctx)
        assertIs<Verification.Unverifiable>(v)
    }

    @Test
    fun `foreground check passes and fails correctly`() {
        val ok = Verifier.verify(Expectation.OpenedAppInForeground, ScreenSnapshot("com.fake.calculator", emptyList()), ctx)
        assertIs<Verification.Verified>(ok)
        val bad = Verifier.verify(Expectation.OpenedAppInForeground, ScreenSnapshot("com.other", emptyList()), ctx)
        assertIs<Verification.Failed>(bad)
        val unknown = Verifier.verify(Expectation.OpenedAppInForeground, ScreenSnapshot("com.other", emptyList()), VerificationContext())
        assertIs<Verification.Unverifiable>(unknown)
    }

    private fun calcExpectation(expected: String, vararg operands: String) =
        Expectation.CalculatorShows(BigDecimal(expected), operands.map(::BigDecimal))

    @Test
    fun `calculator result via identifiable node is verified`() {
        val s = ScreenSnapshot("c", listOf(UiNode(text = "1,000", viewId = "x:id/result_final")))
        assertIs<Verification.Verified>(Verifier.verify(calcExpectation("1000", "125", "8"), s, ctx))
    }

    @Test
    fun `non-terminating results match at displayed precision`() {
        val s = ScreenSnapshot("c", listOf(UiNode(text = "0.33333333", viewId = "x:id/result")))
        assertIs<Verification.Verified>(Verifier.verify(calcExpectation("0.3333333333333333", "1", "3"), s, ctx))
        val wrong = ScreenSnapshot("c", listOf(UiNode(text = "0.34", viewId = "x:id/result")))
        assertIs<Verification.Failed>(Verifier.verify(calcExpectation("0.3333333333333333", "1", "3"), wrong, ctx))
    }

    @Test
    fun `wrong number is a failure`() {
        val s = ScreenSnapshot("c", listOf(UiNode(text = "999", viewId = "x:id/result")))
        assertIs<Verification.Failed>(Verifier.verify(calcExpectation("1000", "125", "8"), s, ctx))
    }

    @Test
    fun `a clickable key is not accepted as the displayed result`() {
        // Expected 8 and the screen only has the "8" key: must NOT verify.
        val s = ScreenSnapshot("c", listOf(UiNode(text = "8", clickable = true)))
        assertIs<Verification.Failed>(Verifier.verify(calcExpectation("8", "2", "4"), s, ctx))
        // A non-clickable display showing 8 is accepted (anonymous id, expected differs from operands).
        val display = ScreenSnapshot("c", listOf(UiNode(text = "8", clickable = false)))
        assertIs<Verification.Verified>(Verifier.verify(calcExpectation("8", "2", "4"), display, ctx))
    }

    @Test
    fun `screen text expectation`() {
        val s = ScreenSnapshot("c", listOf(UiNode(text = "مرحبا بك")))
        assertIs<Verification.Verified>(Verifier.verify(Expectation.ScreenContainsText("مرحبا"), s, ctx))
        assertIs<Verification.Failed>(Verifier.verify(Expectation.ScreenContainsText("وداعا"), s, ctx))
    }

    // ---- SafetyPolicy ----

    @Test
    fun `restricted goals are denied and normal goals allowed`() {
        assertIs<SafetyDecision.Deny>(SafetyPolicy.checkGoal(RestrictedGoal(RestrictedCategory.DELETE, "احذف")))
        assertIs<SafetyDecision.Allow>(SafetyPolicy.checkGoal(OpenAppGoal("x", "x")))
    }

    @Test
    fun `captcha screens are detected in arabic and english`() {
        val en = ScreenSnapshot("c", listOf(UiNode(text = "Please complete the reCAPTCHA")))
        val ar = ScreenSnapshot("c", listOf(UiNode(text = "أثبت أنك لست روبوت")))
        val clean = ScreenSnapshot("c", listOf(UiNode(text = "Hello")))
        assertIs<SafetyDecision.Deny>(SafetyPolicy.checkScreen(en))
        assertIs<SafetyDecision.Deny>(SafetyPolicy.checkScreen(ar))
        assertIs<SafetyDecision.Allow>(SafetyPolicy.checkScreen(clean))
        assertIs<SafetyDecision.Allow>(SafetyPolicy.checkScreen(null))
    }

    @Test
    fun `password fields and unsafe link schemes are denied`() {
        val pw = UiNode(editable = true, password = true)
        val plain = UiNode(editable = true)
        assertIs<SafetyDecision.Deny>(SafetyPolicy.checkAction(Action.TypeText(null, "x"), pw))
        assertIs<SafetyDecision.Allow>(SafetyPolicy.checkAction(Action.TypeText(null, "x"), plain))
        for (bad in listOf("javascript:alert(1)", "file:///etc/passwd", "content://x", "intent://x#Intent;end", "no-scheme")) {
            assertIs<SafetyDecision.Deny>(SafetyPolicy.checkAction(Action.OpenDeepLink(bad), null), bad)
        }
        for (good in listOf("https://a.b", "http://a.b", "geo:0,0", "mailto:a@b.c")) {
            assertIs<SafetyDecision.Allow>(SafetyPolicy.checkAction(Action.OpenDeepLink(good), null), good)
        }
    }

    // ---- ChannelRouter ----

    @Test
    fun `router picks official channels first and requires accessibility for ui actions`() {
        val none = emptySet<Channel>()
        val intentOnly = setOf(Channel.INTENT)
        val all = setOf(Channel.INTENT, Channel.DEEP_LINK, Channel.ACCESSIBILITY)

        assertEquals(Route.Use(Channel.INTENT), ChannelRouter.route(Action.OpenApp("x"), intentOnly))
        assertEquals(Route.Use(Channel.DEEP_LINK), ChannelRouter.route(Action.OpenDeepLink("https://a.b"), all))
        assertIs<Route.Unavailable>(ChannelRouter.route(Action.Click(Selector(listOf("a"))), intentOnly))
        assertEquals(Route.Use(Channel.ACCESSIBILITY), ChannelRouter.route(Action.Click(Selector(listOf("a"))), all))
        assertIs<Route.Unavailable>(ChannelRouter.route(Action.OpenApp("x"), none))
        // Vision is never selected in V0.1 even if advertised.
        assertIs<Route.Unavailable>(ChannelRouter.route(Action.ReadScreen, setOf(Channel.VISION)))
    }

    // ---- SelectorMatcher ----

    @Test
    fun `selector matches exactly not by substring`() {
        val s = Selector(listOf("5"))
        assertTrue(SelectorMatcher.matches(UiNode(text = "5"), s))
        assertTrue(SelectorMatcher.matches(UiNode(contentDescription = " 5 "), s))
        assertTrue(!SelectorMatcher.matches(UiNode(text = "125"), s))
        assertTrue(!SelectorMatcher.matches(UiNode(text = "15"), s))
    }

    @Test
    fun `dash variants and case are normalized and clickable nodes preferred`() {
        val minus = Selector(listOf("-"))
        assertTrue(SelectorMatcher.matches(UiNode(text = "\u2212"), minus))
        assertTrue(SelectorMatcher.matches(UiNode(text = "X"), Selector(listOf("x"))))

        val nodes = listOf(UiNode(text = "=", clickable = false), UiNode(text = "=", clickable = true))
        val best = SelectorMatcher.findBest(nodes, Selector(listOf("=")))
        assertTrue(best!!.clickable)
        assertNull(SelectorMatcher.findBest(nodes, Selector(listOf("?"))))
    }

    @Test
    fun `selector requires labels or id`() {
        assertFailsWith<IllegalArgumentException> { Selector() }
        assertTrue(SelectorMatcher.matches(UiNode(viewId = "a:id/btn_equals"), Selector(idContains = "equals")))
    }

    // ---- AuditLog ----

    @Test
    fun `audit entries are recorded in order and serialized as valid jsonl`() {
        var t = 0L
        val log = AuditLog(clock = { ++t })
        log.record(AuditLevel.INFO, "a \"quoted\"\nline", stepId = "s1", evidence = "e\\x")
        log.record(AuditLevel.ERROR, "b")
        val e = log.entries()
        assertEquals(listOf(1L, 2L), e.map { it.timestampMillis })
        val line = e[0].toJsonLine()
        assertEquals("{\"t\":1,\"level\":\"INFO\",\"step\":\"s1\",\"msg\":\"a \\\"quoted\\\"\\nline\",\"evidence\":\"e\\\\x\"}", line)
        assertEquals("{\"t\":2,\"level\":\"ERROR\",\"step\":null,\"msg\":\"b\",\"evidence\":null}", e[1].toJsonLine())
    }

    @Test
    fun `failing sink does not break logging`() {
        val received = mutableListOf<String>()
        val log = AuditLog(sinks = listOf(AuditSink { error("disk full") }, AuditSink { received += it.message }))
        log.record(AuditLevel.INFO, "still works")
        assertEquals(listOf("still works"), received)
        assertEquals(1, log.entries().size)
    }
}
