package com.venex.core.adaptive

import com.venex.core.env.TestClock
import com.venex.core.goal.GoalFamily
import com.venex.core.goal.Interpretation
import com.venex.core.goal.Slot
import com.venex.core.goal.SlotName
import com.venex.core.goal.SlotStatus
import com.venex.core.memory.ExperienceMemory
import com.venex.core.memory.FileKnowledgeStore
import com.venex.core.memory.InMemoryKnowledgeStore
import com.venex.core.memory.SecretGuard
import com.venex.core.model.TaskStatus
import kotlinx.coroutines.test.runTest
import java.io.File
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** V0.1.8 — category H (Memory) and the persistence of task state. */
class MemoryAndStateTest {

    private val day = 24L * 60 * 60 * 1000

    // ---------------------------------------------------------------- memory: one success is not proof

    @Test
    fun aLabelIsOfferedOnlyAfterRepeatedVerifiedSuccess() {
        val m = ExperienceMemory(clock = TestClock())
        assertTrue(m.recordSuccess(SOCIAL, Roles.COMPOSE, "منشور جديد"))
        assertTrue(m.labelsFor(SOCIAL, Roles.COMPOSE).isEmpty(), "a single success is not proof")
        m.recordSuccess(SOCIAL, Roles.COMPOSE, "منشور جديد")
        assertEquals(listOf("منشور جديد"), m.labelsFor(SOCIAL, Roles.COMPOSE))
        assertTrue(m.labelsFor(CHAT, Roles.COMPOSE).isEmpty(), "what was learned in one app is not assumed in another")
        assertTrue(m.labelsFor(SOCIAL, Roles.SUBMIT_POST).isEmpty())
    }

    @Test
    fun failuresErodeAndRemoveWhatWasLearned() {
        val m = ExperienceMemory(clock = TestClock())
        repeat(3) { m.recordSuccess(SOCIAL, Roles.COMPOSE, "جديد") }
        assertEquals(1, m.labelsFor(SOCIAL, Roles.COMPOSE).size)
        m.recordFailure(SOCIAL, Roles.COMPOSE, "جديد")
        assertEquals(1, m.labelsFor(SOCIAL, Roles.COMPOSE).size, "3 successes - 1 failure = 2 net: still enough")
        m.recordFailure(SOCIAL, Roles.COMPOSE, "جديد")
        assertTrue(m.labelsFor(SOCIAL, Roles.COMPOSE).isEmpty(), "net 1 is below the threshold: no longer offered")
        assertEquals(1, m.entries().size, "but it is kept until failures catch up with successes")
        m.recordFailure(SOCIAL, Roles.COMPOSE, "جديد")
        assertTrue(m.entries().isEmpty(), "failures caught up with successes: the entry is removed")
    }

    @Test
    fun entriesExpire() {
        val clock = TestClock()
        val m = ExperienceMemory(clock = clock, ttlMs = 10 * day)
        repeat(2) { m.recordSuccess(SOCIAL, Roles.COMPOSE, "جديد") }
        assertEquals(1, m.labelsFor(SOCIAL, Roles.COMPOSE).size)
        clock.advance(11 * day)
        assertTrue(m.labelsFor(SOCIAL, Roles.COMPOSE).isEmpty(), "stale knowledge is not used")
        assertEquals(1, m.expire())
        assertTrue(m.entries().isEmpty())
    }

    @Test
    fun theOwnerCanForgetAnAppAnEntryOrEverything() {
        val m = ExperienceMemory(clock = TestClock())
        repeat(2) { m.recordSuccess(SOCIAL, Roles.COMPOSE, "جديد"); m.recordSuccess(CHAT, Roles.SEND_BUTTON, "إرسال") }
        assertEquals(1, m.forget(SOCIAL))
        assertEquals(1, m.entries().size)
        assertTrue(m.forgetEntry(CHAT, Roles.SEND_BUTTON, "إرسال"))
        repeat(2) { m.recordSuccess(SOCIAL, Roles.COMPOSE, "جديد") }
        assertEquals(1, m.forget())
        assertTrue(m.entries().isEmpty())
        assertTrue(m.describe().contains("لا أحتفظ"))
    }

    // ---------------------------------------------------------------- memory never holds secrets

    @Test
    fun secretsAreRefused() {
        val m = ExperienceMemory(clock = TestClock())
        for (s in listOf("كلمة المرور", "Password", "api key", "sk-abcdefghijklmnopqrstuvwx", "me@example.com", "https://x.y/z?token=1", "123456789012", "eyJhbGciOiJIUzI1NiJ9", "a".repeat(41), "")) {
            assertTrue(SecretGuard.looksSecret(s), "should refuse: '$s'")
            assertFalse(m.recordSuccess(SOCIAL, Roles.COMPOSE, s))
        }
        for (s in listOf("نشر", "Post", "منشور جديد", "Send message")) assertFalse(SecretGuard.looksSecret(s), "ordinary control name refused: $s")
        assertTrue(m.entries().isEmpty())
    }

    @Test
    fun memoryNeverLearnsFromFieldsOrFromWhatTheOwnerTyped() = runTest {
        val mem = ExperienceMemory(InMemoryKnowledgeStore(), TestClock())
        val h = Harness(memory = mem)
        repeat(2) {
            h.fx.device.goto("launcher")
            val r = h.coordinator.run((h.coordinator.interpret("افتح شبكة وانشر \"نص-خاص-جداً\"") as Interpretation.Ready).goal)
            assertEquals(TaskStatus.SUCCESS, r.status, r.summary)
        }
        val labels = mem.entries().map { it.label }
        assertTrue(labels.isNotEmpty(), "button names were learned")
        assertTrue(labels.none { it.contains("نص-خاص-جداً") }, "typed text must never be stored: $labels")
        assertTrue(mem.entries().none { it.role == Roles.COMPOSER_FIELD || it.role == Roles.MESSAGE_FIELD || it.role == Roles.SEARCH_FIELD }, "fields are never learned")
        assertTrue(mem.entries().any { it.role == Roles.COMPOSE && it.label == "منشور جديد" && it.successes == 2 })
    }

    @Test
    fun aRememberedLabelIsOnlyAHint_theLiveScreenStillDecides() = runTest {
        val mem = ExperienceMemory(InMemoryKnowledgeStore(), TestClock())
        repeat(2) { mem.recordSuccess(CHAT, Roles.COMPOSE, "زر-وهمي") }
        val h = Harness(Fixtures(startIn = "contacts"), memory = mem)
        val goal = (h.coordinator.interpret("انشر \"س\"") as Interpretation.Ready).goal
        val plan = h.coordinator.plan(goal)
        val compose = plan.steps.first { it.id == "compose" }
        assertTrue((compose.intent as StepIntent.Tap).target.labels.contains("زر-وهمي"), "the hint is passed to the plan")
        val report = h.coordinator.run(goal)
        assertTrue(report.status != TaskStatus.SUCCESS)
        assertTrue(h.fx.device.log.none { it.startsWith("click:") }, "nothing is pressed just because memory says so: ${h.fx.device.log}")
        assertTrue(mem.labelsFor(CHAT, Roles.COMPOSE).isEmpty(), "a hint that failed on the live screen loses its standing")
    }

    @Test
    fun theKnowledgeFileSurvivesAndIgnoresCorruptLines() {
        val f = File.createTempFile("venex-mem", ".jsonl").also { it.deleteOnExit() }
        val m1 = ExperienceMemory(FileKnowledgeStore(f), TestClock())
        repeat(2) { m1.recordSuccess(SOCIAL, Roles.SUBMIT_POST, "نشر") }
        f.appendText("this is not json\n{\"p\":1}\n")
        val m2 = ExperienceMemory(FileKnowledgeStore(f), TestClock())
        assertEquals(listOf("نشر"), m2.labelsFor(SOCIAL, Roles.SUBMIT_POST))
        assertEquals(1, m2.entries().size)
    }

    // ---------------------------------------------------------------- task state

    private fun state(phase: TaskPhase = TaskPhase.PAUSED, text: String? = "نص المنشور", id: String = "t1") = TaskState(
        id, GoalFamily.CREATE_POST,
        listOf(Slot(SlotName.APP, "شبكة", SlotStatus.EXPLICIT), Slot(SlotName.TEXT, text, if (text == null) SlotStatus.MISSING else SlotStatus.EXPLICIT, "ملاحظة \"بعلامات\" و\\ شرطة")),
        SOCIAL, phase, mapOf("open" to StepMark.DONE, "submit" to StepMark.SENSITIVE_STARTED), "ملاحظة", 10, 20
    )

    @Test
    fun taskStateRoundTripsThroughJson() {
        val s = state()
        assertEquals(s, TaskState.fromJson(s.toJson()))
    }

    @Test
    fun aFinishedTaskIsStoredWithoutItsText() {
        val store = InMemoryTaskStateStore()
        store.save(state(TaskPhase.DONE))
        assertNull(store.load("t1")!!.slots.first { it.name == SlotName.TEXT }.value)
        assertNull(store.latestResumable())
        store.save(state(TaskPhase.WAITING_OWNER, id = "t2"))
        assertNotNull(store.latestResumable())
        assertEquals("t2", store.latestResumable()!!.taskId)
    }

    @Test
    fun theFileStoreKeepsTheLatestStateSkipsGarbageAndDeletes() {
        val f = File.createTempFile("venex-state", ".jsonl").also { it.deleteOnExit() }
        val store = FileTaskStateStore(f)
        store.save(state(TaskPhase.RUNNING))
        store.save(state(TaskPhase.PAUSED))
        f.appendText("garbage line\n" + "x".repeat(20_000) + "\n")
        assertEquals(TaskPhase.PAUSED, store.load("t1")!!.phase, "the last line for a task wins")
        assertEquals("t1", store.latestResumable()!!.taskId)
        store.delete("t1")
        assertNull(store.load("t1"))
    }

    @Test
    fun aTaskWhoseTextWasNotKeptCannotBeResumed() = runTest {
        val h = Harness(Fixtures(startIn = "composer"))
        // text slot EXPLICIT but its value gone (purged): there is nothing to type, so the task must not be offered
        val purged = state(TaskPhase.PAUSED).let { st -> st.copy(slots = st.slots.map { if (it.name == SlotName.TEXT) it.copy(value = null) else it }) }
        assertFalse(purged.resumable)
        h.store.save(purged)
        assertNull(h.store.latestResumable(), "a task that lost its text is not offered for resumption")
        val r = h.coordinator.resume()
        assertEquals(TaskStatus.NOT_EXECUTED, r.status)
        assertTrue(h.fx.device.log.none { it.startsWith("click:") || it.startsWith("type:") })
    }

    @Test
    fun resumeWordsAreRecognisedOnlyAsShortCommands() {
        val h = Harness()
        for (ok in listOf("استأنف", "تابع", "واصل المهمة", "resume", "Continue", "كمل من فضلك")) assertTrue(h.coordinator.isResumeCommand(ok), ok)
        for (no in listOf("تابع الأخبار على يوتيوب", "continue reading the book", "افتح الكاميرا", "")) assertFalse(h.coordinator.isResumeCommand(no), no)
    }

    @Test
    fun pauseHoldsTheTaskBetweenStepsAndCancelEndsIt() = runTest {
        val fx = Fixtures(startIn = "feed")
        val h = Harness(fx)
        val goal = (h.coordinator.interpret("انشر \"س\"") as Interpretation.Ready).goal
        // pause is requested before the task starts its first step boundary; cancel then ends it with no side effects
        val control = TaskControl()
        control.pause()
        assertTrue(control.paused)
        control.cancel()
        assertFalse(control.checkpoint())
        assertTrue(fx.posts.isEmpty())
        assertNotNull(goal)
    }
}
