package com.venex.core.ai.ondevice

import com.venex.core.ai.ChatPrompt
import com.venex.core.ai.Completion
import com.venex.core.ai.FailureKind
import com.venex.core.ai.ProviderFailure
import com.venex.core.ai.ProviderResult
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CoroutineScope
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger

/** Builds GGUF bytes for tests. Only the header and key/value section; tensors are not needed. */
class GgufBuilder {
    private val out = ByteArrayOutputStream()
    private val kvs = ArrayList<ByteArray>()

    private fun le(n: Int, v: Long): ByteArray = ByteBuffer.allocate(n).order(ByteOrder.LITTLE_ENDIAN).also {
        when (n) { 1 -> it.put(v.toByte()); 2 -> it.putShort(v.toShort()); 4 -> it.putInt(v.toInt()); else -> it.putLong(v) }
    }.array()

    private fun str(s: String): ByteArray { val b = s.toByteArray(); return le(8, b.size.toLong()) + b }

    fun string(key: String, v: String) = apply { kvs += str(key) + le(4, 8) + str(v) }
    fun u32(key: String, v: Long) = apply { kvs += str(key) + le(4, 4) + le(4, v) }
    fun u64(key: String, v: Long) = apply { kvs += str(key) + le(4, 10) + le(8, v) }
    fun stringArray(key: String, items: List<String>) = apply {
        kvs += str(key) + le(4, 9) + le(4, 8) + le(8, items.size.toLong()) + items.fold(ByteArray(0)) { a, s -> a + str(s) }
    }
    fun floatArray(key: String, n: Int) = apply { kvs += str(key) + le(4, 9) + le(4, 6) + le(8, n.toLong()) + ByteArray(n * 4) }
    fun rawKv(bytes: ByteArray) = apply { kvs += bytes }

    fun build(version: Int = 3, tensors: Long = 10, declaredKv: Long? = null, magic: ByteArray = "GGUF".toByteArray(), padTo: Int = 0): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(magic); o.write(le(4, version.toLong())); o.write(le(8, tensors)); o.write(le(8, declaredKv ?: kvs.size.toLong()))
        kvs.forEach { o.write(it) }
        val bytes = o.toByteArray()
        return if (padTo > bytes.size) bytes + ByteArray(padTo - bytes.size) else bytes
    }

    companion object {
        fun valid(name: String = "tiny-test", fileType: Long = 15, ctx: Long = 4096) = GgufBuilder()
            .string("general.architecture", "llama").string("general.name", name)
            .u32("general.file_type", fileType).stringArray("tokenizer.ggml.tokens", listOf("a", "b", "حرف"))
            .floatArray("tokenizer.ggml.scores", 3).u32("llama.context_length", ctx)
    }
}

/** A scriptable runtime. Counts concurrent loads so tests can prove two models are never loaded at once. */
class FakeRuntime : LlmRuntime {
    @Volatile var loadResult: ProviderResult<LoadedInfo> = ProviderResult.Ok(
        LoadedInfo("fake llama 1B Q4_K_M", 700_000_000, 1_000_000_000, 4096, 1024, 2), 5
    )
    @Volatile var completeReply: () -> ProviderResult<Completion> = { ProviderResult.Ok(Completion("الجزائر", "fake"), 7) }
    @Volatile var holdLoad: CompletableDeferred<Unit>? = null
    @Volatile var holdComplete: CompletableDeferred<Unit>? = null
    val loadStarted = AtomicInteger(0)
    val concurrentLoads = AtomicInteger(0)
    @Volatile var maxConcurrentLoads = 0
    val loadCalls = AtomicInteger(0)
    val unloadCalls = AtomicInteger(0)
    val completeCalls = AtomicInteger(0)
    val cancelCalls = AtomicInteger(0)
    @Volatile var loadedNow = false
    val prompts = java.util.concurrent.CopyOnWriteArrayList<ChatPrompt>()
    @Volatile var started = CompletableDeferred<Unit>()

    override suspend fun load(path: String, params: RuntimeParams): ProviderResult<LoadedInfo> {
        loadCalls.incrementAndGet(); loadStarted.incrementAndGet()
        val c = concurrentLoads.incrementAndGet()
        if (c > maxConcurrentLoads) maxConcurrentLoads = c
        try {
            started.complete(Unit)
            holdLoad?.await()
            val r = loadResult
            loadedNow = r is ProviderResult.Ok
            return r
        } finally { concurrentLoads.decrementAndGet() }
    }

    override suspend fun complete(prompt: ChatPrompt, timeoutMs: Long): ProviderResult<Completion> {
        completeCalls.incrementAndGet(); prompts += prompt
        started.complete(Unit)
        holdComplete?.await()
        return completeReply()
    }

    override fun cancel() { cancelCalls.incrementAndGet() }
    override suspend fun unload() { unloadCalls.incrementAndGet(); loadedNow = false }
}

class MemoryStore : OnDeviceStore {
    var value: StoredOnDevice? = null
    var writes = 0
    override fun read() = value
    override fun write(settings: StoredOnDevice?) { value = settings; writes++ }
}

/** Real [StreamImporter] + real [GgufParser] over in-memory "documents" and a temp directory. */
class FakeGateway(val dir: File, val sources: MutableMap<String, ByteArray> = HashMap()) : ModelFileGateway {
    @Volatile var freeBytes: Long = 10L shl 30
    @Volatile var memory: MemorySample? = MemorySample(4L shl 30, 6L shl 30, false)
    val deleted = ArrayList<String>()
    @Volatile var failInspect: ProviderFailure? = null

    override suspend fun inspect(uri: String): ProviderResult<InspectedFile> {
        failInspect?.let { return ProviderResult.Err(it) }
        val bytes = sources[uri] ?: return ProviderResult.Err(ProviderFailure(FailureKind.FILE_ACCESS, "لا يمكن فتح الملف"))
        return when (val p = GgufParser.parse(bytes.inputStream())) {
            is GgufParseResult.Invalid -> ProviderResult.Err(ProviderFailure(FailureKind.INVALID_MODEL_FILE, p.reason))
            is GgufParseResult.Ok -> ProviderResult.Ok(InspectedFile(PickedFile(uri, uri.substringAfterLast('/'), bytes.size.toLong()), p.summary), 1)
        }
    }

    override suspend fun import(file: PickedFile, onProgress: (Long, Long) -> Unit): ProviderResult<ImportedModel> {
        val bytes = sources[file.uri] ?: return ProviderResult.Err(ProviderFailure(FailureKind.FILE_ACCESS, "لا يمكن فتح الملف"))
        return StreamImporter.copy(bytes.inputStream(), file.sizeBytes, dir, "model.gguf", { freeBytes }, onProgress)
    }

    override fun resolvePath(imported: ImportedModel): String? {
        val f = File(dir, imported.fileName)
        return if (f.isFile && f.length() == imported.sizeBytes) f.absolutePath else null
    }

    override suspend fun deleteImported(imported: ImportedModel) { deleted += imported.fileName; File(dir, imported.fileName).delete() }
    override fun memory(): MemorySample? = memory
}

fun testScope() = CoroutineScope(SupervisorJob() + Dispatchers.Default)

fun tempDir(): File = File(System.getProperty("java.io.tmpdir"), "venex-ondevice-${System.nanoTime()}").apply { mkdirs() }
