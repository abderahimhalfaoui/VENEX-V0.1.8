package com.venex.core.ai

import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** Connection test and inference test against a real local HTTP server. */
class ConnectionAndInferenceTest {

    private val registry = ProviderRegistry()
    private val connection = ConnectionTester(registry)
    private val inference = InferenceTester(registry)

    @Test
    fun `connection succeeds and confirms the chosen model is listed`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/api/tags", 200, Replies.OLLAMA_TAGS)
            val o = assertIs<ConnectionOutcome.Connected>(
                connection.test(ProviderType.OLLAMA, ConnectionSpec(s.baseUrl, 2_000), "llama3")
            )
            assertEquals(true, o.selectedModelListed)
        }
    }

    @Test
    fun `llama3 matches llama3 latest`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/api/tags", 200, Replies.OLLAMA_TAGS)
            val o = assertIs<ConnectionOutcome.Connected>(connection.test(ProviderType.OLLAMA, ConnectionSpec(s.baseUrl, 2_000), "llama3"))
            assertEquals(true, o.selectedModelListed)
        }
    }

    @Test
    fun `missing model is reported as not listed`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, Replies.OPENAI_MODELS)
            val o = assertIs<ConnectionOutcome.Connected>(
                connection.test(ProviderType.OPENAI_COMPATIBLE, ConnectionSpec(s.baseUrl, 2_000), "not-installed")
            )
            assertEquals(false, o.selectedModelListed)
        }
    }

    @Test
    fun `empty model list leaves the listed-check unknown`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, """{"data":[]}""")
            val o = assertIs<ConnectionOutcome.Connected>(
                connection.test(ProviderType.OPENAI_COMPATIBLE, ConnectionSpec(s.baseUrl, 2_000), "m")
            )
            assertNull(o.selectedModelListed)
            assertTrue(o.models.isEmpty())
        }
    }

    @Test
    fun `connection failure is reported as failed`() = runTest {
        val port = FakeModelServer().use { it.port }
        val o = assertIs<ConnectionOutcome.Failed>(
            connection.test(ProviderType.OLLAMA, ConnectionSpec("http://127.0.0.1:$port", 1_000), "m")
        )
        assertEquals(FailureKind.UNREACHABLE, o.failure.kind)
    }

    @Test
    fun `inference passes only when the answer contains the expected fact`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"))
            val o = assertIs<InferenceOutcome.Passed>(inference.test(ProviderType.OLLAMA, ConnectionSpec(s.baseUrl, 2_000), "llama3:latest"))
            assertEquals("الجزائر", o.answer)
            assertTrue(s.requests.single().body.contains(InferenceTester.PROBE_QUESTION))
        }
    }

    @Test
    fun `english answer also passes`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/v1/chat/completions", 200, Replies.openAiChat("Algiers."))
            assertIs<InferenceOutcome.Passed>(inference.test(ProviderType.OPENAI_COMPATIBLE, ConnectionSpec(s.baseUrl, 2_000), "m"))
        }
    }

    @Test
    fun `wrong answer is an unexpected answer and never a pass`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("باريس"))
            assertIs<InferenceOutcome.UnexpectedAnswer>(inference.test(ProviderType.OLLAMA, ConnectionSpec(s.baseUrl, 2_000), "m"))
        }
    }

    @Test
    fun `empty reply fails inference`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat(" "))
            val o = assertIs<InferenceOutcome.Failed>(inference.test(ProviderType.OLLAMA, ConnectionSpec(s.baseUrl, 2_000), "m"))
            assertEquals(FailureKind.EMPTY_RESPONSE, o.failure.kind)
        }
    }

    @Test
    fun `slow model fails inference by timeout`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"), delayMs = 1_500)
            val o = assertIs<InferenceOutcome.Failed>(inference.test(ProviderType.OLLAMA, ConnectionSpec(s.baseUrl, 300), "m"))
            assertEquals(FailureKind.TIMEOUT, o.failure.kind)
        }
    }

    @Test
    fun `http 500 during inference fails`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 500, "crashed")
            val o = assertIs<InferenceOutcome.Failed>(inference.test(ProviderType.OLLAMA, ConnectionSpec(s.baseUrl, 2_000), "m"))
            assertEquals(FailureKind.HTTP_ERROR, o.failure.kind)
        }
    }
}

/** The settings state machine, with a real server and an in-memory store. */
class AiSettingsControllerTest {

    private class MemoryStore(var value: StoredAiSettings? = null) : AiSettingsStore {
        override fun read(): StoredAiSettings? = value
        override fun write(settings: StoredAiSettings?) {
            value = settings
        }
    }

    private fun controller(store: AiSettingsStore, audit: MutableList<String> = mutableListOf()): AiSettingsController {
        val reg = ProviderRegistry()
        return AiSettingsController(store, reg, ConnectionTester(reg), InferenceTester(reg), ModelCatalog(reg)) { audit += it }
    }

    @Test
    fun `fresh install has no model and VENEX works without AI`() {
        val c = controller(MemoryStore())
        assertEquals(AiStage.NO_MODEL_CONFIGURED, c.state.value.stage)
        assertNull(c.activeIntentProvider())
    }

    @Test
    fun `invalid addresses are rejected and nothing is saved`() {
        val store = MemoryStore()
        val c = controller(store)
        assertIs<SaveResult.Rejected>(c.saveConfig(ProviderType.OLLAMA, "ftp://x", "m"))
        assertIs<SaveResult.Rejected>(c.saveConfig(ProviderType.OLLAMA, "http://127.0.0.1:11434", "  "))
        assertNull(store.value)
    }

    @Test
    fun `full lifecycle connection then inference then enable then use`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/api/tags", 200, Replies.OLLAMA_TAGS)
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"))
            val store = MemoryStore()
            val c = controller(store)

            assertIs<SaveResult.Saved>(c.saveConfig(ProviderType.OLLAMA, s.baseUrl, "llama3"))
            assertEquals(AiStage.CONFIGURED, c.state.value.stage)
            assertTrue(c.enable() != null, "enabling before a passed inference test must be refused")

            assertTrue(c.testConnection().contains("لم يتم اختبار استدلال النموذج"))
            assertEquals(AiStage.CONNECTION_OK, c.state.value.stage)
            assertTrue(c.enable() != null)

            assertTrue(c.testInference().contains("نجح اختبار الاستدلال"))
            assertEquals(AiStage.INFERENCE_OK, c.state.value.stage)
            assertNull(c.enable())
            assertEquals(AiStage.ENABLED, c.state.value.stage)
            assertTrue(c.state.value.enabled)
            assertTrue(c.activeIntentProvider() != null, "an enabled, verified model must be used by the parser")

            assertEquals(AiStage.ENABLED, controller(store).state.value.stage, "enabled state survives a restart")
        }
    }

    @Test
    fun `changing the model name disables it and clears verification`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"))
            val c = controller(MemoryStore())
            c.saveConfig(ProviderType.OLLAMA, s.baseUrl, "llama3")
            c.testInference()
            assertNull(c.enable())

            c.saveConfig(ProviderType.OLLAMA, s.baseUrl, "qwen2.5:7b")
            assertFalse(c.state.value.enabled)
            assertEquals(AiStage.CONFIGURED, c.state.value.stage)
            assertNull(c.activeIntentProvider())
        }
    }

    @Test
    fun `model absent from the server is shown as unavailable`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/api/tags", 200, Replies.OLLAMA_TAGS)
            val c = controller(MemoryStore())
            c.saveConfig(ProviderType.OLLAMA, s.baseUrl, "phi-not-pulled")
            c.testConnection()
            assertEquals(AiStage.MODEL_UNAVAILABLE, c.state.value.stage)
        }
    }

    @Test
    fun `failed inference cannot be enabled and shows the error`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 404, """{"error":"not found"}""")
            val c = controller(MemoryStore())
            c.saveConfig(ProviderType.OLLAMA, s.baseUrl, "ghost")
            val msg = c.testInference()
            assertTrue(msg.startsWith("فشل اختبار الاستدلال"), msg)
            assertEquals(AiStage.MODEL_UNAVAILABLE, c.state.value.stage)
            assertTrue(c.enable() != null)
        }
    }

    @Test
    fun `unexpected answer is not a pass`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("لا أعرف"))
            val c = controller(MemoryStore())
            c.saveConfig(ProviderType.OLLAMA, s.baseUrl, "m")
            c.testInference()
            assertEquals(AiStage.INFERENCE_FAILED, c.state.value.stage)
            assertTrue(c.enable() != null)
        }
    }

    @Test
    fun `disable keeps the configuration and VENEX falls back to rules`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"))
            val store = MemoryStore()
            val c = controller(store)
            c.saveConfig(ProviderType.OLLAMA, s.baseUrl, "m")
            c.testInference()
            c.enable()
            c.disable()
            assertNull(c.activeIntentProvider())
            assertEquals(AiStage.INFERENCE_OK, c.state.value.stage)
            assertTrue(store.value!!.config != null, "disable must not erase the setup")
        }
    }

    @Test
    fun `disconnect drops the session token and clear erases everything`() {
        val store = MemoryStore()
        val c = controller(store)
        c.saveConfig(ProviderType.OPENAI_COMPATIBLE, "http://127.0.0.1:8080", "m")
        c.setSessionBearer("super-secret-token")
        c.disconnect()
        assertEquals(AiStage.DISCONNECTED, c.state.value.stage)
        assertFalse(c.state.value.toString().contains("super-secret-token"))
        assertTrue(store.value!!.config != null)

        c.clearSettings()
        assertEquals(AiStage.NO_MODEL_CONFIGURED, c.state.value.stage)
        assertNull(store.value!!.config)
    }

    @Test
    fun `stored settings never contain the session token`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("GET", "/v1/models", 200, Replies.OPENAI_MODELS)
            val store = MemoryStore()
            val c = controller(store)
            c.saveConfig(ProviderType.OPENAI_COMPATIBLE, s.baseUrl, "llama3")
            c.setSessionBearer("tok-very-secret")
            c.testConnection()
            assertFalse(store.value.toString().contains("tok-very-secret"))
            assertEquals("Bearer tok-very-secret", s.requests.last().authorization, "token is still used for requests")
        }
    }

    @Test
    fun `a loaded enabled setup without a matching verification is repaired to not enabled`() {
        val cfg = LocalModelConfig(ProviderType.OLLAMA, "http://127.0.0.1:11434", "m")
        val repaired = AiSettingsController.normalize(StoredAiSettings(cfg, enabled = true, verifiedFingerprint = null, stage = AiStage.ENABLED))
        assertFalse(repaired.enabled)
        assertEquals(AiStage.CONFIGURED, repaired.stage)
    }

    @Test
    fun `runtime failure is shown without changing the enabled state`() = runTest {
        FakeModelServer().use { s ->
            s.fixed("POST", "/api/chat", 200, Replies.ollamaChat("الجزائر"))
            val c = controller(MemoryStore())
            c.saveConfig(ProviderType.OLLAMA, s.baseUrl, "m")
            c.testInference()
            c.enable()
            c.reportRuntimeFailure(ProviderFailure(FailureKind.TIMEOUT, "انتهت المهلة"))
            assertTrue(c.state.value.enabled)
            assertTrue(c.state.value.errorMessage!!.contains("انتهت المهلة"))
        }
    }
}
