package com.venex.core.adaptive

import com.venex.core.audit.AuditLog
import com.venex.core.device.InstalledApp
import com.venex.core.env.FakeAppDevice
import com.venex.core.env.FakeScreen
import com.venex.core.env.TestClock
import com.venex.core.env.tree
import com.venex.core.memory.ExperienceMemory
import com.venex.core.safety.ApprovalHandler
import com.venex.core.safety.ApprovalRequest

const val SOCIAL = "com.example.social"
const val CHAT = "com.example.chat"
const val NOTES = "com.example.notes"
const val SELF = "com.venex.app"

val FIXTURE_APPS = listOf(
    InstalledApp("شبكة", SOCIAL), InstalledApp("رسائل", CHAT), InstalledApp("المفكرة", NOTES)
)

/** Answers every approval the same way and remembers what it was asked. The owner, in a test. */
class RecordingApprovals(var answer: Boolean = true) : ApprovalHandler {
    val requests = mutableListOf<ApprovalRequest>()
    override suspend fun request(request: ApprovalRequest): Boolean {
        requests += request
        return answer
    }
}

/**
 * Generic fake applications. They only use ordinary widgets, labels and ids (nothing here is known to VENEX): the
 * same code that would run against any app has to find "the new-post button" and "the Post button" by itself.
 *
 *  - Social app: a feed with a "new post" button, a composer, a "Post" button that appears enabled only with text.
 *  - Chat app: a contact list, a conversation with a message field and a "Send" button.
 *  - Notes app: a list, an item page with "Delete", and a confirmation dialog.
 */
class Fixtures(
    val posts: MutableList<String> = mutableListOf(),
    val messages: MutableList<String> = mutableListOf(),
    val notes: MutableList<String> = mutableListOf("فاتورة", "قائمة"),
    startIn: String = "launcher"
) {
    val device = FakeAppDevice(apps = FIXTURE_APPS, launchScreens = mapOf(SOCIAL to "feed", CHAT to "contacts", NOTES to "notes"))
    var popupOnNextFeed = false
    var captchaOnComposer = false
    var loginWall = false
    var loadingTicks = 0
    var duplicateNewPostButton = false
    var publishFails = false

    init {
        val s = device.screens
        s["launcher"] = FakeScreen("com.android.launcher", { tree { val r = add(cls = "android.widget.FrameLayout"); add(r, text = "شبكة", clickable = true) } })

        // ---- social
        s["feed"] = FakeScreen(SOCIAL, {
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, text = "الخلاصة", cls = "android.widget.TextView")
                posts.forEach { add(r, text = it, cls = "android.widget.TextView") }
                add(r, text = "منشور جديد", cls = "android.widget.Button", clickable = true, id = "$SOCIAL:id/new_post")
                if (duplicateNewPostButton) add(r, text = "منشور جديد", cls = "android.widget.Button", clickable = true, id = "$SOCIAL:id/new_post_2")
            }
        }, clicks = mapOf("منشور جديد" to { d ->
            d.goto(if (loginWall) "login" else if (popupOnNextFeed) "promo" else "composer")
            popupOnNextFeed = false
        }))
        s["promo"] = FakeScreen(SOCIAL, {
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, text = "جرّب الميزة الجديدة", cls = "android.widget.TextView")
                val dlg = add(r, cls = "androidx.appcompat.app.AlertDialog", id = "$SOCIAL:id/parentPanel")
                add(dlg, text = "ليس الآن", cls = "android.widget.Button", clickable = true)
                add(dlg, text = "اشترك الآن", cls = "android.widget.Button", clickable = true)
            }
        }, clicks = mapOf("ليس الآن" to { d -> d.goto("composer") }, "اشترك الآن" to { d -> d.vars["subscribed"] = true; d.goto("composer") }))
        s["composer"] = FakeScreen(SOCIAL, { d ->
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                if (captchaOnComposer) add(r, text = "أثبت أنك لست روبوتاً", cls = "android.widget.TextView")
                val key = "$SOCIAL:id/compose_body"
                val typed = d.typed[key]
                add(r, text = typed ?: "ماذا يدور في ذهنك؟", hint = typed == null, editable = true, cls = "android.widget.EditText", id = key, focused = true)
                add(r, text = "نشر", cls = "android.widget.Button", clickable = true, enabled = !typed.isNullOrBlank(), id = "$SOCIAL:id/post_button")
                add(r, text = "إغلاق", cls = "android.widget.Button", clickable = true)
            }
        }, clicks = mapOf(
            "نشر" to { d ->
                val key = "$SOCIAL:id/compose_body"
                if (publishFails) return@to
                d.typed[key]?.let { posts.add(0, it) }
                d.typed.remove(key)
                d.goto("feed")
            },
            "إغلاق" to { d -> d.goto("feed") }
        ))
        s["login"] = FakeScreen(SOCIAL, {
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, text = "تسجيل الدخول", cls = "android.widget.TextView")
                add(r, text = "البريد", editable = true, cls = "android.widget.EditText", id = "$SOCIAL:id/email")
                add(r, text = "", editable = true, password = true, cls = "android.widget.EditText", id = "$SOCIAL:id/login_password")
                add(r, text = "دخول", cls = "android.widget.Button", clickable = true)
            }
        })

        // ---- chat
        s["contacts"] = FakeScreen(CHAT, {
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, text = "أحمد", cls = "android.widget.TextView", clickable = true)
                add(r, text = "سارة", cls = "android.widget.TextView", clickable = true)
            }
        }, clicks = mapOf("أحمد" to { d -> d.vars["with"] = "أحمد"; d.goto("conv") }, "سارة" to { d -> d.vars["with"] = "سارة"; d.goto("conv") }))
        s["conv"] = FakeScreen(CHAT, { d ->
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, text = d.vars["with"]?.toString() ?: "؟", cls = "android.widget.TextView", id = "$CHAT:id/header")
                messages.forEach { add(r, text = it, cls = "android.widget.TextView") }
                val key = "$CHAT:id/message_input"
                val typed = d.typed[key]
                add(r, text = typed ?: "اكتب رسالة", hint = typed == null, editable = true, cls = "android.widget.EditText", id = key, focused = true)
                add(r, text = "إرسال", cls = "android.widget.Button", clickable = true, id = "$CHAT:id/send")
            }
        }, clicks = mapOf("إرسال" to { d ->
            val key = "$CHAT:id/message_input"
            d.typed[key]?.let { messages.add(it) }
            d.typed.remove(key)
        }))

        // ---- notes
        s["notes"] = FakeScreen(NOTES, {
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, text = "المفكرة", cls = "android.widget.TextView")
                add(r, cd = "بحث", cls = "android.widget.ImageButton", clickable = true, id = "$NOTES:id/search_icon")
                notes.forEach { n -> add(r, text = n, cls = "android.widget.TextView", clickable = true) }
            }
        }, clicks = notes.associateWith { n -> { d: FakeAppDevice -> d.vars["open"] = n; d.goto("note") } } +
            ("بحث" to { d: FakeAppDevice -> d.goto("search") }))
        s["search"] = FakeScreen(NOTES, { d ->
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                val key = "$NOTES:id/search_input"
                val typed = d.typed[key]
                add(r, text = typed ?: "ابحث في الملاحظات", hint = typed == null, editable = true, cls = "android.widget.EditText", id = key, focused = true)
                add(r, text = "بحث", cls = "android.widget.Button", clickable = true, id = "$NOTES:id/search_go")
            }
        }, clicks = mapOf("بحث" to { d -> d.vars["query"] = d.typed["$NOTES:id/search_input"]; d.goto("results") }))
        s["results"] = FakeScreen(NOTES, { d ->
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, text = "نتائج البحث عن " + (d.vars["query"] ?: ""), cls = "android.widget.TextView")
                notes.filter { n -> n.contains(d.vars["query"]?.toString() ?: "~") }.forEach { n -> add(r, text = n, cls = "android.widget.TextView", clickable = true) }
            }
        })
        s["note"] = FakeScreen(NOTES, { d ->
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, text = d.vars["open"]?.toString() ?: "؟", cls = "android.widget.TextView")
                add(r, text = "حذف", cls = "android.widget.Button", clickable = true, id = "$NOTES:id/delete")
            }
        }, clicks = mapOf("حذف" to { d -> d.goto("confirm") }))
        s["confirm"] = FakeScreen(NOTES, {
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                val dlg = add(r, cls = "androidx.appcompat.app.AlertDialog", id = "$NOTES:id/parentPanel")
                add(dlg, text = "هل تريد الحذف؟", cls = "android.widget.TextView")
                add(dlg, text = "إلغاء", cls = "android.widget.Button", clickable = true)
                add(dlg, text = "حذف", cls = "android.widget.Button", clickable = true, id = "$NOTES:id/button1")
            }
        }, clicks = mapOf(
            "إلغاء" to { d -> d.goto("note") },
            "حذف" to { d -> d.vars["open"]?.toString()?.let { notes.remove(it) }; d.goto("notes") }
        ))
        // The notes screen's click map is built from the initial list; rebuild after deletions by reading `open`.
        device.current = startIn
    }
}

/** A coordinator over a [Fixtures] device with deterministic time. */
class Harness(
    val fx: Fixtures = Fixtures(),
    val approvals: RecordingApprovals = RecordingApprovals(true),
    val store: TaskStateStore = InMemoryTaskStateStore(),
    val memory: ExperienceMemory? = null,
    limits: RunLimits = RunLimits(),
    val clock: TestClock = TestClock()
) {
    val audit = AuditLog(clock)
    val coordinator = AdaptiveCoordinator(
        device = fx.device, audit = audit, approvals = approvals, store = store, memory = memory,
        selfPackage = SELF, limits = limits, clock = clock, settleDelayMs = 0
    )
    init {
        fx.device.clockAdvance = { clock.advance(it) }
    }
}
