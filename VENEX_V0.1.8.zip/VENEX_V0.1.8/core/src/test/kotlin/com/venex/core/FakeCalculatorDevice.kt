package com.venex.core

import com.venex.core.device.ActionResult
import com.venex.core.device.AppResolution
import com.venex.core.device.AppResolver
import com.venex.core.device.Bounds
import com.venex.core.device.Channel
import com.venex.core.device.DeviceController
import com.venex.core.device.InstalledApp
import com.venex.core.device.ScreenSnapshot
import com.venex.core.device.SelectorMatcher
import com.venex.core.device.UiNode
import com.venex.core.model.GlobalKey
import com.venex.core.model.ScrollDirection
import com.venex.core.model.Selector
import java.math.BigDecimal
import java.math.MathContext
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * A tiny simulated device with a working calculator, used to exercise the engine end-to-end on a
 * plain JVM. It records every effect so tests can assert what did (and did not) happen.
 */
class FakeCalculatorDevice(
    var apps: List<InstalledApp> = defaultApps(),
    private val accessibility: Boolean = true,
    private val resultViewId: String = "com.fake.calc:id/result",
    private val corruptEquals: Boolean = false,
    private val captcha: Boolean = false,
    private val missingKeys: Set<String> = emptySet(),
    private val includePasswordField: Boolean = false
) : DeviceController {

    var foreground: String = "com.fake.launcher"
    val launched = mutableListOf<String>()
    val clicked = mutableListOf<String>()
    val typedTexts = mutableListOf<String>()
    val pressed = mutableListOf<GlobalKey>()
    val scrolled = mutableListOf<ScrollDirection>()
    val deepLinks = mutableListOf<String>()

    private var typed = ""
    private var result = ""

    private val keyLabels: List<String> =
        "0123456789".map { it.toString() } + listOf(".", "+", "−", "×", "÷", "=", "C")

    override fun capabilities(): Set<Channel> =
        buildSet {
            add(Channel.INTENT)
            add(Channel.DEEP_LINK)
            if (accessibility) add(Channel.ACCESSIBILITY)
        }

    override suspend fun resolveApp(query: String): AppResolution = AppResolver(apps).resolve(query)

    override suspend fun launchApp(app: InstalledApp): ActionResult {
        launched += app.packageName
        foreground = app.packageName
        return ActionResult.ok("تم إطلاق ${app.label}")
    }

    override suspend fun openDeepLink(uri: String): ActionResult {
        deepLinks += uri
        return ActionResult.ok("تم فتح الرابط")
    }

    override suspend fun snapshot(): ScreenSnapshot? {
        if (!accessibility) return null
        val nodes = ArrayList<UiNode>()
        if (foreground == CALC) {
            nodes += keyNodes()
            nodes += UiNode(text = typed, viewId = "com.fake.calc:id/display")
            if (result.isNotEmpty()) nodes += UiNode(text = result, viewId = resultViewId)
        }
        if (captcha) nodes += UiNode(text = "I'm not a robot")
        if (includePasswordField) nodes += UiNode(className = "EditText", editable = true, password = true)
        return ScreenSnapshot(foreground, nodes)
    }

    private fun keyNodes(): List<UiNode> =
        keyLabels.filter { it !in missingKeys }
            .map { UiNode(text = it, clickable = true, bounds = Bounds(0, 0, 10, 10)) }

    override suspend fun click(selector: Selector): ActionResult {
        if (!accessibility) return ActionResult.fail("Accessibility غير مفعّلة")
        if (foreground != CALC) return ActionResult.fail("الآلة الحاسبة ليست في المقدمة")
        val node = SelectorMatcher.findBest(keyNodes(), selector)
            ?: return ActionResult.fail("لم أجد العنصر «${selector.describe()}»")
        val label = node.text!!
        clicked += label
        when (label) {
            "C" -> {
                typed = ""
                result = ""
            }
            "=" -> evaluate()
            else -> typed += label
        }
        return ActionResult.ok("تم النقر على $label")
    }

    private fun evaluate() {
        val m = Regex("(\\d+(?:\\.\\d+)?)([+−×÷])(\\d+(?:\\.\\d+)?)").matchEntire(typed)
        if (m == null) {
            result = "Error"
            return
        }
        val a = BigDecimal(m.groupValues[1])
        val b = BigDecimal(m.groupValues[3])
        var r = when (m.groupValues[2]) {
            "+" -> a.add(b)
            "−" -> a.subtract(b)
            "×" -> a.multiply(b)
            else -> a.divide(b, MathContext.DECIMAL64)
        }
        if (corruptEquals) r = r.add(BigDecimal.ONE)
        val fmt = DecimalFormat("#,###.################", DecimalFormatSymbols(Locale.US))
        result = fmt.format(r)
    }

    override suspend fun typeText(selector: Selector?, text: String): ActionResult {
        typedTexts += text
        return ActionResult.ok("تم الإدخال")
    }

    override suspend fun scroll(direction: ScrollDirection): ActionResult {
        scrolled += direction
        return ActionResult.ok("تم التمرير")
    }

    override suspend fun press(key: GlobalKey): ActionResult {
        pressed += key
        return ActionResult.ok("تم الضغط على $key")
    }

    companion object {
        const val CALC = "com.fake.calculator"

        fun defaultApps() = listOf(
            InstalledApp("الآلة الحاسبة", CALC, isSystem = true),
            InstalledApp("الكاميرا", "com.fake.camera", isSystem = true)
        )
    }
}
