package com.venex.core

import com.venex.core.device.AppResolution
import com.venex.core.device.AppResolver
import com.venex.core.device.InstalledApp
import com.venex.core.model.Action
import com.venex.core.model.CalculateGoal
import com.venex.core.model.Expectation
import com.venex.core.model.MathOp
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.RestrictedCategory
import com.venex.core.model.RestrictedGoal
import com.venex.core.model.UnknownGoal
import com.venex.core.planner.TaskPlanner
import java.math.BigDecimal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class PlannerAndResolverTest {

    private val planner = TaskPlanner()

    private fun calc(l: String, op: MathOp, r: String) =
        CalculateGoal(BigDecimal(l), op, BigDecimal(r), "raw")

    @Test
    fun `calculator plan is an ordered dependency chain ending with a verified read`() {
        val plan = planner.plan(calc("125", MathOp.MULTIPLY, "8"))
        assertNull(plan.blockedReason)
        assertEquals(
            listOf("open", "clear", "left0", "left1", "left2", "op", "right0", "equals", "read"),
            plan.steps.map { it.id }
        )
        // Each step depends on the one before it.
        plan.steps.drop(1).forEachIndexed { i, s -> assertEquals(listOf(plan.steps[i].id), s.dependsOn) }

        assertEquals(Expectation.OpenedAppInForeground, plan.steps.first().expectation)
        assertTrue(plan.steps.first { it.id == "clear" }.optional)

        val last = plan.steps.last()
        assertIs<Action.ReadScreen>(last.action)
        val exp = last.expectation
        assertIs<Expectation.CalculatorShows>(exp)
        assertEquals(0, BigDecimal("1000").compareTo(exp.expected))
        assertEquals(listOf(BigDecimal("125"), BigDecimal("8")), exp.operands)
    }

    @Test
    fun `decimal numbers use the decimal key`() {
        val plan = planner.plan(calc("2.5", MathOp.ADD, "1"))
        val labels = plan.steps.filter { it.id.startsWith("left") }
            .map { (it.action as Action.Click).selector.labels.first() }
        assertEquals(listOf("2", ".", "5"), labels)
    }

    @Test
    fun `digit selectors include arabic-indic variants`() {
        val s = TaskPlanner.digit('5')
        assertEquals(listOf("5", "٥"), s.labels)
    }

    @Test
    fun `division by zero is blocked without steps`() {
        val plan = planner.plan(calc("5", MathOp.DIVIDE, "0"))
        assertTrue(plan.steps.isEmpty())
        assertNotNull(plan.blockedReason)
    }

    @Test
    fun `negative numbers are refused rather than crashing`() {
        val plan = planner.plan(calc("-5", MathOp.ADD, "1"))
        assertTrue(plan.steps.isEmpty())
        assertNotNull(plan.blockedReason)
    }

    @Test
    fun `restricted and unknown goals produce no steps`() {
        val restricted = planner.plan(RestrictedGoal(RestrictedCategory.PAYMENT, "ادفع"))
        assertTrue(restricted.steps.isEmpty())
        assertNotNull(restricted.blockedReason)

        val unknown = planner.plan(UnknownGoal("؟"))
        assertTrue(unknown.steps.isEmpty())
        assertNotNull(unknown.blockedReason)
    }

    @Test
    fun `open app plan has one verified step`() {
        val plan = planner.plan(OpenAppGoal("الكاميرا", "raw"))
        assertEquals(1, plan.steps.size)
        assertEquals(Expectation.OpenedAppInForeground, plan.steps[0].expectation)
    }

    // ---- AppResolver ----

    private val apps = listOf(
        InstalledApp("Calculator", "com.google.android.calculator", isSystem = false),
        InstalledApp("الكاميرا", "com.fake.camera", isSystem = true),
        InstalledApp("WhatsApp", "com.whatsapp", isSystem = false)
    )

    @Test
    fun `arabic alias resolves english-labelled calculator`() {
        val r = AppResolver(apps).resolve("الآلة الحاسبة")
        assertIs<AppResolution.Found>(r)
        assertEquals("com.google.android.calculator", r.app.packageName)
    }

    @Test
    fun `filler word and exact label`() {
        assertIs<AppResolution.Found>(AppResolver(apps).resolve("تطبيق الكاميرا"))
        assertIs<AppResolution.Found>(AppResolver(apps).resolve("whatsapp"))
    }

    @Test
    fun `unknown app is not found`() {
        assertIs<AppResolution.NotFound>(AppResolver(apps).resolve("تطبيق غير موجود"))
        assertIs<AppResolution.NotFound>(AppResolver(apps).resolve("a"))
    }

    @Test
    fun `two equal calculators are ambiguous unless exactly one is a system app`() {
        val two = listOf(
            InstalledApp("Calculator", "com.google.android.calculator", false),
            InstalledApp("Calculator", "com.miui.calculator", false)
        )
        assertIs<AppResolution.Ambiguous>(AppResolver(two).resolve("الآلة الحاسبة"))

        val withSystem = listOf(two[0], two[1].copy(isSystem = true))
        val r = AppResolver(withSystem).resolve("الآلة الحاسبة")
        assertIs<AppResolution.Found>(r)
        assertEquals("com.miui.calculator", r.app.packageName)

        // An exact label match beats a synonym match.
        val exact = listOf(two[0], InstalledApp("الآلة الحاسبة", "com.miui.calculator", false))
        val e = AppResolver(exact).resolve("الآلة الحاسبة")
        assertIs<AppResolution.Found>(e)
        assertEquals("com.miui.calculator", e.app.packageName)
    }
}
