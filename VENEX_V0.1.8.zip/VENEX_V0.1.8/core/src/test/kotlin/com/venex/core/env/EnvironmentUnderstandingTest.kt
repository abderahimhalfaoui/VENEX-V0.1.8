package com.venex.core.env

import com.venex.core.device.Channel
import com.venex.core.device.UiNode
import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** V0.1.8 — categories A (Environment Discovery) and B (Environment Understanding). */
class EnvironmentUnderstandingTest {

    private fun engine(device: FakeAppDevice, clock: TestClock = TestClock(), labels: (String) -> String? = { null }) =
        EnvironmentUnderstandingEngine(EnvironmentObserver(device, clock), clock, appLabelOf = labels)

    private fun notesHome(items: List<String> = listOf("فاتورة", "قائمة")) = tree {
        val root = add(cls = "android.widget.FrameLayout")
        add(root, text = "المفكرة", cls = "android.widget.TextView", id = "com.example.notes:id/title")
        val list = add(root, cls = "androidx.recyclerview.widget.RecyclerView", scrollable = true, id = "com.example.notes:id/list")
        items.forEach { add(list, text = it, cls = "android.widget.TextView", clickable = true) }
        add(root, cd = "ملاحظة جديدة", cls = "android.widget.ImageButton", clickable = true, id = "com.example.notes:id/fab")
    }

    private fun deviceWith(nodes: () -> List<UiNode>, pkg: String = "com.example.notes") = FakeAppDevice(
        apps = SAMPLE_APPS,
        screens = mutableMapOf("home" to FakeScreen(pkg, { nodes() })),
        current = "home"
    )

    // ---------------------------------------------------------------- A. Environment Discovery

    @Test
    fun discoversActiveAppPackageAndLabel() = runTest {
        val d = deviceWith({ notesHome() })
        val m = engine(d, labels = { if (it == "com.example.notes") "المفكرة" else null }).refresh().model
        assertEquals("com.example.notes", m.packageName)
        assertEquals("المفكرة", m.app?.label)
        assertEquals(Confidence.HIGH, m.app?.confidence)
        assertTrue(m.unknowns.none { it.area == "app.label" })
    }

    @Test
    fun unknownAppLabelIsReportedAsUnknownNotInvented() = runTest {
        val m = engine(deviceWith({ notesHome() })).refresh().model
        assertNull(m.app?.label)
        assertTrue(m.unknowns.any { it.area == "app.label" })
    }

    @Test
    fun discoversCurrentScreenAndItsHierarchy() = runTest {
        val m = engine(deviceWith({ notesHome() })).refresh().model
        val screen = assertNotNull(m.screen)
        assertTrue(screen.hierarchyKnown)
        assertEquals(1, screen.rootIds.size)
        val root = assertNotNull(screen.byId(screen.rootIds.single()))
        assertEquals(3, root.childIds.size) // title, list, fab
        val list = screen.elements.single { it.role == ElementRole.LIST }
        assertEquals(2, screen.children(list.id).size)
        assertEquals(root.id, list.parentId)
        assertEquals(listOf(root.id), screen.ancestors(screen.children(list.id).first().id).map { it.id }.take(1).let { listOf(root.id) })
        assertEquals(2, screen.ancestors(screen.children(list.id).first().id).size) // list, root
    }

    @Test
    fun recognisesButtonsTextsInputsAndInteractableElements() = runTest {
        val nodes = tree {
            val root = add(cls = "android.widget.FrameLayout")
            add(root, text = "عنوان", cls = "android.widget.TextView")
            add(root, text = "بحث…", cls = "android.widget.EditText", editable = true, hint = true, id = "x:id/q")
            add(root, text = "حفظ", cls = "android.widget.Button", clickable = true)
            add(root, text = "تعطيل", cls = "android.widget.Switch", checkable = true, clickable = true)
        }
        val m = engine(deviceWith({ nodes })).refresh().model
        val roles = m.screen!!.elements.map { it.role }
        assertEquals(listOf(ElementRole.CONTAINER, ElementRole.TEXT, ElementRole.INPUT, ElementRole.BUTTON, ElementRole.TOGGLE), roles)
        assertEquals(3, m.screen!!.elements.count { it.interactable })
        val kinds = m.screen!!.actions.map { it.kind }.toSet()
        assertTrue(ActionKind.CLICK in kinds && ActionKind.TYPE_TEXT in kinds && ActionKind.TOGGLE in kinds)
        assertTrue(ActionKind.PRESS_BACK in kinds && ActionKind.READ_SCREEN in kinds)
    }

    @Test
    fun incompleteElementsGetLowConfidenceAndNoSelectorInsteadOfGuesses() = runTest {
        val nodes = tree {
            val root = add(cls = "android.widget.FrameLayout")
            add(root, cls = "android.view.View", clickable = true) // unnamed, no id
            add(root, text = "موافق", cls = "android.widget.Button", clickable = true)
        }
        val m = engine(deviceWith({ nodes })).refresh().model
        val unnamed = m.screen!!.elements[1]
        assertTrue(unnamed.interactable)
        assertNull(unnamed.selector)
        assertEquals(Confidence.LOW, unnamed.confidence)
        assertNotNull(m.screen!!.elements[2].selector)
        assertEquals(Confidence.HIGH, m.screen!!.elements[2].confidence)
    }

    @Test
    fun environmentThatExposesNoElementsIsOpaqueAndSaysWhatIsUnknown() = runTest {
        val m = engine(deviceWith({ emptyList() }, pkg = "com.game")).refresh().model
        assertEquals(UiStateKind.OPAQUE, m.state.kind)
        assertEquals(Confidence.LOW, m.confidence)
        assertTrue(m.hasConstraint(ConstraintKind.OPAQUE_UI))
        assertTrue(m.unknowns.any { it.area == "screen.content" })
        assertEquals("com.game", m.packageName) // the app is still known
    }

    @Test
    fun withoutAccessibilityTheScreenIsUnreadableAndTheSourceIsNeverCalled() = runTest {
        val d = deviceWith({ notesHome() })
        d.caps = setOf(Channel.INTENT, Channel.DEEP_LINK)
        val m = engine(d).refresh().model
        assertNull(m.screen)
        assertEquals(UiStateKind.UNREADABLE, m.state.kind)
        assertEquals(Confidence.NONE, m.confidence)
        assertEquals(0, d.snapshotCalls)
        assertTrue(m.unknowns.any { it.area == "app.identity" })
        assertTrue(m.hasConstraint(ConstraintKind.ACCESS_LIMITED))
        assertTrue(m.state.reason.contains("غير مفعّلة"))
    }

    @Test
    fun noActiveWindowIsReportedWithItsOwnReason() = runTest {
        val d = deviceWith({ notesHome() })
        d.blind = true
        val m = engine(d).refresh().model
        assertNull(m.screen)
        assertTrue(m.state.reason.contains("نافذة"))
    }

    @Test
    fun aFailingDeviceNeverCrashesDiscovery() = runTest {
        val d = deviceWith({ notesHome() })
        d.snapshotThrows = true
        val m = engine(d).refresh().model
        assertNull(m.screen)
        assertTrue(m.state.reason.contains("IllegalStateException"))
    }

    @Test
    fun aFailingExtraSourceIsDroppedAndDoesNotBreakObservation() = runTest {
        val d = deviceWith({ notesHome() })
        val bad = object : ObservationSource {
            override val kind = SourceKind.OFFICIAL_API
            override suspend fun observe(): Observation = throw IllegalStateException("api down")
        }
        val obs = EnvironmentObserver(d, extraSources = listOf(bad))
        val set = obs.observe()
        assertNotNull(set.primary.snapshot)
        assertNull(set.supplements.single().snapshot)
        assertTrue(set.supplements.single().unavailableReason!!.contains("OFFICIAL_API"))
    }

    @Test
    fun sourceInventoryIsHonestAboutWhatDoesNotExist() {
        val all = InformationSources.assess(setOf(Channel.INTENT, Channel.DEEP_LINK, Channel.ACCESSIBILITY)).associateBy { it.kind }
        assertEquals(SourceStatus.AVAILABLE, all[SourceKind.ACCESSIBILITY]!!.status)
        assertTrue(all[SourceKind.ACCESSIBILITY]!!.canObserve)
        assertEquals(SourceStatus.AVAILABLE, all[SourceKind.ANDROID_INTENT]!!.status)
        assertFalse(all[SourceKind.ANDROID_INTENT]!!.canObserve)
        for (k in listOf(SourceKind.OFFICIAL_API, SourceKind.APP_FUNCTION, SourceKind.VISUAL, SourceKind.UI_HIERARCHY)) {
            assertEquals(SourceStatus.NOT_IMPLEMENTED, all[k]!!.status, "$k")
            assertFalse(all[k]!!.canAct)
        }
        val off = InformationSources.assess(setOf(Channel.INTENT)).associateBy { it.kind }
        assertEquals(SourceStatus.UNAVAILABLE_PERMISSION, off[SourceKind.ACCESSIBILITY]!!.status)
        assertEquals(Confidence.NONE, off[SourceKind.ACCESSIBILITY]!!.reliability)
    }

    // ---------------------------------------------------------------- B. Environment Understanding

    @Test
    fun passwordFieldsAreNeverReadNorTypedInAndAreReportedAsConstraint() = runTest {
        val nodes = tree {
            val root = add(cls = "android.widget.FrameLayout")
            add(root, text = "hunter2", cls = "android.widget.EditText", editable = true, password = true, id = "x:id/pw")
            add(root, text = "اسم المستخدم", cls = "android.widget.EditText", editable = true, hint = true, id = "x:id/user")
        }
        val m = engine(deviceWith({ nodes })).refresh().model
        val pw = m.screen!!.inputFields.single { it.password }
        assertNull(pw.currentText)
        assertNull(m.screen!!.elements.single { it.node.password }.label)
        assertTrue(m.screen!!.actions.none { it.kind == ActionKind.TYPE_TEXT && it.elementId == pw.elementId })
        assertTrue(m.hasConstraint(ConstraintKind.PASSWORD_FIELD))
        assertFalse(Describer.describe(m).contains("hunter2"))
        val user = m.screen!!.inputFields.single { !it.password }
        assertNull(user.currentText) // a bare placeholder is not typed content
        assertEquals("اسم المستخدم", user.label)
    }

    @Test
    fun inputFieldReportsTypedTextAndFindsALabelFromANeighbour() = runTest {
        val nodes = tree {
            val root = add(cls = "android.widget.FrameLayout")
            add(root, text = "الاسم", cls = "android.widget.TextView")
            add(root, text = "علي", cls = "android.widget.EditText", editable = true, id = "x:id/f1")
        }
        val f = engine(deviceWith({ nodes })).refresh().model.screen!!.inputFields.single()
        assertEquals("علي", f.currentText)
        assertEquals("الاسم", f.label)
    }

    @Test
    fun elementIdsSurviveTextChangesAndDoNotDependOnCoordinates() = runTest {
        var counter = 1
        var shift = 0
        val d = deviceWith({
            tree {
                val root = add(cls = "android.widget.FrameLayout")
                add(root, text = "العدّاد: $counter", cls = "android.widget.TextView", bounds = com.venex.core.device.Bounds(shift, shift, 100 + shift, 40 + shift))
                add(root, text = "زيادة", cls = "android.widget.Button", clickable = true, bounds = com.venex.core.device.Bounds(shift, 50, 100, 90))
            }
        })
        val e = engine(d)
        val first = e.refresh().model.screen!!
        counter = 2
        shift = 300 // the whole layout moves on screen
        val second = e.refresh()
        assertEquals(first.elements.map { it.id }, second.model.screen!!.elements.map { it.id })
        assertEquals(ChangeKind.CONTENT_CHANGED, second.diff.kind)
        assertEquals(1, second.diff.textChanged.size)
    }

    @Test
    fun diffClassifiesNoChangeContentChangeScreenChangeAndAppChange() = runTest {
        val d = FakeAppDevice(
            screens = mutableMapOf(
                "home" to FakeScreen("com.example.notes", { notesHome() }),
                "home2" to FakeScreen("com.example.notes", { notesHome(listOf("فاتورة", "قائمة", "موعد")) }),
                "editor" to FakeScreen("com.example.notes", {
                    tree {
                        val r = add(cls = "android.widget.LinearLayout")
                        add(r, text = "ملاحظة", cls = "android.widget.EditText", editable = true, id = "x:id/body")
                        add(r, text = "حفظ", cls = "android.widget.Button", clickable = true, id = "x:id/save")
                        add(r, text = "إلغاء", cls = "android.widget.Button", clickable = true, id = "x:id/cancel")
                        add(r, text = "مشاركة", cls = "android.widget.Button", clickable = true, id = "x:id/share")
                    }
                }),
                "other" to FakeScreen("com.other.app", { notesHome() })
            ),
            current = "home"
        )
        val e = engine(d)
        assertEquals(ChangeKind.INITIAL, e.refresh().diff.kind)
        assertEquals(ChangeKind.NONE, e.refresh().diff.kind)
        d.goto("home2")
        assertEquals(ChangeKind.CONTENT_CHANGED, e.refresh().diff.kind) // one list item added: same screen
        d.goto("editor")
        val sc = e.refresh().diff
        assertEquals(ChangeKind.SCREEN_CHANGED, sc.kind)
        assertTrue(sc.appeared.isNotEmpty() && sc.disappeared.isNotEmpty())
        d.goto("other")
        assertEquals(ChangeKind.APP_CHANGED, e.refresh().diff.kind)
    }

    @Test
    fun diffDetectsAPopupAndLossOfAccess() = runTest {
        val d = deviceWith({ notesHome() })
        val e = engine(d)
        e.refresh()
        d.screens["dlg"] = FakeScreen("com.example.notes", {
            tree {
                val r = add(cls = "android.widget.FrameLayout", id = "android:id/parentPanel")
                add(r, text = "حذف الملاحظة؟", cls = "android.widget.TextView", id = "android:id/alertTitle")
                add(r, text = "إلغاء", cls = "android.widget.Button", clickable = true, id = "android:id/button2")
            }
        })
        d.goto("dlg")
        val pop = e.refresh()
        assertEquals(ChangeKind.POPUP_APPEARED, pop.diff.kind)
        assertEquals(UiStateKind.DIALOG, pop.model.state.kind)
        d.blind = true
        val lost = e.refresh()
        assertEquals(ChangeKind.ACCESS_LOST, lost.diff.kind)
        d.blind = false
        assertEquals(ChangeKind.ACCESS_REGAINED, e.refresh().diff.kind)
    }

    @Test
    fun modelIsRebuiltAfterEveryChangeAndOldModelStaysUntouched() = runTest {
        val d = FakeAppDevice(
            screens = mutableMapOf("a" to FakeScreen("p", { tree { add(text = "A", cls = "android.widget.TextView") } }),
                "b" to FakeScreen("p", { tree { add(text = "B", cls = "android.widget.TextView") } })),
            current = "a"
        )
        val e = engine(d)
        val m1 = e.refresh().model
        d.goto("b")
        val m2 = e.refresh().model
        assertEquals(listOf("A"), m1.screen!!.allText())
        assertEquals(listOf("B"), m2.screen!!.allText())
        assertTrue(m2.generation > m1.generation)
        assertEquals(m2, e.current)
        e.invalidate()
        assertNull(e.current)
    }

    @Test
    fun conflictingInformationIsRecordedAndLowersConfidenceNeverSilentlyResolved() = runTest {
        // 1) clickable but disabled
        val nodes = tree {
            val root = add(cls = "android.widget.FrameLayout")
            add(root, text = "إرسال", cls = "android.widget.Button", clickable = true, enabled = false)
            add(root, text = "إلغاء", cls = "android.widget.Button", clickable = true)
        }
        val m = engine(deviceWith({ nodes })).refresh().model
        val c = m.conflicts.single { it.kind == ConflictKind.CLICKABLE_BUT_DISABLED }
        assertEquals(1, c.elementIds.size)
        assertFalse(m.screen!!.elements.single { it.label == "إرسال" }.interactable)
        assertTrue(m.confidence.rank <= Confidence.MEDIUM.rank)

        // 2) two sources disagree about the foreground package
        val d = deviceWith({ notesHome() })
        val intentSource = object : ObservationSource {
            override val kind = SourceKind.ANDROID_INTENT
            override suspend fun observe() = Observation(kind, 1L, null, claimedPackage = "com.example.social")
        }
        val e2 = EnvironmentUnderstandingEngine(EnvironmentObserver(d, extraSources = listOf(intentSource)))
        val m2 = e2.refresh().model
        assertEquals("com.example.notes", m2.packageName) // the screen source is kept ...
        assertTrue(m2.conflicts.any { it.kind == ConflictKind.PACKAGE_DISAGREEMENT }) // ... and the disagreement is visible
        assertTrue(m2.confidence.rank <= Confidence.MEDIUM.rank)

        // 3) an impossible hierarchy (parent after child)
        val broken = listOf(
            UiNode(text = "أ", className = "android.widget.TextView", depth = 1, parentIndex = 1),
            UiNode(text = "ب", className = "android.widget.TextView", depth = 0, parentIndex = -1)
        )
        val m3 = engine(deviceWith({ broken })).refresh().model
        assertTrue(m3.conflicts.any { it.kind == ConflictKind.HIERARCHY_INCONSISTENT })
        assertNull(m3.screen!!.elements[0].parentId)
    }

    @Test
    fun unknownInformationIsRepresentedExplicitly() = runTest {
        val flatNodes = flat(
            UiNode(text = "ا", className = "android.widget.TextView"),
            UiNode(text = "ب", className = "android.widget.Button", clickable = true)
        )
        val m = engine(deviceWith({ flatNodes })).refresh().model
        assertFalse(m.screen!!.hierarchyKnown)
        assertTrue(m.unknowns.any { it.area == "screen.hierarchy" })
        assertTrue(m.hasConstraint(ConstraintKind.NO_HIERARCHY))
        assertTrue(m.unknowns.any { it.area == "visual.content" }) // always: there is no vision in this version
        assertTrue(m.confidence.rank <= Confidence.MEDIUM.rank)

        val many = (0 until EnvironmentModelBuilder.NODE_LIMIT).map { UiNode(text = "n$it", className = "android.widget.TextView") }
        val big = engine(deviceWith({ many })).refresh().model
        assertTrue(big.screen!!.truncated)
        assertTrue(big.unknowns.any { it.area == "screen.completeness" })
    }

    @Test
    fun detectsLoginCaptchaDialogPermissionAndLoadingStates() = runTest {
        fun kindOf(pkg: String, nodes: List<UiNode>) = runTestBlocking { engine(deviceWith({ nodes }, pkg)).refresh().model.state.kind }
        val login = tree {
            val r = add(cls = "android.widget.FrameLayout")
            add(r, text = "تسجيل الدخول", cls = "android.widget.TextView")
            add(r, cls = "android.widget.EditText", editable = true, password = true)
        }
        assertEquals(UiStateKind.LOGIN_REQUIRED, kindOf("com.x", login))
        val captcha = tree { add(text = "أثبت أنك لست روبوتاً", cls = "android.widget.TextView") }
        assertEquals(UiStateKind.CAPTCHA, kindOf("com.x", captcha))
        val perm = tree { add(text = "السماح", cls = "android.widget.Button", clickable = true, id = "com.android.permissioncontroller:id/permission_allow_button") }
        assertEquals(UiStateKind.PERMISSION_PROMPT, kindOf("com.google.android.permissioncontroller", perm))
        val loading = tree { add(cls = "android.widget.ProgressBar") }
        assertEquals(UiStateKind.LOADING, kindOf("com.x", loading))
        val settingsPassword = tree { // a password field WITHOUT any sign-in cue is not a login wall
            val r = add(cls = "android.widget.FrameLayout")
            add(r, text = "كلمة المرور الجديدة", cls = "android.widget.TextView")
            add(r, cls = "android.widget.EditText", editable = true, password = true)
        }
        assertEquals(UiStateKind.NORMAL, kindOf("com.x", settingsPassword))
    }

    private fun <T> runTestBlocking(block: suspend () -> T): T = kotlinx.coroutines.runBlocking { block() }

    @Test
    fun duplicateLabelsAreAddressedOnlyWhereTheMatcherWouldPickThem() = runTest {
        val nodes = tree {
            val r = add(cls = "android.widget.FrameLayout")
            add(r, text = "رد", cls = "android.widget.TextView") // not clickable
            add(r, text = "رد", cls = "android.widget.Button", clickable = true)
            add(r, text = "رد", cls = "android.widget.Button", clickable = true)
        }
        val els = engine(deviceWith({ nodes })).refresh().model.screen!!.elements
        // findBest picks the first clickable+enabled "رد" (index 2): that one is addressable, the others are not.
        assertNull(els[1].selector)
        assertNotNull(els[2].selector)
        assertNull(els[3].selector)
        assertEquals(Confidence.LOW, els[2].confidence) // two clickable twins: still not unambiguous
    }

    @Test
    fun selectorsResolveBackToTheirElementThroughTheExistingMatcher() = runTest {
        val m = engine(deviceWith({ notesHome() })).refresh().model.screen!!
        val nodes = m.elements.map { it.node }
        for (e in m.elements) {
            val sel = e.selector ?: continue
            assertTrue(com.venex.core.device.SelectorMatcher.findBest(nodes, sel) === e.node, "selector of ${e.label ?: e.viewIdShort}")
        }
        assertTrue(m.elements.count { it.selector != null } >= 4)
    }

    @Test
    fun modelFreshnessFollowsTheClock() = runTest {
        val clock = TestClock()
        val e = engine(deviceWith({ notesHome() }), clock)
        val m = e.refresh().model
        assertTrue(e.isFresh(m))
        clock.advance(e.maxAgeMs + 1)
        assertFalse(e.isFresh(m))
        assertEquals(e.maxAgeMs + 1, m.ageMillis(clock()))
    }

    @Test
    fun describeStatesOnlyWhatWasObserved() = runTest {
        val e = engine(deviceWith({ notesHome() }), labels = { "المفكرة" })
        val text = e.describe(e.refresh().model)
        assertTrue(text.contains("المفكرة"))
        assertTrue(text.contains("com.example.notes"))
        assertTrue(text.contains("ملاحظة جديدة"))
        assertTrue(text.contains("مؤقت"))
        val d2 = deviceWith({ notesHome() }); d2.blind = true
        val e2 = engine(d2)
        assertTrue(e2.describe(e2.refresh().model).contains("لا أستطيع رؤية الشاشة"))
    }

    @Test
    fun structuralIdentityIgnoresTextButContentIdentityDoesNot() = runTest {
        var t = "أ"
        val d = deviceWith({ tree { val r = add(cls = "android.widget.FrameLayout"); add(r, text = t, cls = "android.widget.TextView") } })
        val e = engine(d)
        val a = e.refresh().model.screen!!
        t = "ب"
        val b = e.refresh().model.screen!!
        assertEquals(a.screenId, b.screenId)
        assertNotEquals(a.contentId, b.contentId)
        assertIs<ScreenModel>(b)
    }
}
