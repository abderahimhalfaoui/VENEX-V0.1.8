package com.venex.core.ai.ondevice

import com.venex.core.ai.ChatPrompt
import com.venex.core.ai.Completion
import com.venex.core.ai.FailureKind
import com.venex.core.ai.ProviderFailure
import com.venex.core.ai.ProviderResult
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.test.runTest
import java.io.File
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class OnDeviceControllerTest {
    private class Env {
        val dir = tempDir()
        val store = MemoryStore()
        val gateway = FakeGateway(dir)
        val runtime = FakeRuntime()
        val audit = ArrayList<String>()
        val scope = testScope()
        var clock = 0L
        fun controller() = OnDeviceController(store, gateway, runtime, scope, { audit += it }, nanoTime = { clock.also { clock += 3_000_000 } })
        fun addFile(uri: String = "content://downloads/model-a.gguf", bytes: ByteArray = GgufBuilder.valid().build(padTo = 400_000)): String {
            gateway.sources[uri] = bytes; return uri
        }
        fun close() { dir.deleteRecursively() }
    }

    private suspend fun ready(e: Env, c: OnDeviceController, uri: String = e.addFile()) {
        assertTrue(c.selectFile(uri)); assertTrue(c.importSelected())
    }

    @Test
    fun `starts in NOT_SELECTED and is off`() {
        val e = Env()
        val c = e.controller()
        assertEquals(OnDeviceState.NOT_SELECTED, c.state.value.state)
        assertFalse(c.state.value.enabled)
        assertNull(c.activeIntentProvider())
        e.close()
    }

    @Test
    fun `full happy path - select, import, load, test, enable`() = runTest {
        val e = Env(); val c = e.controller()
        assertTrue(c.selectFile(e.addFile()))
        assertEquals(OnDeviceState.FILE_SELECTED, c.state.value.state)
        assertEquals("llama", c.state.value.model!!.gguf.architecture)
        assertTrue(c.importSelected())
        assertEquals(OnDeviceState.READY, c.state.value.state)
        assertNotNull(c.state.value.model!!.imported)
        assertTrue(c.load())
        assertEquals(OnDeviceState.LOADED, c.state.value.state)
        assertNotNull(c.state.value.loadReport)
        assertTrue(c.testInference().startsWith("نجح"))
        assertTrue(c.state.value.verified)
        assertFalse(c.state.value.enabled)
        assertNull(c.enable())
        assertTrue(c.state.value.enabled)
        assertNotNull(c.activeIntentProvider())
        // The original document is untouched.
        assertTrue(e.gateway.sources.containsKey("content://downloads/model-a.gguf"))
        e.close()
    }

    @Test
    fun `cannot enable before a successful inference test`() = runTest {
        val e = Env(); val c = e.controller()
        ready(e, c)
        assertNotNull(c.enable())
        assertTrue(c.load())
        assertNotNull(c.enable(), "loaded but never tested")
        assertFalse(c.state.value.enabled)
        e.close()
    }

    @Test
    fun `a model that answers wrongly or empty is not verified`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        e.runtime.completeReply = { ProviderResult.Ok(Completion("لا أعرف", "x"), 1) }
        assertTrue(c.testInference().contains("لم يجتز"))
        assertFalse(c.state.value.verified)
        assertNotNull(c.enable())
        e.runtime.completeReply = { ProviderResult.Ok(Completion("   ", "x"), 1) }
        c.testInference()
        assertFalse(c.state.value.verified)
        assertEquals(OnDeviceState.LOADED, c.state.value.state)
        e.close()
    }

    @Test
    fun `test failure from the runtime never verifies`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        e.runtime.completeReply = { ProviderResult.Err(ProviderFailure(FailureKind.TIMEOUT, "انتهت المهلة")) }
        assertTrue(c.testInference().contains("فشل"))
        assertFalse(c.state.value.verified)
        assertEquals(OnDeviceState.LOADED, c.state.value.state)
        e.runtime.completeReply = { ProviderResult.Err(ProviderFailure(FailureKind.OUT_OF_MEMORY, "ذاكرة")) }
        c.testInference()
        assertEquals(OnDeviceState.ERROR, c.state.value.state)
        assertTrue(e.runtime.unloadCalls.get() >= 1)
        e.close()
    }

    @Test
    fun `the test really uses the runtime with the Arabic probe`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference()
        assertEquals(1, e.runtime.completeCalls.get())
        assertTrue(e.runtime.prompts[0].user.contains("الجزائر"))
        e.close()
    }

    @Test
    fun `changing context or threads invalidates verification and disables`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference(); assertNull(c.enable())
        assertTrue(c.changeParams(RuntimeParams(2048, 4)))
        assertFalse(c.state.value.verified)
        assertFalse(c.state.value.enabled)
        assertNull(c.activeIntentProvider())
        assertEquals(OnDeviceState.READY, c.state.value.state)
        assertNotNull(c.enable())
        c.testInference(); assertNull(c.enable())
        assertTrue(c.changeParams(RuntimeParams(2048, 2)))
        assertFalse(c.state.value.enabled)
        e.close()
    }

    @Test
    fun `params are clamped to conservative values`() {
        assertEquals(1024, RuntimeParams(100_000, 4).normalized().contextLength)
        assertEquals(8, RuntimeParams(1024, 99).normalized().threads)
        assertEquals(1, RuntimeParams(1024, -3).normalized().threads)
        assertEquals(RuntimeParams(1024, 2), RuntimeParams.forCpuCount(2))
        assertEquals(RuntimeParams(1024, 4), RuntimeParams.forCpuCount(16))
        assertEquals(1024, RuntimeParams().contextLength)
    }

    @Test
    fun `selecting another file replaces the old import and clears verification`() = runTest {
        val e = Env(); val c = e.controller()
        ready(e, c); c.testInference(); c.enable()
        val b = e.addFile("content://downloads/model-b.gguf", GgufBuilder.valid("other").build(padTo = 500_000))
        assertTrue(c.selectFile(b))
        assertEquals(OnDeviceState.FILE_SELECTED, c.state.value.state)
        assertFalse(c.state.value.enabled)
        assertFalse(c.state.value.verified)
        assertEquals(listOf("model.gguf"), e.gateway.deleted)
        assertTrue(e.runtime.unloadCalls.get() >= 1)
        e.close()
    }

    @Test
    fun `invalid file is rejected with a readable error and the old selection is kept`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        val bad = e.addFile("content://downloads/notes.gguf", "plain text pretending to be a model".toByteArray())
        assertFalse(c.selectFile(bad))
        assertTrue(c.state.value.errorMessage!!.contains("GGUF"))
        assertEquals(OnDeviceState.READY, c.state.value.state)
        assertEquals("model-a.gguf", c.state.value.model!!.displayName)
        e.close()
    }

    @Test
    fun `unreadable file reports a file access error`() = runTest {
        val e = Env(); val c = e.controller()
        assertFalse(c.selectFile("content://gone/missing.gguf"))
        assertEquals(OnDeviceState.NOT_SELECTED, c.state.value.state)
        assertNotNull(c.state.value.errorMessage)
        e.close()
    }

    @Test
    fun `import without enough space fails cleanly and can be retried`() = runTest {
        val e = Env(); val c = e.controller()
        c.selectFile(e.addFile())
        e.gateway.freeBytes = 1000
        assertFalse(c.importSelected())
        assertEquals(OnDeviceState.ERROR, c.state.value.state)
        assertEquals(0, e.dir.listFiles()!!.size)
        e.gateway.freeBytes = 10L shl 30
        assertTrue(c.importSelected())
        assertEquals(OnDeviceState.READY, c.state.value.state)
        e.close()
    }

    @Test
    fun `cancelling an import returns to FILE_SELECTED with no partial file`() = runTest {
        val e = Env()
        val gate = CompletableDeferred<Unit>(); val inCopy = CompletableDeferred<Unit>()
        val slowGateway = object : ModelFileGateway by e.gateway {
            override suspend fun import(file: PickedFile, onProgress: (Long, Long) -> Unit): ProviderResult<ImportedModel> {
                inCopy.complete(Unit); gate.await()   // suspended: cancellable
                return e.gateway.import(file, onProgress)
            }
        }
        val c = OnDeviceController(e.store, slowGateway, e.runtime, e.scope)
        c.selectFile(e.addFile())
        val job = async(Dispatchers.Default) { c.importSelected() }
        inCopy.await()
        assertEquals(OnDeviceState.IMPORTING, c.state.value.state)
        c.cancelCurrent()
        runCatching { job.await() }
        assertEquals(OnDeviceState.FILE_SELECTED, c.state.value.state)
        assertEquals(0, e.dir.listFiles()!!.size)
        assertFalse(c.isBusy)
        e.close()
    }

    @Test
    fun `two loads can never overlap - the second request is refused`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        e.runtime.holdLoad = CompletableDeferred()
        val first = async(Dispatchers.Default) { c.load() }
        e.runtime.started.await()
        assertEquals(OnDeviceState.LOADING, c.state.value.state)
        assertFalse(c.load(), "second load while loading must be refused")
        assertFalse(c.importSelected())
        assertEquals("عملية أخرى قيد التنفيذ؛ انتظر انتهاءها أو ألغِها.", c.state.value.message)
        e.runtime.holdLoad!!.complete(Unit)
        assertTrue(first.await())
        assertEquals(1, e.runtime.loadCalls.get())
        assertEquals(1, e.runtime.maxConcurrentLoads)
        e.close()
    }

    @Test
    fun `cancelling a load frees the runtime and returns to READY`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        e.runtime.holdLoad = CompletableDeferred()
        val job = async(Dispatchers.Default) { c.load() }
        e.runtime.started.await()
        c.cancelCurrent()
        runCatching { job.await() }
        assertEquals(OnDeviceState.READY, c.state.value.state)
        assertTrue(e.runtime.unloadCalls.get() >= 1)
        assertTrue(e.runtime.cancelCalls.get() >= 1)
        e.close()
    }

    @Test
    fun `load failure gives ERROR, a clear message and allows retry`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        e.runtime.loadResult = ProviderResult.Err(ProviderFailure(FailureKind.INVALID_MODEL_FILE, "تعذّر تحميل النموذج"))
        assertFalse(c.load())
        assertEquals(OnDeviceState.ERROR, c.state.value.state)
        assertEquals("تعذّر تحميل النموذج", c.state.value.errorMessage)
        e.runtime.loadResult = ProviderResult.Ok(LoadedInfo("ok", 1, 1, 1, 1024, 2), 1)
        assertTrue(c.load())
        assertEquals(OnDeviceState.LOADED, c.state.value.state)
        e.close()
    }

    @Test
    fun `low memory refuses the load before touching the runtime`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        e.gateway.memory = MemorySample(10_000_000, 6L shl 30, true)
        assertFalse(c.load())
        assertEquals(0, e.runtime.loadCalls.get())
        assertTrue(c.state.value.errorMessage!!.contains("الذاكرة"))
        e.close()
    }

    @Test
    fun `load report carries only measured values`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.load()
        val r = c.state.value.loadReport!!
        assertEquals(3L, r.loadMs)
        assertEquals(4L shl 30, r.memoryBefore!!.availableBytes)
        assertEquals("fake llama 1B Q4_K_M", r.info.description)
        e.close()
    }

    @Test
    fun `unload frees memory and turns the model off but keeps verification`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference(); c.enable()
        c.unload()
        assertEquals(OnDeviceState.READY, c.state.value.state)
        assertFalse(c.state.value.enabled)
        assertTrue(c.state.value.verified)
        assertNull(c.activeIntentProvider())
        assertNull(c.enable(), "re-enabling the same verified file needs no new test")
        e.close()
    }

    @Test
    fun `memory pressure unloads but stays enabled and reloads lazily on next use`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference(); c.enable()
        c.onMemoryPressure()
        assertEquals(OnDeviceState.READY, c.state.value.state)
        assertTrue(c.state.value.enabled)
        val loadsBefore = e.runtime.loadCalls.get()
        val r = c.complete(ChatPrompt("s", "u", 16))
        assertIs<ProviderResult.Ok<Completion>>(r)
        assertEquals(loadsBefore + 1, e.runtime.loadCalls.get())
        assertEquals(OnDeviceState.LOADED, c.state.value.state)
        e.close()
    }

    @Test
    fun `complete refuses when not enabled and never calls the runtime`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference()
        val before = e.runtime.completeCalls.get()
        val r = assertIs<ProviderResult.Err>(c.complete(ChatPrompt("s", "u", 16)))
        assertEquals(FailureKind.NOT_READY, r.failure.kind)
        assertEquals(before, e.runtime.completeCalls.get())
        e.close()
    }

    @Test
    fun `out of memory during use disables the model and does not throw`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference(); c.enable()
        e.runtime.completeReply = { ProviderResult.Err(ProviderFailure(FailureKind.OUT_OF_MEMORY, "ذاكرة")) }
        val r = assertIs<ProviderResult.Err>(c.complete(ChatPrompt("s", "u", 16)))
        assertEquals(FailureKind.OUT_OF_MEMORY, r.failure.kind)
        assertFalse(c.state.value.enabled)
        assertNull(c.activeIntentProvider())
        assertTrue(c.state.value.errorMessage!!.contains("الذاكرة"))
        e.close()
    }

    @Test
    fun `settings survive a restart and an enabled model is restored`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference(); c.enable()
        val c2 = e.controller()   // same store, same files: "app restarted"
        assertEquals(OnDeviceState.READY, c2.state.value.state)
        assertTrue(c2.state.value.enabled)
        assertTrue(c2.state.value.verified)
        c2.restoreIfEnabled()
        assertEquals(OnDeviceState.LOADED, c2.state.value.state)
        e.close()
    }

    @Test
    fun `if the private copy vanished, enable is dropped and re-import is required`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference(); c.enable()
        File(e.dir, "model.gguf").delete()
        val c2 = e.controller()
        assertEquals(OnDeviceState.FILE_SELECTED, c2.state.value.state)
        assertFalse(c2.state.value.enabled)
        assertTrue(c2.state.value.message!!.contains("استيراد"))
        assertNull(c2.activeIntentProvider())
        e.close()
    }

    @Test
    fun `a tampered or truncated private copy is not trusted`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        File(e.dir, "model.gguf").writeBytes(ByteArray(10))
        val c2 = e.controller()
        assertEquals(OnDeviceState.FILE_SELECTED, c2.state.value.state)
        e.close()
    }

    @Test
    fun `clear removes the private copy and all stored settings but not the original`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference(); c.enable()
        c.clear()
        assertEquals(OnDeviceState.NOT_SELECTED, c.state.value.state)
        assertNull(e.store.value)
        assertFalse(File(e.dir, "model.gguf").exists())
        assertTrue(e.gateway.sources.containsKey("content://downloads/model-a.gguf"))
        e.close()
    }

    @Test
    fun `persisted data contains no paths and audit never contains a command`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        c.testInference(); c.enable()
        val stored = e.store.value.toString()
        assertFalse(stored.contains(e.dir.absolutePath))
        c.complete(ChatPrompt("s", "افتح السر المرسل", 16))
        assertTrue(e.audit.none { it.contains("السر") })
        e.close()
    }

    @Test
    fun `reasoning text that contains the expected word does not pass the inference test`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        e.runtime.completeReply = { ProviderResult.Ok(Completion("<think>the answer is الجزائر</think>", "x"), 1) }
        assertTrue(c.testInference().contains("لم يجتز"))
        assertFalse(c.state.value.verified)
        assertNotNull(c.enable())
        e.close()
    }

    @Test
    fun `answer after a reasoning block passes and the reasoning is not shown`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        e.runtime.completeReply = { ProviderResult.Ok(Completion("<think>Algeria's capital</think>الجزائر", "x"), 1) }
        assertTrue(c.testInference().startsWith("نجح"))
        assertTrue(c.state.value.verified)
        assertEquals("الجزائر", c.state.value.testReport!!.answer)
        e.close()
    }

    @Test
    fun `the probe asks for a budget that a short answer fits in, and the test is not run without thinking control`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        assertTrue(c.load())
        assertTrue(c.testInference().startsWith("نجح"))
        val probe = e.runtime.prompts.last()
        assertEquals(com.venex.core.ai.InferenceTester.PROBE_MAX_TOKENS, probe.maxTokens)
        assertTrue(probe.maxTokens >= 32)
        e.close()
    }

    @Test
    fun `readiness never calls a merely loaded model working`() = runTest {
        val e = Env(); val c = e.controller(); ready(e, c)
        assertTrue(c.load())
        // loaded, no passing test yet
        assertTrue(c.state.value.readiness.contains("لم يثبت بعد أنه يجيب"), c.state.value.readiness)
        assertFalse(c.state.value.readiness.startsWith("يعمل"))
        assertTrue(c.testInference().startsWith("نجح"))
        // tested but not enabled
        assertTrue(c.state.value.readiness.contains("غير مفعّل"), c.state.value.readiness)
        assertFalse(c.state.value.readiness.startsWith("يعمل"))
        assertNull(c.enable())
        assertTrue(c.state.value.readiness.startsWith("يعمل"), c.state.value.readiness)
        // a failed test after a change withdraws "working"
        c.changeParams(RuntimeParams(512, 2))
        assertFalse(c.state.value.readiness.startsWith("يعمل"), c.state.value.readiness)
        e.close()
    }
}
