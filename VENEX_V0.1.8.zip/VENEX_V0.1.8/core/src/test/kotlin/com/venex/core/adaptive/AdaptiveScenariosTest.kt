package com.venex.core.adaptive

import com.venex.core.device.Channel
import com.venex.core.env.FakeAppDevice
import com.venex.core.env.FakeScreen
import com.venex.core.env.tree
import com.venex.core.goal.Interpretation
import com.venex.core.goal.StructuredGoal
import com.venex.core.model.StepStatus
import com.venex.core.model.TaskReport
import com.venex.core.model.TaskStatus
import kotlinx.coroutines.async
import kotlinx.coroutines.test.runTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/**
 * V0.1.8 — categories D (Adaptive Planning), E (Execution), F (Recovery) and G (Verification), end to end through the
 * coordinator against generic fake applications. VENEX has no knowledge of these apps beyond what is on their screens.
 */
class AdaptiveScenariosTest {

    private suspend fun goalOf(h: Harness, text: String): StructuredGoal {
        val r = h.coordinator.interpret(text)
        assertIs<Interpretation.Ready>(r, "not ready: $r")
        return r.goal
    }

    private suspend fun cmd(h: Harness, text: String): TaskReport = h.coordinator.run(goalOf(h, text))

    // ================================================================ D. Adaptive Planning

    @Test
    fun d_planIsMadeOfElementIntentsNotCoordinates() = runTest {
        val h = Harness()
        val plan = h.coordinator.plan(goalOf(h, "افتح شبكة وانشر \"مرحبا\""))
        assertNull(plan.blockedReason)
        assertEquals(listOf("open", "compose", "type", "submit"), plan.steps.map { it.id })
        assertEquals(SOCIAL, plan.appPackage)
        assertTrue(plan.steps.single { it.commit }.id == "submit")
        // every step names an element or an app; none holds a selector or a coordinate
        assertTrue(plan.steps.all { it.intent is StepIntent.OpenApp || it.intent is StepIntent.Tap || it.intent is StepIntent.Type })
        // the text is carried to the step that types it, and to the one the approval is bound to
        assertEquals("مرحبا", plan.steps.single { it.id == "submit" }.content)
    }

    @Test
    fun d_planIsBlockedWithAReasonWhenTheAppIsNotInstalled() = runTest {
        val h = Harness()
        val plan = h.coordinator.plan(goalOf(h, "افتح تطبيقاً غريباً وانشر \"س\""))
        assertNotNull(plan.blockedReason)
        assertTrue(plan.blockedReason!!.contains("لم أجد"))
        assertTrue(plan.steps.isEmpty())
    }

    @Test
    fun d_planIsBlockedWhenAccessibilityIsOff_withTheMethodsThatWereRejected() = runTest {
        val h = Harness()
        h.fx.device.caps = setOf(Channel.INTENT)
        val goal = goalOf(h, "افتح شبكة وانشر \"س\"")
        val plan = h.coordinator.plan(goal)
        assertNotNull(plan.blockedReason)
        assertTrue(plan.methodNotes.any { it.contains("مرفوض") || it.contains("لا توجد") })
        val report = h.coordinator.run(goal)
        assertEquals(TaskStatus.NOT_EXECUTED, report.status)
        assertTrue(h.fx.device.log.isEmpty(), "nothing may be done without a permitted channel: ${h.fx.device.log}")
    }

    @Test
    fun d_clarificationsStopBeforeAnythingHappens() = runTest {
        val h = Harness()
        val r = h.coordinator.interpret("انشر")
        assertIs<Interpretation.NeedsClarification>(r)
        assertTrue(h.fx.device.log.isEmpty())
    }

    // ================================================================ E. Execution

    @Test
    fun e_postFromTheLauncher_endToEnd_withABoundApproval() = runTest {
        val h = Harness()
        val report = cmd(h, "افتح شبكة وانشر \"مرحبا بالعالم\"")
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(listOf("مرحبا بالعالم"), h.fx.posts)

        assertEquals(1, h.approvals.requests.size, "one sensitive step, one approval")
        val b = h.approvals.requests[0].binding
        assertTrue(b.operation.contains("POST"))
        assertEquals(SOCIAL, b.appPackage)
        assertEquals("نشر", b.control)
        assertNotNull(b.contentDigest)
        assertNull(b.account, "the account is not known and must not be invented")
        val lines = h.approvals.requests[0].lines
        assertTrue(lines.any { it.contains("مرحبا بالعالم") })
        assertTrue(lines.any { it.contains("الحساب: غير معروف") })
        // the report speaks in the V0.1.7 vocabulary the UI already knows
        assertTrue(report.steps.any { it.stepId == "submit" && it.status == StepStatus.VERIFIED })
    }

    @Test
    fun e_composerAlreadyOpen_stepsThatAreAlreadyTrueAreSkipped() = runTest {
        val h = Harness(Fixtures(startIn = "composer"))
        val report = cmd(h, "انشر \"س\"")
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(0, h.fx.device.clicksOf("منشور جديد"))
        assertEquals(StepStatus.SKIPPED, report.steps.single { it.stepId == "compose" }.status)
        assertEquals(listOf("س"), h.fx.posts)
    }

    @Test
    fun e_theOwnersOwnExample_withAnAttachedText() = runTest {
        val h = Harness(Fixtures(startIn = "feed"))
        val raw = "[ملف: post.txt]\nنص جاهز للنشر\n\nافتح التطبيق وأنشئ منشوراً يحتوي على النص الذي أعطيتك إياه"
        val report = cmd(h, raw)
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(listOf("نص جاهز للنشر"), h.fx.posts)
        assertEquals(1, h.approvals.requests.size)
    }

    @Test
    fun e_sendMessage_toARecipient() = runTest {
        val h = Harness()
        val report = cmd(h, "افتح رسائل وأرسل رسالة إلى أحمد تقول \"مرحبا يا أحمد\"")
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(listOf("مرحبا يا أحمد"), h.fx.messages)
        val b = h.approvals.requests.single().binding
        assertTrue(b.operation.contains("SEND"))
        assertTrue(b.target!!.contains("أحمد") && b.target!!.contains("ظاهر على الشاشة"), "the recipient is shown only as seen: ${b.target}")
        assertEquals("إرسال", b.control)
    }

    @Test
    fun e_searchInAnApp_isOnlyPartiallyVerified() = runTest {
        val h = Harness(Fixtures(startIn = "notes"))
        val report = cmd(h, "ابحث عن فاتورة")
        // the results screen is reached and shows the query, but nothing proves the results are the right ones
        assertEquals(TaskStatus.UNVERIFIED, report.status, report.summary)
        assertTrue(report.summary.contains("جزء"))
        assertEquals("فاتورة", h.fx.device.vars["query"])
        assertEquals(0, h.approvals.requests.size, "a search is not sensitive")
    }

    @Test
    fun e_deleteNeedsTwoApprovals_oneForEachSensitivePress() = runTest {
        val h = Harness(Fixtures(startIn = "notes"))
        val report = cmd(h, "احذف \"فاتورة\"")
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(listOf("قائمة"), h.fx.notes)
        assertEquals(2, h.approvals.requests.size)
        assertTrue(h.approvals.requests.all { it.binding.operation.contains("DELETE") && it.binding.target == "فاتورة" })
    }

    @Test
    fun e_deleteRefusedByTheOwner_deletesNothing() = runTest {
        val h = Harness(Fixtures(startIn = "notes"), RecordingApprovals(answer = false))
        val report = cmd(h, "احذف \"فاتورة\"")
        assertEquals(TaskStatus.CANCELLED, report.status)
        assertEquals(listOf("فاتورة", "قائمة"), h.fx.notes)
        assertEquals(0, h.fx.device.clicksOf("حذف"))
        assertEquals(1, h.approvals.requests.size, "a refusal ends the task; it is not asked again")
    }

    @Test
    fun e_describeTheScreen_isReadOnly() = runTest {
        val h = Harness(Fixtures(startIn = "notes"))
        val report = cmd(h, "ماذا ترى على الشاشة؟")
        assertEquals(TaskStatus.SUCCESS, report.status)
        assertTrue(report.summary.contains("com.example.notes"))
        assertTrue(h.fx.device.log.none { it.startsWith("click:") || it.startsWith("type:") })
    }

    // ================================================================ F. Recovery

    @Test
    fun f_unexpectedPromotionalDialog_isDismissedWithTheHarmlessButton() = runTest {
        val fx = Fixtures(startIn = "feed").also { it.popupOnNextFeed = true }
        val h = Harness(fx)
        val report = cmd(h, "انشر \"بعد النافذة\"")
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(listOf("بعد النافذة"), fx.posts)
        assertEquals(1, fx.device.clicksOf("ليس الآن"))
        assertEquals(0, fx.device.clicksOf("اشترك الآن"), "never the button that subscribes or buys")
        assertNull(fx.device.vars["subscribed"])
    }

    @Test
    fun f_loginWall_stopsAndHandsBackToTheOwner_thenResumes() = runTest {
        val fx = Fixtures(startIn = "feed").also { it.loginWall = true }
        val h = Harness(fx)
        val report = cmd(h, "انشر \"بعد الدخول\"")
        assertEquals(TaskStatus.UNVERIFIED, report.status, "it acted (opened the composer) so it is partial progress, not success")
        assertTrue(report.summary.contains("تسجيل الدخول"))
        assertTrue(report.summary.contains("لا يُدخل كلمات المرور"))
        assertTrue(fx.posts.isEmpty())
        assertTrue(fx.device.typed.isEmpty(), "nothing may be typed into a login screen")
        assertEquals(0, fx.device.clicksOf("دخول"))
        assertTrue(h.approvals.requests.isEmpty())
        assertTrue(h.coordinator.hasResumable())

        // the owner logs in by themselves and says "resume"
        fx.loginWall = false
        fx.device.goto("composer")
        assertTrue(h.coordinator.isResumeCommand("استأنف"))
        val resumed = h.coordinator.resume()
        assertEquals(TaskStatus.SUCCESS, resumed.status, resumed.summary)
        assertEquals(listOf("بعد الدخول"), fx.posts)
        assertFalse(h.coordinator.hasResumable())
    }

    @Test
    fun f_captcha_isNeverTouched() = runTest {
        val fx = Fixtures(startIn = "composer").also { it.captchaOnComposer = true }
        val h = Harness(fx)
        val report = cmd(h, "انشر \"س\"")
        assertTrue(report.status == TaskStatus.NOT_EXECUTED || report.status == TaskStatus.UNVERIFIED)
        assertTrue(report.summary.contains("CAPTCHA"))
        assertTrue(fx.device.typed.isEmpty())
        assertTrue(fx.posts.isEmpty())
        assertEquals(0, fx.device.clicksOf("نشر"))
    }

    @Test
    fun f_elementNotFound_triesToScrollTwiceThenAsksTheOwner() = runTest {
        val h = Harness(Fixtures(startIn = "contacts"))
        val report = cmd(h, "انشر \"س\"")
        assertEquals(TaskStatus.NOT_EXECUTED, report.status)
        assertTrue(report.summary.contains("لم أجد"))
        assertEquals(2, h.fx.device.vars["scrolls"], "bounded: exactly two scroll attempts, no more")
        assertTrue(h.fx.posts.isEmpty())
    }

    @Test
    fun f_twoEquallyGoodElements_areNotGuessedBetween() = runTest {
        val fx = Fixtures(startIn = "feed").also { it.duplicateNewPostButton = true }
        val h = Harness(fx)
        val report = cmd(h, "انشر \"س\"")
        assertEquals(TaskStatus.NOT_EXECUTED, report.status)
        assertTrue(report.summary.contains("أكثر من عنصر"))
        assertEquals(0, fx.device.clicksOf("منشور جديد"))
    }

    @Test
    fun f_aSensitiveStepThatRanButShowedNoResult_isNeverRepeated() = runTest {
        val fx = Fixtures(startIn = "composer").also { it.publishFails = true }
        val h = Harness(fx)
        val report = cmd(h, "انشر \"لن يُنشر\"")
        assertEquals(TaskStatus.FAILED, report.status)
        assertTrue(report.summary.contains("لن أكرّرها"))
        assertEquals(1, fx.device.clicksOf("نشر"), "pressed once, never retried")
        assertEquals(1, h.approvals.requests.size)
        val st = h.store.latestResumable()
        assertNull(st, "a failed task is finished, not resumable")
    }

    @Test
    fun f_aLoadingScreen_isWaitedOutNotActedOn() = runTest {
        val fx = Fixtures(startIn = "feed")
        fx.device.screens["loading"] = FakeScreen(SOCIAL, {
            tree {
                val r = add(cls = "android.widget.FrameLayout")
                add(r, cls = "android.widget.ProgressBar")
                add(r, text = "جار التحميل", cls = "android.widget.TextView")
            }
        })
        val h = Harness(fx, limits = RunLimits(pollIntervalMs = 1, maxWaitPolls = 5))
        val goal = goalOf(h, "انشر \"بعد التحميل\"")
        var snaps = 0
        fx.device.goto("loading")
        fx.device.onBeforeSnapshot = { d -> if (++snaps >= 3 && d.current == "loading") d.goto("feed") }
        val report = h.coordinator.run(goal)
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(listOf("بعد التحميل"), fx.posts)
    }

    @Test
    fun f_aScreenThatNeverFinishesLoading_endsWithAnExplanation() = runTest {
        val fx = Fixtures(startIn = "feed")
        fx.device.screens["loading"] = FakeScreen(SOCIAL, {
            tree { val r = add(cls = "android.widget.FrameLayout"); add(r, cls = "android.widget.ProgressBar"); add(r, text = "جار التحميل") }
        })
        val h = Harness(fx, limits = RunLimits(pollIntervalMs = 1, maxWaitPolls = 3))
        val goal = goalOf(h, "انشر \"س\"")
        fx.device.goto("loading")
        val report = h.coordinator.run(goal)
        assertEquals(TaskStatus.NOT_EXECUTED, report.status)
        assertTrue(report.summary.contains("تُحمَّل"))
        assertTrue(fx.posts.isEmpty())
    }

    @Test
    fun f_theAppLeavingTheForeground_isReopenedOnce() = runTest {
        val fx = Fixtures(startIn = "launcher")
        val h = Harness(fx)
        val goal = goalOf(h, "افتح شبكة وانشر \"س\"")
        // the first time the composer button is about to be used, another app has taken the foreground
        var stolen = false
        fx.device.onBeforeSnapshot = { d -> if (!stolen && d.current == "feed" && d.log.any { it.startsWith("launch:") }) { stolen = true; d.goto("launcher") } }
        val report = h.coordinator.run(goal)
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals(2, fx.device.log.count { it == "launch:$SOCIAL" }, "re-opened exactly once")
        assertEquals(listOf("س"), fx.posts)
    }

    // ================================================================ G. Verification

    @Test
    fun g_anIdenticalEarlierPostMakesTheEvidenceAmbiguous() = runTest {
        val fx = Fixtures(posts = mutableListOf("مرحبا"), startIn = "feed")
        val h = Harness(fx)
        val report = cmd(h, "انشر \"مرحبا\"")
        assertEquals(TaskStatus.UNVERIFIED, report.status, report.summary)
        assertTrue(report.summary.contains("قبل بدء المهمة") || report.summary.contains("ملتبس"))
        assertEquals(2, fx.posts.size)
    }

    @Test
    fun g_aTapCanOnlyShowThatTheScreenChanged() = runTest {
        val h = Harness(Fixtures(startIn = "notes"))
        val report = cmd(h, "اضغط على \"فاتورة\"")
        assertEquals(TaskStatus.UNVERIFIED, report.status, report.summary)
        assertTrue(report.summary.contains("لا أستطيع تأكيد") || report.summary.contains("تغيّرت الواجهة"))
    }

    @Test
    fun g_nothingIsClaimedWhenEverythingWasAlreadyTrue() = runTest {
        val fx = Fixtures(startIn = "composer")
        fx.device.typed["$SOCIAL:id/compose_body"] = "موجود أصلاً"
        val h = Harness(fx)
        val report = cmd(h, "اكتب \"موجود أصلاً\" في حقل المنشور")
        assertEquals(TaskStatus.UNVERIFIED, report.status, report.summary)
        assertTrue(report.summary.contains("لم أنفّذ أي إجراء"))
        assertEquals(0, fx.device.log.count { it.startsWith("type:") })
    }

    @Test
    fun g_typingIsVerifiedByTheFieldContent() = runTest {
        val h = Harness(Fixtures(startIn = "composer"))
        val report = cmd(h, "اكتب \"مسودة\" في حقل المنشور")
        assertEquals(TaskStatus.SUCCESS, report.status, report.summary)
        assertEquals("مسودة", h.fx.device.typed["$SOCIAL:id/compose_body"])
        assertTrue(h.fx.posts.isEmpty(), "typing is not posting")
        assertTrue(h.approvals.requests.isEmpty())
    }

    @Test
    fun g_aFailedTypeIsReportedAsFailureNotSuccess() = runTest {
        val fx = Fixtures(startIn = "composer").also { it.device.failTyping = true }
        val h = Harness(fx)
        val report = cmd(h, "اكتب \"س\" في حقل المنشور")
        assertEquals(TaskStatus.FAILED, report.status)
    }

    // ================================================================ one task at a time

    @Test
    fun a_secondTaskWhileOneIsWaitingForApproval_isRefused() = runTest {
        val gate = kotlinx.coroutines.CompletableDeferred<Boolean>()
        val fx = Fixtures(startIn = "composer")
        val h = Harness(fx, approvals = RecordingApprovals(true))
        val waiting = com.venex.core.safety.ApprovalHandler { gate.await() }
        val coordinator = com.venex.core.adaptive.AdaptiveCoordinator(fx.device, h.audit, waiting, selfPackage = SELF, clock = h.clock, settleDelayMs = 0)
        val goal = (coordinator.interpret("انشر \"س\"") as Interpretation.Ready).goal
        val first = async { coordinator.run(goal) }
        kotlinx.coroutines.yield()
        assertTrue(coordinator.isRunning)
        val second = coordinator.run(goal)
        assertEquals(TaskStatus.NOT_EXECUTED, second.status)
        assertTrue(second.summary.contains("قيد التنفيذ"))
        gate.complete(false)
        assertEquals(TaskStatus.CANCELLED, first.await().status)
        assertFalse(coordinator.isRunning)
    }
}
