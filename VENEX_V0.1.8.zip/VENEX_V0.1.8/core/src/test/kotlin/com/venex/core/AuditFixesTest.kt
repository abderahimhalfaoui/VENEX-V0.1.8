package com.venex.core

import com.venex.core.device.AppResolution
import com.venex.core.device.AppResolver
import com.venex.core.device.InstalledApp
import com.venex.core.intent.RuleBasedIntentParser
import com.venex.core.model.CalculateGoal
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.UnknownGoal
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertIs

/** Regression tests for defects found during the v0.1.1 audit. */
class AuditFixesTest {

    private val rules = RuleBasedIntentParser()

    @Test
    fun `calculation with three numbers is refused instead of silently truncated`() {
        // Before the fix this returned 2 + 3 and ignored the rest.
        assertIs<UnknownGoal>(rules.parseSync("احسب 2 + 3 + 4"))
        assertIs<CalculateGoal>(rules.parseSync("احسب 2 + 3"))
    }

    @Test
    fun `polite suffixes are removed from app names`() {
        assertEquals("الكاميرا", (rules.parseSync("افتح الكاميرا لو سمحت") as OpenAppGoal).appName)
        assertEquals("الكاميرا", (rules.parseSync("افتح الكاميرا من فضلك") as OpenAppGoal).appName)
        assertEquals("camera", (rules.parseSync("open camera please") as OpenAppGoal).appName)
    }

    @Test
    fun `stacked filler words are removed`() {
        assertEquals("الكاميرا", (rules.parseSync("افتح لي تطبيق الكاميرا") as OpenAppGoal).appName)
    }

    @Test
    fun `package substring does not cause a wrong app match`() {
        // The label is unrelated; only the package name contains "calc" as a substring of "calcrypto".
        val apps = listOf(InstalledApp("Wallet", "com.example.calcrypto", false))
        assertEquals(AppResolution.NotFound, AppResolver(apps).resolve("calc"))
        assertEquals(AppResolution.NotFound, AppResolver(apps).resolve("الآلة الحاسبة"))
    }

    @Test
    fun `calculator package segment still resolves`() {
        val apps = listOf(InstalledApp("Tools", "com.google.android.calculator", false))
        assertIs<AppResolution.Found>(AppResolver(apps).resolve("الآلة الحاسبة"))
    }
}
