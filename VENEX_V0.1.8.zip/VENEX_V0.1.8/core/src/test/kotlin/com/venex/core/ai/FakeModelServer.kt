package com.venex.core.ai

import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/**
 * A REAL HTTP server bound to 127.0.0.1 on an ephemeral port. The provider adapters, the transport
 * and the timeouts are exercised over a socket. What it cannot prove is that a genuine model
 * (Ollama, LM Studio, ...) answers; that is the job of the in-app "اختبار الاستدلال" on the phone.
 */
class FakeModelServer : AutoCloseable {

    data class Recorded(val method: String, val path: String, val body: String, val authorization: String?)

    class Reply(val status: Int, val body: String, val delayMs: Long = 0)

    val requests = CopyOnWriteArrayList<Recorded>()
    private val routes = ConcurrentHashMap<String, (Recorded) -> Reply>()
    private val server: HttpServer = HttpServer.create(InetSocketAddress(InetAddress.getLoopbackAddress(), 0), 0)

    init {
        server.executor = Executors.newCachedThreadPool()
        server.createContext("/") { exchange -> handle(exchange) }
        server.start()
    }

    val port: Int get() = server.address.port

    val baseUrl: String get() = "http://127.0.0.1:$port"

    fun route(method: String, path: String, handler: (Recorded) -> Reply) {
        routes["$method $path"] = handler
    }

    fun fixed(method: String, path: String, status: Int, body: String, delayMs: Long = 0) {
        route(method, path) { Reply(status, body, delayMs) }
    }

    fun count(method: String, path: String): Int = requests.count { it.method == method && it.path == path }

    private fun handle(exchange: HttpExchange) {
        val body = exchange.requestBody.readBytes().toString(Charsets.UTF_8)
        val rec = Recorded(
            method = exchange.requestMethod,
            path = exchange.requestURI.path,
            body = body,
            authorization = exchange.requestHeaders.getFirst("Authorization")
        )
        requests += rec
        val reply = routes["${rec.method} ${rec.path}"]?.invoke(rec) ?: Reply(404, """{"error":"not found"}""")
        if (reply.delayMs > 0) Thread.sleep(reply.delayMs)
        val bytes = reply.body.toByteArray(Charsets.UTF_8)
        exchange.responseHeaders.add("Content-Type", "application/json; charset=utf-8")
        exchange.sendResponseHeaders(reply.status, if (bytes.isEmpty()) -1 else bytes.size.toLong())
        if (bytes.isNotEmpty()) exchange.responseBody.use { it.write(bytes) }
        exchange.close()
    }

    override fun close() {
        server.stop(0)
    }
}

/** Standard replies that mimic the documented shapes of each server. */
object Replies {
    const val OPENAI_MODELS = """{"object":"list","data":[{"id":"qwen2.5-7b-instruct"},{"id":"llama3"}]}"""
    const val OLLAMA_TAGS = """{"models":[{"name":"llama3:latest","model":"llama3:latest"},{"name":"qwen2.5:7b","model":"qwen2.5:7b"}]}"""

    fun openAiChat(content: String, model: String = "qwen2.5-7b-instruct"): String =
        """{"id":"x","object":"chat.completion","model":"$model","choices":[{"index":0,"message":{"role":"assistant","content":${jsonString(content)}},"finish_reason":"stop"}]}"""

    fun ollamaChat(content: String, model: String = "llama3:latest"): String =
        """{"model":"$model","created_at":"2026-11-22T00:00:00Z","message":{"role":"assistant","content":${jsonString(content)}},"done":true}"""

    private fun jsonString(s: String): String = MiniJson.encode(s)
}
