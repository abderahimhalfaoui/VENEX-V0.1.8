package com.venex.core.goal

import com.venex.core.safety.RiskLevel
import com.venex.core.safety.SensitiveCategory
import com.venex.core.verify.TextScope
import com.venex.core.verify.VerificationCondition
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotEquals
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** V0.1.8 — category C (Goal Interpretation): clear goals, missing information, ambiguity, refusals. */
class GoalInterpreterTest {

    private val interp = GoalInterpreter()
    private val self = "com.venex.app"
    private val inNotes = InterpretationContext("com.example.notes", "المفكرة", self)
    private val inVenex = InterpretationContext(self, "VENEX", self)
    private val nowhere = InterpretationContext(null, null, self)

    private fun attach(name: String, text: String) = "[ملف: $name]\n$text"

    private fun goalOf(r: Interpretation): StructuredGoal = when (r) {
        is Interpretation.Ready -> r.goal
        is Interpretation.NeedsClarification -> r.goal
        is Interpretation.Refused -> r.goal
        is Interpretation.Unsupported -> error("unsupported: ${r.reason}")
    }

    // ---------------------------------------------------------------- the owner's own example

    private val ownerSentence = "افتح التطبيق وأنشئ منشوراً يحتوي على النص الذي أعطيتك إياه"

    @Test
    fun ownerExample_withAttachment_isReadyAndUsesTheAttachedText() {
        val r = interp.interpret(attach("post.txt", "مرحباً بكم في صفحتنا الجديدة") + "\n\n" + ownerSentence, inNotes)
        assertIs<Interpretation.Ready>(r)
        val g = r.goal
        assertEquals(GoalFamily.CREATE_POST, g.family)
        assertEquals("مرحباً بكم في صفحتنا الجديدة", g.value(SlotName.TEXT))
        assertEquals(SlotStatus.EXPLICIT, g.slot(SlotName.TEXT)?.status)
        assertTrue(g.slot(SlotName.TEXT)?.note?.contains("post.txt") == true)
        // "the app" was taken to mean the app in front — and that is shown as an inference, not as something the owner said
        assertEquals(SlotStatus.INFERRED, g.slot(SlotName.APP)?.status)
        assertEquals("المفكرة", g.value(SlotName.APP))
        assertTrue(g.statementsOf(Origin.SYSTEM_INFERRED).any { it.contains("المفكرة") })
        assertTrue(g.statementsOf(Origin.OWNER_EXPLICIT).any { it.contains("النص") })
        assertTrue(g.clarifications.isEmpty())
    }

    @Test
    fun ownerExample_postingIsHighRiskAndNeedsApproval() {
        val g = goalOf(interp.interpret(attach("post.txt", "نص") + "\n\n" + ownerSentence, inNotes))
        assertEquals(RiskLevel.HIGH, g.risk.level)
        assertTrue(g.risk.requiresApproval)
        assertTrue(SensitiveCategory.POST in g.risk.categories)
        assertTrue(g.risk.affectsOthers)
        assertFalse(g.risk.reversible)
        assertTrue(g.statementsOf(Origin.NEEDS_OWNER).any { it.contains("موافقة") })
    }

    @Test
    fun ownerExample_withoutAnyAttachment_asksInsteadOfInventingText() {
        val r = interp.interpret(ownerSentence, inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        val t = r.goal.slot(SlotName.TEXT)
        assertNotNull(t)
        assertNull(t.value)
        assertEquals(SlotStatus.REFERENCED_BUT_ABSENT, t.status)
        assertTrue(r.goal.clarifications.any { it.slot == SlotName.TEXT && it.question.contains("مرفق") })
    }

    @Test
    fun ownerExample_whenNoOtherAppIsOpen_asksWhichApp() {
        val r = interp.interpret(attach("post.txt", "نص") + "\n\n" + ownerSentence, inVenex)
        assertIs<Interpretation.NeedsClarification>(r)
        assertEquals(SlotStatus.MISSING, r.goal.slot(SlotName.APP)?.status)
        assertTrue(r.goal.clarifications.any { it.slot == SlotName.APP })
        // the text is still resolved, only the app is asked for
        assertEquals("نص", r.goal.value(SlotName.TEXT))
        val r2 = interp.interpret(attach("post.txt", "نص") + "\n\n" + ownerSentence, nowhere)
        assertIs<Interpretation.NeedsClarification>(r2)
    }

    @Test
    fun ownerExample_withTwoAttachments_asksWhichOne() {
        val raw = attach("a.txt", "الأول") + "\n\n" + attach("b.txt", "الثاني") + "\n\n" + ownerSentence
        val r = interp.interpret(raw, inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        assertNull(r.goal.value(SlotName.TEXT))
        val q = r.goal.clarifications.first { it.slot == SlotName.TEXT }.question
        assertTrue(q.contains("a.txt") && q.contains("b.txt"))
    }

    @Test
    fun ownerExample_withAnImageOnly_saysTheImageCannotBeRead() {
        val raw = "[ملف: shot.png]\n(محتوى الصور لا يُقرأ هنا)\n\n" + ownerSentence
        val r = interp.interpret(raw, inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        assertEquals(SlotStatus.REFERENCED_BUT_ABSENT, r.goal.slot(SlotName.TEXT)?.status)
        assertTrue(r.goal.slot(SlotName.TEXT)?.note?.contains("shot.png") == true)
    }

    // ---------------------------------------------------------------- posting: where the text comes from

    @Test
    fun quotedPostText_isTakenVerbatim() {
        val g = goalOf(interp.interpret("انشر \"إِلَى اللِّقَاءِ يا أصدقاء\"", inNotes))
        assertEquals(GoalFamily.CREATE_POST, g.family)
        assertEquals("إِلَى اللِّقَاءِ يا أصدقاء", g.value(SlotName.TEXT))
        assertEquals(SlotStatus.EXPLICIT, g.slot(SlotName.TEXT)?.status)
    }

    @Test
    fun openClauseNamesTheApp_andMarkerIntroducesUnquotedText() {
        val r = interp.interpret("افتح المفكرة وأنشئ منشوراً يقول مرحباً بكم", inVenex)
        assertIs<Interpretation.Ready>(r)
        assertEquals("المفكرة", r.goal.value(SlotName.APP))
        assertEquals(SlotStatus.EXPLICIT, r.goal.slot(SlotName.APP)?.status)
        assertEquals("مرحباً بكم", r.goal.value(SlotName.TEXT))
    }

    @Test
    fun appNamedAtTheEnd_isExplicit() {
        val r = interp.interpret("post \"Hello World\" in the Notes app", nowhere)
        assertIs<Interpretation.Ready>(r)
        assertEquals("Notes", r.goal.value(SlotName.APP))
        assertEquals("Hello World", r.goal.value(SlotName.TEXT))
    }

    @Test
    fun aTopicIsNotText_vnexDoesNotComposeContent() {
        val r = interp.interpret("اكتب منشوراً عن السلام", inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        assertNull(r.goal.value(SlotName.TEXT))
        assertTrue(r.goal.clarifications.any { it.slot == SlotName.TEXT && it.question.contains("لا أؤلف") })
    }

    @Test
    fun aPostWithNoTextAtAll_isAskedFor() {
        val r = interp.interpret("أنشئ منشوراً", inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        assertTrue(r.goal.clarifications.any { it.slot == SlotName.TEXT })
    }

    @Test
    fun singleAttachmentWithoutAReference_isUsedButShownAsAnInference() {
        val r = interp.interpret(attach("note.txt", "نص مرفق") + "\n\n" + "أنشئ منشوراً", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertEquals("نص مرفق", r.goal.value(SlotName.TEXT))
        assertEquals(SlotStatus.INFERRED, r.goal.slot(SlotName.TEXT)?.status)
        assertTrue(r.goal.statementsOf(Origin.SYSTEM_INFERRED).any { it.contains("note.txt") })
    }

    @Test
    fun twoQuotedTexts_areAmbiguous() {
        val r = interp.interpret("انشر \"الأول\" و \"الثاني\"", inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        assertNull(r.goal.value(SlotName.TEXT))
    }

    @Test
    fun anOverLongTextIsNotSilentlyCut() {
        val long = "ب".repeat(GoalComposer.MAX_TEXT_CHARS + 1)
        val r = interp.interpret("[ملف: big.txt]\n$long\n\nانشر النص المرفق", inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        assertNull(r.goal.value(SlotName.TEXT))
        assertTrue(r.goal.clarifications.any { it.question.contains("أطول") })
    }

    @Test
    fun postingGoalIsVerifiedByTheTextAppearingOutsideAnInputField() {
        val g = goalOf(interp.interpret("انشر \"مرحبا بالعالم\"", inNotes))
        val outcome = g.verification.first { it.required }.condition
        assertIs<VerificationCondition.TextVisible>(outcome)
        assertEquals(TextScope.NON_INPUT, outcome.scope)
        assertEquals("مرحبا بالعالم", outcome.text)
        // "the app is in front" is context, never required proof
        assertTrue(g.verification.filter { it.condition is VerificationCondition.AppInForeground }.none { it.required })
    }

    // ---------------------------------------------------------------- messages

    @Test
    fun arabicMessage_recipientAndQuotedText() {
        val r = interp.interpret("أرسل رسالة إلى أحمد تقول \"مرحباً، كيف حالك؟\"", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertEquals(GoalFamily.SEND_MESSAGE, r.goal.family)
        assertEquals("أحمد", r.goal.value(SlotName.RECIPIENT))
        assertEquals("مرحباً، كيف حالك؟", r.goal.value(SlotName.TEXT))
        assertTrue(SensitiveCategory.SEND in r.goal.risk.categories)
        assertTrue(r.goal.risk.requiresApproval)
    }

    @Test
    fun englishMessage_withMarker() {
        val r = interp.interpret("Send a message to Ahmed saying Hello There", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertEquals("Ahmed", r.goal.value(SlotName.RECIPIENT))
        assertEquals("Hello There", r.goal.value(SlotName.TEXT))
    }

    @Test
    fun messageWithoutRecipient_isAsked() {
        val r = interp.interpret("أرسل رسالة \"مرحبا\"", inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        assertTrue(r.goal.clarifications.any { it.slot == SlotName.RECIPIENT })
        assertEquals("مرحبا", r.goal.value(SlotName.TEXT))
    }

    @Test
    fun messageWithoutText_isAsked() {
        val r = interp.interpret("أرسل رسالة إلى أحمد", inNotes)
        assertIs<Interpretation.NeedsClarification>(r)
        assertEquals("أحمد", r.goal.value(SlotName.RECIPIENT))
        assertTrue(r.goal.clarifications.any { it.slot == SlotName.TEXT })
    }

    @Test
    fun textBeforeRecipient() {
        val r = interp.interpret("send \"see you at 5\" to Sara", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertEquals("Sara", r.goal.value(SlotName.RECIPIENT))
        assertEquals("see you at 5", r.goal.value(SlotName.TEXT))
    }

    // ---------------------------------------------------------------- payments are refused, whatever the wording

    @Test
    fun paymentsAreRefused() {
        for (cmd in listOf("ادفع الفاتورة", "اشتري هذا المنتج", "buy it now", "حول 100 دولار إلى أحمد", "purchase the premium plan", "افتح المتجر واشتري التذكرة")) {
            val r = interp.interpret(cmd, inNotes)
            assertIs<Interpretation.Refused>(r, cmd)
            assertEquals(RiskLevel.BLOCKED, r.goal.risk.level, cmd)
            assertTrue(r.reason.contains("محظورة"), cmd)
        }
    }

    @Test
    fun aPaymentWordInsideQuotedPostTextIsJustText() {
        val r = interp.interpret("انشر \"اشتري الآن بخصم 50٪\"", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertEquals(GoalFamily.CREATE_POST, r.goal.family)
    }

    @Test
    fun tappingAPaymentControlIsRefused_andTappingSendNeedsApproval() {
        assertIs<Interpretation.Refused>(interp.interpret("اضغط على زر الدفع", inNotes))
        assertIs<Interpretation.Refused>(interp.interpret("tap \"Buy now\"", inNotes))
        val send = goalOf(interp.interpret("tap the Send button", inNotes))
        assertEquals(RiskLevel.HIGH, send.risk.level)
    }

    // ---------------------------------------------------------------- tap / delete / enter / search / describe

    @Test
    fun tap_namesTheElementAsTheOwnerWroteIt() {
        val r = interp.interpret("اضغط على زر الإعدادات", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertEquals(GoalFamily.TAP, r.goal.family)
        assertEquals("الإعدادات", r.goal.value(SlotName.TARGET))
        assertEquals(RiskLevel.LOW, r.goal.risk.level)
        // pressing something can only be shown to have changed the screen, so that is all that is promised
        assertIs<VerificationCondition.StateChanged>(r.goal.verification.single().condition)
    }

    @Test
    fun tapWithoutAName_isAsked() {
        for (cmd in listOf("اضغط", "اضغط هنا", "tap this", "click it")) {
            val r = interp.interpret(cmd, inNotes)
            assertIs<Interpretation.NeedsClarification>(r, cmd)
            assertTrue(r.goal.clarifications.any { it.slot == SlotName.TARGET }, cmd)
        }
    }

    @Test
    fun delete_needsAnExplicitTarget_andIsHighRisk() {
        val ok = interp.interpret("احذف \"ملاحظة قديمة\"", inNotes)
        assertIs<Interpretation.Ready>(ok)
        assertEquals("ملاحظة قديمة", ok.goal.value(SlotName.TARGET))
        assertTrue(SensitiveCategory.DELETE in ok.goal.risk.categories)
        assertTrue(ok.goal.risk.requiresApproval)
        val outcome = ok.goal.verification.single().condition
        assertIs<VerificationCondition.ElementAbsent>(outcome)
        assertTrue(outcome.asOutcome)

        for (cmd in listOf("احذف هذا", "delete it", "احذف")) {
            val r = interp.interpret(cmd, inNotes)
            assertIs<Interpretation.NeedsClarification>(r, cmd)
            assertTrue(r.goal.clarifications.any { it.question.contains("حذف") }, cmd)
        }
    }

    @Test
    fun enterText_withQuotedTextAndNamedField() {
        val r = interp.interpret("اكتب \"hello\" في حقل البحث", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertEquals(GoalFamily.ENTER_TEXT, r.goal.family)
        assertEquals("hello", r.goal.value(SlotName.TEXT))
        assertEquals("حقل البحث", r.goal.value(SlotName.FIELD))
        val check = r.goal.verification.single().condition
        assertIs<VerificationCondition.FieldContains>(check)
        assertTrue("البحث" in check.target.labels)
        assertEquals(RiskLevel.LOW, r.goal.risk.level)
    }

    @Test
    fun enterText_withoutFieldUsesTheActiveField() {
        val r = interp.interpret("type \"abc\"", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertNull(r.goal.value(SlotName.FIELD))
        val check = r.goal.verification.single().condition
        assertIs<VerificationCondition.FieldContains>(check)
        assertTrue(check.target.labels.isEmpty())
    }

    @Test
    fun searchInTheCurrentApp_keepsThePlaceInTheQuery() {
        val r = interp.interpret("ابحث عن مطاعم في الجزائر", inNotes)
        assertIs<Interpretation.Ready>(r)
        assertEquals(GoalFamily.SEARCH_IN_APP, r.goal.family)
        assertEquals("مطاعم في الجزائر", r.goal.value(SlotName.QUERY))
        assertEquals(SlotStatus.INFERRED, r.goal.slot(SlotName.APP)?.status)
    }

    @Test
    fun searchNamesTheApp() {
        val a = interp.interpret("ابحث في تطبيق المفكرة عن فاتورة", inVenex)
        assertIs<Interpretation.Ready>(a)
        assertEquals("المفكرة", a.goal.value(SlotName.APP))
        assertEquals("فاتورة", a.goal.value(SlotName.QUERY))

        val b = interp.interpret("search for cats in the Photos app", inVenex)
        assertIs<Interpretation.Ready>(b)
        assertEquals("Photos", b.goal.value(SlotName.APP))
        assertEquals("cats", b.goal.value(SlotName.QUERY))

        val c = interp.interpret("افتح المفكرة وابحث عن فاتورة", inVenex)
        assertIs<Interpretation.Ready>(c)
        assertEquals("المفكرة", c.goal.value(SlotName.APP))
        assertEquals("فاتورة", c.goal.value(SlotName.QUERY))
    }

    @Test
    fun searchWithoutAppOrQuery_isAsked() {
        val noApp = interp.interpret("ابحث عن قطط", inVenex)
        assertIs<Interpretation.NeedsClarification>(noApp)
        assertTrue(noApp.goal.clarifications.any { it.slot == SlotName.APP })
        val noQuery = interp.interpret("ابحث", inNotes)
        assertIs<Interpretation.NeedsClarification>(noQuery)
        assertTrue(noQuery.goal.clarifications.any { it.slot == SlotName.QUERY })
    }

    @Test
    fun describeScreen_isReadOnlyAndSafe() {
        for (cmd in listOf("ماذا ترى على الشاشة؟", "صف الشاشة", "describe the screen", "what is on the screen")) {
            val r = interp.interpret(cmd, inNotes)
            assertIs<Interpretation.Ready>(r, cmd)
            assertEquals(GoalFamily.DESCRIBE_SCREEN, r.goal.family, cmd)
            assertEquals(RiskLevel.LOW, r.goal.risk.level, cmd)
            assertTrue(r.goal.verification.isEmpty(), cmd)
        }
    }

    // ---------------------------------------------------------------- what is not understood

    @Test
    fun unsupportedCommands_areReportedNotGuessed() {
        for (cmd in listOf("ما لون السماء", "hello", "كيف حالك", "")) {
            assertIs<Interpretation.Unsupported>(interp.interpret(cmd, inNotes), cmd)
        }
    }

    @Test
    fun openAppAlone_isLeftToTheBaseline() {
        assertIs<Interpretation.Unsupported>(interp.interpret("افتح الكاميرا", inNotes))
    }

    @Test
    fun anAttachmentWithoutACommand_isNotATask() {
        val r = interp.interpret(attach("a.txt", "نص"), inNotes)
        assertIs<Interpretation.Unsupported>(r)
        assertTrue(r.reason.contains("دون أمر"))
    }

    // ---------------------------------------------------------------- the goal is a structure the planner can trust

    @Test
    fun theGoalSeparatesExplicitInferredUnknownAndNeedsOwner() {
        val g = goalOf(interp.interpret("انشر \"مرحبا\"", inNotes))
        assertTrue(g.statementsOf(Origin.OWNER_EXPLICIT).isNotEmpty())
        assertTrue(g.statementsOf(Origin.SYSTEM_INFERRED).isNotEmpty())
        assertTrue(g.statementsOf(Origin.UNKNOWN).isNotEmpty())
        assertTrue(g.statementsOf(Origin.NEEDS_OWNER).isNotEmpty())
        assertTrue(g.preconditions.isNotEmpty())
        assertTrue(g.constraints.any { it.contains("CAPTCHA") })
        assertTrue(g.expectedFinalState.isNotBlank())
        assertTrue(g.desiredOutcome.isNotBlank())
    }

    @Test
    fun fingerprintFollowsTheContent() {
        val a = goalOf(interp.interpret("انشر \"أ\"", inNotes))
        val a2 = goalOf(interp.interpret("انشر \"أ\"", inNotes))
        val b = goalOf(interp.interpret("انشر \"ب\"", inNotes))
        assertEquals(a.fingerprint, a2.fingerprint)
        assertNotEquals(a.fingerprint, b.fingerprint)
        assertNotEquals(a.contentDigest(), b.contentDigest())
        assertNull(goalOf(interp.interpret("اضغط على الإعدادات", inNotes)).contentDigest())
    }

    @Test
    fun anExplicitAppNeedsTheIntentChannel_aForegroundAppDoesNot() {
        val explicit = goalOf(interp.interpret("افتح المفكرة وانشر \"س\"", inVenex))
        assertTrue(com.venex.core.device.Channel.INTENT in explicit.requiredPermissions)
        val inferred = goalOf(interp.interpret("انشر \"س\"", inNotes))
        assertFalse(com.venex.core.device.Channel.INTENT in inferred.requiredPermissions)
        assertTrue(com.venex.core.device.Channel.ACCESSIBILITY in inferred.requiredPermissions)
    }

    // ---------------------------------------------------------------- the attachment envelope

    @Test
    fun envelopeSeparatesAttachmentsFromTheTypedCommand() {
        val e = CommandEnvelope.parse("[ملف: a.txt]\nسطر 1\nسطر 2\n\n[ملف: b.md]\nنص ثان\n\nانشر النص")
        assertEquals("انشر النص", e.typed)
        assertEquals(listOf("a.txt", "b.md"), e.attachments.map { it.name })
        assertEquals("سطر 1\nسطر 2", e.attachments[0].text)
        assertEquals("نص ثان", e.attachments[1].text)
        val plain = CommandEnvelope.parse("  افتح الكاميرا  ")
        assertEquals("افتح الكاميرا", plain.typed)
        assertTrue(plain.attachments.isEmpty())
    }

    @Test
    fun envelopeRecognisesUnreadableAttachments() {
        val e = CommandEnvelope.parse("[ملف: shot.png]\n(محتوى الصور لا يُقرأ هنا)\n\nافتح التطبيق")
        assertTrue(e.attachments.isEmpty())
        assertEquals(listOf("shot.png"), e.unreadableNames)
        assertEquals("افتح التطبيق", e.typed)
    }
}
