package com.venex.core.env

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicLong

/** The result of one understanding round: the new model, the one it replaced, and what changed between them. */
data class Understanding(val model: EnvironmentModel, val previous: EnvironmentModel?, val diff: ScreenDiff)

/**
 * Discover → Observe → Understand → Model. Owns the "current" model, refreshes it on demand and reports what changed.
 * The model is never treated as permanent: [isFresh] answers whether it may still be trusted, and every consumer
 * calls [refresh] after anything that can change the screen.
 */
class EnvironmentUnderstandingEngine(
    private val observer: EnvironmentObserver,
    private val clock: () -> Long = System::currentTimeMillis,
    private val identity: EnvironmentIdentity = EnvironmentIdentity(),
    private val appLabelOf: (String) -> String? = { null },
    /** Models older than this are considered stale. */
    val maxAgeMs: Long = 5_000
) {
    private val mutex = Mutex()
    private val generation = AtomicLong(0)

    @Volatile
    var current: EnvironmentModel? = null
        private set

    /** Observes, builds a new model, diffs it against the previous one and makes it current. Calls are serialised. */
    suspend fun refresh(): Understanding = mutex.withLock {
        val set = observer.observe()
        val previous = current
        val model = EnvironmentModelBuilder.build(set, BuildContext(generation.incrementAndGet(), identity, appLabelOf))
        current = model
        Understanding(model, previous, ScreenDiffer.diff(previous, model))
    }

    fun isFresh(model: EnvironmentModel): Boolean = model.isFresh(clock(), maxAgeMs)

    /** Forgets the current model (for example after a long pause): the next consumer is forced to observe again. */
    fun invalidate() {
        current = null
    }

    /** What VENEX can say about the current model, in the owner's language. Only states what was actually observed. */
    fun describe(model: EnvironmentModel): String = Describer.describe(model)
}

internal object Describer {

    fun describe(m: EnvironmentModel): String = buildString {
        val screen = m.screen
        if (screen == null) {
            appendLine("لا أستطيع رؤية الشاشة الآن.")
            appendLine("السبب: ${m.state.reason}")
            m.unknowns.firstOrNull { it.area != "visual.content" }?.let { appendLine("غير معروف: ${it.reason}") }
            return@buildString
        }
        val appName = m.app?.label ?: m.app?.packageName ?: "غير معروف"
        appendLine("التطبيق: $appName" + (m.app?.label?.let { " (${m.app.packageName})" } ?: ""))
        appendLine("حالة الواجهة: ${stateLabel(m.state.kind)} — الثقة: ${m.confidence.name}")
        val interactive = screen.elements.count { it.interactable }
        appendLine("العناصر: ${screen.elements.size} (القابل للتفاعل: $interactive)، حقول الإدخال: ${screen.inputFields.size}")

        val named = screen.elements.filter { it.interactable && it.label != null && !it.node.editable }.take(MAX_LISTED)
        if (named.isNotEmpty()) appendLine("أزرار/عناصر ظاهرة: " + named.joinToString("، ") { "«${it.label!!.take(30)}»" })
        if (screen.inputFields.isNotEmpty()) {
            appendLine("حقول: " + screen.inputFields.take(MAX_LISTED).joinToString("، ") { f ->
                when {
                    f.password -> "حقل كلمة مرور (لا أقرؤه)"
                    f.label != null -> "«${f.label.take(30)}»"
                    else -> "حقل بلا اسم"
                }
            })
        }
        if (m.constraints.isNotEmpty()) appendLine("قيود: " + m.constraints.joinToString("؛ ") { it.description })
        if (m.conflicts.isNotEmpty()) appendLine("تعارضات: " + m.conflicts.joinToString("؛ ") { it.description })
        val gaps = m.unknowns.filter { it.area != "visual.content" }
        if (gaps.isNotEmpty()) appendLine("غير معروف: " + gaps.joinToString("؛ ") { it.reason })
        append("ملاحظة: هذا فهم مؤقت قد يتغيّر، ولا أرى ما لا يكشفه Accessibility.")
    }.trim()

    fun stateLabel(k: UiStateKind): String = when (k) {
        UiStateKind.UNREADABLE -> "غير مقروءة"
        UiStateKind.OPAQUE -> "واجهة معتمة"
        UiStateKind.NORMAL -> "عادية"
        UiStateKind.DIALOG -> "نافذة حوار"
        UiStateKind.LOADING -> "تحميل"
        UiStateKind.PERMISSION_PROMPT -> "طلب صلاحية"
        UiStateKind.LOGIN_REQUIRED -> "تسجيل دخول مطلوب"
        UiStateKind.CAPTCHA -> "تحقق بشري"
    }

    private const val MAX_LISTED = 12
}
