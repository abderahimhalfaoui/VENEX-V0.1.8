package com.venex.core.env

import com.venex.core.device.Bounds
import com.venex.core.device.Channel
import com.venex.core.device.SelectorMatcher
import com.venex.core.device.UiNode
import com.venex.core.intent.TextNormalizer
import com.venex.core.model.Selector

/**
 * Stable identifier of a UI element across observations. It is derived from the element's place in the hierarchy
 * and its own identity (class, view id, or label for unnamed buttons), NEVER from screen coordinates.
 */
@JvmInline
value class ElementId(val value: String) {
    override fun toString(): String = value
}

enum class ElementRole { BUTTON, TEXT, INPUT, TOGGLE, SCROLLABLE, IMAGE, LIST, CONTAINER, UNKNOWN }

/** One element of the current screen, with what is known about it and how sure we are. */
data class UiElement(
    val id: ElementId,
    /** Position in the observed snapshot. For debugging and diffs only; it is not an identity. */
    val index: Int,
    val parentId: ElementId?,
    val childIds: List<ElementId>,
    val depth: Int,
    val role: ElementRole,
    /** Best human label: text, else content description. Null for password fields and unlabeled elements. */
    val label: String?,
    val node: UiNode,
    /** Enabled and offering at least one interaction (click, type, scroll, toggle). */
    val interactable: Boolean,
    /** A selector that, evaluated against the same screen, resolves to exactly this element; null if none does. */
    val selector: Selector?,
    val confidence: Confidence
) {
    val viewIdShort: String? get() = node.viewId?.substringAfter(":id/")?.takeIf { it.isNotBlank() }
}

enum class ActionKind { CLICK, TYPE_TEXT, SCROLL, TOGGLE, PRESS_BACK, PRESS_HOME, READ_SCREEN }

/** Something VENEX could do on this screen right now, through a named channel. */
data class AvailableAction(
    val kind: ActionKind,
    val elementId: ElementId?,
    val label: String?,
    val selector: Selector?,
    val channel: Channel,
    val confidence: Confidence
)

data class InputField(
    val elementId: ElementId,
    /** Placeholder, content description, nearby label or view id, in that order. */
    val label: String?,
    /** What the field currently holds. Always null for password fields (never read) and for a bare placeholder. */
    val currentText: String?,
    val password: Boolean,
    val focused: Boolean
)

enum class UiStateKind {
    /** The screen could not be read at all. */
    UNREADABLE,

    /** Readable, but exposes no elements: an opaque UI (game, canvas, protected window). */
    OPAQUE,
    NORMAL,
    DIALOG,
    LOADING,
    PERMISSION_PROMPT,
    LOGIN_REQUIRED,
    CAPTCHA
}

enum class UiFlag { HAS_PASSWORD_FIELD, HAS_INPUT, HAS_SCROLLABLE, TRUNCATED, HIERARCHY_UNKNOWN }

data class UiStateReport(val kind: UiStateKind, val flags: Set<UiFlag>, val confidence: Confidence, val reason: String)

enum class ConstraintKind { ACCESS_LIMITED, OPAQUE_UI, PASSWORD_FIELD, LOGIN_REQUIRED, CAPTCHA, PARTIAL_SCREEN, NO_HIERARCHY }

/** A limit that follows from what was observed (not from policy in the abstract). */
data class ObservableConstraint(val kind: ConstraintKind, val description: String, val elementIds: List<ElementId> = emptyList())

enum class ConflictKind { CLICKABLE_BUT_DISABLED, HIERARCHY_INCONSISTENT, PACKAGE_DISAGREEMENT }

/** Contradicting information. It is recorded and lowers confidence; it is never silently resolved. */
data class Conflict(val kind: ConflictKind, val description: String, val elementIds: List<ElementId> = emptyList())

/** Something VENEX cannot know, with the reason. Absence of data is stated, not hidden. */
data class UnknownInfo(val area: String, val reason: String)

data class EnvironmentIdentity(
    val platform: String = "android",
    val osVersion: String? = null,
    val sessionId: String = "default"
)

data class ApplicationIdentity(val packageName: String, val label: String?, val confidence: Confidence)

data class SourceUse(val kind: SourceKind, val reliability: Confidence, val note: String? = null)

/** The visible part of the current window. */
data class ScreenModel(
    /** Structural identity of the screen: same layout, regardless of changing text. */
    val screenId: String,
    /** Identity of the content: structure plus every label. Differs when only the text changed. */
    val contentId: String,
    val elements: List<UiElement>,
    val rootIds: List<ElementId>,
    val inputFields: List<InputField>,
    val actions: List<AvailableAction>,
    val hierarchyKnown: Boolean,
    val truncated: Boolean
) {
    private val byId: Map<ElementId, UiElement> by lazy { elements.associateBy { it.id } }

    fun byId(id: ElementId): UiElement? = byId[id]
    fun children(id: ElementId): List<UiElement> = byId(id)?.childIds?.mapNotNull { byId[it] }.orEmpty()

    /** Ancestors from the parent up to the root. */
    fun ancestors(id: ElementId): List<UiElement> {
        val out = ArrayList<UiElement>()
        var cur = byId(id)?.parentId?.let { byId[it] }
        var guard = 0
        while (cur != null && guard++ < 64) {
            out += cur
            cur = cur.parentId?.let { byId[it] }
        }
        return out
    }

    /** Every visible text and description, as the Verifier and SafetyPolicy see it. */
    fun allText(): List<String> = elements.flatMap { listOfNotNull(it.node.text, it.node.contentDescription) }

    /** Text of elements that are not input fields: the place where results and posted content appear. */
    fun nonInputText(): List<String> =
        elements.filter { !it.node.editable }.flatMap { listOfNotNull(it.node.text, it.node.contentDescription) }

    fun matching(selector: Selector): List<UiElement> = elements.filter { SelectorMatcher.matches(it.node, selector) }

    fun hasEditable(): Boolean = elements.any { it.node.editable && !it.node.password && it.node.enabled }
}

/**
 * VENEX's temporary understanding of one moment of the environment. It is a representation that can be wrong and
 * goes stale: every consumer must check [isFresh] and re-observe after anything that may change the screen.
 */
data class EnvironmentModel(
    val generation: Long,
    val identity: EnvironmentIdentity,
    val app: ApplicationIdentity?,
    val screen: ScreenModel?,
    val state: UiStateReport,
    val constraints: List<ObservableConstraint>,
    val conflicts: List<Conflict>,
    val unknowns: List<UnknownInfo>,
    val confidence: Confidence,
    val observedAtMillis: Long,
    val sources: List<SourceUse>
) {
    fun ageMillis(now: Long): Long = (now - observedAtMillis).coerceAtLeast(0)

    fun isFresh(now: Long, maxAgeMs: Long): Boolean = ageMillis(now) <= maxAgeMs

    val packageName: String? get() = app?.packageName
    val readable: Boolean get() = screen != null

    fun hasConstraint(kind: ConstraintKind): Boolean = constraints.any { it.kind == kind }
}

internal fun normLabel(s: String?): String = if (s == null) "" else TextNormalizer.normalize(s)

internal fun Bounds.isEmpty(): Boolean = right <= left || bottom <= top
