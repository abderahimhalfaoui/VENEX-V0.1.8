package com.venex.core.adaptive

import com.venex.core.device.Channel
import com.venex.core.env.Confidence
import com.venex.core.safety.RiskAssessment
import com.venex.core.safety.RiskLevel

/** Ways to carry out one step. The order is the tie-break order: more official and more verifiable first. */
enum class ExecutionMethod(val arabicLabel: String, val channel: Channel?) {
    OFFICIAL_API("واجهة رسمية (API)", Channel.OFFICIAL_API),
    APP_FUNCTION("App Function", null),
    ANDROID_INTENT("Android Intent", Channel.INTENT),
    DEEP_LINK("رابط عميق", Channel.DEEP_LINK),
    ACCESSIBILITY_INTERACTION("إجراء Accessibility عام (تمرير/رجوع/قراءة)", Channel.ACCESSIBILITY),
    UI_ELEMENT_INTERACTION("تفاعل مع عنصر واجهة", Channel.ACCESSIBILITY),
    VISUAL_INTERACTION("تفاعل بصري", Channel.VISION)
}

/** What a step needs, independent of how it will be done. */
enum class StepKind { OPEN_APP, OPEN_LINK, TAP, TYPE, SCROLL, PRESS_KEY, OBSERVE }

data class MethodRequest(
    val step: StepKind,
    val risk: RiskAssessment = RiskAssessment.SAFE,
    /** The step carries content the owner would not want exposed (message or post text). */
    val sensitiveData: Boolean = false,
    /** The outcome can only be confirmed by reading the screen. */
    val needsScreenVerification: Boolean = false,
    /** Official methods the planner knows really apply here (for example a known deep link for a search). */
    val officialAlternatives: Set<ExecutionMethod> = emptySet()
)

data class MethodCandidate(
    val method: ExecutionMethod,
    val available: Boolean,
    /** Why it cannot be used; null when it can. */
    val rejection: String?,
    val reliability: Confidence,
    val verifiability: Confidence,
    val score: Int
)

data class MethodDecision(val selected: MethodCandidate?, val candidates: List<MethodCandidate>, val explanation: String)

/**
 * Chooses the method for a step by availability, permission, reliability, the nature and risk of the operation, the
 * sensitivity of the data and how well the result can be verified. A method VENEX has no permission for, or has no
 * code for, is rejected with its reason and can never be chosen. Accessibility is not used merely because it is
 * available when an official method that applies is available too.
 */
class ExecutionMethodSelector(
    private val implemented: Set<ExecutionMethod> = DEFAULT_IMPLEMENTED
) {
    fun select(request: MethodRequest, capabilities: Set<Channel>): MethodDecision {
        val applicable = applicableMethods(request)
        val evaluated = applicable.map { evaluate(it, request, capabilities) }
            .sortedWith(compareByDescending<MethodCandidate> { it.available }.thenByDescending { it.score }.thenBy { it.method.ordinal })
        val best = evaluated.firstOrNull { it.available }
        val explanation = if (best != null) {
            "اخترت ${best.method.arabicLabel}" + evaluated.filter { !it.available }.takeIf { it.isNotEmpty() }
                ?.joinToString(prefix = " (مرفوض: ", postfix = ")", separator = "؛ ") { "${it.method.arabicLabel}: ${it.rejection}" }.orEmpty()
        } else {
            "لا توجد وسيلة متاحة: " + evaluated.joinToString("؛ ") { "${it.method.arabicLabel}: ${it.rejection}" }
        }
        return MethodDecision(best, evaluated, explanation)
    }

    private fun applicableMethods(r: MethodRequest): List<ExecutionMethod> {
        val base = when (r.step) {
            StepKind.OPEN_APP -> listOf(ExecutionMethod.ANDROID_INTENT)
            StepKind.OPEN_LINK -> listOf(ExecutionMethod.DEEP_LINK)
            StepKind.TAP, StepKind.TYPE -> listOf(ExecutionMethod.UI_ELEMENT_INTERACTION, ExecutionMethod.VISUAL_INTERACTION)
            StepKind.SCROLL, StepKind.PRESS_KEY, StepKind.OBSERVE ->
                listOf(ExecutionMethod.ACCESSIBILITY_INTERACTION, ExecutionMethod.VISUAL_INTERACTION)
        }
        return (base + r.officialAlternatives).distinct()
    }

    private fun evaluate(m: ExecutionMethod, r: MethodRequest, caps: Set<Channel>): MethodCandidate {
        val reliability = when (m) {
            ExecutionMethod.OFFICIAL_API, ExecutionMethod.APP_FUNCTION, ExecutionMethod.ANDROID_INTENT, ExecutionMethod.ACCESSIBILITY_INTERACTION -> Confidence.HIGH
            ExecutionMethod.DEEP_LINK, ExecutionMethod.UI_ELEMENT_INTERACTION -> Confidence.MEDIUM
            ExecutionMethod.VISUAL_INTERACTION -> Confidence.LOW
        }
        val canReadScreen = Channel.ACCESSIBILITY in caps
        val verifiability = when {
            m == ExecutionMethod.OFFICIAL_API || m == ExecutionMethod.APP_FUNCTION -> Confidence.HIGH
            !r.needsScreenVerification -> Confidence.MEDIUM
            canReadScreen -> Confidence.HIGH
            else -> Confidence.NONE
        }
        val rejection = when {
            m !in implemented -> "غير منفَّذة في هذه النسخة"
            m.channel == null -> "لا قناة لها"
            m.channel !in caps -> "الصلاحية/القناة غير متاحة الآن"
            m == ExecutionMethod.VISUAL_INTERACTION && r.sensitiveData -> "بيانات حساسة لا تُعرَض على فهم بصري"
            else -> null
        }
        val preference = when (m) {
            ExecutionMethod.OFFICIAL_API -> 4
            ExecutionMethod.APP_FUNCTION -> 3
            ExecutionMethod.ANDROID_INTENT, ExecutionMethod.DEEP_LINK -> 2
            ExecutionMethod.ACCESSIBILITY_INTERACTION, ExecutionMethod.UI_ELEMENT_INTERACTION -> 0
            ExecutionMethod.VISUAL_INTERACTION -> -2
        }
        var score = reliability.rank * 3 + verifiability.rank * 2 + preference
        if (r.risk.level == RiskLevel.HIGH && reliability.rank <= Confidence.LOW.rank) score -= 4
        return MethodCandidate(m, rejection == null, rejection, reliability, verifiability, score)
    }

    companion object {
        /** What this version really has code for. Anything else is rejected, however the channel set looks. */
        val DEFAULT_IMPLEMENTED = setOf(
            ExecutionMethod.ANDROID_INTENT, ExecutionMethod.DEEP_LINK,
            ExecutionMethod.ACCESSIBILITY_INTERACTION, ExecutionMethod.UI_ELEMENT_INTERACTION
        )
    }
}
