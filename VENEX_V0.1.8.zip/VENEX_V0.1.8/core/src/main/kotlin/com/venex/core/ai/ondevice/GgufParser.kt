package com.venex.core.ai.ondevice

import java.io.EOFException
import java.io.InputStream

/** What VENEX learns from a GGUF header without loading any weights. */
data class GgufSummary(
    val version: Int,
    val tensorCount: Long,
    val metadataCount: Long,
    val architecture: String?,
    val name: String?,
    /** llama.cpp "general.file_type" code (e.g. 15 = Q4_K_M), or null when absent. */
    val fileType: Int?,
    val trainedContextLength: Long?
) {
    /** Human-readable quantization, only for the codes that are well known; otherwise "type N". */
    val quantization: String? get() = fileType?.let { FILE_TYPES[it] ?: "type $it" }

    companion object {
        private val FILE_TYPES = mapOf(
            0 to "F32", 1 to "F16", 2 to "Q4_0", 3 to "Q4_1", 7 to "Q8_0", 8 to "Q5_0", 9 to "Q5_1",
            10 to "Q2_K", 11 to "Q3_K_S", 12 to "Q3_K_M", 13 to "Q3_K_L", 14 to "Q4_K_S", 15 to "Q4_K_M",
            16 to "Q5_K_S", 17 to "Q5_K_M", 18 to "Q6_K", 32 to "BF16"
        )
    }
}

sealed interface GgufParseResult {
    data class Ok(val summary: GgufSummary) : GgufParseResult
    data class Invalid(val reason: String) : GgufParseResult
}

/**
 * Minimal, bounded GGUF header reader (spec: https://github.com/ggml-org/ggml/blob/master/docs/gguf.md).
 * It reads the magic, version, counts and the metadata key/value section, skipping large arrays
 * (tokenizer vocabularies) without keeping them. It never trusts a length: every read is bounded.
 *
 * A passing parse proves the HEADER is well-formed. It does not prove that the tensors are intact or
 * that llama.cpp supports the architecture; only loading and the inference test prove that.
 */
object GgufParser {
    private const val MAGIC = 0x46554747 // "GGUF" little-endian
    private const val MAX_METADATA_ENTRIES = 100_000L
    private const val MAX_TENSORS = 1_000_000L
    private const val MAX_STRING_BYTES = 1 shl 20          // 1 MiB per string
    private const val MAX_HEADER_BYTES = 256L * 1024 * 1024 // never read more than this of the header
    private const val MAX_ARRAY_NESTING = 4

    fun parse(input: InputStream): GgufParseResult {
        val r = Reader(input)
        try {
            val magic = r.u32()
            if (magic != MAGIC.toLong()) return GgufParseResult.Invalid("الملف ليس بصيغة GGUF (التوقيع غير صحيح)")
            val version = r.u32().toInt()
            if (version !in 2..3) return GgufParseResult.Invalid("إصدار GGUF غير مدعوم ($version)")
            val tensors = r.u64()
            val kvCount = r.u64()
            if (tensors < 0 || tensors > MAX_TENSORS) return GgufParseResult.Invalid("عدد المصفوفات في الترويسة غير معقول")
            if (kvCount < 0 || kvCount > MAX_METADATA_ENTRIES) return GgufParseResult.Invalid("عدد حقول البيانات الوصفية غير معقول")

            var arch: String? = null
            var name: String? = null
            var fileType: Int? = null
            var ctxLen: Long? = null
            val ctxCandidates = HashMap<String, Long>()

            for (i in 0 until kvCount) {
                val key = r.string()
                val type = r.u32().toInt()
                when {
                    key == "general.architecture" && type == T_STRING -> arch = r.string()
                    key == "general.name" && type == T_STRING -> name = r.string().take(120)
                    key == "general.file_type" && type in INT_TYPES -> fileType = r.integer(type).toInt()
                    key.endsWith(".context_length") && type in INT_TYPES -> ctxCandidates[key] = r.integer(type)
                    else -> r.skipValue(type, 0)
                }
            }
            if (arch == null) return GgufParseResult.Invalid("الترويسة لا تحدد معمارية النموذج (general.architecture)")
            if (arch.length !in 1..64 || arch.any { !(it.isLetterOrDigit() || it == '-' || it == '_' || it == '.') }) {
                return GgufParseResult.Invalid("اسم المعمارية غير صالح")
            }
            ctxLen = ctxCandidates["$arch.context_length"]
            return GgufParseResult.Ok(GgufSummary(version, tensors, kvCount, arch, name, fileType, ctxLen))
        } catch (e: EOFException) {
            return GgufParseResult.Invalid("الملف مبتور: انتهى قبل اكتمال الترويسة")
        } catch (e: FormatException) {
            return GgufParseResult.Invalid(e.message ?: "ترويسة GGUF غير صالحة")
        }
    }

    private class FormatException(message: String) : Exception(message)

    private const val T_UINT8 = 0
    private const val T_INT8 = 1
    private const val T_UINT16 = 2
    private const val T_INT16 = 3
    private const val T_UINT32 = 4
    private const val T_INT32 = 5
    private const val T_FLOAT32 = 6
    private const val T_BOOL = 7
    private const val T_STRING = 8
    private const val T_ARRAY = 9
    private const val T_UINT64 = 10
    private const val T_INT64 = 11
    private const val T_FLOAT64 = 12
    private val INT_TYPES = setOf(T_UINT8, T_INT8, T_UINT16, T_INT16, T_UINT32, T_INT32, T_UINT64, T_INT64)

    private class Reader(private val input: InputStream) {
        private var consumed = 0L
        private val buf = ByteArray(8)

        private fun guard(n: Long) {
            consumed += n
            if (consumed > MAX_HEADER_BYTES) throw FormatException("الترويسة أكبر من الحد المقبول")
        }

        private fun fill(n: Int) {
            guard(n.toLong())
            var off = 0
            while (off < n) {
                val c = input.read(buf, off, n - off)
                if (c < 0) throw EOFException()
                off += c
            }
        }

        fun u32(): Long { fill(4); return le(4) }
        fun u64(): Long { fill(8); return le(8) }

        private fun le(n: Int): Long {
            var v = 0L
            for (i in n - 1 downTo 0) v = (v shl 8) or (buf[i].toLong() and 0xFF)
            return v
        }

        fun string(): String {
            val len = u64()
            if (len < 0 || len > MAX_STRING_BYTES) throw FormatException("طول نص غير معقول في الترويسة")
            val bytes = ByteArray(len.toInt())
            guard(len)
            var off = 0
            while (off < bytes.size) {
                val c = input.read(bytes, off, bytes.size - off)
                if (c < 0) throw EOFException()
                off += c
            }
            return String(bytes, Charsets.UTF_8)
        }

        fun integer(type: Int): Long = when (type) {
            T_UINT8 -> { fill(1); le(1) }
            T_INT8 -> { fill(1); le(1).toByte().toLong() }
            T_UINT16 -> { fill(2); le(2) }
            T_INT16 -> { fill(2); le(2).toShort().toLong() }
            T_UINT32 -> { fill(4); le(4) }
            T_INT32 -> { fill(4); le(4).toInt().toLong() }
            T_UINT64, T_INT64 -> { fill(8); le(8) }
            else -> throw FormatException("نوع عدد غير متوقع")
        }

        private fun skipBytes(n: Long) {
            if (n < 0) throw FormatException("حجم سالب في الترويسة")
            guard(n)
            var left = n
            while (left > 0) {
                val s = input.skip(left)
                if (s > 0) { left -= s; continue }
                // skip() may return 0 without being at EOF; fall back to a real read.
                if (input.read() < 0) throw EOFException()
                left--
            }
        }

        fun skipValue(type: Int, depth: Int) {
            when (type) {
                T_UINT8, T_INT8, T_BOOL -> skipBytes(1)
                T_UINT16, T_INT16 -> skipBytes(2)
                T_UINT32, T_INT32, T_FLOAT32 -> skipBytes(4)
                T_UINT64, T_INT64, T_FLOAT64 -> skipBytes(8)
                T_STRING -> {
                    val len = u64()
                    if (len < 0 || len > MAX_STRING_BYTES) throw FormatException("طول نص غير معقول في الترويسة")
                    skipBytes(len)
                }
                T_ARRAY -> {
                    if (depth >= MAX_ARRAY_NESTING) throw FormatException("تداخل مصفوفات مفرط في الترويسة")
                    val elemType = u32().toInt()
                    val count = u64()
                    if (count < 0 || count > 50_000_000L) throw FormatException("حجم مصفوفة غير معقول")
                    val fixed = fixedSize(elemType)
                    if (fixed > 0) skipBytes(Math.multiplyExact(count, fixed.toLong()))
                    else for (i in 0 until count) skipValue(elemType, depth + 1)
                }
                else -> throw FormatException("نوع قيمة غير معروف ($type) في الترويسة")
            }
        }

        private fun fixedSize(t: Int): Int = when (t) {
            T_UINT8, T_INT8, T_BOOL -> 1
            T_UINT16, T_INT16 -> 2
            T_UINT32, T_INT32, T_FLOAT32 -> 4
            T_UINT64, T_INT64, T_FLOAT64 -> 8
            else -> 0
        }
    }
}

/** File-name checks that complement (never replace) the header parse. */
object GgufFileName {
    private val SPLIT = Regex("-\\d{5}-of-\\d{5}\\.gguf$", RegexOption.IGNORE_CASE)

    /** Returns null if the name is acceptable, otherwise a readable reason. */
    fun problem(name: String): String? = when {
        !name.endsWith(".gguf", ignoreCase = true) -> "امتداد الملف ليس .gguf؛ اختر ملف نموذج GGUF"
        SPLIT.containsMatchIn(name) -> "هذا ملف GGUF مجزّأ إلى أجزاء (…-00001-of-0000N)؛ هذه النسخة تدعم ملفاً واحداً فقط"
        else -> null
    }
}
