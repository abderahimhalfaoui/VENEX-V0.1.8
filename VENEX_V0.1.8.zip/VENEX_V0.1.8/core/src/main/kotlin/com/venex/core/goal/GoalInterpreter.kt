package com.venex.core.goal

import com.venex.core.safety.ApprovalBinding

/**
 * Deterministic, bilingual (Arabic/English) interpreter: command text -> [Interpretation]. No model, no network.
 * It recognises a small, explicit set of goal families (see [GoalFamily]) and reports honestly when it does not
 * understand. It never invents a missing detail: an absent text, recipient, target or app becomes a clarification
 * question, and a phrase like "the text I gave you" is resolved against a real attachment or reported as absent.
 *
 * Free text (a post, a message) is cut out of the ORIGINAL command, so the owner's own words are preserved exactly.
 * Text between quotation marks is the preferred way to give content; unquoted text is accepted only after an
 * explicit marker such as "يحتوي على" / "saying".
 */
class GoalInterpreter {

    fun interpret(rawText: String, ctx: InterpretationContext = InterpretationContext()): Interpretation {
        val envelope = CommandEnvelope.parse(rawText)
        val typed = envelope.typed
        if (typed.isBlank()) {
            val why = if (envelope.attachments.isNotEmpty() || envelope.unreadableNames.isNotEmpty()) "أرفقتَ ملفاً دون أمر مكتوب." else "الأمر فارغ."
            return Interpretation.Unsupported(rawText, why)
        }
        if (typed.length > MAX_COMMAND_CHARS) return Interpretation.Unsupported(rawText, "الأمر المكتوب أطول من الحد ($MAX_COMMAND_CHARS حرفاً).")

        val quotes = QUOTE.findAll(typed).map { it.groupValues[1].trim() }.toList()
        val view = View(typed, AlignedText(mask(typed)))
        val n = view.norm
        if (n.isBlank()) return Interpretation.Unsupported(rawText, "الأمر فارغ.")

        val statements = ArrayList<Statement>()
        val slots = ArrayList<Slot>()
        val clar = ArrayList<Clarification>()

        val lead = LEAD.find(n)?.range?.last?.plus(1) ?: 0
        val head = tokenize(n, lead)
        if (head.isEmpty()) return Interpretation.Unsupported(rawText, "الأمر فارغ.")

        // "افتح X و<فعل>": the open clause names the app; the rest is the goal.
        var actionStart = lead
        if (core(head[0].text) in OPEN_VERBS) {
            val split = findActionStart(head)
                ?: return Interpretation.Unsupported(rawText, "الأمر يطلب فتح تطبيق فقط، وهذا يتولاه المسار الأساسي لا الطبقة التكيفية.")
            val appToks = head.subList(1, split.appEnd).let(::stripFillers)
            val appNorm = appToks.joinToString(" ") { core(it.text) }
            if (appToks.isEmpty() || appNorm in DEICTIC_APP) {
                statements += Statement("فهمتُ «التطبيق» بمعنى التطبيق الظاهر الآن لا تطبيقاً مسمّى", Origin.SYSTEM_INFERRED)
            } else {
                slots += Slot(SlotName.APP, view.orig(appToks.first().start, appToks.last().end), SlotStatus.EXPLICIT)
            }
            actionStart = split.start
        } else {
            val t0 = core(head[0].text)
            if (t0.length > 2 && t0.startsWith("و") && t0.drop(1) in ALL_VERBS) actionStart = head[0].start + 1
        }

        var r = n.substring(actionStart)
        val rToks0 = tokenize(r, 0)
        if (rToks0.isEmpty()) return Interpretation.Unsupported(rawText, "لا يوجد هدف بعد فتح التطبيق.")
        val v0 = core(rToks0[0].text)

        // "… في تطبيق X": the app named at the end of the command.
        // (not for "ابحث في X عن Y": there the app comes first and is read by the search rule itself)
        val appFirstSearch = v0 in SEARCH_VERBS && SEARCH_IN_APP_FIRST.containsMatchIn(r)
        val appTail = if (appFirstSearch) null else APP_TAIL.find(r)
        if (appTail != null) {
            val g = if (appTail.groups[1] != null) 1 else 2
            val gr = appTail.groups[g]!!.range
            if (slots.none { it.name == SlotName.APP }) {
                slots += Slot(SlotName.APP, view.orig(actionStart + gr.first, actionStart + gr.last + 1), SlotStatus.EXPLICIT)
            }
            r = r.substring(0, appTail.range.first).trimEnd()
        }
        val toks = tokenize(r, 0)
        val w = Work(view, envelope, quotes, r, actionStart, toks)

        // Payment first: it is refused whatever else the sentence says.
        val family: GoalFamily = when {
            DESCRIBE.containsMatchIn(r) -> GoalFamily.DESCRIBE_SCREEN
            v0 in PAY_VERBS || (v0 == "حول" && r.any { it.isDigit() }) -> GoalFamily.PAYMENT
            v0 in SEARCH_VERBS -> GoalFamily.SEARCH_IN_APP
            v0 in DELETE_VERBS -> GoalFamily.DELETE_ITEM
            v0 in SEND_VERBS -> GoalFamily.SEND_MESSAGE
            v0 in POST_DIRECT -> GoalFamily.CREATE_POST
            v0 in POST_CREATE && hasPostNoun(toks) -> GoalFamily.CREATE_POST
            v0 in TYPE_VERBS -> GoalFamily.ENTER_TEXT
            v0 in TAP_VERBS -> GoalFamily.TAP
            else -> return Interpretation.Unsupported(rawText, "لم أفهم الهدف المطلوب. أدعم: وصف الشاشة، الضغط على عنصر، الكتابة في حقل، البحث داخل تطبيق، نشر منشور، إرسال رسالة، حذف عنصر.")
        }

        val d: Draft = when (family) {
            GoalFamily.DESCRIBE_SCREEN, GoalFamily.PAYMENT -> Draft()
            GoalFamily.SEARCH_IN_APP -> parseSearch(w)
            GoalFamily.DELETE_ITEM -> parseTarget(w, SlotName.TARGET, deleteWord = true)
            GoalFamily.TAP -> parseTarget(w, SlotName.TARGET, deleteWord = false)
            GoalFamily.SEND_MESSAGE -> parseSend(w)
            GoalFamily.CREATE_POST -> parsePost(w)
            GoalFamily.ENTER_TEXT -> parseEnter(w)
        }
        slots += d.slots
        clar += d.clar
        statements += d.statements

        val goal = GoalComposer.compose(rawText, family, slots, ctx, clar, statements)
        return when {
            goal.risk.blocked -> Interpretation.Refused(goal, REFUSE_PAYMENT)
            goal.needsClarification -> Interpretation.NeedsClarification(goal)
            else -> Interpretation.Ready(goal)
        }
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Families

    private fun parseSearch(w: Work): Draft {
        // "ابحث في X عن Y": the app comes first.
        SEARCH_IN_APP_FIRST.find(w.r)?.let { m ->
            val appG = m.groups[1]!!.range
            val qG = m.groups[2]!!.range
            val q = w.quoteIn(qG.first, qG.last + 1).firstOrNull() ?: w.orig(qG.first, qG.last + 1)
            val slots = listOf(
                Slot(SlotName.APP, w.orig(appG.first, appG.last + 1), SlotStatus.EXPLICIT),
                Slot(SlotName.QUERY, q.ifBlank { null }, if (q.isBlank()) SlotStatus.MISSING else SlotStatus.EXPLICIT)
            )
            return Draft(slots)
        }
        val m = SEARCH_BODY.find(w.r) ?: return Draft(listOf(Slot(SlotName.QUERY, null, SlotStatus.MISSING)))
        val g = m.groups[1]!!.range
        val quoted = w.quoteIn(g.first, g.last + 1)
        val q = quoted.firstOrNull() ?: w.orig(g.first, g.last + 1)
        return Draft(listOf(Slot(SlotName.QUERY, q.ifBlank { null }, if (q.isBlank()) SlotStatus.MISSING else SlotStatus.EXPLICIT)))
    }

    /** TAP and DELETE: the element is named by the owner; "this"/"it" is not a name. */
    private fun parseTarget(w: Work, name: SlotName, deleteWord: Boolean): Draft {
        val from = w.toks.getOrNull(1)?.start ?: return Draft(listOf(Slot(name, null, SlotStatus.MISSING)))
        val quoted = w.quoteIn(from, w.r.length)
        if (quoted.size > 1) return Draft(listOf(Slot(name, null, SlotStatus.MISSING)), listOf(Clarification(name, "وجدتُ أكثر من نص بين علامتي تنصيص. أي عنصر تقصد؟")))
        var label = quoted.firstOrNull()
        if (label == null) {
            var i = 1
            val skip = if (deleteWord) SKIP_DELETE else SKIP_TAP
            while (i < w.toks.size && core(w.toks[i].text) in skip) i++
            val words = w.toks.drop(i).dropLastWhile { core(it.text) in TRAILING_UI }
            label = if (words.isEmpty()) null else w.orig(words.first().start, words.last().end)
        }
        val deictic = label == null || normalizedWords(label).all { it in DEICTIC_TARGET }
        if (deictic) {
            return Draft(
                listOf(Slot(name, null, SlotStatus.MISSING, "«هذا/هذه» ليس اسماً لعنصر")),
                statements = listOf(Statement("لم تُسمِّ العنصر بوضوح", Origin.UNKNOWN))
            )
        }
        return Draft(listOf(Slot(name, label, SlotStatus.EXPLICIT)))
    }

    private fun parsePost(w: Work): Draft {
        // After the verb: optionally a noun ("منشور"), optional adjectives, then maybe a marker and the text.
        var i = 1
        var sawNoun = false
        while (i < w.toks.size) {
            val c = core(w.toks[i].text)
            when {
                isPostNoun(c) -> { sawNoun = true; i++ }
                c in POST_FILLERS -> i++
                else -> break
            }
        }
        val from = w.toks.getOrNull(i)?.start ?: w.r.length
        val bareOk = core(w.toks[0].text) in POST_DIRECT && !sawNoun
        return textDraft(w, from, w.r.length, bareOk, SlotName.TEXT)
    }

    private fun parseSend(w: Work): Draft {
        val r = w.r
        val slots = ArrayList<Slot>()
        val clar = ArrayList<Clarification>()
        val st = ArrayList<Statement>()

        // "ارسل [رسالة] الى X [تقول Y]" / "send [a message] to X [saying Y]"
        val m = SEND_TO.find(r)
        if (m != null) {
            val g = m.groups[1]!!.range
            val tail = r.substring(g.first)
            val marker = TEXT_MARKER.find(tail)?.takeIf { it.range.first > 0 }
            val firstQuote = w.quoteIn(g.first, r.length).firstOrNull()
            val cut = when {
                marker != null -> g.first + marker.range.first
                firstQuote != null -> w.firstQuoteStart(g.first, r.length) ?: r.length
                else -> r.length
            }
            val recipient = w.orig(g.first, cut).trimEnd(':', ',', '،').trim()
            slots += if (recipient.isBlank()) Slot(SlotName.RECIPIENT, null, SlotStatus.MISSING)
            else Slot(SlotName.RECIPIENT, recipient, SlotStatus.EXPLICIT)
            val textFrom = if (cut < r.length) cut else r.length
            val td = textDraft(w, textFrom, r.length, bareOk = false, SlotName.TEXT)
            slots += td.slots; clar += td.clar; st += td.statements
            return Draft(slots, clar, st)
        }
        // "ارسل X الى Y": text first, recipient last
        val m2 = SEND_TEXT_TO.find(r)
        if (m2 != null) {
            val tg = m2.groups[1]!!.range
            val rg = m2.groups[2]!!.range
            val td = textDraft(w, tg.first, tg.last + 1, bareOk = true, SlotName.TEXT)
            slots += td.slots; clar += td.clar; st += td.statements
            val recipient = w.orig(rg.first, rg.last + 1)
            slots += Slot(SlotName.RECIPIENT, recipient.ifBlank { null }, if (recipient.isBlank()) SlotStatus.MISSING else SlotStatus.EXPLICIT)
            return Draft(slots, clar, st)
        }
        // No recipient found: whatever text there is is kept, the recipient is asked for.
        var i = 1
        while (i < w.toks.size && (isMessageNoun(core(w.toks[i].text)) || core(w.toks[i].text) in POST_FILLERS)) i++
        val from = w.toks.getOrNull(i)?.start ?: r.length
        val td = textDraft(w, from, r.length, bareOk = false, SlotName.TEXT)
        slots += Slot(SlotName.RECIPIENT, null, SlotStatus.MISSING)
        slots += td.slots; clar += td.clar; st += td.statements
        return Draft(slots, clar, st)
    }

    private fun parseEnter(w: Work): Draft {
        // The last "في/in <field noun …>" is the field; what is before it is the text.
        var cut = -1
        for (j in w.toks.indices.reversed()) {
            if (j == 0) break
            if (core(w.toks[j].text) !in FIELD_PREPS) continue
            val after = w.toks.drop(j + 1).take(3).map { core(it.text).removePrefix("ال") }
            if (after.any { it in FIELD_WORDS }) { cut = j; break }
        }
        val slots = ArrayList<Slot>()
        val textTo = if (cut >= 0) w.toks[cut].start else w.r.length
        if (cut >= 0 && cut + 1 < w.toks.size) {
            val field = w.orig(w.toks[cut + 1].start, w.toks.last().end)
            slots += Slot(SlotName.FIELD, field, SlotStatus.EXPLICIT)
        }
        val from = w.toks.getOrNull(1)?.start ?: w.r.length
        val td = textDraft(w, from, maxOf(from, textTo), bareOk = true, SlotName.TEXT)
        return Draft(slots + td.slots, td.clar, td.statements)
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Free text: quotes, an explicit marker, a reference to an attachment, or nothing

    private fun textDraft(w: Work, from: Int, to: Int, bareOk: Boolean, name: SlotName): Draft {
        val region = if (from < to) w.r.substring(from, to) else ""
        val regionTrim = region.trim()
        if (regionTrim.isEmpty()) return attachmentFallback(w, name, "لم يُذكر نص")

        val marker = TEXT_MARKER.find(region)?.takeIf { it.range.first <= 24 }
        val leadingColon = marker == null && regionTrim.startsWith(":")
        val candStart = from + when {
            marker != null -> marker.range.last + 1
            leadingColon -> region.indexOf(':') + 1
            else -> 0
        }
        val cand = if (candStart < to) w.r.substring(candStart, to) else ""
        val candTrim = cand.trim()

        val quoted = w.quoteIn(candStart, to).ifEmpty { w.quoteIn(from, to) }
        if (quoted.size > 1) {
            return Draft(
                listOf(Slot(name, null, SlotStatus.MISSING, "أكثر من نص بين علامتي تنصيص")),
                listOf(Clarification(name, "وجدتُ أكثر من نص بين علامتي تنصيص. أيها تريد؟ اتركْ نصاً واحداً."))
            )
        }
        if (quoted.size == 1) {
            val t = quoted[0]
            return if (t.isBlank()) attachmentFallback(w, name, "النص بين علامتي التنصيص فارغ")
            else Draft(listOf(Slot(name, t, SlotStatus.EXPLICIT, "بين علامتي تنصيص")))
        }
        if (candTrim.isEmpty()) return attachmentFallback(w, name, "لم يُذكر نص")

        if (candTrim.length <= 70 && REFERENCE.containsMatchIn(candTrim)) return referenceDraft(w, name)

        if (TOPIC.containsMatchIn(candTrim)) {
            return Draft(
                listOf(Slot(name, null, SlotStatus.MISSING, "طُلب موضوع لا نص")),
                listOf(Clarification(name, "ذكرتَ موضوعاً لا نصاً. لا أؤلف محتوى من عندي؛ أعطني النص نفسه بين علامتي تنصيص أو أرفقه كملف.")),
                listOf(Statement("المطلوب موضوع وليس نصاً جاهزاً", Origin.UNKNOWN))
            )
        }
        if (marker != null || leadingColon || bareOk) {
            val t = w.orig(candStart + (cand.length - cand.trimStart().length), to).trim()
            if (t.isNotEmpty()) return Draft(listOf(Slot(name, t, SlotStatus.EXPLICIT)))
        }
        return attachmentFallback(w, name, "لم يُذكر نص صريح")
    }

    /** The owner pointed at text they supplied ("the text I gave you"): it must exist as an attachment. */
    private fun referenceDraft(w: Work, name: SlotName): Draft {
        val atts = w.env.attachments
        return when {
            atts.size == 1 -> Draft(listOf(Slot(name, atts[0].text, SlotStatus.EXPLICIT, "من الملف المرفق «${atts[0].name}»")))
            atts.size > 1 -> Draft(
                listOf(Slot(name, null, SlotStatus.MISSING, "أكثر من ملف مرفق")),
                listOf(Clarification(name, "أرفقتَ ${atts.size} ملفات نصية (${atts.joinToString("، ") { "«${it.name}»" }}). أيها تقصد؟"))
            )
            else -> Draft(
                listOf(Slot(name, null, SlotStatus.REFERENCED_BUT_ABSENT,
                    if (w.env.unreadableNames.isNotEmpty()) "المرفقات غير النصية لا تُقرأ: ${w.env.unreadableNames.joinToString("، ")}" else "لا مرفق")),
                emptyList(),
                listOf(Statement("أشرتَ إلى نص أعطيتنيه ولم أجده", Origin.UNKNOWN))
            )
        }
    }

    /** No text in the command: a single attached text file is used (as an inference, shown to the owner), else it is asked for. */
    private fun attachmentFallback(w: Work, name: SlotName, why: String): Draft {
        val atts = w.env.attachments
        return when {
            atts.size == 1 -> Draft(listOf(Slot(name, atts[0].text, SlotStatus.INFERRED, "لم يُذكر نص في الأمر فاستُخدم المرفق الوحيد «${atts[0].name}»")))
            atts.size > 1 -> Draft(
                listOf(Slot(name, null, SlotStatus.MISSING, "أكثر من ملف مرفق")),
                listOf(Clarification(name, "أرفقتَ ${atts.size} ملفات نصية (${atts.joinToString("، ") { "«${it.name}»" }}). أيها تريد استخدامه؟"))
            )
            else -> Draft(listOf(Slot(name, null, SlotStatus.MISSING, why)))
        }
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Helpers

    private class Draft(
        val slots: List<Slot> = emptyList(),
        val clar: List<Clarification> = emptyList(),
        val statements: List<Statement> = emptyList()
    )

    private class Tok(val text: String, val start: Int, val end: Int)

    /** A normalised command with the way back to the original characters. */
    private class View(val typed: String, val al: AlignedText) {
        val norm: String = al.norm
        val runs: List<IntRange> = Regex("§+").findAll(norm).map { it.range }.toList()
        fun orig(from: Int, to: Int): String = al.span(from, to)?.let { typed.substring(it.first, it.last + 1).trim() } ?: ""
    }

    /** The working view of the goal clause: [r] is the normalised clause, [offset] its position inside the whole normalised command. */
    private class Work(val v: View, val env: CommandEnvelope, val quotes: List<String>, val r: String, val offset: Int, val toks: List<Tok>) {
        fun orig(from: Int, to: Int): String = v.orig(offset + from, offset + to)

        /** Quoted texts whose masked run lies inside [from, to) of the clause. */
        fun quoteIn(from: Int, to: Int): List<String> {
            val out = ArrayList<String>()
            for ((idx, run) in v.runs.withIndex()) {
                if (run.first >= offset + from && run.last < offset + to) quotes.getOrNull(idx)?.let { out += it }
            }
            return out
        }

        fun firstQuoteStart(from: Int, to: Int): Int? {
            for (run in v.runs) {
                if (run.first >= offset + from && run.last < offset + to) {
                    // include the opening quotation mark that precedes the masked run
                    val p = run.first - 1
                    return (if (p >= offset + from && v.norm[p] in QUOTE_CHARS) p else run.first) - offset
                }
            }
            return null
        }
    }

    private fun mask(typed: String): String {
        val sb = StringBuilder(typed)
        for (m in QUOTE.findAll(typed)) for (i in m.groups[1]!!.range) sb.setCharAt(i, '§')
        return sb.toString()
    }

    private fun tokenize(s: String, base: Int): List<Tok> =
        Regex("\\S+").findAll(s).map { Tok(it.value, base + it.range.first, base + it.range.last + 1) }.toList()

    private fun core(s: String): String = s.trim { !(it.isLetterOrDigit() || it == '§') }

    private fun normalizedWords(s: String): List<String> =
        com.venex.core.intent.TextNormalizer.normalize(s).split(' ').map(::core).filter { it.isNotEmpty() }

    private fun stripFillers(toks: List<Tok>): List<Tok> {
        var a = 0
        var b = toks.size
        while (a < b && core(toks[a].text) in FILLERS) a++
        while (b > a && core(toks[b - 1].text) in POLITE_TAIL) b--
        return toks.subList(a, b)
    }

    private class Split(val appEnd: Int, val start: Int)

    /** Where the action begins in "open X and <action>": after at least one app word, optionally after a conjunction. */
    private fun findActionStart(toks: List<Tok>): Split? {
        for (i in 2 until toks.size) {
            val t = core(toks[i].text)
            if (t in CONJ && i + 1 < toks.size && core(toks[i + 1].text).let { x -> x in ALL_VERBS || (x.startsWith("و") && x.drop(1) in ALL_VERBS) }) {
                val nxt = toks[i + 1]
                val off = if (core(nxt.text) in ALL_VERBS) 0 else 1
                return Split(i, nxt.start + off)
            }
            if (t.length > 2 && t.startsWith("و") && t.drop(1) in ALL_VERBS) return Split(i, toks[i].start + 1)
            if (t in ALL_VERBS) return Split(i, toks[i].start)
        }
        return null
    }

    private fun hasPostNoun(toks: List<Tok>): Boolean = toks.drop(1).take(4).any { isPostNoun(core(it.text)) }

    private fun isPostNoun(c: String): Boolean =
        c.startsWith("منشور") || c.startsWith("بوست") || c.startsWith("تغريد") || c.startsWith("تدوين") ||
            c == "post" || c == "posts" || c == "tweet" || c == "status"

    private fun isMessageNoun(c: String): Boolean = c.startsWith("رساله") || c.startsWith("رسال") || c in setOf("message", "msg", "sms", "text")

    companion object {
        const val MAX_COMMAND_CHARS = 20_000
        const val REFUSE_PAYMENT = "عمليات الدفع والشراء والتحويل محظورة في VENEX ولا تُنفَّذ حتى بموافقة."

        private const val B0 = "(?<![\\p{L}\\p{N}§])"
        private const val B1 = "(?![\\p{L}\\p{N}§])"
        private const val QUOTE_CHARS = "\"“«"

        private val QUOTE = Regex("[\"“«]([^\"”»]+)[\"”»]")
        private val LEAD = Regex("^(?:(?:please|ممكن|يمكنك|هل يمكنك|هل تستطيع|تقدر|لو سمحت|من فضلك|can you|could you|would you)\\s+)+")

        private val OPEN_VERBS = setOf("افتح", "افتحي", "شغل", "شغلي", "open", "launch", "start")
        private val SEARCH_VERBS = setOf("ابحث", "ابحثي", "دور", "search")
        private val POST_DIRECT = setOf("انشر", "انشري", "post", "publish", "tweet")
        private val POST_CREATE = setOf("انشئ", "انشئي", "اكتب", "اكتبي", "اعمل", "اضف", "create", "write", "make", "compose", "add")
        private val SEND_VERBS = setOf("ارسل", "ارسلي", "ابعث", "ابعثي", "send")
        private val DELETE_VERBS = setOf("احذف", "احذفي", "امسح", "امسحي", "ازل", "delete", "remove", "erase")
        private val TAP_VERBS = setOf("اضغط", "اضغطي", "انقر", "انقري", "اختر", "click", "tap", "press", "select")
        private val TYPE_VERBS = setOf("اكتب", "اكتبي", "ادخل", "ادخلي", "type", "enter", "write", "input")
        private val PAY_VERBS = setOf(
            "ادفع", "ادفعي", "اشتري", "اشتر", "اشتري", "اطلب", "تبرع", "اشترك", "دفع", "شراء", "تحويل",
            "pay", "buy", "purchase", "checkout", "transfer", "donate", "subscribe", "order"
        )
        private val ALL_VERBS = SEARCH_VERBS + POST_DIRECT + POST_CREATE + SEND_VERBS + DELETE_VERBS + TAP_VERBS + TYPE_VERBS + PAY_VERBS

        private val CONJ = setOf("و", "ثم", "and", "then")
        private val FILLERS = setOf("تطبيق", "برنامج", "لي", "app", "application", "the")
        private val POLITE_TAIL = setOf("لو", "سمحت", "من", "فضلك", "please")
        private val DEICTIC_APP = setOf("التطبيق", "هذا التطبيق", "التطبيق المفتوح", "التطبيق الحالي", "البرنامج", "هذا البرنامج", "the app", "this app", "current app", "the current app", "it", "هذا")
        private val DEICTIC_TARGET = setOf("هذا", "هذه", "ذلك", "تلك", "هنا", "هناك", "this", "that", "it", "here", "there", "the", "one", "هذا العنصر", "العنصر", "item", "thing", "الشيء", "شيء")
        private val SKIP_TAP = setOf("علي", "on", "the", "زر", "ازرار", "button", "ايقونه", "icon", "خيار", "option", "لي", "علي")
        private val SKIP_DELETE = setOf("ال", "the", "لي", "هذا", "هذه", "this")
        private val TRAILING_UI = setOf("button", "icon", "زر", "ايقونه")
        private val POST_FILLERS = setOf("لي", "جديد", "جديدا", "جديده", "واحد", "واحدا", "new", "a", "an", "the", "one", "بسيط", "بسيطا")
        private val FIELD_PREPS = setOf("في", "داخل", "into", "in", "on")
        private val FIELD_WORDS = setOf("حقل", "مربع", "خانه", "شريط", "field", "box", "bar", "input", "textbox")

        private val APP_TAIL = Regex("\\s(?:في|داخل|علي|in|inside|on|within)\\s+(?:(?:تطبيق|برنامج|application|app)\\s+(.+?)|(?:the\\s+)?(.+?)\\s+(?:app|application))\\s*$")
        private val SEARCH_IN_APP_FIRST = Regex("^(?:ابحث|ابحثي|دور|search)\\s+(?:في|داخل|in)\\s+(?:تطبيق\\s+|the\\s+)?(.+?)\\s+(?:عن|for)\\s+(.+)$", RegexOption.DOT_MATCHES_ALL)
        private val SEARCH_BODY = Regex("^(?:ابحث|ابحثي|دور|search)\\s+(?:لي\\s+)?(?:(?:عن|علي|for|about)\\s+)?(.+)$", RegexOption.DOT_MATCHES_ALL)
        private val SEND_TO = Regex("^\\S+\\s+(?:لي\\s+)?(?:(?:a|an|the)\\s+)?(?:(?:رساله|رسالة|message|msg|sms|text)\\s+)?(?:الي|الى|to)\\s+(.+)$", RegexOption.DOT_MATCHES_ALL)
        private val SEND_TEXT_TO = Regex("^\\S+\\s+(.+?)\\s+(?:الي|الى|to)\\s+(.+)$", RegexOption.DOT_MATCHES_ALL)

        /** Words that introduce the text of a post or message. Only recognised near the start of the text region. */
        private val TEXT_MARKER = Regex(
            "(?:(?:يحتوي|تحتوي|يتضمن|تتضمن)\\s+(?:علي\\s+)?|ينص\\s+علي\\s+|بالنص\\s+|نصه\\s+|نصها\\s+|يقول\\s+|تقول(?:\\s+له|\\s+لها)?\\s+|بمحتوي\\s+|" +
                "(?:that\\s+)?(?:says|contains|reads)\\s+|saying\\s+|containing\\s+|reading\\s+|with\\s+(?:the\\s+)?(?:text|content)\\s+|(?:the\\s+)?(?:text|content)\\s*:\\s*)"
        )

        /** "the text I gave you", "the attached file", "النص الذي أعطيتك إياه", "النص المرفق" */
        private val REFERENCE = Regex(
            "(?:(?:ال)?(?:نص|محتوي|كلام|ملف|رساله)$B1.*$B0(?:الذي|اللي|التي|المرفق|المرفقه|اعطيتك|اعطيتني|ارسلته|ارفقته|زودتك|قدمته|ارسلتها|اعطيتها)$B1)|" +
                "(?:$B0(?:اعطيتك|ارسلته|ارفقته|المرفق|المرفقه|اعطيتني)$B1)|" +
                "(?:(?:the\\s+)?(?:attached|above|previous)\\s+(?:text|file|content|message))|" +
                "(?:(?:text|content|file)\\s+(?:i|that\\s+i|which\\s+i)\\s+(?:gave|sent|attached|provided|shared))"
        )

        /** "about X" / "عن X": a subject, not text. */
        private val TOPIC = Regex("^(?:عن|حول|about|regarding)\\s+")

        private val DESCRIBE = Regex(
            "^(?:(?:ماذا|ما الذي|شو|ايش)\\s+.*(?:تري|الشاشه|امامك)|(?:صف|اوصف|اقرا|حلل|describe|read|analyze)\\s+(?:لي\\s+)?(?:the\\s+)?(?:ال)?(?:شاشه|screen).*|" +
                "what(?:'s|\\s+is|\\s+do\\s+you)\\s+.*(?:screen|see).*)$"
        )
    }
}

/** Convenience for approvals and stored tasks: a stable digest of the goal's content slot, never the text itself. */
fun StructuredGoal.contentDigest(): String? = ApprovalBinding.digestOf(value(SlotName.TEXT))
