package com.venex.core.ai

import com.venex.core.ai.ondevice.OnDeviceController
import com.venex.core.intent.AiProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Which AI path the OWNER chose. Exactly one is active at a time; OFF is the default.
 *  - SERVER: a model server the owner runs (Ollama / OpenAI-compatible), V0.1.1 behaviour;
 *  - CLOUD: a hosted provider with the owner's API key; the command text leaves the phone;
 *  - ON_DEVICE: a GGUF file run inside VENEX; works offline.
 */
enum class AiMode(val arabic: String) {
    OFF("بلا ذكاء اصطناعي (قواعد محلية فقط)"),
    SERVER("خادم محلي/شبكتي"),
    CLOUD("مزوّد سحابي (API)"),
    ON_DEVICE("داخل الهاتف (GGUF)")
}

/** Persisted choice. [cloudConsentHost] is the cloud host the owner acknowledged sending commands to. */
data class StoredAiMode(val mode: AiMode, val cloudConsentHost: String?)

interface AiModeStore {
    fun read(): StoredAiMode?
    fun write(value: StoredAiMode)
}

data class AiModeSnapshot(val mode: AiMode, val cloudConsentHost: String?)

/**
 * Chooses the single active provider and enforces the privacy rules:
 *  - nothing is sent to a cloud provider unless CLOUD is the active mode AND the owner acknowledged
 *    sending commands to THAT host (the acknowledgement is dropped when the host changes);
 *  - activating a mode switches the other modes off (a model is never consulted "in the background");
 *  - V0.1.1 data migrates without loss: with no stored mode, an enabled server model keeps working as SERVER.
 */
class AiModeRouter(
    private val store: AiModeStore,
    val server: AiSettingsController,
    val cloud: AiSettingsController,
    val onDevice: OnDeviceController,
    private val audit: (String) -> Unit = {}
) {
    private var stored: StoredAiMode = store.read() ?: migrate()

    private val _state = MutableStateFlow(AiModeSnapshot(stored.mode, stored.cloudConsentHost))
    val state: StateFlow<AiModeSnapshot> = _state.asStateFlow()

    private fun migrate(): StoredAiMode {
        // V0.1.1 had no mode: an enabled, verified server model meant "use it".
        val legacy = if (server.state.value.enabled) AiMode.SERVER else AiMode.OFF
        val m = StoredAiMode(legacy, null)
        store.write(m)
        return m
    }

    val mode: AiMode get() = stored.mode

    private fun set(m: StoredAiMode) {
        stored = m
        store.write(m)
        _state.value = AiModeSnapshot(m.mode, m.cloudConsentHost)
    }

    /** Stops every AI path. VENEX then uses only the offline rules. */
    suspend fun useRulesOnly() {
        server.disable()
        cloud.disable()
        onDevice.disable()
        set(stored.copy(mode = AiMode.OFF))
        audit("وضع الذكاء الاصطناعي: قواعد محلية فقط")
    }

    /**
     * Activates [target] after its own checks (inference test passed, etc.). Returns null on success or the
     * reason it could not be activated. [cloudConsent] must be true for CLOUD.
     */
    suspend fun activate(target: AiMode, cloudConsent: Boolean = false): String? {
        if (target == AiMode.OFF) { useRulesOnly(); return null }
        if (target == AiMode.CLOUD) {
            val host = cloudHost() ?: return "أعدّ المزوّد السحابي أولاً"
            if (!cloud.hasApiKey()) return "أدخل مفتاح API للمزوّد السحابي أولاً"
            if (!cloudConsent && stored.cloudConsentHost != host) {
                return "وافق أولاً على إرسال أوامرك إلى $host"
            }
        }
        val error = when (target) {
            AiMode.SERVER -> server.enable()
            AiMode.CLOUD -> cloud.enable()
            AiMode.ON_DEVICE -> onDevice.enable()
            AiMode.OFF -> null
        }
        if (error != null) return error
        // Only now switch the others off, so a failed activation does not leave the owner with nothing.
        if (target != AiMode.SERVER) server.disable()
        if (target != AiMode.CLOUD) cloud.disable()
        if (target != AiMode.ON_DEVICE) onDevice.disable()
        set(
            StoredAiMode(
                target,
                if (target == AiMode.CLOUD) cloudHost() else stored.cloudConsentHost?.takeIf { it == cloudHost() }
            )
        )
        audit("وضع الذكاء الاصطناعي: ${target.name}")
        return null
    }

    fun cloudHost(): String? = cloud.state.value.config?.baseUrl?.let { EndpointRules.hostOf(it) }

    /** The provider VENEX should use right now, or null (rules only). */
    fun activeIntentProvider(): AiProvider? = when (stored.mode) {
        AiMode.OFF -> null
        AiMode.SERVER -> server.activeIntentProvider()
        AiMode.ON_DEVICE -> onDevice.activeIntentProvider()
        AiMode.CLOUD -> {
            val host = cloudHost()
            if (host != null && stored.cloudConsentHost == host && cloud.hasApiKey()) cloud.activeIntentProvider() else null
        }
    }

    /** Human-readable label for the chat screen. */
    fun describe(): String = when (stored.mode) {
        AiMode.OFF -> "المحلل: قواعد محلية (بلا ذكاء اصطناعي)"
        AiMode.SERVER -> if (server.state.value.enabled) "المحلل: خادم نموذج (${server.state.value.config?.modelId.orEmpty()}) مع احتياط محلي"
        else "المحلل: قواعد محلية (بلا ذكاء اصطناعي)"
        AiMode.CLOUD -> if (activeIntentProvider() != null) "المحلل: مزوّد سحابي ${cloudHost()} (الأوامر غير المفهومة تُرسل إليه) مع احتياط محلي"
        else "المحلل: قواعد محلية (بلا ذكاء اصطناعي)"
        AiMode.ON_DEVICE -> if (activeIntentProvider() != null) "المحلل: نموذج داخل الهاتف مع احتياط محلي"
        else "المحلل: قواعد محلية (بلا ذكاء اصطناعي)"
    }
}
