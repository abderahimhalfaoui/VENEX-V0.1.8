package com.venex.core.intent

import com.venex.core.model.CalculateGoal
import com.venex.core.model.Goal
import com.venex.core.model.MathOp
import com.venex.core.model.NavTarget
import com.venex.core.model.NavigateGoal
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.RestrictedGoal
import com.venex.core.model.ScrollDirection
import com.venex.core.model.ScrollGoal
import com.venex.core.model.UnknownGoal
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Structured interpretation suggested by an AI provider. A suggestion is only a candidate: it is
 * converted by [LayeredIntentParser.toGoal], which accepts a closed set of intents and fields.
 *
 * Supported [intent] values and their [params]:
 *  - "open_app":  app
 *  - "calculate": left, op (add|subtract|multiply|divide), right
 *  - "navigate":  target (home|back)
 *  - "scroll":    direction (up|down)
 */
data class AiInterpretation(val intent: String, val params: Map<String, String> = emptyMap())

/** Intent-level seam for any model backend. Implementations may throw; the parser degrades safely. */
interface AiProvider {
    val name: String
    suspend fun interpret(text: String): AiInterpretation?
}

/** Default: no model, no network. */
object NoAiProvider : AiProvider {
    override val name: String = "none"
    override suspend fun interpret(text: String): AiInterpretation? = null
}

/** Where the goal came from. Used by tests and the audit to prove which component decided. */
enum class IntentSource { RESTRICTED_RULE, RULES, MODEL, NONE }

data class ParsedIntent(val goal: Goal, val source: IntentSource)

/**
 * Order of layers:
 *  1. RestrictedActionDetector (before any model; a model can never bypass it);
 *  2. offline rules (always available, no AI needed);
 *  3. the AI provider, only for commands the rules do not understand, under a timeout.
 * Any AI failure, timeout or invalid suggestion falls back to the rules' UnknownGoal.
 */
class LayeredIntentParser(
    private val rules: RuleBasedIntentParser = RuleBasedIntentParser(),
    private val ai: AiProvider = NoAiProvider,
    private val aiTimeoutMs: Long = 20_000
) : IntentParser {

    override suspend fun parse(text: String): Goal = parseWithSource(text).goal

    suspend fun parseWithSource(text: String): ParsedIntent {
        RestrictedActionDetector.detect(text)?.let { return ParsedIntent(RestrictedGoal(it, text), IntentSource.RESTRICTED_RULE) }

        val ruleGoal = rules.parseSync(text)
        if (ruleGoal !is UnknownGoal) return ParsedIntent(ruleGoal, IntentSource.RULES)

        val suggestion: AiInterpretation? = try {
            withTimeoutOrNull(aiTimeoutMs) { ai.interpret(text) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
        val modelGoal = suggestion?.let { toGoal(it, text) }
        return if (modelGoal != null) ParsedIntent(modelGoal, IntentSource.MODEL)
        else ParsedIntent(ruleGoal, IntentSource.NONE)
    }

    internal fun toGoal(s: AiInterpretation, raw: String): Goal? = when (s.intent) {
        "open_app" -> s.params["app"]?.trim()
            ?.takeIf { it.length in 2..60 && RestrictedActionDetector.detect(it) == null }
            ?.let { OpenAppGoal(it, raw) }
        "calculate" -> {
            val l = s.params["left"]?.toBigDecimalOrNull()
            val r = s.params["right"]?.toBigDecimalOrNull()
            val op = when (s.params["op"]) {
                "add" -> MathOp.ADD
                "subtract" -> MathOp.SUBTRACT
                "multiply" -> MathOp.MULTIPLY
                "divide" -> MathOp.DIVIDE
                else -> null
            }
            if (l != null && r != null && op != null) CalculateGoal(l, op, r, raw) else null
        }
        "navigate" -> when (s.params["target"]) {
            "home" -> NavigateGoal(NavTarget.HOME, raw)
            "back" -> NavigateGoal(NavTarget.BACK, raw)
            else -> null
        }
        "scroll" -> when (s.params["direction"]) {
            "up" -> ScrollGoal(ScrollDirection.UP, raw)
            "down" -> ScrollGoal(ScrollDirection.DOWN, raw)
            else -> null
        }
        else -> null // includes "unsupported": the model cannot create unsupported goals
    }
}
