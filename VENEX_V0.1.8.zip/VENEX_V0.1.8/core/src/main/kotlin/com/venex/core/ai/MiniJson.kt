package com.venex.core.ai

import java.math.BigDecimal

/**
 * Small, dependency-free JSON reader/writer for model traffic. Numbers are read as [BigDecimal]
 * so that amounts are never silently rounded. Input size and nesting are bounded.
 */
object MiniJson {

    class JsonException(message: String) : Exception(message)

    private const val MAX_DEPTH = 16
    private const val MAX_INPUT_CHARS = 16_000
    private const val MAX_NUMBER_CHARS = 40

    /** Parses one complete JSON document. Throws [JsonException] on syntax errors or trailing data. */
    fun parse(text: String): Any? {
        if (text.length > MAX_INPUT_CHARS) throw JsonException("input too large")
        val p = Parser(text)
        val value = p.value(0)
        p.skipWs()
        if (!p.atEnd()) throw JsonException("trailing data")
        return value
    }

    /**
     * Finds the first JSON object inside free text (prose before/after, code fences, ...).
     * Returns null when no object parses.
     */
    fun firstObject(text: String): Map<String, Any?>? {
        if (text.length > MAX_INPUT_CHARS) return null
        var start = text.indexOf('{')
        var tries = 0
        while (start >= 0 && tries < 5) {
            try {
                val value = Parser(text, start).value(0)
                if (value is Map<*, *>) {
                    @Suppress("UNCHECKED_CAST")
                    return value as Map<String, Any?>
                }
            } catch (_: JsonException) {
                // try the next '{'
            }
            tries++
            start = text.indexOf('{', start + 1)
        }
        return null
    }

    fun encode(value: Any?): String {
        val sb = StringBuilder()
        write(sb, value)
        return sb.toString()
    }

    private fun write(sb: StringBuilder, v: Any?) {
        when (v) {
            null -> sb.append("null")
            is String -> quote(sb, v)
            is Boolean -> sb.append(if (v) "true" else "false")
            is Number -> sb.append(v.toString())
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, x) in v) {
                    if (!first) sb.append(',')
                    first = false
                    quote(sb, k.toString())
                    sb.append(':')
                    write(sb, x)
                }
                sb.append('}')
            }
            is List<*> -> {
                sb.append('[')
                v.forEachIndexed { i, x ->
                    if (i > 0) sb.append(',')
                    write(sb, x)
                }
                sb.append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
    }

    private class Parser(private val s: String, var pos: Int = 0) {

        fun atEnd(): Boolean = pos >= s.length

        fun skipWs() {
            while (pos < s.length && s[pos].isWhitespace()) pos++
        }

        private fun peek(): Char {
            if (pos >= s.length) throw JsonException("unexpected end")
            return s[pos]
        }

        private fun expect(c: Char) {
            if (peek() != c) throw JsonException("expected '$c'")
            pos++
        }

        fun value(depth: Int): Any? {
            if (depth > MAX_DEPTH) throw JsonException("too deep")
            skipWs()
            return when (peek()) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> str()
                't' -> literal("true", true)
                'f' -> literal("false", false)
                'n' -> literal("null", null)
                else -> num()
            }
        }

        private fun literal(word: String, v: Any?): Any? {
            if (!s.startsWith(word, pos)) throw JsonException("bad literal")
            pos += word.length
            return v
        }

        private fun obj(depth: Int): Map<String, Any?> {
            expect('{')
            val out = LinkedHashMap<String, Any?>()
            skipWs()
            if (peek() == '}') {
                pos++
                return out
            }
            while (true) {
                skipWs()
                if (peek() != '"') throw JsonException("key expected")
                val key = str()
                skipWs()
                expect(':')
                out[key] = value(depth + 1)
                skipWs()
                when (peek()) {
                    ',' -> pos++
                    '}' -> {
                        pos++
                        return out
                    }
                    else -> throw JsonException("bad object")
                }
            }
        }

        private fun arr(depth: Int): List<Any?> {
            expect('[')
            val out = ArrayList<Any?>()
            skipWs()
            if (peek() == ']') {
                pos++
                return out
            }
            while (true) {
                out += value(depth + 1)
                skipWs()
                when (peek()) {
                    ',' -> pos++
                    ']' -> {
                        pos++
                        return out
                    }
                    else -> throw JsonException("bad array")
                }
            }
        }

        private fun str(): String {
            expect('"')
            val sb = StringBuilder()
            while (true) {
                val c = peek()
                pos++
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        val e = peek()
                        pos++
                        when (e) {
                            '"', '\\', '/' -> sb.append(e)
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > s.length) throw JsonException("bad unicode escape")
                                val code = s.substring(pos, pos + 4).toIntOrNull(16)
                                if (code == null || code < 0) throw JsonException("bad unicode escape")
                                sb.append(code.toChar())
                                pos += 4
                            }
                            else -> throw JsonException("bad escape")
                        }
                    }
                    c < ' ' -> throw JsonException("control character in string")
                    else -> sb.append(c)
                }
            }
        }

        private fun num(): BigDecimal {
            val start = pos
            if (pos < s.length && s[pos] == '-') pos++
            val intStart = pos
            while (pos < s.length && isDigit(s[pos])) pos++
            if (pos == intStart) throw JsonException("bad number")
            if (pos < s.length && s[pos] == '.') {
                pos++
                val fracStart = pos
                while (pos < s.length && isDigit(s[pos])) pos++
                if (pos == fracStart) throw JsonException("bad number")
            }
            if (pos < s.length && (s[pos] == 'e' || s[pos] == 'E')) {
                pos++
                if (pos < s.length && (s[pos] == '+' || s[pos] == '-')) pos++
                val expStart = pos
                while (pos < s.length && isDigit(s[pos])) pos++
                if (pos == expStart) throw JsonException("bad number")
            }
            if (pos - start > MAX_NUMBER_CHARS) throw JsonException("number too long")
            return try {
                BigDecimal(s.substring(start, pos))
            } catch (e: NumberFormatException) {
                throw JsonException("bad number")
            }
        }

        private fun isDigit(c: Char): Boolean = c in '0'..'9'
    }
}
