package com.venex.core.device

import com.venex.core.model.Action

sealed interface Route {
    data class Use(val channel: Channel) : Route
    data class Unavailable(val reason: String) : Route
}

/**
 * Chooses the execution channel for an action from what the device offers. Official, narrow
 * channels (Intents, deep links) are preferred over UI automation; Accessibility is used only for
 * actions that need to read or touch another app's UI.
 */
object ChannelRouter {

    fun route(action: Action, available: Set<Channel>): Route = when (action) {
        is Action.OpenApp ->
            if (Channel.INTENT in available) Route.Use(Channel.INTENT)
            else Route.Unavailable("قناة Android Intents غير متاحة")

        is Action.OpenDeepLink ->
            if (Channel.DEEP_LINK in available) Route.Use(Channel.DEEP_LINK)
            else Route.Unavailable("قناة الروابط العميقة غير متاحة")

        is Action.Click, is Action.TypeText, is Action.Scroll, Action.ReadScreen, is Action.Press ->
            if (Channel.ACCESSIBILITY in available) Route.Use(Channel.ACCESSIBILITY)
            else Route.Unavailable("هذه العملية تتطلب تفعيل خدمة إمكانية الوصول (Accessibility) من إعدادات النظام")
    }
}
