package com.venex.core.ai

/**
 * Removes model-internal text from a reply before it is parsed, tested or shown.
 *
 * Qwen3-style models reason inside `<think> … </think>` and may leak that text (or chat-control tokens)
 * into the reply. Such text is never an answer: a reply that contains only reasoning becomes empty, which
 * the callers treat as a failure, not as success.
 */
object ModelOutputSanitizer {

    private val THINK_BLOCK = Regex("<think>[\\s\\S]*?</think>", RegexOption.IGNORE_CASE)
    private val CONTROL_TOKENS = Regex("<\\|im_start\\|>|<\\|im_end\\|>|<\\|endoftext\\|>")

    fun clean(raw: String): String {
        var s = THINK_BLOCK.replace(raw, " ")
        // An opened but never closed reasoning block: everything after it is reasoning, not answer.
        val open = s.indexOf("<think>", ignoreCase = true)
        if (open >= 0) s = s.substring(0, open)
        // A dangling closing tag is also internal.
        s = s.replace("</think>", " ", ignoreCase = true)
        return CONTROL_TOKENS.replace(s, " ").trim()
    }

    /** True when the raw reply contained reasoning markers at all (for diagnostics; the text is not shown). */
    fun containsReasoning(raw: String): Boolean =
        raw.contains("<think>", ignoreCase = true) || raw.contains("</think>", ignoreCase = true)
}
