package com.venex.core.adaptive

import com.venex.core.env.UiElement
import com.venex.core.model.ScrollDirection

/** Hard bounds on one task. Whatever happens, the runner stops at these and tells the owner why. */
data class RunLimits(
    val maxStepsExecuted: Int = 40,
    val maxRecoveriesPerStep: Int = 2,
    val maxRecoveriesTotal: Int = 8,
    val maxWaitPolls: Int = 6,
    val pollIntervalMs: Long = 400,
    val maxDurationMs: Long = 180_000
)

/** What went wrong at a step, stated by facts, for the recovery decision. */
sealed interface Situation {
    data class NotFound(val what: String) : Situation
    data class Ambiguous(val labels: List<String>) : Situation
    data class NotAddressable(val reason: String) : Situation

    /** The action did not run (resolution or safety refused it, or the device reported failure). Nothing was pressed. */
    data class NotExecuted(val reason: String) : Situation

    /** The action ran, but its expectation was observed to be false. */
    data class ExecutedButContradicted(val detail: String) : Situation
    data class Interrupted(val dismiss: UiElement) : Situation
    data object WrongApp : Situation
}

sealed interface Recovery {
    data class ScrollToFind(val direction: ScrollDirection) : Recovery
    data class Dismiss(val element: UiElement) : Recovery
    data object ReopenApp : Recovery
    data object RetryStep : Recovery
    data class AskOwner(val reason: String) : Recovery
    data class GiveUp(val reason: String) : Recovery
}

class RecoveryLedger(private val limits: RunLimits) {
    private val perStep = HashMap<String, Int>()
    var total = 0
        private set

    fun used(stepId: String): Int = perStep[stepId] ?: 0

    /** Takes one recovery for [stepId] if the bounds allow it. */
    fun tryConsume(stepId: String): Boolean {
        if (used(stepId) >= limits.maxRecoveriesPerStep || total >= limits.maxRecoveriesTotal) return false
        perStep[stepId] = used(stepId) + 1
        total++
        return true
    }
}

/**
 * Chooses a bounded recovery. Two rules sit above everything else:
 *  - a sensitive step that already ran is never repeated by recovery (no double send/post/delete);
 *  - a step is retried only when running it again is harmless: it is not sensitive and it can tell for itself that
 *    its result is already there (it has skip conditions).
 */
object RecoveryEngine {

    fun decide(step: AdaptiveStep, effectiveSensitive: Boolean, s: Situation, ledger: RecoveryLedger): Recovery {
        val attempt = ledger.used(step.id)
        fun allowed() = ledger.tryConsume(step.id)
        val idempotent = step.skipWhen.isNotEmpty()

        return when (s) {
            is Situation.Ambiguous ->
                Recovery.AskOwner("وجدتُ أكثر من عنصر يطابق «${stepTarget(step)}» (${s.labels.take(4).joinToString("، ") { "«$it»" }}) ولا أخمّن بينها. أيها تقصد؟")
            is Situation.NotAddressable -> Recovery.GiveUp(s.reason)
            is Situation.NotFound ->
                if (attempt < 2 && allowed()) Recovery.ScrollToFind(if (attempt == 0) ScrollDirection.DOWN else ScrollDirection.UP)
                else Recovery.AskOwner("لم أجد «${s.what}» على الشاشة. هل الشاشة الصحيحة مفتوحة؟")
            is Situation.NotExecuted ->
                // Nothing was pressed, so one more try is safe even for a sensitive step.
                if (attempt < 1 && allowed()) Recovery.RetryStep else Recovery.GiveUp(s.reason)
            is Situation.ExecutedButContradicted ->
                when {
                    effectiveSensitive -> Recovery.GiveUp("نُفِّذت خطوة حساسة ولم أرصد نتيجتها (${s.detail}). لن أكرّرها تلقائياً حتى لا تتكرر العملية.")
                    idempotent && attempt < 1 && allowed() -> Recovery.RetryStep
                    else -> Recovery.GiveUp("لم تتحقق نتيجة الخطوة: ${s.detail}")
                }
            is Situation.Interrupted ->
                if (allowed()) Recovery.Dismiss(s.dismiss) else Recovery.AskOwner("تتكرر نوافذ غير متوقعة. أغلقها بنفسك ثم قل لي «استأنف».")
            Situation.WrongApp ->
                if (allowed()) Recovery.ReopenApp else Recovery.AskOwner("يخرج التطبيق من المقدمة. افتحه بنفسك ثم قل لي «استأنف».")
        }
    }

    private fun stepTarget(step: AdaptiveStep): String = when (val i = step.intent) {
        is StepIntent.Tap -> i.target.description
        is StepIntent.Type -> i.target.description
        else -> step.description
    }
}
