package com.venex.core.model

import com.venex.core.goal.StructuredGoal

/**
 * V0.1.8: a goal handled by the adaptive layer (see com.venex.core.adaptive). It is a [Goal] only so the existing
 * report types (TaskReport) and UI keep working unchanged; the classic TaskPlanner never executes it.
 *
 * [structured] is null for a request to resume the last paused task ([resume] = true).
 */
data class AdaptiveGoal(
    val structured: StructuredGoal?,
    val resume: Boolean,
    override val rawText: String
) : Goal
