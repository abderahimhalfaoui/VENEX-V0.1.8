package com.venex.core.env

enum class ChangeKind {
    /** There was no earlier model to compare with. */
    INITIAL,

    /** Same structure, same content. */
    NONE,

    /** The same screen with different text/state, or a small structural change (list items added or removed). */
    CONTENT_CHANGED,

    /** A different screen of the same app. */
    SCREEN_CHANGED,

    /** A different foreground application. */
    APP_CHANGED,

    /** A dialog or a system permission prompt appeared. */
    POPUP_APPEARED,

    /** The screen was readable and now is not. */
    ACCESS_LOST,
    ACCESS_REGAINED
}

data class ScreenDiff(
    val kind: ChangeKind,
    val appeared: List<ElementId>,
    val disappeared: List<ElementId>,
    val textChanged: List<ElementId>,
    /** Jaccard similarity of the two screens' element identities (1.0 = same structure). */
    val similarity: Double,
    val note: String
) {
    /** True when anything observable differs. */
    val changed: Boolean get() = kind != ChangeKind.NONE && kind != ChangeKind.INITIAL
}

object ScreenDiffer {

    /** At or above this identity overlap a difference is treated as a change of content, not a new screen. */
    const val SAME_SCREEN_SIMILARITY = 0.8

    fun diff(prev: EnvironmentModel?, cur: EnvironmentModel): ScreenDiff {
        if (prev == null) return ScreenDiff(ChangeKind.INITIAL, emptyList(), emptyList(), emptyList(), 0.0, "أول مراقبة")
        val a = prev.screen
        val b = cur.screen
        if (a == null && b == null) return ScreenDiff(ChangeKind.NONE, emptyList(), emptyList(), emptyList(), 1.0, "الشاشة غير مقروءة في المرتين")
        if (a != null && b == null) return ScreenDiff(ChangeKind.ACCESS_LOST, emptyList(), a.elements.map { it.id }, emptyList(), 0.0, cur.state.reason)
        if (a == null && b != null) return ScreenDiff(ChangeKind.ACCESS_REGAINED, b.elements.map { it.id }, emptyList(), emptyList(), 0.0, "عادت قراءة الشاشة")
        a!!; b!!

        val idsA = a.elements.map { it.id }.toSet()
        val idsB = b.elements.map { it.id }.toSet()
        val union = (idsA + idsB).size
        val sim = if (union == 0) 1.0 else (idsA intersect idsB).size.toDouble() / union
        val appeared = b.elements.map { it.id }.filter { it !in idsA }
        val gone = a.elements.map { it.id }.filter { it !in idsB }
        val changedText = changedTextIds(a, b)

        val popupKinds = setOf(UiStateKind.DIALOG, UiStateKind.PERMISSION_PROMPT)
        if (cur.state.kind in popupKinds && prev.state.kind != cur.state.kind) {
            return ScreenDiff(ChangeKind.POPUP_APPEARED, appeared, gone, changedText, sim, "ظهرت نافذة (${cur.state.kind})")
        }
        if (prev.packageName != cur.packageName) {
            return ScreenDiff(ChangeKind.APP_CHANGED, appeared, gone, changedText, sim, "من ${prev.packageName} إلى ${cur.packageName}")
        }
        if (a.screenId == b.screenId) {
            return if (a.contentId == b.contentId) ScreenDiff(ChangeKind.NONE, emptyList(), emptyList(), emptyList(), 1.0, "لا تغيّر")
            else ScreenDiff(ChangeKind.CONTENT_CHANGED, emptyList(), emptyList(), changedText, 1.0, "تغيّر المحتوى (${changedText.size} عنصراً)")
        }
        return if (sim >= SAME_SCREEN_SIMILARITY) {
            ScreenDiff(ChangeKind.CONTENT_CHANGED, appeared, gone, changedText, sim, "تغيّر بنيوي طفيف")
        } else {
            ScreenDiff(ChangeKind.SCREEN_CHANGED, appeared, gone, changedText, sim, "شاشة مختلفة (تشابه ${"%.2f".format(sim)})")
        }
    }

    private fun changedTextIds(a: ScreenModel, b: ScreenModel): List<ElementId> {
        val before = a.elements.associate { it.id to (it.node.text to it.node.contentDescription) }
        return b.elements.filter { e ->
            val old = before[e.id]
            old != null && old != (e.node.text to e.node.contentDescription)
        }.map { it.id }
    }
}
