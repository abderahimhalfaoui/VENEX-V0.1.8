package com.venex.core.model

import java.math.BigDecimal

/**
 * Identifies a UI element by visible text / content description and optionally by view id.
 * Matching is exact (case-insensitive, trimmed) on the labels, never substring-based, so that
 * pressing "5" can never hit the "125" display.
 */
data class Selector(val labels: List<String> = emptyList(), val idContains: String? = null) {
    init {
        require(labels.isNotEmpty() || idContains != null) { "Selector needs labels or an id fragment" }
    }

    fun describe(): String = labels.firstOrNull() ?: "id~$idContains"
}

enum class GlobalKey { HOME, BACK }

/** A single atomic operation executed by the engine through a DeviceController. */
sealed interface Action {
    /** Launches an installed app by (Arabic or English) name via Android Intents. */
    data class OpenApp(val appName: String) : Action

    /** Opens a URI via ACTION_VIEW (restricted scheme allow-list on the Android side). */
    data class OpenDeepLink(val uri: String) : Action

    data class Click(val selector: Selector) : Action

    data class TypeText(val selector: Selector?, val text: String) : Action

    data class Scroll(val direction: ScrollDirection) : Action

    data class Press(val key: GlobalKey) : Action

    /** Reads the current screen tree (no side effects); used to gather evidence. */
    data object ReadScreen : Action
}

/** What must be observably true after a step for it to count as verified. */
sealed interface Expectation {
    /** The app launched by an earlier OpenApp step must be the foreground package. */
    data object OpenedAppInForeground : Expectation

    /** A calculator-like screen shows [expected] as its result. [operands] guards against false positives. */
    data class CalculatorShows(val expected: BigDecimal, val operands: List<BigDecimal>) : Expectation

    data class ScreenContainsText(val text: String) : Expectation
}

data class Step(
    val id: String,
    val description: String,
    val action: Action,
    val dependsOn: List<String> = emptyList(),
    val expectation: Expectation? = null,
    /** If true, the engine asks the user for explicit approval before running this step. */
    val needsConfirmation: Boolean = false,
    /** If true, failure does not abort dependents (e.g. an optional "clear" key press). */
    val optional: Boolean = false,
    /** Attempts for the *action* itself (only re-run when the action reported failure). */
    val maxAttempts: Int = 1,
    /** Re-reads of the screen when verification fails (does not repeat the action). */
    val verifyAttempts: Int = 3
)

data class Plan(
    val goal: Goal,
    val steps: List<Step>,
    /** Non-null when the goal cannot / must not be executed; [steps] is then empty. */
    val blockedReason: String? = null
)
