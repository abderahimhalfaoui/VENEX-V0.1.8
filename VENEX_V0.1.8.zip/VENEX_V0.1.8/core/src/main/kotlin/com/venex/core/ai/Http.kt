package com.venex.core.ai

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URI
import java.net.UnknownHostException

/**
 * Single place where HTTP is performed for model providers.
 *  - redirects are not followed (a redirect could move credentials to another host);
 *  - reply bodies are capped; error bodies are never copied into user-facing messages;
 *  - the bearer token is sent only when present and is never logged.
 */
internal object Http {

    private const val MAX_BODY_BYTES = 1_000_000

    class Reply(val code: Int, val body: String)

    fun send(url: String, method: String, jsonBody: String?, spec: ConnectionSpec): Reply {
        val conn = URI(url).toURL().openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.instanceFollowRedirects = false
            conn.connectTimeout = spec.timeoutMs
            conn.readTimeout = spec.timeoutMs
            conn.useCaches = false
            conn.setRequestProperty("Accept", "application/json")
            spec.bearer?.takeIf { it.isNotBlank() }?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
            if (jsonBody != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { it.write(jsonBody.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream: InputStream? = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.use { readLimited(it) }.orEmpty()
            return Reply(code, body)
        } catch (e: SocketTimeoutException) {
            throw ProviderIo(FailureKind.TIMEOUT, "انتهت مهلة الانتظار قبل أن يردّ الخادم")
        } catch (e: ConnectException) {
            throw ProviderIo(FailureKind.UNREACHABLE, "الخادم غير متاح أو المنفذ مغلق")
        } catch (e: UnknownHostException) {
            throw ProviderIo(FailureKind.UNREACHABLE, "تعذّر العثور على اسم المضيف")
        } catch (e: IOException) {
            throw ProviderIo(FailureKind.UNREACHABLE, "حدث خطأ في الشبكة أثناء الاتصال")
        } finally {
            conn.disconnect()
        }
    }

    private fun readLimited(input: InputStream): String {
        val buf = ByteArray(8192)
        val out = ByteArrayOutputStream()
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > MAX_BODY_BYTES) throw ProviderIo(FailureKind.INVALID_RESPONSE, "الرد أكبر من الحد المسموح")
            out.write(buf, 0, n)
        }
        return out.toString(Charsets.UTF_8.name())
    }

    fun statusFailure(code: Int): ProviderResult<Nothing> = when (code) {
        401, 403 -> ProviderResult.Err(ProviderFailure(FailureKind.UNAUTHORIZED, "الخادم رفض بيانات الدخول (HTTP $code)"))
        else -> ProviderResult.Err(ProviderFailure(FailureKind.HTTP_ERROR, "الخادم أعاد خطأ HTTP $code"))
    }

    fun <T> invalid(message: String = "الرد لا يحتوي على البيانات المتوقعة"): ProviderResult<T> =
        ProviderResult.Err(ProviderFailure(FailureKind.INVALID_RESPONSE, message))

    fun <T> empty(): ProviderResult<T> =
        ProviderResult.Err(ProviderFailure(FailureKind.EMPTY_RESPONSE, "الرد فارغ"))

    fun elapsedMs(startNanos: Long): Long = (System.nanoTime() - startNanos) / 1_000_000
}
