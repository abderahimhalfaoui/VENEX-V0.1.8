package com.venex.core.intent

/** Normalizes Arabic/English command text so rules and app names can be matched reliably. */
object TextNormalizer {

    private val diacritics = Regex("[ً-ٰٟـ]")
    private val spaces = Regex("\\s+")

    fun normalize(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            sb.append(
                when (ch) {
                    in '٠'..'٩' -> '0' + (ch - '٠') // Arabic-Indic digits
                    in '۰'..'۹' -> '0' + (ch - '۰') // Persian digits
                    '٫' -> '.'                                // Arabic decimal separator
                    '،' -> ' '                                // Arabic comma
                    '؟' -> ' '                                // Arabic question mark
                    'أ', 'إ', 'آ', 'ٱ' -> 'ا' // أ إ آ ٱ -> ا
                    'ى' -> 'ي'                           // ى -> ي
                    'ة' -> 'ه'                           // ة -> ه
                    else -> ch
                }
            )
        }
        return sb.toString()
            .replace(diacritics, "")
            .lowercase()
            .replace(spaces, " ")
            .trim()
    }
}
