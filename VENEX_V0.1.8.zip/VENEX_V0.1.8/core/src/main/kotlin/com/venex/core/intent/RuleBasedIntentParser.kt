package com.venex.core.intent

import com.venex.core.model.CalculateGoal
import com.venex.core.model.Goal
import com.venex.core.model.MathOp
import com.venex.core.model.NavTarget
import com.venex.core.model.NavigateGoal
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.ScrollDirection
import com.venex.core.model.ScrollGoal
import com.venex.core.model.SearchInAppGoal
import com.venex.core.model.UnknownGoal
import java.math.BigDecimal

/**
 * Offline Arabic/English command parser. It needs no network, API key or model.
 * Supported: calculate, open app, home/back, scroll.
 *
 * Audit fix: a calculation with more than two numbers (e.g. "2 + 3 + 4") used to be silently
 * truncated to its first pair. It is now refused, so the user is never shown a partial result.
 */
class RuleBasedIntentParser : IntentParser {

    override suspend fun parse(text: String): Goal = parseSync(text)

    fun parseSync(text: String): Goal {
        val n = TextNormalizer.normalize(text)
        if (n.isEmpty()) return UnknownGoal(text)

        parseCalculation(n)?.let { (l, op, r) -> return CalculateGoal(l, op, r, text) }
        parseNavigation(n)?.let { return NavigateGoal(it, text) }
        parseScroll(n)?.let { return ScrollGoal(it, text) }
        parseOpenAndSearch(n, text)?.let { return it }
        parseOpenApp(n)?.let { return OpenAppGoal(it, text) }
        return UnknownGoal(text)
    }

    private fun parseCalculation(n: String): Triple<BigDecimal, MathOp, BigDecimal>? {
        if (NUMBER.findAll(n).count() != 2) return null
        val m = CALC.find(n) ?: return null
        val left = m.groupValues[1].toBigDecimalOrNull() ?: return null
        val right = m.groupValues[3].toBigDecimalOrNull() ?: return null
        val op = operatorFrom(m.groupValues[2]) ?: return null
        return Triple(left, op, right)
    }

    private fun operatorFrom(raw: String): MathOp? {
        val o = raw.trim()
        return when {
            o in listOf("×", "✕", "x", "*", "في") || o.startsWith("ضرب") -> MathOp.MULTIPLY
            o in listOf("+", "زايد", "زاءد", "زائد", "جمع") -> MathOp.ADD
            o in listOf("-", "−", "–", "ناقص", "طرح") -> MathOp.SUBTRACT
            o in listOf("÷", "/") || o.startsWith("مقسوم") || o.startsWith("قسمه") || o == "علي" -> MathOp.DIVIDE
            else -> null
        }
    }

    private fun parseNavigation(n: String): NavTarget? = when {
        HOME_WORDS.any { n.contains(it) } -> NavTarget.HOME
        BACK_WORDS.any { n == it || n.startsWith("$it ") } -> NavTarget.BACK
        else -> null
    }

    private fun parseScroll(n: String): ScrollDirection? {
        val tokens = n.split(' ')
        if (tokens.none { it in SCROLL_VERBS }) return null
        return if (tokens.any { it in UP_WORDS }) ScrollDirection.UP else ScrollDirection.DOWN
    }

    private fun parseOpenApp(n: String): String? {
        val verb = OPEN_VERBS.firstOrNull { n == it || n.startsWith("$it ") } ?: return null
        var rest = stripPolite(n.removePrefix(verb).trim())
        // Filler words may stack ("افتح لي تطبيق الكاميرا"), so strip repeatedly.
        repeat(3) {
            val filler = FILLERS.firstOrNull { rest.startsWith("$it ") } ?: return@repeat
            rest = rest.removePrefix(filler).trim()
        }
        return rest.takeIf { it.length >= 2 }
    }

    /**
     * "افتح يوتيوب وابحث عن أغنية" -> app "يوتيوب", query "أغنية" (as typed). Without this split the whole rest of the
     * sentence became the app name and nothing could be resolved.
     */
    private fun parseOpenAndSearch(n: String, raw: String): Goal? {
        val m = OPEN_AND_SEARCH.find(n) ?: return null
        var app = stripPolite(m.groupValues[1].trim())
        repeat(3) {
            val filler = FILLERS.firstOrNull { app.startsWith("$it ") } ?: return@repeat
            app = app.removePrefix(filler).trim()
        }
        val query = stripPolite(m.groupValues[2].trim())
        if (app.length < 2 || query.length !in 2..80) return null
        // The normalized form is for matching only; the search must carry the user's own words
        // ("أغنية", "Lofi Music"), not "اغنيه" / "lofi music".
        return SearchInAppGoal(app, originalWords(raw, query), raw)
    }

    /**
     * Maps a query found in the normalized text back to the words as the user typed them: the last run of
     * raw words whose normalized forms equal the normalized query. If no such run exists (for example a word
     * that normalizes into two), the normalized query is returned unchanged rather than guessing.
     */
    private fun originalWords(raw: String, normalizedQuery: String): String {
        val wanted = normalizedQuery.split(' ').map(::trimPunctuation).filter { it.isNotEmpty() }
        if (wanted.isEmpty()) return normalizedQuery
        val pairs = raw.split(Regex("\\s+"))
            .map(::trimPunctuation)
            .map { TextNormalizer.normalize(it) to it }
            .filter { it.first.isNotEmpty() && !it.first.contains(' ') }
        for (start in pairs.size - wanted.size downTo 0) {
            if (wanted.indices.all { pairs[start + it].first == wanted[it] }) {
                return (start until start + wanted.size).joinToString(" ") { pairs[it].second }
            }
        }
        return normalizedQuery
    }

    /** Drops leading/trailing characters that are neither letters, digits nor Arabic diacritics. */
    private fun trimPunctuation(word: String): String =
        word.trim { c -> !(Character.isLetterOrDigit(c) || Character.getType(c) == Character.NON_SPACING_MARK.toInt()) }

    private fun stripPolite(s: String): String {
        var out = s
        for (p in POLITE) {
            if (out == p) return ""
            if (out.endsWith(" $p")) out = out.removeSuffix(" $p").trim()
        }
        return out
    }

    companion object {
        private const val NUM = """(\d+(?:\.\d+)?)"""
        private const val OPS =
            """(ضرب\s+في|ضرب|مقسوم\s+علي|قسمه\s+علي|قسمه|×|✕|x|\*|\+|زايد|زائد|جمع|−|–|-|ناقص|طرح|÷|/|في|علي)"""
        private val CALC = Regex("$NUM\\s*$OPS\\s*$NUM")
        private val NUMBER = Regex("\\d+(?:\\.\\d+)?")

        private val OPEN_AND_SEARCH = Regex(
            "^(?:افتح|افتحي|شغل|شغلي|open|launch|start)\\s+(.+?)\\s+(?:(?:و|ثم|and)\\s*)?(?:ابحث|ابحثي|دور|search)\\s+(?:لي\\s+)?(?:عن\\s+|على\\s+|for\\s+)?(.+)$"
        )
        private val OPEN_VERBS = listOf("افتح", "افتحي", "شغل", "شغلي", "open", "launch", "start")
        private val FILLERS = listOf("تطبيق", "برنامج", "لي", "app", "application")
        private val POLITE = listOf("لو سمحت", "لو سمحتي", "من فضلك", "من فضلك", "please")
        private val HOME_WORDS = listOf("الشاشه الرئيسيه", "الصفحه الرئيسيه", "go home", "home screen")
        private val BACK_WORDS = listOf("ارجع", "رجوع", "عد للخلف", "back", "go back")
        private val SCROLL_VERBS = setOf("مرر", "انزل", "اسحب", "scroll", "اصعد")
        private val UP_WORDS = setOf("لاعلي", "للاعلي", "فوق", "اعلي", "اصعد", "up")
    }
}
