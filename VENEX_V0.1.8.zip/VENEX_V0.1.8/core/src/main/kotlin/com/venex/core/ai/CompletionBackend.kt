package com.venex.core.ai

/**
 * The one thing [ModelIntentProvider] needs from any model: turn a [ChatPrompt] into text.
 * Server providers (Ollama / OpenAI-compatible / cloud) and the on-device runtime implement it, so
 * the prompt and [ModelReplyParser] are shared and cannot drift apart between backends.
 * Implementations never throw for ordinary failures; they return [ProviderResult.Err].
 */
interface CompletionBackend {
    suspend fun complete(prompt: ChatPrompt): ProviderResult<Completion>
}

/** A server backend: one [ModelProvider] + connection + model id. */
class ServerCompletionBackend(
    private val provider: ModelProvider,
    private val spec: ConnectionSpec,
    private val modelId: String
) : CompletionBackend {
    override suspend fun complete(prompt: ChatPrompt): ProviderResult<Completion> =
        provider.complete(spec, modelId, prompt)
}

/**
 * Secrets (API keys) live behind this interface. The Android implementation encrypts with a key held
 * in the Android Keystore. A secret is never part of any snapshot, audit entry or error message.
 */
interface SecretStore {
    fun get(alias: String): String?
    fun put(alias: String, value: String)
    fun delete(alias: String)
    fun has(alias: String): Boolean = get(alias) != null
}

/** Test implementation. Not persistent. The app never uses it; it uses KeystoreSecretStore. */
class InMemorySecretStore : SecretStore {
    private val map = HashMap<String, String>()
    override fun get(alias: String): String? = map[alias]
    override fun put(alias: String, value: String) { map[alias] = value }
    override fun delete(alias: String) { map.remove(alias) }
}
