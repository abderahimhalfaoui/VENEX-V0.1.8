package com.venex.core.goal

import com.venex.core.intent.TextNormalizer

/** A text file the owner attached to the message. */
data class AttachedText(val name: String, val text: String)

/**
 * The chat client sends attachments as `[ملف: NAME]` blocks followed by the typed command, all joined by a blank line.
 * This separates the typed command from the attached text, so a phrase like "the text I gave you" can be resolved to
 * a real attachment instead of being guessed. Known limit: a text file that itself contains a blank line, sent with no
 * typed command, is indistinguishable from "file + command".
 */
data class CommandEnvelope(
    val typed: String,
    val attachments: List<AttachedText>,
    /** Attached files whose content was not readable (images, PDFs), by name. */
    val unreadableNames: List<String> = emptyList()
) {
    companion object {
        private val BLOCK = Regex("(?m)^\\[ملف: ([^\\]\\n]*)\\]")
        private const val UNREADABLE_MARK = "(محتوى الصور"

        fun parse(raw: String): CommandEnvelope {
            val t = raw.trim()
            val blocks = BLOCK.findAll(t).toList()
            if (blocks.isEmpty()) return CommandEnvelope(t, emptyList())

            val lastBlockStart = blocks.last().range.first
            val cut = t.lastIndexOf("\n\n")
            val typed: String
            val region: String
            if (cut > lastBlockStart) {
                typed = t.substring(cut + 2).trim()
                region = t.substring(0, cut)
            } else {
                typed = ""
                region = t
            }
            val regionBlocks = BLOCK.findAll(region).toList()
            val texts = ArrayList<AttachedText>()
            val unreadable = ArrayList<String>()
            for ((i, b) in regionBlocks.withIndex()) {
                val bodyStart = b.range.last + 1
                val bodyEnd = if (i + 1 < regionBlocks.size) regionBlocks[i + 1].range.first else region.length
                val body = region.substring(bodyStart, bodyEnd).trim()
                val name = b.groupValues[1]
                if (body.startsWith(UNREADABLE_MARK) || body.isEmpty()) unreadable += name else texts += AttachedText(name, body)
            }
            return CommandEnvelope(typed, texts, unreadable)
        }
    }
}

/**
 * Normalised view of a command with a map back to the original characters, so free text (a post, a message) can be cut
 * out of the ORIGINAL string verbatim even though matching is done on the normalised one.
 */
internal class AlignedText(val raw: String) {
    val norm: String
    private val map: IntArray

    init {
        val sb = StringBuilder()
        val idx = ArrayList<Int>()
        for ((i, ch) in raw.withIndex()) {
            if (ch.isWhitespace()) {
                if (sb.isNotEmpty() && sb.last() != ' ') { sb.append(' '); idx += i }
                continue
            }
            val t = TextNormalizer.normalize("a${ch}a")
            when {
                t == "aa" -> Unit                                   // dropped (diacritic, tatweel)
                t == "a a" -> if (sb.isNotEmpty() && sb.last() != ' ') { sb.append(' '); idx += i } // Arabic comma, question mark
                t.length == 3 -> { sb.append(t[1]); idx += i }
                else -> { for (c in t.drop(1).dropLast(1)) { sb.append(c); idx += i } }
            }
        }
        while (sb.isNotEmpty() && sb.last() == ' ') { sb.setLength(sb.length - 1); idx.removeAt(idx.size - 1) }
        norm = sb.toString()
        map = idx.toIntArray()
    }

    /** Range of ORIGINAL characters that corresponds to the normalised range [from, to), or null if it is empty. */
    fun span(from: Int, to: Int = norm.length): IntRange? {
        if (map.isEmpty() || from < 0 || from >= norm.length || from >= to) return null
        val a = map[from]
        val b = if (to >= norm.length) raw.length else map[to]
        return if (b > a) a until b else null
    }

    /** Original text for the normalised range [from, to), trimmed. */
    fun rawRange(from: Int, to: Int = norm.length): String = span(from, to)?.let { raw.substring(it.first, it.last + 1).trim() } ?: ""
}
