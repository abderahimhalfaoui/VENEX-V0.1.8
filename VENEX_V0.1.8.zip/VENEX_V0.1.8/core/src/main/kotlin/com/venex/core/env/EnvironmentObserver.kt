package com.venex.core.env

import com.venex.core.device.Channel
import com.venex.core.device.DeviceController
import com.venex.core.device.ScreenSnapshot
import kotlinx.coroutines.CancellationException

/**
 * One reading from one source. [snapshot] is the screen, when the source can see it. A source that cannot see the
 * screen (Intents, deep links, APIs) may still contribute [claimedPackage], and a conflict with the screen source
 * is then recorded by the builder rather than hidden.
 */
data class Observation(
    val source: SourceKind,
    val atMillis: Long,
    val snapshot: ScreenSnapshot?,
    /** Why there is no snapshot (never "no error": an unreadable screen always has a stated reason). */
    val unavailableReason: String? = null,
    val claimedPackage: String? = null
)

/** What one observation round produced. [primary] is the screen reading; [supplements] are the other sources. */
data class ObservationSet(
    val primary: Observation,
    val supplements: List<Observation>,
    val capabilities: Set<Channel>
)

/** The seam for a new way of understanding the environment. Implementations must not act on the device. */
interface ObservationSource {
    val kind: SourceKind
    suspend fun observe(): Observation
}

/**
 * Reads the current screen through the [DeviceController]. If the device does not advertise the Accessibility
 * channel the source does not even try (VENEX never uses a method it has no permission for) and says so.
 */
class DeviceScreenSource(
    private val device: DeviceController,
    private val clock: () -> Long = System::currentTimeMillis
) : ObservationSource {
    override val kind: SourceKind = SourceKind.ACCESSIBILITY

    override suspend fun observe(): Observation {
        val now = clock()
        if (Channel.ACCESSIBILITY !in device.capabilities()) {
            return Observation(kind, now, null, "خدمة إمكانية الوصول غير مفعّلة؛ لا أستطيع قراءة الشاشة.")
        }
        return try {
            val snap = device.snapshot()
            if (snap == null) Observation(kind, now, null, "لا توجد نافذة نشطة قابلة للقراءة (قد يكون التطبيق يحجب القراءة أو الشاشة مقفلة).")
            else Observation(kind, now, snap)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Observation(kind, now, null, "تعذّرت قراءة الشاشة: ${e.javaClass.simpleName}")
        }
    }
}

/**
 * Collects observations from the screen source and any extra sources. A failing extra source is dropped (with its
 * reason recorded) and never breaks the observation.
 */
class EnvironmentObserver(
    private val device: DeviceController,
    private val clock: () -> Long = System::currentTimeMillis,
    private val screenSource: ObservationSource = DeviceScreenSource(device, clock),
    private val extraSources: List<ObservationSource> = emptyList()
) {
    suspend fun observe(): ObservationSet {
        val caps = try {
            device.capabilities()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptySet()
        }
        val primary = screenSource.observe()
        val extras = extraSources.map { s ->
            try {
                s.observe()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Observation(s.kind, clock(), null, "فشل المصدر ${s.kind}: ${e.javaClass.simpleName}")
            }
        }
        return ObservationSet(primary, extras, caps)
    }
}
