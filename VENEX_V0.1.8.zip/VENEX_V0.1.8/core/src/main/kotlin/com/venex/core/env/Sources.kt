package com.venex.core.env

import com.venex.core.device.Channel

/** How far an observation or an inference can be trusted. Ordered; [NONE] means "no usable information". */
enum class Confidence(val rank: Int) {
    NONE(0), LOW(1), MEDIUM(2), HIGH(3);

    /** The lower of the two: a conclusion is never more certain than its weakest input. */
    fun capAt(limit: Confidence): Confidence = if (rank <= limit.rank) this else limit

    companion object {
        fun lowest(a: Confidence, b: Confidence): Confidence = if (a.rank <= b.rank) a else b
    }
}

/**
 * Ways VENEX can learn about the digital environment. The list is the extension point: a new source implements
 * [ObservationSource], is reported by [InformationSources.assess], and nothing else in the pipeline changes.
 */
enum class SourceKind(val arabicLabel: String) {
    ACCESSIBILITY("إمكانية الوصول (Accessibility)"),

    /** A hierarchy that does NOT come from Accessibility (for example a system UI dump). Not implemented. */
    UI_HIERARCHY("شجرة واجهة من مصدر آخر"),
    ANDROID_INTENT("Android Intents"),
    DEEP_LINK("الروابط العميقة"),
    OFFICIAL_API("واجهات رسمية (API)"),
    APP_FUNCTION("App Functions"),
    VISUAL("الفهم البصري للشاشة")
}

enum class SourceStatus {
    /** Implemented and its permission/channel is present now. */
    AVAILABLE,

    /** Implemented, but the owner has not granted what it needs (for example the Accessibility service is off). */
    UNAVAILABLE_PERMISSION,

    /** There is no implementation in this version. Never advertised, never selected. */
    NOT_IMPLEMENTED
}

/** What one source offers right now, how much it can be trusted, and where it stops. */
data class SourceAssessment(
    val kind: SourceKind,
    val status: SourceStatus,
    val reliability: Confidence,
    val canObserve: Boolean,
    val canAct: Boolean,
    val limitations: List<String>
)

/**
 * Honest inventory of the understanding/acting sources. It reads the live channel set from the device, so a source
 * is "available" only when the device says so; the sources without code in this version are reported as such.
 */
object InformationSources {

    fun assess(capabilities: Set<Channel>): List<SourceAssessment> = listOf(
        accessibility(capabilities),
        SourceAssessment(
            SourceKind.UI_HIERARCHY, SourceStatus.NOT_IMPLEMENTED, Confidence.NONE, false, false,
            listOf("لا يوجد مصدر هرمي غير Accessibility في هذه النسخة؛ الهرمية تأتي من خدمة Accessibility عند توفرها.")
        ),
        launchOnly(
            SourceKind.ANDROID_INTENT, Channel.INTENT in capabilities,
            "يفتح التطبيقات فقط؛ لا يقرأ حالة أي واجهة."
        ),
        launchOnly(
            SourceKind.DEEP_LINK, Channel.DEEP_LINK in capabilities,
            "يفتح عنواناً معروفاً فقط (https/http/geo/mailto)؛ لا يقرأ حالة الواجهة ولا يضمن أن التطبيق سيعالج العنوان."
        ),
        SourceAssessment(
            SourceKind.OFFICIAL_API,
            if (Channel.OFFICIAL_API in capabilities) SourceStatus.AVAILABLE else SourceStatus.NOT_IMPLEMENTED,
            if (Channel.OFFICIAL_API in capabilities) Confidence.HIGH else Confidence.NONE,
            Channel.OFFICIAL_API in capabilities, Channel.OFFICIAL_API in capabilities,
            listOf("لا يوجد أي تكامل مع واجهة رسمية في هذه النسخة.")
        ),
        SourceAssessment(
            SourceKind.APP_FUNCTION, SourceStatus.NOT_IMPLEMENTED, Confidence.NONE, false, false,
            listOf("لا يوجد دعم لـ App Functions في هذه النسخة.")
        ),
        SourceAssessment(
            SourceKind.VISUAL,
            if (Channel.VISION in capabilities) SourceStatus.AVAILABLE else SourceStatus.NOT_IMPLEMENTED,
            if (Channel.VISION in capabilities) Confidence.LOW else Confidence.NONE,
            Channel.VISION in capabilities, Channel.VISION in capabilities,
            listOf("الفهم البصري غير منفَّذ؛ الواجهات التي لا تكشف عناصرها تبقى «مجهولة».")
        )
    )

    private fun accessibility(caps: Set<Channel>): SourceAssessment {
        val on = Channel.ACCESSIBILITY in caps
        return SourceAssessment(
            SourceKind.ACCESSIBILITY,
            if (on) SourceStatus.AVAILABLE else SourceStatus.UNAVAILABLE_PERMISSION,
            if (on) Confidence.MEDIUM else Confidence.NONE,
            canObserve = on, canAct = on,
            limitations = listOf(
                "تُقرأ النافذة النشطة فقط، بحدّ أقصى للعمق والعدد.",
                "التطبيقات التي تحجب القراءة (مثل FLAG_SECURE أو واجهات بلا وصف) تظهر فارغة أو ناقصة.",
                "نصوص حقول كلمات المرور لا تُقرأ أبداً."
            ) + (if (on) emptyList() else listOf("الخدمة غير مفعّلة: على المالك تفعيلها يدوياً من إعدادات النظام."))
        )
    }

    private fun launchOnly(kind: SourceKind, present: Boolean, limit: String) = SourceAssessment(
        kind,
        if (present) SourceStatus.AVAILABLE else SourceStatus.UNAVAILABLE_PERMISSION,
        if (present) Confidence.HIGH else Confidence.NONE,
        canObserve = false, canAct = present, limitations = listOf(limit)
    )
}
