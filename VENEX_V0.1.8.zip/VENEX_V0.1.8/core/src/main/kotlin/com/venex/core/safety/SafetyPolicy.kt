package com.venex.core.safety

import com.venex.core.device.ScreenSnapshot
import com.venex.core.model.Action
import com.venex.core.model.Goal
import com.venex.core.model.RestrictedGoal
import com.venex.core.device.UiNode
import com.venex.core.intent.TextNormalizer

sealed interface SafetyDecision {
    data object Allow : SafetyDecision
    data class Deny(val reason: String) : SafetyDecision
}

/**
 * Non-negotiable limits: no CAPTCHA bypass, no typing into password fields, no auto
 * send/post/delete/pay, no secret extraction. Evaluated by the engine before every step.
 */
object SafetyPolicy {

    private val captchaMarkers = listOf(
        "captcha", "recaptcha", "i'm not a robot", "i am not a robot", "verify you are human",
        "كابتشا", "لست روبوت", "لست برنامج روبوت", "تحقق من انك انسان", "تحقق من أنك إنسان"
    ).map(TextNormalizer::normalize)

    fun checkGoal(goal: Goal): SafetyDecision =
        if (goal is RestrictedGoal) {
            SafetyDecision.Deny(
                "طلب «${goal.category.arabicLabel}» يتطلب موافقة صريحة منك، وتنفيذه التلقائي غير مدعوم في V0.1."
            )
        } else SafetyDecision.Allow

    /** Screen-level checks done before acting on the current screen. */
    fun checkScreen(snapshot: ScreenSnapshot?): SafetyDecision {
        if (snapshot == null) return SafetyDecision.Allow
        val joined = snapshot.allText().joinToString(" ") { TextNormalizer.normalize(it) }
        if (captchaMarkers.any { joined.contains(it) }) {
            return SafetyDecision.Deny("تم رصد CAPTCHA/تحقق بشري. VENEX لا يتجاوزه؛ يرجى إكماله بنفسك.")
        }
        return SafetyDecision.Allow
    }

    /** Action-level checks given the target node (if known). */
    fun checkAction(action: Action, target: UiNode?): SafetyDecision {
        if (action is Action.TypeText && target?.password == true) {
            return SafetyDecision.Deny("لا يكتب VENEX في حقول كلمات المرور.")
        }
        if (action is Action.OpenDeepLink) {
            val scheme = action.uri.substringBefore(':', "").lowercase()
            if (scheme !in ALLOWED_SCHEMES) {
                return SafetyDecision.Deny("نوع الرابط غير مسموح: $scheme")
            }
        }
        return SafetyDecision.Allow
    }

    val ALLOWED_SCHEMES = setOf("https", "http", "geo", "mailto")
}
