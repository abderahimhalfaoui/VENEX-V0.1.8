package com.venex.core.audit

enum class AuditLevel { INFO, WARN, ERROR, EVIDENCE }

data class AuditEntry(
    val timestampMillis: Long,
    val level: AuditLevel,
    val stepId: String?,
    val message: String,
    val evidence: String? = null
) {
    /** One JSON object per line (JSONL); no external serializer needed. */
    fun toJsonLine(): String = buildString {
        append("{\"t\":").append(timestampMillis)
        append(",\"level\":\"").append(level.name).append('"')
        append(",\"step\":").append(if (stepId == null) "null" else "\"${escape(stepId)}\"")
        append(",\"msg\":\"").append(escape(message)).append('"')
        append(",\"evidence\":").append(if (evidence == null) "null" else "\"${escape(evidence)}\"")
        append('}')
    }

    private fun escape(s: String): String = buildString {
        for (c in s) when (c) {
            '"' -> append("\\\"")
            '\\' -> append("\\\\")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> if (c < ' ') append(String.format("\\u%04x", c.code)) else append(c)
        }
    }
}

fun interface AuditSink {
    fun write(entry: AuditEntry)
}

/**
 * Append-only, thread-safe execution log. Sinks (e.g. a file) receive every entry; sink failures
 * never break task execution. Secrets must not be logged: callers pass lengths, not typed text.
 */
class AuditLog(
    private val clock: () -> Long = System::currentTimeMillis,
    private val sinks: List<AuditSink> = emptyList()
) {
    private val lock = Any()
    private val items = ArrayList<AuditEntry>()

    fun record(level: AuditLevel, message: String, stepId: String? = null, evidence: String? = null) {
        val entry = AuditEntry(clock(), level, stepId, message, evidence)
        synchronized(lock) { items.add(entry) }
        for (sink in sinks) {
            try {
                sink.write(entry)
            } catch (_: Exception) {
                // Logging must never crash a task.
            }
        }
    }

    fun entries(): List<AuditEntry> = synchronized(lock) { items.toList() }

    fun clear() = synchronized(lock) { items.clear() }
}
