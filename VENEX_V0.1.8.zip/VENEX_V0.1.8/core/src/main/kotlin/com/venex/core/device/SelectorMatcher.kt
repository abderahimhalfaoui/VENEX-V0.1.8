package com.venex.core.device

import com.venex.core.model.Selector

object SelectorMatcher {

    private val dashes = Regex("[−–—‒]")

    private fun canon(s: String): String =
        s.trim().replace(dashes, "-").lowercase()

    /** The exact normalisation [matches] applies to labels (V0.1.8: exposed so the environment model indexes labels identically). */
    fun canonical(s: String): String = canon(s)

    fun matches(node: UiNode, selector: Selector): Boolean {
        if (selector.idContains != null) {
            val id = node.viewId
            if (id == null || !id.contains(selector.idContains, ignoreCase = true)) return false
            if (selector.labels.isEmpty()) return true
        }
        if (selector.labels.isEmpty()) return false
        val wanted = selector.labels.map(::canon).toSet()
        val candidates = listOfNotNull(node.text, node.contentDescription).map(::canon)
        return candidates.any { it in wanted }
    }

    /** Prefers clickable, enabled nodes when several match. */
    fun findBest(nodes: List<UiNode>, selector: Selector): UiNode? {
        val matched = nodes.filter { matches(it, selector) }
        return matched.firstOrNull { it.clickable && it.enabled }
            ?: matched.firstOrNull { it.enabled }
            ?: matched.firstOrNull()
    }
}
