package com.venex.core.verify

import com.venex.core.env.Confidence
import com.venex.core.env.EnvironmentModel
import com.venex.core.env.ScreenDiff
import com.venex.core.env.TargetResolution
import com.venex.core.env.TargetResolver
import com.venex.core.env.TargetSpec
import com.venex.core.env.normLabel

/** The ladder from "VENEX sent something" to "the result is confirmed". Each rung needs more than the one below. */
enum class EvidenceLevel { COMMAND_SENT, ACTION_EXECUTED, STATE_CHANGED, OUTCOME_ACHIEVED, OUTCOME_VERIFIED }

enum class EvidenceVerdict { VERIFIED, PARTIALLY_VERIFIED, UNVERIFIED, FAILED }

/** What a satisfied condition can establish: that something changed, or that the desired outcome holds. */
enum class Proof { STATE_CHANGE, OUTCOME }

enum class TextScope { ANYWHERE, NON_INPUT, INPUT }

/** A declarative, observable condition. Pressing a button or a window disappearing is never one of them by itself. */
sealed interface VerificationCondition {
    val proves: Proof
    fun describe(): String

    /** [packageName] null = the package of the app launched earlier in the task. */
    data class AppInForeground(val packageName: String?) : VerificationCondition {
        override val proves = Proof.OUTCOME
        override fun describe() = "التطبيق ${packageName ?: "المُطلَق"} في المقدمة"
    }

    /** Only the first [prefixChars] normalised characters are compared, since long text is often shortened on screen. */
    data class TextVisible(val text: String, val scope: TextScope = TextScope.NON_INPUT, val prefixChars: Int = 60) : VerificationCondition {
        override val proves = Proof.OUTCOME
        override fun describe() = "النص «${text.take(40)}» ظاهر (${scope.name})"
    }

    data class TextAbsent(val text: String, val scope: TextScope = TextScope.ANYWHERE, val prefixChars: Int = 60) : VerificationCondition {
        override val proves = Proof.OUTCOME
        override fun describe() = "النص «${text.take(40)}» غير ظاهر (${scope.name})"
    }

    data class ElementPresent(val target: TargetSpec) : VerificationCondition {
        override val proves = Proof.OUTCOME
        override fun describe() = "العنصر «${target.description}» موجود"
    }

    /** By default only a state change: a vanished element is not proof the goal was reached. [asOutcome] = it IS the goal (a deletion). */
    data class ElementAbsent(val target: TargetSpec, val asOutcome: Boolean = false) : VerificationCondition {
        override val proves = if (asOutcome) Proof.OUTCOME else Proof.STATE_CHANGE
        override fun describe() = "العنصر «${target.description}» غير موجود"
    }

    data class FieldContains(val target: TargetSpec, val text: String) : VerificationCondition {
        override val proves = Proof.OUTCOME
        override fun describe() = "الحقل «${target.description}» يحتوي «${text.take(40)}»"
    }

    data object StateChanged : VerificationCondition {
        override val proves = Proof.STATE_CHANGE
        override fun describe() = "تغيّرت حالة الواجهة"
    }

    /** Evidence from a source other than the screen (an API response, stored data). Unknown unless a provider supplied it. */
    data class ExternalEvidence(val key: String, val expected: String) : VerificationCondition {
        override val proves = Proof.OUTCOME
        override fun describe() = "الدليل الخارجي «$key» = «${expected.take(40)}»"
    }
}

data class Check(val condition: VerificationCondition, val required: Boolean = true)

enum class CheckResult { SATISFIED, CONTRADICTED, UNKNOWN }
enum class Strength { STRONG, WEAK }

data class Evidence(val condition: String, val proves: Proof, val result: CheckResult, val strength: Strength, val detail: String)

data class VerificationReport(
    val verdict: EvidenceVerdict,
    val level: EvidenceLevel,
    val evidence: List<Evidence>,
    val limitations: List<String>,
    val summary: String
)

/** Everything the verifier may look at. It never acts and never reads the device itself. */
data class EvidenceInput(
    val commandSent: Boolean,
    val actionExecuted: Boolean,
    val before: EnvironmentModel?,
    val after: EnvironmentModel?,
    val diff: ScreenDiff?,
    /** The post-action screen was read twice in a row with the same content (it had stopped changing). */
    val stable: Boolean,
    val launchedPackage: String? = null,
    val external: Map<String, String> = emptyMap()
)

/**
 * Evaluates conditions against observed state and reports one of VERIFIED / PARTIALLY_VERIFIED / UNVERIFIED / FAILED
 * with the evidence and the limits. Rules that cannot be argued with:
 *  - nothing is VERIFIED unless every required condition is an OUTCOME condition that was observed and was strong
 *    and the screen had settled;
 *  - a state change alone (or a window going away) never exceeds UNVERIFIED;
 *  - if the screen cannot be read, the result is UNVERIFIED, never a guess;
 *  - a required condition that is observably contradicted is FAILED unless other outcome evidence exists.
 */
object EvidenceVerifier {

    fun verify(checks: List<Check>, input: EvidenceInput): VerificationReport {
        val limitations = ArrayList<String>()
        val evals = checks.map { Triple(it, evaluate(it.condition, input), it.required) }
        val evidence = evals.map { (c, e, _) -> Evidence(c.condition.describe(), c.condition.proves, e.first, e.second, e.third) }

        val stateChange = input.diff?.changed == true
        var level = if (input.commandSent) EvidenceLevel.COMMAND_SENT else EvidenceLevel.COMMAND_SENT
        if (input.actionExecuted) level = EvidenceLevel.ACTION_EXECUTED
        if (input.actionExecuted && stateChange) level = EvidenceLevel.STATE_CHANGED

        if (!input.actionExecuted) {
            return VerificationReport(
                EvidenceVerdict.FAILED, EvidenceLevel.COMMAND_SENT, evidence, listOf("لم يُنفَّذ الإجراء فعلياً."),
                if (input.commandSent) "أُرسل الأمر لكن لم يُنفَّذ الإجراء." else "لم يُرسَل أي أمر."
            )
        }

        val readable = input.after?.screen != null
        if (!readable) limitations += "الشاشة غير مقروءة بعد الإجراء؛ لا دليل مرصود."
        if (readable && input.after?.confidence == Confidence.LOW) limitations += "الفهم المرصود ضعيف الثقة (عناصر غير مسمّاة أو واجهة معتمة)."
        if (readable && !input.stable) limitations += "لم تستقر الشاشة بعد الإجراء؛ القراءة قد تتغيّر."
        if (evals.any { it.second.first == CheckResult.UNKNOWN }) limitations += "بعض الشروط لا يمكن الحكم عليها بالمصادر المتاحة."

        val required = evals.filter { it.third }
        val allRequiredSatisfied = required.isNotEmpty() && required.all { it.second.first == CheckResult.SATISFIED }
        val allRequiredAreOutcomes = required.all { it.first.condition.proves == Proof.OUTCOME }
        val outcomeSatisfied = evals.any { it.first.condition.proves == Proof.OUTCOME && it.second.first == CheckResult.SATISFIED }
        val requiredContradicted = required.any { it.second.first == CheckResult.CONTRADICTED }
        val strong = required.all { it.second.second == Strength.STRONG }

        val verdict = when {
            allRequiredSatisfied && allRequiredAreOutcomes ->
                if (strong && input.stable) EvidenceVerdict.VERIFIED else EvidenceVerdict.PARTIALLY_VERIFIED
            requiredContradicted -> if (outcomeSatisfied) EvidenceVerdict.PARTIALLY_VERIFIED else EvidenceVerdict.FAILED
            outcomeSatisfied -> EvidenceVerdict.PARTIALLY_VERIFIED
            else -> EvidenceVerdict.UNVERIFIED
        }
        if (verdict == EvidenceVerdict.PARTIALLY_VERIFIED && allRequiredSatisfied && !strong) limitations += "الدليل ضعيف الثقة."
        if (allRequiredSatisfied && allRequiredAreOutcomes) {
            level = if (verdict == EvidenceVerdict.VERIFIED) EvidenceLevel.OUTCOME_VERIFIED else EvidenceLevel.OUTCOME_ACHIEVED
        }
        if (verdict == EvidenceVerdict.UNVERIFIED && stateChange) limitations += "تغيّرت الواجهة لكن لا دليل على تحقق الهدف نفسه."

        val summary = when (verdict) {
            EvidenceVerdict.VERIFIED -> "تحقق الهدف بدليل مرصود: " + evidence.filter { it.result == CheckResult.SATISFIED }.joinToString("؛ ") { it.detail }
            EvidenceVerdict.PARTIALLY_VERIFIED -> "تحقق جزء من الهدف: " + evidence.filter { it.result == CheckResult.SATISFIED }.joinToString("؛ ") { it.detail }
            EvidenceVerdict.UNVERIFIED -> "لا أستطيع تأكيد تحقق الهدف. " + (limitations.firstOrNull() ?: "")
            EvidenceVerdict.FAILED -> "لم يتحقق الهدف: " + evidence.filter { it.result == CheckResult.CONTRADICTED }.joinToString("؛ ") { it.detail }
        }
        return VerificationReport(verdict, level, evidence, limitations.distinct(), summary.trim())
    }

    // ---------------------------------------------------------------------------------------------------------------

    private fun evaluate(c: VerificationCondition, input: EvidenceInput): Triple<CheckResult, Strength, String> {
        val after = input.after
        val screen = after?.screen
        val unreadable = Triple(CheckResult.UNKNOWN, Strength.WEAK, "الشاشة غير مقروءة")
        val strength = if (after?.confidence == Confidence.LOW) Strength.WEAK else Strength.STRONG

        return when (c) {
            is VerificationCondition.StateChanged -> when {
                input.diff == null -> Triple(CheckResult.UNKNOWN, Strength.WEAK, "لا مقارنة متاحة")
                input.diff.changed -> Triple(CheckResult.SATISFIED, Strength.STRONG, "تغيّرت الواجهة: ${input.diff.note}")
                else -> Triple(CheckResult.CONTRADICTED, Strength.STRONG, "لم تتغيّر الواجهة")
            }
            is VerificationCondition.ExternalEvidence -> {
                val got = input.external[c.key]
                when {
                    got == null -> Triple(CheckResult.UNKNOWN, Strength.WEAK, "لا مزوّد دليل خارجي لـ ${c.key}")
                    normLabel(got) == normLabel(c.expected) -> Triple(CheckResult.SATISFIED, Strength.STRONG, "الدليل الخارجي ${c.key} مطابق")
                    else -> Triple(CheckResult.CONTRADICTED, Strength.STRONG, "الدليل الخارجي ${c.key} مخالف")
                }
            }
            else -> {
                if (screen == null) return unreadable
                when (c) {
                    is VerificationCondition.AppInForeground -> {
                        val want = c.packageName ?: input.launchedPackage
                        when {
                            want == null -> Triple(CheckResult.UNKNOWN, Strength.WEAK, "لا حزمة معروفة للتحقق")
                            after.packageName == want -> Triple(CheckResult.SATISFIED, strength, "التطبيق $want في المقدمة")
                            else -> Triple(CheckResult.CONTRADICTED, strength, "الظاهر ${after.packageName ?: "غير معروف"} وليس $want")
                        }
                    }
                    is VerificationCondition.TextVisible -> {
                        val hit = textHit(screen.elements, c.text, c.scope, c.prefixChars)
                        if (hit) Triple(CheckResult.SATISFIED, strength, "النص ظاهر (${c.scope.name})")
                        else Triple(CheckResult.CONTRADICTED, strength, "النص غير ظاهر (${c.scope.name})")
                    }
                    is VerificationCondition.TextAbsent -> {
                        notJudgeable(after)?.let { return it }
                        val hit = textHit(screen.elements, c.text, c.scope, c.prefixChars)
                        if (!hit) Triple(CheckResult.SATISFIED, strength, "النص غير ظاهر") else Triple(CheckResult.CONTRADICTED, strength, "النص ما زال ظاهراً")
                    }
                    is VerificationCondition.ElementPresent ->
                        if (TargetResolver.resolve(c.target, screen) !is TargetResolution.NotFound) Triple(CheckResult.SATISFIED, strength, "العنصر «${c.target.description}» موجود")
                        else Triple(CheckResult.CONTRADICTED, strength, "العنصر «${c.target.description}» غير موجود")
                    is VerificationCondition.ElementAbsent -> {
                        notJudgeable(after)?.let { return it }
                        if (TargetResolver.resolve(c.target, screen) is TargetResolution.NotFound) Triple(CheckResult.SATISFIED, strength, "العنصر «${c.target.description}» لم يعد موجوداً")
                        else Triple(CheckResult.CONTRADICTED, strength, "العنصر «${c.target.description}» ما زال موجوداً")
                    }
                    is VerificationCondition.FieldContains -> fieldContains(c, screen)
                    else -> unreadable
                }
            }
        }
    }

    /**
     * "Something is not on screen" proves nothing while the screen is a dialog, still loading, or a gate that hides the
     * app's content: it is simply not there. Absence is judged only on an ordinary, readable screen.
     */
    private fun notJudgeable(after: com.venex.core.env.EnvironmentModel): Triple<CheckResult, Strength, String>? =
        when (after.state.kind) {
            com.venex.core.env.UiStateKind.NORMAL -> null
            else -> Triple(CheckResult.UNKNOWN, Strength.WEAK, "الغياب لا يُعدّ دليلاً ما دامت الشاشة في حالة ${after.state.kind.name}")
        }

    private fun fieldContains(c: VerificationCondition.FieldContains, screen: com.venex.core.env.ScreenModel): Triple<CheckResult, Strength, String> {
        val wanted = normLabel(c.text)
        fun holds(e: com.venex.core.env.UiElement) = !e.node.showingHint && !e.node.password && normLabel(e.node.text).contains(wanted)
        return when (val r = TargetResolver.resolve(c.target, screen)) {
            is TargetResolution.Found ->
                if (holds(r.element)) Triple(CheckResult.SATISFIED, if (r.confidence == Confidence.LOW) Strength.WEAK else Strength.STRONG, "الحقل يحتوي النص")
                else Triple(CheckResult.CONTRADICTED, Strength.STRONG, "الحقل لا يحتوي النص")
            is TargetResolution.Ambiguous ->
                if (r.candidates.any { holds(it) }) Triple(CheckResult.SATISFIED, Strength.WEAK, "أحد الحقول المحتملة يحتوي النص")
                else Triple(CheckResult.CONTRADICTED, Strength.WEAK, "لا حقل محتمل يحتوي النص")
            is TargetResolution.NotAddressable ->
                if (holds(r.element)) Triple(CheckResult.SATISFIED, Strength.WEAK, "الحقل يحتوي النص") else Triple(CheckResult.CONTRADICTED, Strength.WEAK, "الحقل لا يحتوي النص")
            TargetResolution.NotFound -> Triple(CheckResult.CONTRADICTED, Strength.STRONG, "الحقل «${c.target.description}» غير موجود")
        }
    }

    private fun textHit(elements: List<com.venex.core.env.UiElement>, text: String, scope: TextScope, prefixChars: Int): Boolean {
        val probe = normLabel(text).take(prefixChars)
        if (probe.isEmpty()) return false
        val pool = when (scope) {
            TextScope.ANYWHERE -> elements
            TextScope.NON_INPUT -> elements.filter { !it.node.editable }
            TextScope.INPUT -> elements.filter { it.node.editable && !it.node.password && !it.node.showingHint }
        }
        return pool.any { e -> listOfNotNull(e.node.text, e.node.contentDescription).any { normLabel(it).contains(probe) } }
    }
}

/** Mapping from the V0.1.7 verification result, so old and new evidence share one vocabulary. */
fun Verification.toVerdict(): EvidenceVerdict = when (this) {
    is Verification.Verified -> EvidenceVerdict.VERIFIED
    is Verification.Failed -> EvidenceVerdict.FAILED
    is Verification.Unverifiable -> EvidenceVerdict.UNVERIFIED
}
