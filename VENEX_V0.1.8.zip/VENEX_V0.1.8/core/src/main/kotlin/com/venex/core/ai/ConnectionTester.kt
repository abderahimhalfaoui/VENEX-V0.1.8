package com.venex.core.ai

/** Result of the CONNECTION test. It never claims that inference works. */
sealed interface ConnectionOutcome {
    data class Connected(
        val models: List<String>,
        /** true/false when a model name was given and the list is non-empty; null when unknown. */
        val selectedModelListed: Boolean?,
        val latencyMs: Long
    ) : ConnectionOutcome

    data class Failed(val failure: ProviderFailure) : ConnectionOutcome
}

/** Checks that the server is reachable, speaks the chosen protocol, and lists the chosen model. */
class ConnectionTester(private val registry: ProviderRegistry) {

    suspend fun test(type: ProviderType, spec: ConnectionSpec, modelId: String?): ConnectionOutcome =
        when (val r = registry.get(type).listModels(spec)) {
            is ProviderResult.Err -> ConnectionOutcome.Failed(r.failure)
            is ProviderResult.Ok -> {
                val ids = r.value.map { it.id }
                val listed = modelId?.takeIf { ids.isNotEmpty() }?.let { wanted -> ids.any { sameModel(it, wanted) } }
                ConnectionOutcome.Connected(ids, listed, r.latencyMs)
            }
        }

    companion object {
        /** "llama3" and "llama3:latest" name the same Ollama model. */
        internal fun sameModel(listed: String, wanted: String): Boolean {
            if (listed == wanted) return true
            return listed.removeSuffix(":latest") == wanted.removeSuffix(":latest")
        }
    }
}
