package com.venex.core.engine

import com.venex.core.audit.AuditLevel
import com.venex.core.audit.AuditLog
import com.venex.core.device.ActionResult
import com.venex.core.device.AppResolution
import com.venex.core.device.ChannelRouter
import com.venex.core.device.DeviceController
import com.venex.core.device.Route
import com.venex.core.device.SelectorMatcher
import com.venex.core.model.Action
import com.venex.core.model.Plan
import com.venex.core.model.Step
import com.venex.core.model.StepResult
import com.venex.core.model.StepStatus
import com.venex.core.model.TaskReport
import com.venex.core.model.TaskStatus
import com.venex.core.safety.SafetyDecision
import com.venex.core.safety.SafetyPolicy
import com.venex.core.verify.Verification
import com.venex.core.verify.VerificationContext
import com.venex.core.verify.Verifier
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext

/** Asked before any step flagged `needsConfirmation`. Returning false cancels the task. */
fun interface ConfirmationHandler {
    suspend fun confirm(step: Step): Boolean
}

/** Default handler: never approves. Auto-approval must be a conscious, explicit choice. */
object DenyAllConfirmations : ConfirmationHandler {
    override suspend fun confirm(step: Step): Boolean = false
}

/**
 * Executes a [Plan]. Independent of the chat UI and of any AI provider: it only knows the plan,
 * a [DeviceController], and the safety/verification/audit components.
 *
 * Guarantees:
 *  - steps run in dependency order; a failed required step marks its dependents SKIPPED;
 *  - a step is VERIFIED only when [Verifier] observed its expectation;
 *  - the task is SUCCESS only if every required step ran and the last expectation was verified;
 *  - actions are re-run only when they reported failure (never after a verification miss), so
 *    key presses cannot be duplicated;
 *  - every decision is written to the [AuditLog].
 */
class ExecutionEngine(
    private val device: DeviceController,
    private val audit: AuditLog,
    private val confirmations: ConfirmationHandler = DenyAllConfirmations,
    private val settleDelayMs: Long = 150,
    private val onProgress: (StepResult) -> Unit = {}
) {

    suspend fun execute(plan: Plan): TaskReport {
        audit.record(AuditLevel.INFO, "بدء المهمة: ${plan.goal.rawText}")

        plan.blockedReason?.let { reason ->
            audit.record(AuditLevel.WARN, "لم تُنفَّذ المهمة: $reason")
            return TaskReport(plan.goal, TaskStatus.NOT_EXECUTED, reason, emptyList())
        }
        if (plan.steps.isEmpty()) {
            return TaskReport(plan.goal, TaskStatus.NOT_EXECUTED, "لا توجد خطوات للتنفيذ.", emptyList())
        }
        validateDependencies(plan)?.let { problem ->
            audit.record(AuditLevel.ERROR, problem)
            return TaskReport(plan.goal, TaskStatus.FAILED, problem, emptyList())
        }

        val results = LinkedHashMap<String, StepResult>()
        val byId = plan.steps.associateBy { it.id }
        var ctx = VerificationContext()
        var cancelled = false

        for (step in orderSteps(plan.steps)) {
            coroutineContext.ensureActive()

            // An optional step that itself FAILED does not block its dependents; a SKIPPED or
            // cancelled one always does (otherwise later steps could run on the wrong screen).
            val blocker = step.dependsOn.firstOrNull { dep ->
                val r = results[dep]
                when {
                    r == null -> true
                    r.status == StepStatus.FAILED -> byId[dep]?.optional != true
                    r.status == StepStatus.SKIPPED || r.status == StepStatus.CANCELLED_BY_USER -> true
                    else -> false
                }
            }
            if (blocker != null) {
                emit(results, StepResult(step.id, step.description, StepStatus.SKIPPED, "تخطّي: فشلت الخطوة السابقة «$blocker»"))
                audit.record(AuditLevel.WARN, "تخطّي الخطوة بسبب فشل «$blocker»", step.id)
                continue
            }

            if (step.needsConfirmation) {
                val approved = confirmations.confirm(step)
                audit.record(AuditLevel.INFO, if (approved) "وافق المستخدم على الخطوة" else "رفض المستخدم الخطوة", step.id)
                if (!approved) {
                    emit(results, StepResult(step.id, step.description, StepStatus.CANCELLED_BY_USER, "لم يوافق المستخدم"))
                    cancelled = true
                    continue
                }
            }

            val result = runStep(step, ctx)
            emit(results, result.first)
            ctx = result.second
        }

        return buildReport(plan, results.values.toList(), cancelled)
    }

    /**
     * V0.1.8: runs ONE step through exactly the same safety -> channel -> action -> verification path as [execute]
     * (CAPTCHA / password / link-scheme checks, channel routing, audit). The adaptive runner uses it, so it can never
     * act through a path that V0.1.7's safety did not cover. It adds no behaviour to [execute].
     */
    suspend fun executeStep(step: Step, ctx: VerificationContext = VerificationContext()): Pair<StepResult, VerificationContext> =
        runStep(step, ctx)

    private suspend fun runStep(step: Step, ctx: VerificationContext): Pair<StepResult, VerificationContext> {
        // 1. Safety on the current screen (CAPTCHA etc.).
        if (step.action !is Action.OpenApp && step.action !is Action.OpenDeepLink) {
            val screenDecision = SafetyPolicy.checkScreen(device.snapshot())
            if (screenDecision is SafetyDecision.Deny) {
                audit.record(AuditLevel.WARN, screenDecision.reason, step.id)
                return fail(step, screenDecision.reason) to ctx
            }
        }

        // 2. Action-level safety (password fields, link schemes).
        val target = (step.action as? Action.TypeText)?.let { a ->
            val nodes = device.snapshot()?.nodes.orEmpty()
            a.selector?.let { SelectorMatcher.findBest(nodes, it) } ?: nodes.firstOrNull { it.editable }
        }
        val actionDecision = SafetyPolicy.checkAction(step.action, target)
        if (actionDecision is SafetyDecision.Deny) {
            audit.record(AuditLevel.WARN, actionDecision.reason, step.id)
            return fail(step, actionDecision.reason) to ctx
        }

        // 3. Pick the channel.
        when (val route = ChannelRouter.route(step.action, device.capabilities())) {
            is Route.Unavailable -> {
                audit.record(AuditLevel.ERROR, route.reason, step.id)
                return fail(step, route.reason) to ctx
            }
            is Route.Use -> audit.record(AuditLevel.INFO, "القناة: ${route.channel}", step.id)
        }

        // 4. Run the action (re-run only if it reported failure).
        var newCtx = ctx
        var outcome: ActionResult = ActionResult.fail("لم تُنفَّذ")
        for (attempt in 1..step.maxAttempts.coerceAtLeast(1)) {
            val (res, c) = perform(step, newCtx)
            outcome = res
            newCtx = c
            if (res.success) break
            audit.record(AuditLevel.WARN, "فشلت المحاولة $attempt: ${res.message}", step.id)
            if (attempt < step.maxAttempts) delay(settleDelayMs)
        }
        if (!outcome.success) {
            audit.record(AuditLevel.ERROR, outcome.message, step.id)
            return fail(step, outcome.message) to newCtx
        }
        audit.record(AuditLevel.INFO, outcome.message, step.id, outcome.evidence)

        // 5. Verify.
        val expectation = step.expectation
        if (expectation == null) {
            return StepResult(step.id, step.description, StepStatus.EXECUTED_UNVERIFIED, outcome.message, outcome.evidence) to newCtx
        }

        var verification: Verification = Verification.Unverifiable("لم يتم التحقق")
        for (attempt in 1..step.verifyAttempts.coerceAtLeast(1)) {
            delay(settleDelayMs)
            verification = Verifier.verify(expectation, device.snapshot(), newCtx)
            if (verification !is Verification.Failed) break
        }
        return when (val v = verification) {
            is Verification.Verified -> {
                audit.record(AuditLevel.EVIDENCE, "تم التحقق", step.id, v.evidence)
                StepResult(step.id, step.description, StepStatus.VERIFIED, "تم التحقق", v.evidence) to newCtx
            }
            is Verification.Failed -> {
                audit.record(AuditLevel.ERROR, "فشل التحقق: ${v.reason}", step.id)
                fail(step, "فشل التحقق: ${v.reason}") to newCtx
            }
            is Verification.Unverifiable -> {
                audit.record(AuditLevel.WARN, "تعذّر التحقق: ${v.reason}", step.id)
                StepResult(step.id, step.description, StepStatus.EXECUTED_UNVERIFIED, "نُفّذت دون تأكيد: ${v.reason}", outcome.evidence) to newCtx
            }
        }
    }

    private suspend fun perform(step: Step, ctx: VerificationContext): Pair<ActionResult, VerificationContext> =
        when (val a = step.action) {
            is Action.OpenApp -> when (val r = device.resolveApp(a.appName)) {
                is AppResolution.NotFound ->
                    ActionResult.fail("لم أجد تطبيقاً باسم «${a.appName}» بين التطبيقات المثبتة.") to ctx
                is AppResolution.Ambiguous ->
                    ActionResult.fail(
                        "عدّة تطبيقات تطابق «${a.appName}»: ${r.candidates.joinToString("، ") { it.label }}. حدّد أحدها."
                    ) to ctx
                is AppResolution.Found -> {
                    val res = device.launchApp(r.app)
                    res to (if (res.success) VerificationContext(openedPackage = r.app.packageName) else ctx)
                }
            }
            is Action.OpenDeepLink -> device.openDeepLink(a.uri) to ctx
            is Action.Click -> device.click(a.selector) to ctx
            is Action.TypeText -> device.typeText(a.selector, a.text) to ctx
            is Action.Scroll -> device.scroll(a.direction) to ctx
            is Action.Press -> device.press(a.key) to ctx
            Action.ReadScreen -> {
                val s = device.snapshot()
                (if (s == null) ActionResult.fail("تعذّرت قراءة الشاشة")
                else ActionResult.ok("قُرئت الشاشة (${s.nodes.size} عنصر)", s.packageName)) to ctx
            }
        }

    private fun fail(step: Step, message: String) =
        StepResult(step.id, step.description, StepStatus.FAILED, message)

    private fun emit(map: MutableMap<String, StepResult>, r: StepResult) {
        map[r.stepId] = r
        try {
            onProgress(r)
        } catch (_: Exception) {
            // UI listener errors must not affect execution.
        }
    }

    private fun validateDependencies(plan: Plan): String? {
        val ids = plan.steps.map { it.id }
        if (ids.toSet().size != ids.size) return "خطة غير صالحة: معرّفات الخطوات مكررة"
        for (s in plan.steps) for (d in s.dependsOn) {
            if (d !in ids) return "خطة غير صالحة: الخطوة «${s.id}» تعتمد على «$d» غير الموجودة"
        }
        if (orderSteps(plan.steps).size != plan.steps.size) return "خطة غير صالحة: تبعيات دائرية"
        return null
    }

    /** Stable topological order (Kahn); steps in a cycle are omitted so callers can detect it. */
    internal fun orderSteps(steps: List<Step>): List<Step> {
        val remaining = steps.toMutableList()
        val done = HashSet<String>()
        val out = ArrayList<Step>()
        while (remaining.isNotEmpty()) {
            val next = remaining.firstOrNull { s -> s.dependsOn.all { it in done } } ?: break
            remaining.remove(next)
            done += next.id
            out += next
        }
        return out
    }

    private fun buildReport(plan: Plan, results: List<StepResult>, cancelled: Boolean): TaskReport {
        val byId = plan.steps.associateBy { it.id }
        val requiredFailed = results.filter { r ->
            (r.status == StepStatus.FAILED || r.status == StepStatus.SKIPPED) && byId[r.stepId]?.optional != true
        }
        val lastExpectationStep = plan.steps.lastOrNull { it.expectation != null }
        val lastResult = lastExpectationStep?.let { s -> results.firstOrNull { it.stepId == s.id } }

        val (status, summary) = when {
            cancelled -> TaskStatus.CANCELLED to "أُلغيت المهمة لأنك لم توافق على إحدى الخطوات."
            requiredFailed.isNotEmpty() -> {
                val first = requiredFailed.firstOrNull { it.status == StepStatus.FAILED } ?: requiredFailed.first()
                TaskStatus.FAILED to "فشلت المهمة عند «${first.description}»: ${first.message}"
            }
            lastResult?.status == StepStatus.VERIFIED ->
                TaskStatus.SUCCESS to "تمت المهمة وتم التحقق منها. ${lastResult.evidence ?: ""}".trim()
            else ->
                TaskStatus.UNVERIFIED to "نُفّذت الخطوات لكن لا يوجد دليل يؤكد النتيجة، فلا أستطيع الجزم بنجاحها."
        }
        audit.record(
            if (status == TaskStatus.SUCCESS) AuditLevel.INFO else AuditLevel.WARN,
            "انتهت المهمة: $status — $summary"
        )
        return TaskReport(plan.goal, status, summary, results)
    }
}
