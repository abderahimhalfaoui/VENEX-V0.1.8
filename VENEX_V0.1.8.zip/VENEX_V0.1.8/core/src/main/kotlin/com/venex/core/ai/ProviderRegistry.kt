package com.venex.core.ai

/** Maps each [ProviderType] to its adapter. Replacing an adapter never touches the engine. */
class ProviderRegistry(
    private val providers: Map<ProviderType, ModelProvider> = mapOf(
        ProviderType.OPENAI_COMPATIBLE to OpenAiCompatibleProvider(),
        ProviderType.OLLAMA to OllamaProvider()
    )
) {
    fun get(type: ProviderType): ModelProvider = providers.getValue(type)
}

/** Model discovery through the registry. */
class ModelCatalog(private val registry: ProviderRegistry) {
    suspend fun discover(type: ProviderType, spec: ConnectionSpec): ProviderResult<List<ModelInfo>> =
        registry.get(type).listModels(spec)
}
