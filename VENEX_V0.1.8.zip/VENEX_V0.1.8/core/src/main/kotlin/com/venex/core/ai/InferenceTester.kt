package com.venex.core.ai

/** Result of the INFERENCE test (a real request to the model). */
sealed interface InferenceOutcome {
    /** The model answered and the answer is the expected one. */
    data class Passed(val answer: String, val latencyMs: Long, val servedModel: String?) : InferenceOutcome

    /** The model answered, but not with the expected fact. Reported as a failure, never as success. */
    data class UnexpectedAnswer(val answer: String, val latencyMs: Long, val servedModel: String?) : InferenceOutcome

    data class Failed(val failure: ProviderFailure) : InferenceOutcome
}

class InferenceTester(private val registry: ProviderRegistry) {

    suspend fun test(type: ProviderType, spec: ConnectionSpec, modelId: String): InferenceOutcome {
        val prompt = ChatPrompt(system = "Answer in as few words as possible.", user = PROBE_QUESTION, maxTokens = PROBE_MAX_TOKENS)
        return when (val r = registry.get(type).complete(spec, modelId, prompt)) {
            is ProviderResult.Err -> InferenceOutcome.Failed(r.failure)
            is ProviderResult.Ok -> {
                // Only the visible answer counts: reasoning text that happens to contain the expected word does not.
                val text = ModelOutputSanitizer.clean(r.value.text)
                if (text.isEmpty()) {
                    InferenceOutcome.Failed(ProviderFailure(FailureKind.EMPTY_RESPONSE, "الرد فارغ"))
                } else if (PROBE_EXPECTED.any { text.contains(it, ignoreCase = true) }) {
                    InferenceOutcome.Passed(text, r.latencyMs, r.value.servedModel)
                } else {
                    InferenceOutcome.UnexpectedAnswer(text, r.latencyMs, r.value.servedModel)
                }
            }
        }
    }

    companion object {
        const val PROBE_QUESTION = "أجب بكلمة واحدة: ما عاصمة الجزائر؟"
        val PROBE_EXPECTED = listOf("الجزائر", "algiers")
        /** Room for a short answer after the (disabled) reasoning block; a reply cut at this budget fails. */
        const val PROBE_MAX_TOKENS = 48
    }
}
