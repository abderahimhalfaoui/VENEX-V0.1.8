package com.venex.core.ai.ondevice

import com.venex.core.ai.FailureKind
import com.venex.core.ai.ProviderFailure
import com.venex.core.ai.ProviderResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest

/**
 * Copies a stream into `dir/<name>` safely. Pure JVM so that it is unit-tested here; the Android
 * gateway only supplies the input stream and the free-space figure.
 *
 *  - free space is checked BEFORE copying (size + margin) when the size is known;
 *  - data goes to `<name>.part`; the final name appears only after a verified, complete copy (atomic rename);
 *  - cancellation or any error removes the `.part` file; nothing partial is ever left under the final name;
 *  - the SHA-256 of the copied bytes is computed in the same pass and returned.
 */
object StreamImporter {
    const val SAFETY_MARGIN_BYTES = 256L * 1024 * 1024
    private const val BUFFER = 1 shl 20

    suspend fun copy(
        input: InputStream,
        expectedSize: Long?,
        dir: File,
        finalName: String,
        freeBytes: () -> Long,
        onProgress: (copied: Long, total: Long) -> Unit
    ): ProviderResult<ImportedModel> {
        val started = System.nanoTime()
        if (!dir.isDirectory && !dir.mkdirs()) {
            return err(FailureKind.FILE_ACCESS, "تعذّر إنشاء مجلد النماذج الخاص بالتطبيق")
        }
        if (expectedSize != null) {
            val free = freeBytes()
            if (free < expectedSize + SAFETY_MARGIN_BYTES) {
                return err(
                    FailureKind.NO_SPACE,
                    "المساحة الحرة غير كافية: يلزم ≈${mb(expectedSize + SAFETY_MARGIN_BYTES)} MB والمتاح ${mb(free)} MB"
                )
            }
        }
        val part = File(dir, "$finalName.part")
        val target = File(dir, finalName)
        part.delete()
        var committed = false
        try {
            val digest = MessageDigest.getInstance("SHA-256")
            var copied = 0L
            val buf = ByteArray(BUFFER)
            part.outputStream().use { out ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    digest.update(buf, 0, n)
                    copied += n
                    // Unknown size: re-check space periodically so a full disk fails cleanly, not half-way silently.
                    if (expectedSize == null && copied % (64L * BUFFER) < n && freeBytes() < SAFETY_MARGIN_BYTES) {
                        return err(FailureKind.NO_SPACE, "نفدت المساحة أثناء النسخ")
                    }
                    onProgress(copied, expectedSize ?: -1L)
                }
                out.flush()
                out.fd.sync()
            }
            if (copied == 0L) return err(FailureKind.INVALID_MODEL_FILE, "الملف فارغ")
            if (expectedSize != null && copied != expectedSize) {
                return err(FailureKind.FILE_ACCESS, "حجم النسخة ($copied) لا يطابق حجم الأصل ($expectedSize)")
            }
            target.delete()
            if (!part.renameTo(target)) return err(FailureKind.FILE_ACCESS, "تعذّر إنهاء حفظ الملف المستورد")
            committed = true
            val sha = digest.digest().joinToString("") { "%02x".format(it) }
            onProgress(copied, copied)
            return ProviderResult.Ok(ImportedModel(finalName, copied, sha), (System.nanoTime() - started) / 1_000_000)
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            val noSpace = e.message?.contains("ENOSPC", ignoreCase = true) == true ||
                e.message?.contains("No space", ignoreCase = true) == true
            return if (noSpace) err(FailureKind.NO_SPACE, "نفدت المساحة أثناء النسخ")
            else err(FailureKind.FILE_ACCESS, "تعذّرت قراءة الملف أو كتابته أثناء الاستيراد")
        } finally {
            if (!committed) part.delete()
        }
    }

    private fun err(kind: FailureKind, msg: String): ProviderResult.Err = ProviderResult.Err(ProviderFailure(kind, msg))
    private fun mb(b: Long) = b / (1024 * 1024)
}
