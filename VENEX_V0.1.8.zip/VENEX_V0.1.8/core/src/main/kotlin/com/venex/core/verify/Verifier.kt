package com.venex.core.verify

import com.venex.core.device.ScreenSnapshot
import com.venex.core.intent.TextNormalizer
import com.venex.core.model.Expectation
import java.math.BigDecimal
import java.math.RoundingMode

sealed interface Verification {
    data class Verified(val evidence: String) : Verification
    data class Failed(val reason: String) : Verification

    /** Not enough information to confirm OR refute (e.g. Accessibility unavailable). */
    data class Unverifiable(val reason: String) : Verification
}

/** Facts the engine knows from earlier steps. */
data class VerificationContext(val openedPackage: String? = null)

object Verifier {

    fun verify(expectation: Expectation, snapshot: ScreenSnapshot?, ctx: VerificationContext): Verification {
        if (snapshot == null) {
            return Verification.Unverifiable("تعذّرت قراءة الشاشة (خدمة إمكانية الوصول غير مفعّلة أو لا توجد نافذة نشطة).")
        }
        return when (expectation) {
            Expectation.OpenedAppInForeground -> verifyForeground(snapshot, ctx)
            is Expectation.CalculatorShows -> verifyCalculator(expectation, snapshot)
            is Expectation.ScreenContainsText -> {
                val wanted = TextNormalizer.normalize(expectation.text)
                val hit = snapshot.allText().firstOrNull { TextNormalizer.normalize(it).contains(wanted) }
                if (hit != null) Verification.Verified("النص «${expectation.text}» ظاهر على الشاشة")
                else Verification.Failed("النص «${expectation.text}» غير ظاهر على الشاشة")
            }
        }
    }

    private fun verifyForeground(s: ScreenSnapshot, ctx: VerificationContext): Verification {
        val expected = ctx.openedPackage
            ?: return Verification.Unverifiable("لا توجد حزمة تطبيق معروفة للتحقق منها.")
        return if (s.packageName == expected) {
            Verification.Verified("التطبيق $expected في المقدمة")
        } else {
            Verification.Failed("التطبيق الظاهر هو ${s.packageName ?: "غير معروف"} وليس $expected")
        }
    }

    private fun verifyCalculator(e: Expectation.CalculatorShows, s: ScreenSnapshot): Verification {
        // Strong evidence: a node that is explicitly the result (id contains "result"/"final").
        val resultNodes = s.nodes.filter { n ->
            val id = n.viewId?.lowercase().orEmpty()
            id.contains("result") || id.contains("final")
        }
        val strongMatch = resultNodes.firstNotNullOfOrNull { n -> matchNumber(n.text ?: n.contentDescription, e.expected) }
        if (strongMatch != null) {
            return Verification.Verified("حقل النتيجة يعرض $strongMatch (المتوقع ${e.expected.toPlainString()})")
        }

        // Weak evidence: any numeric text equal to the expected value. If the expected value equals
        // an operand, the match could just be the typed input, so we refuse to call it verified.
        // Clickable nodes are keys/buttons (e.g. the "8" key), never the display, so they are ignored.
        val anyMatch = s.nodes.filter { !it.clickable }.firstNotNullOfOrNull { n ->
            listOfNotNull(n.text, n.contentDescription).firstNotNullOfOrNull { matchNumber(it, e.expected) }
        }
        if (anyMatch != null) {
            val ambiguous = e.operands.any { it.compareTo(e.expected) == 0 }
            return if (ambiguous) {
                Verification.Unverifiable("القيمة $anyMatch ظاهرة لكنها تساوي أحد المدخلات؛ لا يمكن تأكيد أنها النتيجة.")
            } else {
                Verification.Verified("الشاشة تعرض $anyMatch (المتوقع ${e.expected.toPlainString()})")
            }
        }

        val numbers = s.allTextNumbers()
        return Verification.Failed(
            "النتيجة المتوقعة ${e.expected.toPlainString()} لم تظهر. الأرقام الظاهرة: ${numbers.take(6).joinToString(", ").ifEmpty { "لا شيء" }}"
        )
    }

    private fun ScreenSnapshot.allTextNumbers(): List<String> =
        allText().mapNotNull { parseNumber(it)?.toPlainString() }

    /** Returns the display string if [raw] parses to a number equal (to displayed precision) to [expected]. */
    private fun matchNumber(raw: String?, expected: BigDecimal): String? {
        val shown = parseNumber(raw ?: return null) ?: return null
        if (shown.compareTo(expected) == 0) return shown.toPlainString()
        // Calculators round long/non-terminating results; compare at the displayed scale.
        if (shown.scale() > 0) {
            val up = expected.setScale(shown.scale(), RoundingMode.HALF_UP)
            val down = expected.setScale(shown.scale(), RoundingMode.DOWN)
            if (shown.compareTo(up) == 0 || shown.compareTo(down) == 0) return shown.toPlainString()
        }
        return null
    }

    /** Parses calculator display strings such as "1,000", "= 1000", "١٠٠٠", "−5". */
    fun parseNumber(raw: String): BigDecimal? {
        val t = TextNormalizer.normalize(raw)
            .replace("=", "")
            .replace(",", "")
            .replace(" ", "")
            .replace("−", "-")
            .replace("–", "-")
        if (t.isEmpty()) return null
        if (!Regex("-?\\d+(\\.\\d+)?").matches(t)) return null
        return t.toBigDecimalOrNull()
    }
}
