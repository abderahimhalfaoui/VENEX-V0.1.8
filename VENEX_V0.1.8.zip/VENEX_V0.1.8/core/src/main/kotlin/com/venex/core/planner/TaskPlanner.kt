package com.venex.core.planner

import com.venex.core.model.Action
import com.venex.core.model.AdaptiveGoal
import com.venex.core.model.CalculateGoal
import com.venex.core.model.Expectation
import com.venex.core.model.GlobalKey
import com.venex.core.model.Goal
import com.venex.core.model.MathOp
import com.venex.core.model.NavTarget
import com.venex.core.model.NavigateGoal
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.Plan
import com.venex.core.model.RestrictedGoal
import com.venex.core.model.ScrollGoal
import com.venex.core.model.SearchInAppGoal
import com.venex.core.model.Selector
import com.venex.core.model.Step
import com.venex.core.model.UnknownGoal
import com.venex.core.safety.SafetyDecision
import com.venex.core.safety.SafetyPolicy
import java.math.BigDecimal

/** Splits a [Goal] into ordered, dependency-linked steps with verifiable expectations. */
class TaskPlanner {

    fun plan(goal: Goal): Plan {
        val decision = SafetyPolicy.checkGoal(goal)
        if (decision is SafetyDecision.Deny) return Plan(goal, emptyList(), decision.reason)

        return when (goal) {
            is OpenAppGoal -> planOpenApp(goal)
            is SearchInAppGoal -> planSearch(goal)
            is CalculateGoal -> planCalculate(goal)
            is NavigateGoal -> Plan(
                goal,
                listOf(
                    Step(
                        id = "nav",
                        description = if (goal.target == NavTarget.HOME) "العودة إلى الشاشة الرئيسية" else "الرجوع للخلف",
                        action = Action.Press(if (goal.target == NavTarget.HOME) GlobalKey.HOME else GlobalKey.BACK)
                    )
                )
            )
            is ScrollGoal -> Plan(
                goal,
                listOf(Step("scroll", "تمرير الشاشة", Action.Scroll(goal.direction)))
            )
            // V0.1.8: adaptive goals are carried out by AdaptiveCoordinator, never by this fixed-step planner.
            is AdaptiveGoal -> Plan(goal, emptyList(), "هذا الهدف يُنفَّذ عبر المسار التكيفي لا عبر المخطِّط الأساسي.")
            is RestrictedGoal -> Plan(goal, emptyList(), "طلب مقيَّد")
            is UnknownGoal -> Plan(
                goal,
                emptyList(),
                "لم أفهم الأمر. جرّب مثلاً: «افتح تطبيق الآلة الحاسبة واحسب 125 × 8» أو «افتح الكاميرا»."
            )
        }
    }

    private fun planOpenApp(goal: OpenAppGoal): Plan = Plan(
        goal,
        listOf(
            Step(
                id = "open",
                description = "فتح تطبيق «${goal.appName}»",
                action = Action.OpenApp(goal.appName),
                expectation = Expectation.OpenedAppInForeground
            )
        )
    )

    /**
     * One verifiable step: the results address is opened, and the step is verified only if the query text is
     * visible on the screen afterwards. Without that evidence the report stays UNVERIFIED, never SUCCESS.
     */
    private fun planSearch(goal: SearchInAppGoal): Plan {
        val service = SearchServices.forApp(goal.appName)
            ?: return Plan(
                goal,
                emptyList(),
                "البحث داخل «${goal.appName}» غير مدعوم في هذه النسخة، ولا أستطيع الكتابة في حقول البحث بعد. " +
                    "أستطيع فتح التطبيق فقط."
            )
        return Plan(
            goal,
            listOf(
                Step(
                    id = "search",
                    description = "فتح نتائج البحث عن «${goal.query}» في ${service.label}",
                    action = Action.OpenDeepLink(service.url(goal.query)),
                    expectation = Expectation.ScreenContainsText(goal.query)
                )
            )
        )
    }

    private fun planCalculate(goal: CalculateGoal): Plan {
        val expected = goal.expected()
            ?: return Plan(goal, emptyList(), "العملية غير معرّفة رياضياً (قسمة على صفر).")

        if (goal.left.signum() < 0 || goal.right.signum() < 0) {
            return Plan(goal, emptyList(), "الأعداد السالبة غير مدعومة في V0.1.")
        }

        val steps = ArrayList<Step>()
        var prev: String? = null
        fun add(id: String, desc: String, action: Action, optional: Boolean = false, exp: Expectation? = null) {
            steps += Step(
                id = id,
                description = desc,
                action = action,
                dependsOn = listOfNotNull(prev),
                optional = optional,
                expectation = exp,
                // A click that reports failure did nothing (e.g. the app UI is still loading), so
                // re-trying it cannot duplicate a key press.
                maxAttempts = if (action is Action.Click) 3 else 1
            )
            prev = id
        }

        add("open", "فتح تطبيق الآلة الحاسبة", Action.OpenApp("الآلة الحاسبة"), exp = Expectation.OpenedAppInForeground)
        add("clear", "مسح الشاشة", Action.Click(CLEAR), optional = true)

        keysFor(goal.left).forEachIndexed { i, key -> add("left$i", "إدخال «${key.describe()}»", Action.Click(key)) }
        add("op", "اختيار العملية ${goal.op.symbol}", Action.Click(opSelector(goal.op)))
        keysFor(goal.right).forEachIndexed { i, key -> add("right$i", "إدخال «${key.describe()}»", Action.Click(key)) }
        add("equals", "الضغط على يساوي", Action.Click(EQUALS))
        add(
            "read",
            "قراءة النتيجة والتحقق منها (المتوقع ${expected.stripTrailingZeros().toPlainString()})",
            Action.ReadScreen,
            exp = Expectation.CalculatorShows(expected, listOf(goal.left, goal.right))
        )
        return Plan(goal, steps)
    }

    private fun keysFor(n: BigDecimal): List<Selector> =
        n.toPlainString().map { c ->
            when {
                c.isDigit() -> digit(c)
                c == '.' -> DECIMAL
                else -> error("Unsupported character '$c' (negative numbers are out of scope for V0.1)")
            }
        }

    companion object {
        private val ARABIC_INDIC = "٠١٢٣٤٥٦٧٨٩"

        fun digit(c: Char): Selector = Selector(listOf(c.toString(), ARABIC_INDIC[c - '0'].toString()))

        val DECIMAL = Selector(listOf(".", ",", "٫", "decimal", "point", "dot"))
        val CLEAR = Selector(listOf("C", "AC", "CE", "clear", "مسح"))
        val EQUALS = Selector(listOf("=", "equals", "equal", "يساوي"))

        fun opSelector(op: MathOp): Selector = when (op) {
            MathOp.ADD -> Selector(listOf("+", "plus", "add", "زائد"))
            MathOp.SUBTRACT -> Selector(listOf("−", "-", "–", "minus", "subtract", "ناقص"))
            MathOp.MULTIPLY -> Selector(listOf("×", "x", "*", "multiply", "times", "ضرب"))
            MathOp.DIVIDE -> Selector(listOf("÷", "/", "divide", "division", "قسمة"))
        }
    }
}
