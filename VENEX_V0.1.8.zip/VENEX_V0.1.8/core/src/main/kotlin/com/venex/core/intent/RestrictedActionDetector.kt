package com.venex.core.intent

import com.venex.core.model.RestrictedCategory

/**
 * Detects commands that ask to send / post / delete / pay. This runs BEFORE any parser
 * (including AI providers) so that no model output can turn such a request into an
 * auto-executed plan.
 */
object RestrictedActionDetector {

    private val words: Map<RestrictedCategory, Set<String>> = mapOf(
        RestrictedCategory.SEND to setOf(
            "ارسل", "ارسال", "ابعث", "بعث", "send"
        ),
        RestrictedCategory.POST to setOf(
            "انشر", "نشر", "post", "publish", "tweet"
        ),
        RestrictedCategory.DELETE to setOf(
            "احذف", "حذف", "delete", "remove", "erase", "uninstall"
        ),
        RestrictedCategory.PAYMENT to setOf(
            "ادفع", "دفع", "حول", "تحويل", "اشتري", "شراء", "pay", "buy", "purchase", "transfer", "checkout"
        )
    )

    fun detect(text: String): RestrictedCategory? {
        val tokens = TextNormalizer.normalize(text)
            .split(' ', '+', '*', '/', '-', ',', '.')
            .filter { it.isNotEmpty() }
        for (token in tokens) {
            // Strip a leading conjunction "و" (e.g. وارسل, واحذف) when the remainder matches.
            val variants = if (token.length > 3 && token.startsWith("و")) listOf(token, token.drop(1)) else listOf(token)
            for ((category, set) in words) {
                if (variants.any { it in set }) return category
            }
        }
        return null
    }
}
