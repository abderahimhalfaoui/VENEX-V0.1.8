package com.venex.core.adaptive

import com.venex.core.ai.MiniJson
import com.venex.core.goal.GoalFamily
import com.venex.core.goal.Slot
import com.venex.core.goal.SlotName
import com.venex.core.goal.SlotStatus
import java.io.File
import java.math.BigDecimal

enum class TaskPhase { RUNNING, PAUSED, WAITING_OWNER, DONE, FAILED, CANCELLED }

/**
 * Per-step bookkeeping that lets a task be resumed without repeating what is already done. SENSITIVE_STARTED is written
 * BEFORE a sensitive control is pressed: if the process dies right after, the resumed task knows the press may have
 * happened and will verify instead of pressing again.
 */
enum class StepMark { DONE, SKIPPED, SENSITIVE_STARTED, FAILED }

data class TaskState(
    val taskId: String,
    val family: GoalFamily,
    /** Slot values, including the owner's text, kept only on this device and only while the task can still be resumed. */
    val slots: List<Slot>,
    val appPackage: String?,
    val phase: TaskPhase,
    val steps: Map<String, StepMark>,
    val note: String?,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
) {
    val terminal: Boolean get() = phase == TaskPhase.DONE || phase == TaskPhase.FAILED || phase == TaskPhase.CANCELLED
    val resumable: Boolean get() = !terminal && slots.none { it.name == SlotName.TEXT && it.value == null && it.status != SlotStatus.MISSING }

    /** A finished task keeps no content: the owner's text is dropped from what is stored. */
    fun purged(): TaskState = copy(slots = slots.map { if (it.name == SlotName.TEXT) it.copy(value = null, note = "حُذف النص بعد انتهاء المهمة") else it })

    fun toJson(): String = MiniJson.encode(
        mapOf(
            "id" to taskId, "family" to family.name, "pkg" to appPackage, "phase" to phase.name, "note" to note,
            "created" to createdAtMillis, "updated" to updatedAtMillis,
            "steps" to steps.mapValues { it.value.name },
            "slots" to slots.map { mapOf("n" to it.name.name, "v" to it.value, "s" to it.status.name, "note" to it.note) }
        )
    )

    companion object {
        /** Null for anything that is not a well-formed state (a corrupt or foreign line is ignored, never trusted). */
        fun fromJson(line: String): TaskState? {
            return try {
                val parsed = MiniJson.parse(line) as? Map<*, *> ?: return null
                val slots = (parsed["slots"] as? List<*>).orEmpty().mapNotNull { e ->
                    val s = e as? Map<*, *> ?: return@mapNotNull null
                    Slot(SlotName.valueOf(s["n"] as String), s["v"] as String?, SlotStatus.valueOf(s["s"] as String), s["note"] as String?)
                }
                val steps = (parsed["steps"] as? Map<*, *>).orEmpty().entries.associate { (k, v) -> (k as String) to StepMark.valueOf(v as String) }
                TaskState(
                    taskId = parsed["id"] as String, family = GoalFamily.valueOf(parsed["family"] as String), slots = slots,
                    appPackage = parsed["pkg"] as String?, phase = TaskPhase.valueOf(parsed["phase"] as String), steps = steps,
                    note = parsed["note"] as String?,
                    createdAtMillis = (parsed["created"] as BigDecimal).toLong(), updatedAtMillis = (parsed["updated"] as BigDecimal).toLong()
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

interface TaskStateStore {
    fun save(state: TaskState)
    fun load(taskId: String): TaskState?

    /** The most recently updated task that can still be resumed. */
    fun latestResumable(): TaskState?
    fun delete(taskId: String)
}

class InMemoryTaskStateStore : TaskStateStore {
    private val map = LinkedHashMap<String, TaskState>()

    @Synchronized override fun save(state: TaskState) { map[state.taskId] = if (state.terminal) state.purged() else state }
    @Synchronized override fun load(taskId: String): TaskState? = map[taskId]
    @Synchronized override fun latestResumable(): TaskState? = map.values.filter { it.resumable }.maxByOrNull { it.updatedAtMillis }
    @Synchronized override fun delete(taskId: String) { map.remove(taskId) }
}

/**
 * Local JSONL file (one state per line, the last line for a task wins). A line that cannot be read is skipped; the
 * file is rewritten compactly when it grows. A task that ended keeps no text. Nothing here leaves the device.
 */
class FileTaskStateStore(private val file: File, private val maxLinesBeforeCompaction: Int = 200) : TaskStateStore {
    private val lock = Any()

    override fun save(state: TaskState) = synchronized(lock) {
        val s = if (state.terminal) state.purged() else state
        val line = s.toJson()
        if (line.length > MAX_LINE_CHARS) {
            // Too large for the bounded JSON reader: store without the text (such a task cannot be resumed with its text).
            appendLine(s.copy(slots = s.slots.map { if (it.name == SlotName.TEXT) it.copy(value = null, note = "النص أطول من أن يُحفظ للاستئناف") else it }).toJson())
        } else appendLine(line)
        compactIfNeeded()
    }

    override fun load(taskId: String): TaskState? = synchronized(lock) { readAll()[taskId] }
    override fun latestResumable(): TaskState? = synchronized(lock) { readAll().values.filter { it.resumable }.maxByOrNull { it.updatedAtMillis } }
    override fun delete(taskId: String) = synchronized(lock) {
        val all = readAll().filterKeys { it != taskId }
        rewrite(all.values)
    }

    private fun appendLine(line: String) {
        file.parentFile?.mkdirs()
        file.appendText(line + "\n", Charsets.UTF_8)
    }

    private fun readAll(): Map<String, TaskState> {
        if (!file.exists()) return emptyMap()
        val out = LinkedHashMap<String, TaskState>()
        try {
            file.readLines(Charsets.UTF_8).forEach { l ->
                if (l.isNotBlank() && l.length <= MAX_LINE_CHARS) TaskState.fromJson(l)?.let { out[it.taskId] = it }
            }
        } catch (_: Exception) {
            // an unreadable file is treated as empty, never as a reason to crash a task
        }
        return out
    }

    private fun compactIfNeeded() {
        try {
            if (file.length() < 64 * 1024) return
            val lines = file.readLines(Charsets.UTF_8).size
            if (lines > maxLinesBeforeCompaction) rewrite(readAll().values.sortedBy { it.updatedAtMillis }.takeLast(50))
        } catch (_: Exception) {
        }
    }

    private fun rewrite(states: Collection<TaskState>) {
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".tmp")
        tmp.writeText(states.joinToString("") { it.toJson() + "\n" }, Charsets.UTF_8)
        if (!tmp.renameTo(file)) { file.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8); tmp.delete() }
    }

    companion object {
        const val MAX_LINE_CHARS = 15_000
    }
}
