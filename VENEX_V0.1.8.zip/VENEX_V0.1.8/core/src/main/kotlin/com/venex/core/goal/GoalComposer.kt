package com.venex.core.goal

import com.venex.core.adaptive.ExecutionMethod
import com.venex.core.device.Channel
import com.venex.core.env.TargetKind
import com.venex.core.env.TargetSpec
import com.venex.core.env.normLabel
import com.venex.core.safety.ActionRiskClassifier
import com.venex.core.safety.RiskAssessment
import com.venex.core.safety.SensitiveCategory
import com.venex.core.verify.Check
import com.venex.core.verify.TextScope
import com.venex.core.verify.VerificationCondition

/** What the interpreter may know about the device right now. Plain data: the core never reads Android itself. */
data class InterpretationContext(
    val foregroundPackage: String? = null,
    val foregroundLabel: String? = null,
    /** VENEX's own package: when it is in front, there is no "current app" to refer to. */
    val selfPackage: String? = null
) {
    val foregroundIsUsable: Boolean get() = foregroundPackage != null && foregroundPackage != selfPackage
}

/**
 * Turns a family plus the slots found in a command into a complete [StructuredGoal]: it decides which slots are still
 * missing (and what to ask), what the risk is, what the expected final state is, how it will be verified, and keeps
 * what the owner said apart from what was inferred and what is unknown. It is also what a resumed task uses to
 * rebuild its goal from stored slots.
 */
object GoalComposer {

    const val MAX_TEXT_CHARS = 8_000

    fun required(family: GoalFamily): List<SlotName> = when (family) {
        GoalFamily.DESCRIBE_SCREEN, GoalFamily.PAYMENT -> emptyList()
        GoalFamily.TAP, GoalFamily.DELETE_ITEM -> listOf(SlotName.TARGET)
        GoalFamily.ENTER_TEXT -> listOf(SlotName.TEXT)
        GoalFamily.SEARCH_IN_APP -> listOf(SlotName.APP, SlotName.QUERY)
        GoalFamily.CREATE_POST -> listOf(SlotName.APP, SlotName.TEXT)
        GoalFamily.SEND_MESSAGE -> listOf(SlotName.APP, SlotName.RECIPIENT, SlotName.TEXT)
    }

    fun compose(
        rawText: String,
        family: GoalFamily,
        given: List<Slot>,
        ctx: InterpretationContext,
        extraClarifications: List<Clarification> = emptyList(),
        extraStatements: List<Statement> = emptyList()
    ): StructuredGoal {
        val slots = LinkedHashMap<SlotName, Slot>()
        given.forEach { slots[it.name] = it }
        val required = required(family)
        val clarifications = ArrayList<Clarification>(extraClarifications)

        // An over-long text is not silently cut: the owner is told.
        slots[SlotName.TEXT]?.let { t ->
            if (t.usable && (t.value?.length ?: 0) > MAX_TEXT_CHARS) {
                slots[SlotName.TEXT] = Slot(SlotName.TEXT, null, SlotStatus.MISSING, "النص أطول من الحد (${t.value?.length} حرفاً)")
                clarifications += Clarification(SlotName.TEXT, "النص أطول من الحد المسموح ($MAX_TEXT_CHARS حرفاً). اختصره أو قسّمه.")
            }
        }

        // The app: what the owner named, else the app in front (as an inference), else it is missing.
        val appNeeded = family != GoalFamily.DESCRIBE_SCREEN && family != GoalFamily.PAYMENT
        if (appNeeded && slots[SlotName.APP]?.usable != true) {
            if (ctx.foregroundIsUsable) {
                val shown = ctx.foregroundLabel ?: ctx.foregroundPackage
                slots[SlotName.APP] = Slot(SlotName.APP, shown, SlotStatus.INFERRED, "التطبيق الظاهر في المقدمة الآن")
            } else if (SlotName.APP in required) {
                slots[SlotName.APP] = Slot(SlotName.APP, null, SlotStatus.MISSING, "لا تطبيق آخر في المقدمة")
            }
        }
        if (family == GoalFamily.ENTER_TEXT && slots[SlotName.FIELD] == null) {
            slots[SlotName.FIELD] = Slot(SlotName.FIELD, null, SlotStatus.MISSING, "الحقل المركَّز أو الوحيد على الشاشة")
        }

        for (name in required) {
            val s = slots[name]
            if (s != null && s.usable) continue
            if (clarifications.any { it.slot == name }) continue
            if (s == null) slots[name] = Slot(name, null, SlotStatus.MISSING)
            clarifications += Clarification(name, question(family, slots[name]!!, ctx))
        }

        val risk = riskOf(family, slots)
        val statements = ArrayList<Statement>(extraStatements)
        for (s in slots.values) {
            val v = s.value ?: continue
            val shown = if (s.name == SlotName.TEXT) "«${v.take(60)}${if (v.length > 60) "…" else ""}» (${v.length} حرفاً)" else "«${v.take(80)}»"
            when (s.status) {
                SlotStatus.EXPLICIT -> statements += Statement("${s.name.arabicLabel}: $shown" + (s.note?.let { " — $it" } ?: ""), Origin.OWNER_EXPLICIT)
                SlotStatus.INFERRED -> statements += Statement("${s.name.arabicLabel}: $shown — استنتاج: ${s.note ?: "من السياق"}", Origin.SYSTEM_INFERRED)
                else -> Unit
            }
        }
        unknownsOf(family).forEach { statements += Statement(it, Origin.UNKNOWN) }
        clarifications.forEach { statements += Statement(it.question, Origin.NEEDS_OWNER) }
        if (risk.requiresApproval) {
            val what = risk.categories.joinToString("، ") { it.arabicLabel }
            statements += Statement("موافقة صريحة منك مرتبطة بهذه العملية بعينها قبل $what", Origin.NEEDS_OWNER)
        }

        val appExplicit = slots[SlotName.APP]?.status == SlotStatus.EXPLICIT
        val perms = LinkedHashSet<Channel>().apply {
            add(Channel.ACCESSIBILITY)
            if (appExplicit) add(Channel.INTENT)
        }
        val constraints = ArrayList<String>().apply {
            add("لا يُتجاوز CAPTCHA أو تسجيل الدخول أو أي قيد يضعه التطبيق")
            add("الخطوات تُحدَّد بما يظهر فعلاً على الشاشة لا بالإحداثيات وحدها")
            if (risk.requiresApproval) add("لا تُنفَّذ الخطوة الحساسة دون موافقة مرتبطة بالعملية والمحتوى والتطبيق والهدف")
        }

        return StructuredGoal(
            rawText = rawText,
            family = family,
            desiredOutcome = outcome(family, slots),
            slots = slots.values.toList(),
            preconditions = preconditions(family, appExplicit),
            requiredPermissions = perms,
            constraints = constraints,
            possiblePaths = paths(family, appExplicit),
            expectedFinalState = finalState(family, slots),
            verification = checks(family, slots, ctx),
            risk = risk,
            statements = statements,
            clarifications = clarifications
        )
    }

    // ---------------------------------------------------------------------------------------------------------------

    private fun question(family: GoalFamily, s: Slot, ctx: InterpretationContext): String = when (s.name) {
        SlotName.APP ->
            if (ctx.foregroundPackage != null && ctx.foregroundPackage == ctx.selfPackage)
                "في أي تطبيق تريد ذلك؟ لا يوجد تطبيق آخر مفتوح أمامي الآن، فلا أعرف أي تطبيق تقصد."
            else "في أي تطبيق تريد ذلك؟"
        SlotName.TEXT -> when {
            s.status == SlotStatus.REFERENCED_BUT_ABSENT ->
                "أشرتَ إلى نص أعطيتنيه، لكنني لم أجد ملفاً نصياً مرفقاً" + (s.note?.let { " ($it)" } ?: "") +
                    ". أرفق الملف أو اكتب النص نفسه بين علامتي تنصيص."
            family == GoalFamily.CREATE_POST -> "ما النص الذي تريد نشره؟ اكتبه بين علامتي تنصيص أو أرفقه كملف نصي. لا أؤلف محتوى من عندي."
            family == GoalFamily.SEND_MESSAGE -> "ما نص الرسالة؟ اكتبه بين علامتي تنصيص أو أرفقه كملف نصي."
            else -> "ما النص الذي تريد كتابته؟ اكتبه بين علامتي تنصيص."
        }
        SlotName.RECIPIENT -> "لمن تريد إرسال الرسالة؟ اذكر اسم المستلم كما يظهر في التطبيق."
        SlotName.QUERY -> "عن ماذا تريد أن أبحث؟"
        SlotName.TARGET ->
            if (family == GoalFamily.DELETE_ITEM) "ما العنصر الذي تريد حذفه تحديداً؟ لا أحذف شيئاً لم يُسمَّ بوضوح."
            else "أي عنصر تريد الضغط عليه؟ اذكر اسمه كما يظهر على الشاشة."
        SlotName.FIELD -> "أي حقل تقصد؟"
    }

    private fun riskOf(family: GoalFamily, slots: Map<SlotName, Slot>): RiskAssessment = when (family) {
        GoalFamily.CREATE_POST -> ActionRiskClassifier.assessCategories(setOf(SensitiveCategory.POST), "نشر منشور يظهر للآخرين ولا يُسترجع بسهولة")
        GoalFamily.SEND_MESSAGE -> ActionRiskClassifier.assessCategories(setOf(SensitiveCategory.SEND), "إرسال رسالة إلى شخص آخر")
        GoalFamily.DELETE_ITEM -> {
            val label = slots[SlotName.TARGET]?.value
            val cats = LinkedHashSet<SensitiveCategory>().apply {
                add(SensitiveCategory.DELETE)
                addAll(ActionRiskClassifier.assessLabel(label).categories)
            }
            ActionRiskClassifier.assessCategories(cats, "حذف عنصر")
        }
        GoalFamily.PAYMENT -> ActionRiskClassifier.assessCategories(setOf(SensitiveCategory.PAYMENT), "عملية دفع أو شراء أو تحويل")
        GoalFamily.TAP -> ActionRiskClassifier.assessLabel(slots[SlotName.TARGET]?.value)
        GoalFamily.ENTER_TEXT, GoalFamily.SEARCH_IN_APP, GoalFamily.DESCRIBE_SCREEN -> RiskAssessment.SAFE
    }

    private fun unknownsOf(family: GoalFamily): List<String> = when (family) {
        GoalFamily.CREATE_POST -> listOf(
            "هل الحساب مسجَّل الدخول وهل يتيح التطبيق النشر؟ لا أعرف قبل رؤية الشاشة",
            "حدود طول المنشور وقواعده في التطبيق غير معروفة"
        )
        GoalFamily.SEND_MESSAGE -> listOf("هوية المستلم الفعلية في التطبيق لا تُعرف إلا بعد رؤية الشاشة", "هل الحساب مسجَّل الدخول؟ غير معروف")
        GoalFamily.DELETE_ITEM -> listOf("هل العنصر موجود على الشاشة الآن وهل الحذف قابل للتراجع؟ غير معروف")
        GoalFamily.SEARCH_IN_APP -> listOf("موضع حقل البحث في هذا التطبيق غير معروف حتى تُرى الشاشة")
        GoalFamily.TAP -> listOf("هل العنصر موجود على الشاشة الآن؟ غير معروف")
        GoalFamily.ENTER_TEXT -> listOf("هل يوجد حقل نصي قابل للكتابة الآن؟ غير معروف")
        GoalFamily.DESCRIBE_SCREEN, GoalFamily.PAYMENT -> emptyList()
    }

    private fun outcome(family: GoalFamily, s: Map<SlotName, Slot>): String {
        val app = s[SlotName.APP]?.value?.let { " في $it" } ?: ""
        return when (family) {
            GoalFamily.DESCRIBE_SCREEN -> "وصف ما يظهر على الشاشة الآن"
            GoalFamily.TAP -> "الضغط على «${s[SlotName.TARGET]?.value ?: "؟"}»$app"
            GoalFamily.ENTER_TEXT -> "كتابة النص في الحقل المطلوب"
            GoalFamily.SEARCH_IN_APP -> "البحث عن «${s[SlotName.QUERY]?.value ?: "؟"}»$app وإظهار النتائج"
            GoalFamily.CREATE_POST -> "نشر المنشور المطلوب$app"
            GoalFamily.SEND_MESSAGE -> "إرسال الرسالة إلى «${s[SlotName.RECIPIENT]?.value ?: "؟"}»$app"
            GoalFamily.DELETE_ITEM -> "حذف «${s[SlotName.TARGET]?.value ?: "؟"}»$app"
            GoalFamily.PAYMENT -> "عملية مالية (محظورة)"
        }
    }

    private fun finalState(family: GoalFamily, s: Map<SlotName, Slot>): String = when (family) {
        GoalFamily.DESCRIBE_SCREEN -> "لا تغيير: قراءة فقط"
        GoalFamily.TAP -> "تغيّرت الواجهة بعد الضغط (النتيجة المقصودة غير محدَّدة، فلا يمكن تأكيدها إلا جزئياً)"
        GoalFamily.ENTER_TEXT -> "الحقل يحتوي النص المطلوب"
        GoalFamily.SEARCH_IN_APP -> "شاشة نتائج بحث تعرض «${s[SlotName.QUERY]?.value ?: "؟"}»"
        GoalFamily.CREATE_POST -> "المنشور ظاهر خارج حقل الكتابة (في الصفحة/الخلاصة) وحقل الكتابة أُغلق"
        GoalFamily.SEND_MESSAGE -> "الرسالة ظاهرة في المحادثة خارج حقل الكتابة"
        GoalFamily.DELETE_ITEM -> "العنصر لم يعد ظاهراً"
        GoalFamily.PAYMENT -> "لا يُنفَّذ"
    }

    private fun preconditions(family: GoalFamily, appExplicit: Boolean): List<String> = buildList {
        add("خدمة إمكانية الوصول (Accessibility) مفعّلة")
        if (appExplicit) add("التطبيق المطلوب مثبَّت وقابل للفتح")
        if (family in setOf(GoalFamily.CREATE_POST, GoalFamily.SEND_MESSAGE, GoalFamily.DELETE_ITEM)) add("الحساب داخل التطبيق مسجَّل الدخول (يُتحقَّق منه من الشاشة)")
    }

    private fun paths(family: GoalFamily, appExplicit: Boolean): List<ExecutionMethod> = buildList {
        when (family) {
            GoalFamily.DESCRIBE_SCREEN -> add(ExecutionMethod.ACCESSIBILITY_INTERACTION)
            GoalFamily.PAYMENT -> Unit
            else -> {
                if (appExplicit) add(ExecutionMethod.ANDROID_INTENT)
                if (family == GoalFamily.SEARCH_IN_APP) add(ExecutionMethod.DEEP_LINK)
                add(ExecutionMethod.UI_ELEMENT_INTERACTION)
            }
        }
    }

    private fun checks(family: GoalFamily, s: Map<SlotName, Slot>, ctx: InterpretationContext): List<Check> {
        val text = s[SlotName.TEXT]?.takeIf { it.usable }?.value
        val inferredApp = s[SlotName.APP]?.takeIf { it.status == SlotStatus.INFERRED }?.let { ctx.foregroundPackage }
        // The app being in front is context, not proof of the goal, so it is never a required condition.
        val appCheck = Check(VerificationCondition.AppInForeground(inferredApp), required = false)
        return when (family) {
            GoalFamily.DESCRIBE_SCREEN, GoalFamily.PAYMENT -> emptyList()
            GoalFamily.TAP -> listOf(Check(VerificationCondition.StateChanged))
            GoalFamily.ENTER_TEXT ->
                if (text == null) emptyList() else listOf(Check(VerificationCondition.FieldContains(fieldSpec(s[SlotName.FIELD]?.value), text)))
            GoalFamily.SEARCH_IN_APP -> {
                val q = s[SlotName.QUERY]?.takeIf { it.usable }?.value
                // The query alone proves little (it sits in the field once typed), so a changed screen is required too and the
                // verdict can honestly reach "partially verified", not more.
                listOfNotNull(q?.let { Check(VerificationCondition.TextVisible(it, TextScope.ANYWHERE)) }, Check(VerificationCondition.StateChanged), appCheck)
            }
            GoalFamily.CREATE_POST, GoalFamily.SEND_MESSAGE ->
                // Outside an input field: while it is still being typed it is inside one, so only publishing/sending puts it elsewhere.
                listOfNotNull(text?.let { Check(VerificationCondition.TextVisible(it, TextScope.NON_INPUT)) }, appCheck)
            GoalFamily.DELETE_ITEM -> {
                val t = s[SlotName.TARGET]?.takeIf { it.usable }?.value
                listOfNotNull(t?.let { Check(VerificationCondition.ElementAbsent(targetSpec(it, TargetKind.ANY), asOutcome = true)) })
            }
        }
    }

    // ---- symbolic targets ------------------------------------------------------------------------------------------

    private val FIELD_NOUNS = setOf("حقل", "مربع", "خانه", "خانة", "شريط", "field", "box", "bar", "input", "textbox", "the")

    /** A label as the owner wrote it, with and without the Arabic definite article, as exact and loose alternatives. */
    fun targetSpec(label: String, kind: TargetKind, description: String = label): TargetSpec {
        val t = label.trim()
        val variants = LinkedHashSet<String>()
        if (t.isNotEmpty()) variants += t
        if (t.startsWith("ال") && t.length > 3) variants += t.drop(2)
        return TargetSpec(
            description = description,
            labels = variants.toList(),
            labelContains = variants.filter { normLabel(it).length >= 2 },
            kind = kind
        )
    }

    /** "حقل البحث" / "the search field" -> a spec for the input whose label is "البحث"/"search". No label = "the" field. */
    fun fieldSpec(fieldPhrase: String?): TargetSpec {
        if (fieldPhrase.isNullOrBlank()) return TargetSpec("الحقل المركَّز أو الوحيد", kind = TargetKind.INPUT)
        val words = fieldPhrase.trim().split(Regex("\\s+")).filter { w ->
            val c = normLabel(w)
            c !in FIELD_NOUNS && c.removePrefix("ال") !in FIELD_NOUNS
        }
        val core = words.joinToString(" ").trim()
        if (core.isEmpty()) return TargetSpec("الحقل المركَّز أو الوحيد", kind = TargetKind.INPUT)
        return targetSpec(core, TargetKind.INPUT, description = "حقل $core")
    }
}
