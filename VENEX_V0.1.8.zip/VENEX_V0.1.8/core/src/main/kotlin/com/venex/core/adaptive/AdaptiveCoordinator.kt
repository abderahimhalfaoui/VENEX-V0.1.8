package com.venex.core.adaptive

import com.venex.core.audit.AuditLevel
import com.venex.core.audit.AuditLog
import com.venex.core.device.Channel
import com.venex.core.device.DeviceController
import com.venex.core.engine.DenyAllConfirmations
import com.venex.core.engine.ExecutionEngine
import com.venex.core.env.EnvironmentObserver
import com.venex.core.env.EnvironmentUnderstandingEngine
import com.venex.core.goal.GoalComposer
import com.venex.core.goal.GoalInterpreter
import com.venex.core.goal.Interpretation
import com.venex.core.goal.InterpretationContext
import com.venex.core.goal.StructuredGoal
import com.venex.core.intent.TextNormalizer
import com.venex.core.memory.ExperienceMemory
import com.venex.core.model.AdaptiveGoal
import com.venex.core.model.StepResult
import com.venex.core.model.StepStatus
import com.venex.core.model.TaskReport
import com.venex.core.model.TaskStatus
import com.venex.core.safety.ApprovalGate
import com.venex.core.safety.ApprovalHandler
import com.venex.core.safety.ApprovalLedger
import com.venex.core.verify.EvidenceVerdict
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Entry point of the V0.1.8 adaptive layer. It owns the pieces that must be shared by every task of a session (the
 * environment model, the approval ledger, the task store, the memory) and runs ONE task at a time.
 *
 * It does not depend on Android or on any chat UI: the device, the approval handler and the stores are handed in.
 * It never bypasses the engine: every action goes through [ExecutionEngine.executeStep].
 */
class AdaptiveCoordinator(
    private val device: DeviceController,
    private val audit: AuditLog,
    approvals: ApprovalHandler,
    private val store: TaskStateStore = InMemoryTaskStateStore(),
    private val memory: ExperienceMemory? = null,
    /** VENEX's own package: when it is in front, there is no "current app" to act in. */
    private val selfPackage: String? = null,
    private val interpreter: GoalInterpreter = GoalInterpreter(),
    private val limits: RunLimits = RunLimits(),
    private val clock: () -> Long = System::currentTimeMillis,
    private val settleDelayMs: Long = 150,
    approvalTtlMs: Long = 120_000
) {
    private val ledger = ApprovalLedger(clock, approvalTtlMs)
    private val gate = ApprovalGate(approvals, ledger)
    private val planner = AdaptivePlanner(memory ?: LabelHints.NONE)
    private val understanding = EnvironmentUnderstandingEngine(EnvironmentObserver(device, clock), clock)
    private val busy = AtomicBoolean(false)
    private val counter = AtomicLong(0)

    @Volatile private var control: TaskControl? = null

    // ---- what the owner asked ------------------------------------------------------------------------------------

    /** Reads the goal from [command] using what is in front of the device right now. Never acts. */
    suspend fun interpret(command: String): Interpretation = interpreter.interpret(command, context())

    /** Whether a stopped task is waiting to be resumed. */
    fun hasResumable(): Boolean = store.latestResumable() != null

    /** "استأنف" / "resume" — only meaningful (and only recognised by the assistant) when [hasResumable]. */
    fun isResumeCommand(command: String): Boolean {
        val words = TextNormalizer.normalize(command).split(' ').map { it.trim('.', '!', '؟', '?', ',', '،') }.filter { it.isNotEmpty() }
        if (words.isEmpty() || words.size > 3) return false
        return words[0] in RESUME_WORDS && words.drop(1).all { it in RESUME_FILLERS }
    }

    /** Plans without acting, so the caller can show the plan or the question for the owner first. */
    suspend fun plan(goal: StructuredGoal): AdaptivePlan = planner.plan(goal, device, foregroundPackage())

    // ---- running -------------------------------------------------------------------------------------------------

    suspend fun run(goal: StructuredGoal, onProgress: (StepResult) -> Unit = {}): TaskReport {
        val plan = plan(goal)
        plan.blockedReason?.let { return notExecuted(goal, it) }
        return runPlan(plan, null, onProgress)
    }

    /** Continues the last paused task. Steps already done are not repeated, and a sensitive step is never pressed twice. */
    suspend fun resume(onProgress: (StepResult) -> Unit = {}): TaskReport {
        val st = store.latestResumable()
            ?: return TaskReport(AdaptiveGoal(null, true, "استئناف"), TaskStatus.NOT_EXECUTED, "لا توجد مهمة متوقفة لأستأنفها.", emptyList())
        val goal = GoalComposer.compose("", st.family, st.slots, context(), emptyList(), emptyList())
        val plan = planner.plan(goal, device, st.appPackage ?: foregroundPackage())
        plan.blockedReason?.let { return notExecuted(goal, it) }
        return runPlan(plan, st, onProgress)
    }

    private suspend fun runPlan(plan: AdaptivePlan, resumeFrom: TaskState?, onProgress: (StepResult) -> Unit): TaskReport {
        if (!busy.compareAndSet(false, true)) {
            return notExecuted(plan.goal, "هناك مهمة تكيفية قيد التنفيذ الآن. انتظر انتهاءها أو أوقفها أولاً.")
        }
        val ctl = TaskControl()
        control = ctl
        try {
            val taskId = resumeFrom?.taskId ?: "t${clock()}-${counter.incrementAndGet()}"
            val engine = ExecutionEngine(device, audit, DenyAllConfirmations, settleDelayMs)
            val runner = AdaptiveRunner(device, audit, engine, understanding, gate, store, memory, limits, clock, settleDelayMs)
            val result = runner.run(plan, taskId, resumeFrom, ctl) { onProgress(it.toStepResult()) }
            return result.toTaskReport()
        } finally {
            control = null
            ledger.revokeAll() // an approval never outlives the task it was given for
            busy.set(false)
        }
    }

    /** Controls for the task that is running now. They act between steps, never in the middle of a press. */
    fun pause() { control?.pause() }
    fun resumePaused() { control?.resume() }
    fun cancel() { control?.cancel() }
    val isRunning: Boolean get() = busy.get()

    // ---- helpers -------------------------------------------------------------------------------------------------

    private suspend fun foregroundPackage(): String? =
        try {
            if (Channel.ACCESSIBILITY in device.capabilities()) device.snapshot()?.packageName else null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }

    private suspend fun context(): InterpretationContext {
        val pkg = foregroundPackage()
        return InterpretationContext(foregroundPackage = pkg, foregroundLabel = null, selfPackage = selfPackage)
    }

    private fun notExecuted(goal: StructuredGoal, why: String) =
        TaskReport(AdaptiveGoal(goal, false, goal.rawText), TaskStatus.NOT_EXECUTED, why, emptyList())

    companion object {
        private val RESUME_WORDS = setOf("استانف", "استمر", "تابع", "واصل", "كمل", "resume", "continue")
        private val RESUME_FILLERS = setOf("المهمه", "المهمة", "task", "من", "فضلك", "please", "الان", "now")
    }
}

// ---- mapping to the report types that the UI already understands ---------------------------------------------------

fun AdaptiveStepResult.toStepResult(): StepResult {
    val status = when (outcome) {
        StepOutcome.DONE -> if (verdict == EvidenceVerdict.VERIFIED) StepStatus.VERIFIED else StepStatus.EXECUTED_UNVERIFIED
        StepOutcome.SKIPPED -> StepStatus.SKIPPED
        StepOutcome.FAILED, StepOutcome.NEEDS_OWNER -> StepStatus.FAILED
        StepOutcome.DENIED -> StepStatus.CANCELLED_BY_USER
    }
    return StepResult(stepId, description, status, message, evidence.takeIf { it.isNotEmpty() }?.joinToString("؛ "))
}

/**
 * Honest mapping: only a goal-level VERIFIED verdict is SUCCESS. A task that stopped for the owner after acting is
 * UNVERIFIED (partial progress), never success; one that stopped before acting is NOT_EXECUTED.
 */
fun AdaptiveResult.toTaskReport(): TaskReport {
    val st = when (status) {
        RunStatus.COMPLETED -> when (verdict) {
            EvidenceVerdict.VERIFIED -> TaskStatus.SUCCESS
            EvidenceVerdict.FAILED -> TaskStatus.FAILED
            else -> TaskStatus.UNVERIFIED
        }
        RunStatus.FAILED -> TaskStatus.FAILED
        RunStatus.CANCELLED -> TaskStatus.CANCELLED
        RunStatus.NOT_EXECUTED -> TaskStatus.NOT_EXECUTED
        RunStatus.NEEDS_OWNER -> if (executedActions == 0) TaskStatus.NOT_EXECUTED else TaskStatus.UNVERIFIED
    }
    return TaskReport(AdaptiveGoal(goal, false, goal.rawText), st, summary, steps.map { it.toStepResult() })
}
