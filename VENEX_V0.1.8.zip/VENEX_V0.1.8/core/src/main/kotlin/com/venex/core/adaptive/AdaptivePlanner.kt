package com.venex.core.adaptive

import com.venex.core.device.AppResolution
import com.venex.core.device.DeviceController
import com.venex.core.env.TargetCatalog
import com.venex.core.env.TargetKind
import com.venex.core.env.TargetSpec
import com.venex.core.goal.GoalComposer
import com.venex.core.goal.GoalFamily
import com.venex.core.goal.SlotName
import com.venex.core.goal.SlotStatus
import com.venex.core.goal.StructuredGoal
import com.venex.core.safety.RiskAssessment
import com.venex.core.verify.Check
import com.venex.core.verify.TextScope
import com.venex.core.verify.VerificationCondition as C

/**
 * Turns a [StructuredGoal] into an ordered list of element-level steps. A plan is a sequence of INTENTS with the
 * conditions that make each of them unnecessary (skipWhen) and the evidence that shows it worked (expect); it contains
 * no coordinates and no per-app knowledge. Because every step starts by looking at the live screen, "re-planning" after
 * something unexpected is simply running the same plan again: steps whose result is already true are skipped.
 *
 * Needs a live device only to resolve an app NAME and to know which channels exist.
 */
class AdaptivePlanner(
    private val hints: LabelHints = LabelHints.NONE,
    private val selector: ExecutionMethodSelector = ExecutionMethodSelector()
) {

    suspend fun plan(goal: StructuredGoal, device: DeviceController, foregroundPackage: String? = null): AdaptivePlan {
        if (goal.needsClarification) return blocked(goal, goal.clarifications.joinToString("\n") { it.question })
        if (goal.risk.blocked) return blocked(goal, "هذه العملية محظورة في VENEX ولا تُنفَّذ حتى بموافقة.")

        val caps = device.capabilities()
        val notes = ArrayList<String>()

        // ---- the app
        var pkg: String? = null
        var label: String? = null
        var openName: String? = null
        val appSlot = goal.slot(SlotName.APP)
        if (appSlot?.usable == true) {
            if (appSlot.status == SlotStatus.EXPLICIT) {
                when (val r = device.resolveApp(appSlot.value!!)) {
                    AppResolution.NotFound -> return blocked(goal, "لم أجد تطبيقاً باسم «${appSlot.value}» بين التطبيقات المثبتة.")
                    is AppResolution.Ambiguous ->
                        return blocked(goal, "عدّة تطبيقات تطابق «${appSlot.value}»: ${r.candidates.joinToString("، ") { it.label }}. حدّد أحدها.")
                    is AppResolution.Found -> { pkg = r.app.packageName; label = r.app.label; openName = appSlot.value }
                }
            } else {
                pkg = foregroundPackage
                label = appSlot.value
            }
        }

        // ---- methods: a step whose method is unavailable blocks the plan with the reason, never a silent fallback
        fun choose(kind: StepKind, risk: RiskAssessment = RiskAssessment.SAFE, sensitive: Boolean = false, screen: Boolean = false): ExecutionMethod? {
            val d = selector.select(MethodRequest(kind, risk, sensitive, screen), caps)
            notes += d.explanation
            return d.selected?.method
        }

        val steps = ArrayList<AdaptiveStep>()
        fun spec(base: TargetSpec, role: String): TargetSpec {
            val learned = hints.labelsFor(pkg, role)
            return if (learned.isEmpty()) base else base.copy(labels = (learned + base.labels).distinct())
        }
        fun strict(s: TargetSpec) = s.copy(soleFallback = false)

        if (goal.family != GoalFamily.DESCRIBE_SCREEN && openName != null) {
            val m = choose(StepKind.OPEN_APP) ?: return blocked(goal, unavailable(notes), notes = notes)
            steps += AdaptiveStep(
                id = "open", description = "فتح تطبيق «$openName»", intent = StepIntent.OpenApp(openName, pkg),
                skipWhen = listOf(C.AppInForeground(pkg)), expect = listOf(Check(C.AppInForeground(pkg))), method = m
            )
        }

        val uiMethod = if (goal.family == GoalFamily.DESCRIBE_SCREEN) choose(StepKind.OBSERVE, screen = true)
        else choose(StepKind.TAP, goal.risk, sensitive = goal.value(SlotName.TEXT) != null, screen = true)
        if (uiMethod == null) return blocked(goal, unavailable(notes), notes = notes)

        val text = goal.value(SlotName.TEXT)
        when (goal.family) {
            GoalFamily.DESCRIBE_SCREEN ->
                steps += AdaptiveStep("observe", "قراءة الشاشة الحالية", StepIntent.Observe, method = uiMethod)

            GoalFamily.TAP -> {
                val t = goal.value(SlotName.TARGET)!!
                steps += AdaptiveStep(
                    "tap", "الضغط على «$t»", StepIntent.Tap(GoalComposer.targetSpec(t, TargetKind.CLICKABLE)),
                    expect = listOf(Check(C.StateChanged)), commit = goal.risk.requiresApproval,
                    risk = goal.risk, approvalTarget = t, method = uiMethod
                )
            }

            GoalFamily.ENTER_TEXT -> {
                val field = GoalComposer.fieldSpec(goal.slot(SlotName.FIELD)?.value)
                steps += AdaptiveStep(
                    "type", "كتابة نص من ${text!!.length} حرفاً", StepIntent.Type(field, text),
                    skipWhen = listOf(C.FieldContains(field, text)), expect = listOf(Check(C.FieldContains(field, text))), method = uiMethod
                )
            }

            GoalFamily.SEARCH_IN_APP -> {
                val q = goal.value(SlotName.QUERY)!!
                val affordance = spec(TargetCatalog.SEARCH_AFFORDANCE, Roles.SEARCH_AFFORDANCE)
                val field = spec(TargetCatalog.SEARCH_FIELD, Roles.SEARCH_FIELD)
                val submit = spec(TargetCatalog.SEARCH_SUBMIT, Roles.SEARCH_SUBMIT)
                steps += AdaptiveStep(
                    "search_open", "فتح حقل البحث", StepIntent.Tap(affordance), role = Roles.SEARCH_AFFORDANCE,
                    skipWhen = listOf(C.ElementPresent(strict(field))), expect = listOf(Check(C.ElementPresent(strict(field)))), method = uiMethod
                )
                steps += AdaptiveStep(
                    "search_type", "كتابة عبارة البحث (${q.length} حرفاً)", StepIntent.Type(field, q), role = Roles.SEARCH_FIELD,
                    skipWhen = listOf(C.FieldContains(field, q)), expect = listOf(Check(C.FieldContains(field, q))), method = uiMethod
                )
                steps += AdaptiveStep(
                    "search_go", "تنفيذ البحث", StepIntent.Tap(submit), role = Roles.SEARCH_SUBMIT,
                    expect = listOf(Check(C.StateChanged)), method = uiMethod
                )
            }

            GoalFamily.CREATE_POST -> {
                val compose = spec(TargetCatalog.COMPOSE, Roles.COMPOSE)
                val field = spec(TargetCatalog.COMPOSER_FIELD, Roles.COMPOSER_FIELD)
                val submit = spec(TargetCatalog.SUBMIT_POST, Roles.SUBMIT_POST)
                val body = text!!
                steps += AdaptiveStep(
                    "compose", "فتح محرر المنشور", StepIntent.Tap(compose), role = Roles.COMPOSE,
                    skipWhen = listOf(C.ElementPresent(strict(field))), expect = listOf(Check(C.ElementPresent(strict(field)))), method = uiMethod
                )
                steps += AdaptiveStep(
                    "type", "كتابة نص المنشور (${body.length} حرفاً)", StepIntent.Type(field, body), role = Roles.COMPOSER_FIELD,
                    skipWhen = listOf(C.FieldContains(field, body)), expect = listOf(Check(C.FieldContains(field, body))), method = uiMethod
                )
                steps += AdaptiveStep(
                    "submit", "الضغط على زر النشر", StepIntent.Tap(submit), role = Roles.SUBMIT_POST,
                    expect = listOf(Check(C.TextVisible(body, TextScope.NON_INPUT))), ambiguousIfAlreadyTrue = true,
                    commit = true, risk = goal.risk, content = body, approvalTarget = "منشور سيظهر في ${label ?: "التطبيق"}", method = uiMethod
                )
            }

            GoalFamily.SEND_MESSAGE -> {
                val to = goal.value(SlotName.RECIPIENT)!!
                val body = text!!
                val field = spec(TargetCatalog.MESSAGE_FIELD, Roles.MESSAGE_FIELD)
                val send = spec(TargetCatalog.SEND_BUTTON, Roles.SEND_BUTTON)
                val person = GoalComposer.targetSpec(to, TargetKind.CLICKABLE)
                val here = listOf(C.ElementPresent(strict(field)), C.TextVisible(to, TextScope.NON_INPUT))
                steps += AdaptiveStep(
                    "conversation", "فتح محادثة «$to»", StepIntent.Tap(person),
                    skipWhen = here, expect = here.map { Check(it) }, method = uiMethod
                )
                steps += AdaptiveStep(
                    "type", "كتابة نص الرسالة (${body.length} حرفاً)", StepIntent.Type(field, body), role = Roles.MESSAGE_FIELD,
                    skipWhen = listOf(C.FieldContains(field, body)), expect = listOf(Check(C.FieldContains(field, body))), method = uiMethod
                )
                steps += AdaptiveStep(
                    "send", "الضغط على زر الإرسال", StepIntent.Tap(send), role = Roles.SEND_BUTTON,
                    expect = listOf(Check(C.TextVisible(body, TextScope.NON_INPUT))), ambiguousIfAlreadyTrue = true,
                    commit = true, risk = goal.risk, content = body, approvalTarget = to, method = uiMethod
                )
            }

            GoalFamily.DELETE_ITEM -> {
                val t = goal.value(SlotName.TARGET)!!
                val item = GoalComposer.targetSpec(t, TargetKind.CLICKABLE)
                val anyItem = GoalComposer.targetSpec(t, TargetKind.ANY)
                val delete = spec(TargetCatalog.DELETE_BUTTON, Roles.DELETE_BUTTON)
                val confirm = spec(TargetCatalog.CONFIRM_DELETE, Roles.CONFIRM_DELETE)
                // Already on the item's page (its delete control is on screen): nothing to select.
                steps += AdaptiveStep(
                    "select", "تحديد «$t»", StepIntent.Tap(item),
                    skipWhen = listOf(C.ElementPresent(strict(delete))), method = uiMethod
                )
                steps += AdaptiveStep(
                    "delete", "الضغط على زر الحذف", StepIntent.Tap(delete), role = Roles.DELETE_BUTTON,
                    commit = true, risk = goal.risk, approvalTarget = t, expectsDialog = true,
                    expect = listOf(Check(C.StateChanged)), method = uiMethod
                )
                // Many apps ask "are you sure?"; it is a second, separate sensitive press and needs its own approval.
                steps += AdaptiveStep(
                    "confirm", "تأكيد الحذف إن ظهر طلب تأكيد", StepIntent.Tap(confirm), role = Roles.CONFIRM_DELETE,
                    optional = true, commit = true, risk = goal.risk,
                    approvalTarget = t, expectsDialog = true,
                    expect = listOf(Check(C.ElementAbsent(anyItem, asOutcome = true))), method = uiMethod
                )
            }

            GoalFamily.PAYMENT -> return blocked(goal, "هذه العملية محظورة في VENEX ولا تُنفَّذ حتى بموافقة.")
        }
        return AdaptivePlan(goal, steps, null, pkg, label, notes)
    }

    private fun blocked(goal: StructuredGoal, reason: String, notes: List<String> = emptyList()) =
        AdaptivePlan(goal, emptyList(), reason, null, null, notes)

    private fun unavailable(notes: List<String>): String = "لا توجد وسيلة متاحة الآن لتنفيذ هذا الهدف. " + (notes.lastOrNull() ?: "")
}
