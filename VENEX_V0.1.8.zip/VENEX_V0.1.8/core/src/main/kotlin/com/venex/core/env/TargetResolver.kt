package com.venex.core.env

import com.venex.core.device.SelectorMatcher
import com.venex.core.model.Selector

enum class TargetKind {
    /** Anything with a matching label. */
    ANY,

    /** Something that can be pressed: itself clickable, or inside something clickable. */
    CLICKABLE,

    /** An editable, non-password field. */
    INPUT
}

/**
 * A SYMBOLIC description of an element ("the search field", "the Post button"), resolved against the live screen
 * at execution time. Plans carry specs, not selectors or coordinates, so they survive a changed layout.
 */
data class TargetSpec(
    val description: String,
    /** Exact (case-insensitive, trimmed) label alternatives, e.g. "Post", "نشر". */
    val labels: List<String> = emptyList(),
    /** Looser alternatives: a normalised substring of the element's label. Lower confidence. */
    val labelContains: List<String> = emptyList(),
    /** Fragments of the view id ("search", "compose"). */
    val idHints: List<String> = emptyList(),
    val kind: TargetKind = TargetKind.ANY,
    /**
     * For INPUT specs: when nothing matches by name, accept the screen's only editable field. Turn it off to ask
     * "is THIS particular field there?" (a search box on a feed is not the post composer).
     */
    val soleFallback: Boolean = true
)

sealed interface TargetResolution {
    /** [selector] may be null only for an INPUT that is the sole editable field (the device then types into "the" field). */
    data class Found(val element: UiElement, val selector: Selector?, val confidence: Confidence, val how: String) : TargetResolution

    /** Several elements fit equally well. VENEX does not guess between them. */
    data class Ambiguous(val candidates: List<UiElement>) : TargetResolution

    /** The element is there, but nothing short of screen coordinates can address it. VENEX does not act on coordinates alone. */
    data class NotAddressable(val element: UiElement, val reason: String) : TargetResolution

    data object NotFound : TargetResolution
}

/** Maps a [TargetSpec] to an element of the current [ScreenModel] — by label first, then id, then a looser label match. */
object TargetResolver {

    fun resolve(spec: TargetSpec, screen: ScreenModel): TargetResolution {
        val pool = when (spec.kind) {
            TargetKind.INPUT -> screen.elements.filter { it.node.editable && !it.node.password && it.node.enabled }
            TargetKind.CLICKABLE -> screen.elements.filter { !it.node.password && (it.interactable || hasClickableAncestor(it, screen)) }
            TargetKind.ANY -> screen.elements.filter { !it.node.password }
        }
        val hasCriteria = spec.labels.isNotEmpty() || spec.labelContains.isNotEmpty() || spec.idHints.isNotEmpty()

        if (!hasCriteria) {
            // Only meaningful for INPUT: "the field". One editable field is unambiguous; several are not, unless one is focused.
            if (spec.kind != TargetKind.INPUT) return TargetResolution.NotFound
            return pick(pool, screen, "الحقل الوحيد", Confidence.MEDIUM, preferFocused = true)
        }

        val exact = spec.labels.map(SelectorMatcher::canonical).toSet()
        if (exact.isNotEmpty()) {
            val hits = pool.filter { e -> labelsFor(e, screen).any { SelectorMatcher.canonical(it) in exact } }
            if (hits.isNotEmpty()) return pick(hits, screen, "تطابق الاسم", Confidence.HIGH, preferFocused = spec.kind == TargetKind.INPUT)
        }
        if (spec.idHints.isNotEmpty()) {
            val hits = pool.filter { e -> val id = e.node.viewId; id != null && spec.idHints.any { id.contains(it, ignoreCase = true) } }
            if (hits.isNotEmpty()) return pick(hits, screen, "تطابق المعرّف", Confidence.MEDIUM, preferFocused = spec.kind == TargetKind.INPUT)
        }
        val loose = spec.labelContains.map { normLabel(it) }.filter { it.length >= 2 }
        if (loose.isNotEmpty()) {
            val hits = pool.filter { e -> labelsFor(e, screen).any { l -> val n = normLabel(l); loose.any { n.contains(it) } } }
            if (hits.isNotEmpty()) return pick(hits, screen, "تطابق جزئي للاسم", Confidence.LOW, preferFocused = spec.kind == TargetKind.INPUT)
        }
        // A named field was wanted but nothing matched: if the screen has exactly one editable field, it is "the" field.
        if (spec.kind == TargetKind.INPUT && spec.soleFallback && pool.size == 1) return pick(pool, screen, "الحقل الوحيد", Confidence.MEDIUM, preferFocused = true)
        return TargetResolution.NotFound
    }

    /** Labels an element answers to: its text, description, and, for fields, the label the model derived for it. */
    private fun labelsFor(e: UiElement, screen: ScreenModel): List<String> {
        val own = listOfNotNull(e.node.text, e.node.contentDescription).filter { it.isNotBlank() }
        if (!e.node.editable) return own
        val fieldLabel = screen.inputFields.firstOrNull { it.elementId == e.id }?.label
        return own + listOfNotNull(fieldLabel)
    }

    private fun pick(cands: List<UiElement>, screen: ScreenModel, how: String, base: Confidence, preferFocused: Boolean): TargetResolution {
        var c = cands
        if (c.size > 1) {
            val active = c.filter { it.interactable }
            if (active.isNotEmpty()) c = active
        }
        if (c.size > 1 && preferFocused) {
            val f = c.filter { it.node.focused }
            if (f.size == 1) c = f
        }
        if (c.size > 1) {
            // Twins that the device would resolve to the same single node are not a real ambiguity.
            val nodes = screen.elements.map { it.node }
            val addressable = c.filter { it.selector != null && SelectorMatcher.findBest(nodes, it.selector) === it.node }
            if (addressable.size == 1 && c.count { it.interactable } == 1) c = addressable else return TargetResolution.Ambiguous(c)
        }
        val e = c.single()
        val nodes = screen.elements.map { it.node }
        val sel = e.selector
        if (sel != null && SelectorMatcher.findBest(nodes, sel) === e.node) {
            val conf = if (e.confidence.rank < base.rank) e.confidence else base
            return TargetResolution.Found(e, sel, conf, how)
        }
        // An editable that is the only one on screen can be targeted without a selector.
        if (e.node.editable && screen.elements.count { it.node.editable && !it.node.password && it.node.enabled } == 1) {
            return TargetResolution.Found(e, null, base.capAt(Confidence.MEDIUM), "$how (الحقل الوحيد)")
        }
        return TargetResolution.NotAddressable(e, "لا يمكن تحديد العنصر بالاسم أو المعرّف دون الاعتماد على الإحداثيات")
    }

    private fun hasClickableAncestor(e: UiElement, screen: ScreenModel): Boolean =
        screen.ancestors(e.id).take(6).any { it.node.clickable && it.node.enabled }
}
