package com.venex.core.env

import com.venex.core.device.Channel
import com.venex.core.device.ScreenSnapshot
import com.venex.core.device.SelectorMatcher
import com.venex.core.device.UiNode
import com.venex.core.model.Selector
import com.venex.core.safety.SafetyDecision
import com.venex.core.safety.SafetyPolicy

/** Inputs that are not part of the observation itself. */
data class BuildContext(
    val generation: Long,
    val identity: EnvironmentIdentity = EnvironmentIdentity(),
    /** Looks up a human label for a package (the Android layer supplies installed-app labels). */
    val appLabelOf: (String) -> String? = { null }
)

/**
 * Turns raw observations into an [EnvironmentModel]. Pure and deterministic: the same observation always yields the
 * same model, which is what makes the understanding layer testable without a device.
 */
object EnvironmentModelBuilder {

    /** Same bound the Accessibility service uses; hitting it means the screen was cut and the model is partial. */
    const val NODE_LIMIT = 1500

    private val LOGIN_WORDS = listOf("تسجيل الدخول", "سجل الدخول", "sign in", "signin", "log in", "login")
        .map(::normLabel)
    private val LOADING_WORDS = listOf("جار التحميل", "جاري التحميل", "loading", "please wait").map(::normLabel)

    fun build(set: ObservationSet, ctx: BuildContext): EnvironmentModel {
        val primary = set.primary
        val snapshot = primary.snapshot
        val sources = mutableListOf(SourceUse(primary.source, if (snapshot != null) Confidence.MEDIUM else Confidence.NONE, primary.unavailableReason))
        set.supplements.forEach { sources += SourceUse(it.source, Confidence.LOW, it.unavailableReason) }

        val pkg = snapshot?.packageName
        val app = pkg?.let { ApplicationIdentity(it, ctx.appLabelOf(it), Confidence.HIGH) }
        val unknowns = ArrayList<UnknownInfo>()
        val constraints = ArrayList<ObservableConstraint>()
        val conflicts = ArrayList<Conflict>()

        // The visual source does not exist in this version: what only a picture could show is unknown, always.
        unknowns += UnknownInfo("visual.content", "لا يوجد فهم بصري للشاشة؛ ما لا يكشفه Accessibility غير معروف.")

        if (snapshot == null) {
            val reason = primary.unavailableReason ?: "تعذّرت قراءة الشاشة."
            unknowns += UnknownInfo("screen.content", reason)
            unknowns += UnknownInfo("app.identity", "لا يمكن معرفة التطبيق الظاهر بدون قراءة الشاشة.")
            constraints += ObservableConstraint(ConstraintKind.ACCESS_LIMITED, reason)
            return EnvironmentModel(
                generation = ctx.generation, identity = ctx.identity, app = null, screen = null,
                state = UiStateReport(UiStateKind.UNREADABLE, emptySet(), Confidence.HIGH, reason),
                constraints = constraints, conflicts = conflicts, unknowns = unknowns,
                confidence = Confidence.NONE, observedAtMillis = primary.atMillis, sources = sources
            )
        }

        if (pkg == null) unknowns += UnknownInfo("app.package", "النافذة لم تُبلِّغ عن اسم الحزمة.")
        if (app?.label == null && pkg != null) unknowns += UnknownInfo("app.label", "اسم التطبيق المعروض غير معروف.")

        // Cross-source consistency: another source naming a different foreground package is a conflict, not a vote.
        for (s in set.supplements) {
            val claimed = s.claimedPackage ?: continue
            if (pkg != null && claimed != pkg) {
                conflicts += Conflict(
                    ConflictKind.PACKAGE_DISAGREEMENT,
                    "مصدر ${s.source.arabicLabel} يقول إن التطبيق هو $claimed بينما الشاشة تعرض $pkg."
                )
            }
        }

        val screen = buildScreen(snapshot, set.capabilities, conflicts)
        val state = detectState(snapshot, screen)

        if (!screen.hierarchyKnown && screen.elements.size > 1) {
            unknowns += UnknownInfo("screen.hierarchy", "المصدر لم يُبلِّغ عن العلاقات الهرمية؛ ترتيب العناصر فقط معروف.")
            constraints += ObservableConstraint(ConstraintKind.NO_HIERARCHY, "الهرمية غير معروفة")
        }
        if (screen.truncated) {
            unknowns += UnknownInfo("screen.completeness", "بلغت القراءة حدّ $NODE_LIMIT عنصراً؛ قد تكون الشاشة ناقصة.")
            constraints += ObservableConstraint(ConstraintKind.PARTIAL_SCREEN, "قراءة مقطوعة عند $NODE_LIMIT عنصراً")
        }
        val pwIds = screen.elements.filter { it.node.password }.map { it.id }
        if (pwIds.isNotEmpty()) {
            constraints += ObservableConstraint(ConstraintKind.PASSWORD_FIELD, "حقل كلمة مرور: لا يقرأه VENEX ولا يكتب فيه.", pwIds)
        }
        when (state.kind) {
            UiStateKind.LOGIN_REQUIRED -> constraints += ObservableConstraint(ConstraintKind.LOGIN_REQUIRED, "تسجيل الدخول مطلوب؛ على المالك إتمامه بنفسه.")
            UiStateKind.CAPTCHA -> constraints += ObservableConstraint(ConstraintKind.CAPTCHA, "تحقق بشري (CAPTCHA)؛ لا يتجاوزه VENEX.")
            UiStateKind.OPAQUE -> {
                constraints += ObservableConstraint(ConstraintKind.OPAQUE_UI, "الواجهة لا تكشف أي عنصر.")
                unknowns += UnknownInfo("screen.content", "الواجهة لا تكشف عناصرها عبر Accessibility (واجهة معتمة).")
            }
            else -> Unit
        }

        return EnvironmentModel(
            generation = ctx.generation, identity = ctx.identity, app = app, screen = screen, state = state,
            constraints = constraints, conflicts = conflicts, unknowns = unknowns,
            confidence = modelConfidence(screen, state, conflicts), observedAtMillis = primary.atMillis, sources = sources
        )
    }

    // ---------------------------------------------------------------------------------------------------------------

    private fun buildScreen(
        snapshot: ScreenSnapshot,
        caps: Set<Channel>,
        conflicts: MutableList<Conflict>
    ): ScreenModel {
        val nodes = snapshot.nodes
        val parents = validatedParents(nodes)
        val hierarchyKnown = nodes.any { it.depth >= 0 }
        val ids = ElementIds.assign(snapshot.packageName, nodes, parents.parent)

        parents.badIndices.takeIf { it.isNotEmpty() }?.let { bad ->
            conflicts += Conflict(
                ConflictKind.HIERARCHY_INCONSISTENT,
                "علاقة أب غير صالحة لـ ${bad.size} عنصراً؛ عوملت كجذور.",
                bad.take(10).map { ids[it] }
            )
        }
        val disabledClickable = nodes.indices.filter { nodes[it].clickable && !nodes[it].enabled }
        if (disabledClickable.isNotEmpty()) {
            conflicts += Conflict(
                ConflictKind.CLICKABLE_BUT_DISABLED,
                "${disabledClickable.size} عنصراً يُبلَّغ أنه قابل للنقر وهو معطّل؛ عُدّ غير قابل للتفاعل.",
                disabledClickable.take(10).map { ids[it] }
            )
        }

        val children = Array(nodes.size) { ArrayList<ElementId>() }
        for (i in nodes.indices) if (parents.parent[i] >= 0) children[parents.parent[i]].add(ids[i])

        val addressing = Addressing(nodes)
        val elements = nodes.indices.map { i ->
            val n = nodes[i]
            val label = labelOf(n)
            val interactable = n.enabled && (n.clickable || n.editable || n.scrollable || n.checkable)
            val addr = addressing.selectorFor(i)
            val conf = elementConfidence(n, label, addr)
            UiElement(
                id = ids[i], index = i,
                parentId = parents.parent[i].takeIf { it >= 0 }?.let { ids[it] },
                childIds = children[i],
                depth = if (n.depth >= 0) n.depth else 0,
                role = roleOf(n), label = label, node = n, interactable = interactable,
                selector = addr.selector, confidence = conf
            )
        }

        val fields = elements.filter { it.node.editable }.map { e -> inputFieldOf(e, elements) }
        val actions = availableActions(elements, caps)
        val structure = hash(snapshot.packageName.orEmpty() + "|" + ids.map { it.value }.sorted().joinToString(","))
        val content = hash(
            structure + "|" + elements.joinToString("\u0001") {
                (it.node.text ?: "") + "\u0002" + (it.node.contentDescription ?: "") + "\u0002" + it.node.checked + it.node.selected
            }
        )
        return ScreenModel(
            screenId = structure, contentId = content, elements = elements,
            rootIds = elements.filter { it.parentId == null }.map { it.id },
            inputFields = fields, actions = actions, hierarchyKnown = hierarchyKnown,
            truncated = nodes.size >= NODE_LIMIT
        )
    }

    private class Parents(val parent: IntArray, val badIndices: List<Int>)

    private fun validatedParents(nodes: List<UiNode>): Parents {
        val parent = IntArray(nodes.size) { -1 }
        val bad = ArrayList<Int>()
        for (i in nodes.indices) {
            val p = nodes[i].parentIndex
            if (p < 0) continue
            val valid = p < i && (nodes[p].depth < 0 || nodes[i].depth < 0 || nodes[p].depth < nodes[i].depth)
            if (valid) parent[i] = p else bad += i
        }
        return Parents(parent, bad)
    }

    fun labelOf(n: UiNode): String? {
        if (n.password) return null
        return n.text?.takeIf { it.isNotBlank() && !n.showingHint }
            ?: n.contentDescription?.takeIf { it.isNotBlank() }
            ?: n.text?.takeIf { it.isNotBlank() } // a hint is still the best name an unnamed field has
    }

    fun roleOf(n: UiNode): ElementRole {
        val cls = n.className?.substringAfterLast('.')?.lowercase().orEmpty()
        return when {
            n.editable || cls.contains("edittext") || cls.contains("textfield") -> ElementRole.INPUT
            n.checkable || cls.contains("checkbox") || cls.contains("switch") || cls.contains("radiobutton") ||
                cls.contains("togglebutton") -> ElementRole.TOGGLE
            cls.contains("button") -> ElementRole.BUTTON
            cls.contains("recyclerview") || cls.contains("listview") || cls.contains("gridview") -> ElementRole.LIST
            n.scrollable -> ElementRole.SCROLLABLE
            n.clickable && (n.text != null || n.contentDescription != null) -> ElementRole.BUTTON
            cls.contains("image") -> ElementRole.IMAGE
            cls.contains("textview") || (!n.text.isNullOrBlank()) -> ElementRole.TEXT
            n.className != null -> ElementRole.CONTAINER
            else -> ElementRole.UNKNOWN
        }
    }

    private fun elementConfidence(n: UiNode, label: String?, addr: Addressing.Result): Confidence {
        var c = if (label != null || n.viewId != null) Confidence.HIGH else Confidence.LOW
        if (!addr.unique && addr.selector != null) c = c.capAt(Confidence.LOW)
        if (n.bounds?.isEmpty() == true && (n.clickable || n.editable)) c = c.capAt(Confidence.MEDIUM)
        if (n.clickable && !n.enabled) c = c.capAt(Confidence.LOW)
        return c
    }

    private fun inputFieldOf(e: UiElement, all: List<UiElement>): InputField {
        val n = e.node
        val hint = if (n.showingHint) n.text?.takeIf { it.isNotBlank() } else null
        val nearby = if (hint == null && n.contentDescription.isNullOrBlank()) previousSiblingLabel(e, all) else null
        return InputField(
            elementId = e.id,
            label = hint ?: n.contentDescription?.takeIf { it.isNotBlank() } ?: nearby ?: e.viewIdShort,
            currentText = if (n.password || n.showingHint) null else n.text,
            password = n.password,
            focused = n.focused
        )
    }

    private fun previousSiblingLabel(e: UiElement, all: List<UiElement>): String? {
        if (e.parentId == null) return null
        var j = e.index - 1
        var steps = 0
        while (j >= 0 && steps++ < 200) {
            val c = all[j]
            if (c.parentId == e.parentId && c.role == ElementRole.TEXT && !c.node.clickable) return c.label
            j--
        }
        return null
    }

    private fun availableActions(elements: List<UiElement>, caps: Set<Channel>): List<AvailableAction> {
        if (Channel.ACCESSIBILITY !in caps) return emptyList()
        val out = ArrayList<AvailableAction>()
        for (e in elements) {
            if (!e.interactable) continue
            val n = e.node
            if (n.editable) {
                if (!n.password) out += AvailableAction(ActionKind.TYPE_TEXT, e.id, e.label, e.selector, Channel.ACCESSIBILITY, e.confidence)
            } else if (n.checkable) {
                out += AvailableAction(ActionKind.TOGGLE, e.id, e.label, e.selector, Channel.ACCESSIBILITY, e.confidence)
            } else if (n.clickable) {
                out += AvailableAction(ActionKind.CLICK, e.id, e.label, e.selector, Channel.ACCESSIBILITY, e.confidence)
            }
            if (n.scrollable) out += AvailableAction(ActionKind.SCROLL, e.id, e.label, e.selector, Channel.ACCESSIBILITY, e.confidence)
        }
        out += AvailableAction(ActionKind.PRESS_BACK, null, "رجوع", null, Channel.ACCESSIBILITY, Confidence.HIGH)
        out += AvailableAction(ActionKind.PRESS_HOME, null, "الشاشة الرئيسية", null, Channel.ACCESSIBILITY, Confidence.HIGH)
        out += AvailableAction(ActionKind.READ_SCREEN, null, "قراءة الشاشة", null, Channel.ACCESSIBILITY, Confidence.HIGH)
        return out
    }

    // ---------------------------------------------------------------------------------------------------------------

    private fun detectState(snapshot: ScreenSnapshot, screen: ScreenModel): UiStateReport {
        val flags = HashSet<UiFlag>()
        if (screen.elements.any { it.node.password }) flags += UiFlag.HAS_PASSWORD_FIELD
        if (screen.elements.any { it.node.editable }) flags += UiFlag.HAS_INPUT
        if (screen.elements.any { it.node.scrollable }) flags += UiFlag.HAS_SCROLLABLE
        if (screen.truncated) flags += UiFlag.TRUNCATED
        if (!screen.hierarchyKnown && screen.elements.size > 1) flags += UiFlag.HIERARCHY_UNKNOWN

        fun report(k: UiStateKind, c: Confidence, why: String) = UiStateReport(k, flags, c, why)

        if (screen.elements.isEmpty()) return report(UiStateKind.OPAQUE, Confidence.MEDIUM, "لا عناصر ظاهرة")
        if (SafetyPolicy.checkScreen(snapshot) is SafetyDecision.Deny) return report(UiStateKind.CAPTCHA, Confidence.MEDIUM, "نص تحقق بشري ظاهر")

        val texts = screen.allText().map(::normLabel)
        val ids = screen.elements.mapNotNull { it.node.viewId?.lowercase() }
        val pkg = snapshot.packageName.orEmpty().lowercase()

        if (UiFlag.HAS_PASSWORD_FIELD in flags &&
            (texts.any { t -> LOGIN_WORDS.any { t.contains(it) } } || ids.any { it.contains("login") || it.contains("signin") || it.contains("sign_in") })
        ) return report(UiStateKind.LOGIN_REQUIRED, Confidence.MEDIUM, "حقل كلمة مرور مع عبارة دخول")

        if (pkg.contains("permissioncontroller") || ids.any { it.contains("permission_allow") || it.contains("permission_deny") }) {
            return report(UiStateKind.PERMISSION_PROMPT, Confidence.MEDIUM, "نافذة طلب صلاحية من النظام")
        }
        if (ids.any { it.endsWith(":id/alerttitle") || it.endsWith(":id/parentpanel") || it.contains("dialog") } ||
            screen.elements.any { it.node.className?.contains("AlertDialog") == true }
        ) return report(UiStateKind.DIALOG, Confidence.MEDIUM, "نافذة حوار ظاهرة")

        val progress = screen.elements.any { it.node.className?.contains("ProgressBar") == true }
        if (progress && (screen.elements.count { it.role == ElementRole.TEXT } <= 3 || texts.any { t -> LOADING_WORDS.any { t.contains(it) } })) {
            return report(UiStateKind.LOADING, Confidence.LOW, "مؤشر تقدّم مع محتوى قليل")
        }
        return report(UiStateKind.NORMAL, Confidence.MEDIUM, "لا مؤشرات خاصة")
    }

    private fun modelConfidence(screen: ScreenModel, state: UiStateReport, conflicts: List<Conflict>): Confidence {
        if (state.kind == UiStateKind.OPAQUE) return Confidence.LOW
        val interactive = screen.elements.filter { it.interactable }
        var c = when {
            interactive.isEmpty() -> Confidence.MEDIUM
            else -> {
                val named = interactive.count { it.label != null || it.node.viewId != null }
                val ratio = named.toDouble() / interactive.size
                when {
                    ratio >= 0.6 -> Confidence.HIGH
                    ratio >= 0.3 -> Confidence.MEDIUM
                    else -> Confidence.LOW
                }
            }
        }
        if (!screen.hierarchyKnown && screen.elements.size > 1) c = c.capAt(Confidence.MEDIUM)
        if (screen.truncated) c = c.capAt(Confidence.MEDIUM)
        if (conflicts.isNotEmpty()) c = c.capAt(Confidence.MEDIUM)
        return c
    }

    // ---------------------------------------------------------------------------------------------------------------

    /**
     * Chooses, per element, the narrowest selector that the existing [SelectorMatcher] resolves to it: the label
     * (exact, case-insensitive) if it is unique on the screen, else the view id fragment. Built from indexes, so the
     * cost stays linear in practice on screens of hundreds of nodes.
     */
    private class Addressing(private val nodes: List<UiNode>) {
        class Result(val selector: Selector?, val unique: Boolean)

        private val labelIndex = HashMap<String, MutableList<Int>>()
        private val lowerIds: List<String?> = nodes.map { it.viewId?.lowercase() }

        init {
            nodes.forEachIndexed { i, n ->
                for (l in labelsOf(n)) labelIndex.getOrPut(SelectorMatcher.canonical(l)) { ArrayList() }.add(i)
            }
        }

        private fun labelsOf(n: UiNode): List<String> =
            if (n.password) emptyList() else listOfNotNull(n.text, n.contentDescription).filter { it.isNotBlank() }

        private fun matchesByLabels(labels: List<String>): Set<Int> {
            val s = HashSet<Int>()
            for (l in labels) labelIndex[SelectorMatcher.canonical(l)]?.let { s.addAll(it) }
            return s
        }

        private fun matchesById(fragment: String): Int {
            val f = fragment.lowercase()
            return lowerIds.count { it != null && it.contains(f) }
        }

        fun selectorFor(i: Int): Result {
            val n = nodes[i]
            val labels = labelsOf(n)
            val idShort = n.viewId?.substringAfter(":id/")?.takeIf { it.isNotBlank() }
            if (labels.isNotEmpty()) {
                val byLabel = matchesByLabels(labels).sorted()
                if (byLabel.size == 1) return Result(Selector(labels), true)
                if (idShort != null && matchesById(idShort) == 1) return Result(Selector(labels, idShort), true)
                // Several nodes share the label. SelectorMatcher.findBest prefers the first clickable+enabled match,
                // then the first enabled one, then the first: only the node it would pick is addressable by label.
                val pick = byLabel.firstOrNull { nodes[it].clickable && nodes[it].enabled }
                    ?: byLabel.firstOrNull { nodes[it].enabled } ?: byLabel.first()
                val soleActive = nodes[i].clickable && nodes[i].enabled && byLabel.count { nodes[it].clickable && nodes[it].enabled } == 1
                if (pick == i) return Result(Selector(labels), soleActive)
                if (idShort != null) return Result(Selector(labels, idShort), false)
                return Result(null, false)
            }
            if (idShort != null) {
                val c = matchesById(idShort)
                return Result(Selector(idContains = idShort), c == 1)
            }
            return Result(null, false)
        }
    }

    internal fun hash(s: String): String {
        var h = -0x340d631b7bdddcdbL // FNV-1a 64 offset basis
        for (c in s) {
            h = h xor c.code.toLong()
            h *= 0x100000001b3L
        }
        return java.lang.Long.toHexString(h).padStart(16, '0')
    }
}

/** Element identity: place in the hierarchy plus the element's own identity, never coordinates. */
internal object ElementIds {

    fun assign(pkg: String?, nodes: List<UiNode>, parent: IntArray): List<ElementId> {
        val keys = arrayOfNulls<String>(nodes.size)
        val ordinals = HashMap<String, Int>()
        val used = HashSet<String>()
        val out = ArrayList<ElementId>(nodes.size)
        for (i in nodes.indices) {
            val p = parent[i]
            val parentKey = if (p >= 0) keys[p]!! else "-"
            val base = "$parentKey/${localKey(nodes[i])}"
            val ord = (ordinals[base] ?: 0)
            ordinals[base] = ord + 1
            val chain = EnvironmentModelBuilder.hash("$base[$ord]")
            keys[i] = chain
            var id = "e" + EnvironmentModelBuilder.hash(pkg.orEmpty() + "|" + chain).take(10)
            var n = 0
            while (!used.add(id)) id = "e" + EnvironmentModelBuilder.hash(pkg.orEmpty() + "|" + chain + "#" + (++n)).take(10)
            out += ElementId(id)
        }
        return out
    }

    private fun localKey(n: UiNode): String {
        val cls = n.className?.substringAfterLast('.') ?: "?"
        val vid = n.viewId?.substringAfter(":id/").orEmpty()
        // An unnamed-by-id button is identified by its own label; changing text (a counter, a clock) must not change identity.
        val lbl = if (vid.isEmpty() && n.clickable && !n.editable && !n.password) normLabel(n.text ?: n.contentDescription).take(40) else ""
        return "$cls#$vid" + if (lbl.isNotEmpty()) "@$lbl" else ""
    }
}
