package com.venex.core.model

enum class StepStatus {
    PENDING,
    RUNNING,

    /** Action ran and its expectation was observed (evidence available). */
    VERIFIED,

    /** Action ran but nothing could confirm the outcome. Never reported as success. */
    EXECUTED_UNVERIFIED,
    FAILED,
    SKIPPED,
    CANCELLED_BY_USER
}

data class StepResult(
    val stepId: String,
    val description: String,
    val status: StepStatus,
    val message: String,
    val evidence: String? = null
)

enum class TaskStatus {
    /** Every step ran and the final expectation was verified with evidence. */
    SUCCESS,

    /** Steps ran but the outcome could not be confirmed. */
    UNVERIFIED,
    FAILED,
    NOT_EXECUTED,
    CANCELLED
}

data class TaskReport(
    val goal: Goal,
    val status: TaskStatus,
    val summary: String,
    val steps: List<StepResult>
)
