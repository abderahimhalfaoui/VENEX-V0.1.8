package com.venex.core.intent

import com.venex.core.model.Goal

/** Turns a user command into a structured [Goal]. Implementations must be side-effect free. */
interface IntentParser {
    suspend fun parse(text: String): Goal
}
