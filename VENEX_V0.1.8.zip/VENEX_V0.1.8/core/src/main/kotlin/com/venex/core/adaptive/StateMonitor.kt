package com.venex.core.adaptive

import com.venex.core.env.EnvironmentModel
import com.venex.core.env.TargetCatalog
import com.venex.core.env.TargetResolution
import com.venex.core.env.TargetResolver
import com.venex.core.env.UiElement
import com.venex.core.env.UiStateKind

enum class BlockKind { UNREADABLE, OPAQUE, CAPTCHA, LOGIN, PERMISSION, UNEXPECTED_DIALOG }

/** What the live screen means for the step about to run. */
sealed interface StateAssessment {
    data object Ready : StateAssessment

    /** The screen is still changing: wait and look again. */
    data object Loading : StateAssessment

    /** Only the owner can resolve this. VENEX never bypasses, enters credentials or grants permissions. */
    data class Blocked(val kind: BlockKind, val message: String) : StateAssessment

    /** An unexpected dialog that has a harmless way out ("Not now", "Close", "Cancel"). */
    data class Interrupted(val dismiss: UiElement, val dialogText: String) : StateAssessment

    /** Another app is in front. */
    data class WrongApp(val expected: String, val actual: String?) : StateAssessment
}

/**
 * Compares the observed state with what the step expects to meet. It only classifies; it never acts. A dialog the
 * step itself is expected to meet (a delete confirmation) is not an interruption.
 */
object StateMonitor {

    fun assess(model: EnvironmentModel, step: AdaptiveStep, expectedPackage: String?): StateAssessment {
        val intent = step.intent
        // Opening an app or a link changes the app anyway, and describing the screen is the goal itself.
        if (intent is StepIntent.OpenApp || intent is StepIntent.OpenLink || intent is StepIntent.Observe) return StateAssessment.Ready

        val screen = model.screen
        if (screen == null) {
            return StateAssessment.Blocked(BlockKind.UNREADABLE, "لا أستطيع قراءة الشاشة الآن: ${model.state.reason}")
        }
        when (model.state.kind) {
            UiStateKind.CAPTCHA ->
                return StateAssessment.Blocked(BlockKind.CAPTCHA, "ظهر CAPTCHA أو تحقق بشري. VENEX لا يتجاوزه؛ أكمله بنفسك ثم قل لي «استأنف».")
            UiStateKind.LOGIN_REQUIRED ->
                return StateAssessment.Blocked(BlockKind.LOGIN, "التطبيق يطلب تسجيل الدخول. سجّل الدخول بنفسك (VENEX لا يُدخل كلمات المرور) ثم قل لي «استأنف».")
            UiStateKind.PERMISSION_PROMPT ->
                return StateAssessment.Blocked(BlockKind.PERMISSION, "ظهر طلب صلاحية من النظام. القرار لك وحدك؛ أجبه بنفسك ثم قل لي «استأنف».")
            UiStateKind.OPAQUE ->
                return StateAssessment.Blocked(BlockKind.OPAQUE, "واجهة هذا التطبيق لا تكشف عناصرها لخدمة إمكانية الوصول، فلا أستطيع التعامل معها بأمان.")
            UiStateKind.UNREADABLE ->
                return StateAssessment.Blocked(BlockKind.UNREADABLE, "لا أستطيع قراءة الشاشة الآن: ${model.state.reason}")
            UiStateKind.LOADING -> return StateAssessment.Loading
            UiStateKind.DIALOG -> if (!step.expectsDialog) {
                val dismiss = TargetResolver.resolve(TargetCatalog.SAFE_DISMISS, screen)
                if (dismiss is TargetResolution.Found) {
                    return StateAssessment.Interrupted(dismiss.element, screen.nonInputText().take(3).joinToString(" | ").take(120))
                }
                return StateAssessment.Blocked(BlockKind.UNEXPECTED_DIALOG, "ظهرت نافذة لم أتوقعها وليس فيها زر إغلاق آمن. أغلقها بنفسك ثم قل لي «استأنف».")
            }
            UiStateKind.NORMAL -> Unit
        }
        val actual = model.packageName
        if (expectedPackage != null && actual != null && actual != expectedPackage) {
            return StateAssessment.WrongApp(expectedPackage, actual)
        }
        return StateAssessment.Ready
    }
}
