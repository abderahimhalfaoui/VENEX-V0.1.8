package com.venex.core.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Adapter for Ollama's native API: GET /api/tags (model list) and POST /api/chat (non-streaming).
 */
class OllamaProvider : ModelProvider {

    override val type: ProviderType = ProviderType.OLLAMA

    override suspend fun listModels(spec: ConnectionSpec): ProviderResult<List<ModelInfo>> =
        withContext(Dispatchers.IO) {
            guarded {
                val started = System.nanoTime()
                val reply = Http.send(Urls.join(spec.baseUrl, "/api/tags"), "GET", null, spec)
                if (reply.code == 404) {
                    return@guarded ProviderResult.Err(
                        ProviderFailure(
                            FailureKind.WRONG_PROVIDER,
                            "الخادم لا يستجيب كـ Ollama (المسار /api/tags غير موجود)"
                        )
                    )
                }
                if (reply.code != 200) return@guarded Http.statusFailure(reply.code)
                val root = MiniJson.parse(reply.body) as? Map<*, *> ?: return@guarded Http.invalid()
                val list = root["models"] as? List<*> ?: return@guarded Http.invalid()
                val ids = list.mapNotNull { item ->
                    val m = item as? Map<*, *>
                    (m?.get("name") as? String) ?: (m?.get("model") as? String)
                }
                ProviderResult.Ok(ids.map { ModelInfo(it) }, Http.elapsedMs(started))
            }
        }

    override suspend fun complete(
        spec: ConnectionSpec,
        modelId: String,
        prompt: ChatPrompt
    ): ProviderResult<Completion> = withContext(Dispatchers.IO) {
        guarded {
            val started = System.nanoTime()
            val payload = MiniJson.encode(
                mapOf(
                    "model" to modelId,
                    "messages" to listOf(
                        mapOf("role" to "system", "content" to prompt.system),
                        mapOf("role" to "user", "content" to prompt.user)
                    ),
                    "stream" to false,
                    "options" to mapOf("temperature" to 0, "num_predict" to prompt.maxTokens)
                )
            )
            val reply = Http.send(Urls.join(spec.baseUrl, "/api/chat"), "POST", payload, spec)
            if (reply.code == 404) {
                return@guarded ProviderResult.Err(
                    ProviderFailure(
                        FailureKind.MODEL_NOT_FOUND,
                        "النموذج «$modelId» غير موجود على خادم Ollama (هل سحبته بـ ollama pull؟)"
                    )
                )
            }
            if (reply.code != 200) return@guarded Http.statusFailure(reply.code)

            val root = MiniJson.parse(reply.body) as? Map<*, *> ?: return@guarded Http.invalid()
            val content = (root["message"] as? Map<*, *>)?.get("content") as? String
                ?: return@guarded Http.invalid()
            if (content.isBlank()) return@guarded Http.empty()
            ProviderResult.Ok(Completion(content.trim(), root["model"] as? String), Http.elapsedMs(started))
        }
    }
}
