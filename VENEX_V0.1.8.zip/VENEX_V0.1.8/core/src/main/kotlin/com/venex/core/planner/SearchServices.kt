package com.venex.core.planner

import com.venex.core.intent.TextNormalizer
import java.net.URLEncoder

/**
 * Apps whose search results can be reached by a public https address, which the engine opens with the
 * existing OpenDeepLink action (https is an allowed scheme). Typing into an app's search field is NOT
 * used: VENEX has no verified typing path for it, so an app without an address here is refused.
 */
object SearchServices {

    class Service(val label: String, val aliases: List<String>, private val template: String) {
        /** The https address that shows the results for [query]. */
        fun url(query: String): String = template + URLEncoder.encode(query, Charsets.UTF_8.name())
    }

    private val YOUTUBE = Service(
        label = "يوتيوب",
        aliases = listOf("يوتيوب", "يوتوب", "youtube", "yt").map(TextNormalizer::normalize),
        template = "https://www.youtube.com/results?search_query="
    )

    private val ALL = listOf(YOUTUBE)

    /** The service for an app name as the user typed it, or null when there is no search address. */
    fun forApp(appName: String): Service? {
        val n = TextNormalizer.normalize(appName)
        return ALL.firstOrNull { s -> s.aliases.any { it == n } }
    }
}
