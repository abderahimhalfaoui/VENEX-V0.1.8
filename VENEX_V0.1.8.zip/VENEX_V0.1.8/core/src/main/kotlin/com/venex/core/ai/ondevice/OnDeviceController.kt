package com.venex.core.ai.ondevice

import com.venex.core.ai.ChatPrompt
import com.venex.core.ai.CompletionBackend
import com.venex.core.ai.Completion
import com.venex.core.ai.FailureKind
import com.venex.core.ai.InferenceTester
import com.venex.core.ai.ModelOutputSanitizer
import com.venex.core.ai.ProviderFailure
import com.venex.core.ai.ProviderResult
import com.venex.core.intent.AiProvider
import com.venex.core.ai.ModelIntentProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * State machine for the on-device (GGUF) model. Pure JVM: files and the native runtime are reached
 * through [ModelFileGateway] and [LlmRuntime], so every rule below is unit-tested without Android.
 *
 * Rules:
 *  - at most ONE long operation (select / import / load / test / unload) runs at a time; a second
 *    request is refused immediately, so two models can never be loaded over each other;
 *  - the model can be ENABLED only after a real inference test passed for the same file content
 *    (SHA-256) and the same settings (context length, threads); changing either clears it;
 *  - failures never throw into the assistant: [complete] returns an error and the caller falls back to rules;
 *  - cancellation stops the running operation (native inference is aborted) and leaves a consistent state;
 *  - the persisted data holds no path outside the app's private directory and no conversation content.
 */
class OnDeviceController(
    private val store: OnDeviceStore,
    private val gateway: ModelFileGateway,
    private val runtime: LlmRuntime,
    private val scope: CoroutineScope,
    private val audit: (String) -> Unit = {},
    private val inferenceTimeoutMs: Long = 35_000,
    private val nanoTime: () -> Long = System::nanoTime
) : CompletionBackend {

    private data class S(
        val stored: StoredOnDevice,
        val state: OnDeviceState,
        val importCopied: Long = 0,
        val importTotal: Long = 0,
        val loadReport: LoadReport? = null,
        val testReport: TestReport? = null,
        val message: String? = null,
        val error: String? = null
    )

    private val opMutex = Mutex()
    private val lock = Any()
    private var opJob: Job? = null
    private var loadJob: Deferred<Boolean>? = null

    private var s: S = initial()
    private val _state = MutableStateFlow(snapshotOf(s))
    val state: StateFlow<OnDeviceSnapshot> = _state.asStateFlow()

    // ---------------------------------------------------------------- state plumbing

    private fun initial(): S {
        var stored = store.read() ?: StoredOnDevice.EMPTY
        var note: String? = null
        val model = stored.model
        if (model?.imported != null && gateway.resolvePath(model.imported) == null) {
            // The private copy disappeared (cleared storage, manual delete). Keep the selection, require re-import.
            stored = stored.copy(model = model.copy(imported = null), enabled = false, verifiedFingerprint = null)
            note = "الملف المستورد لم يعد موجوداً؛ أعد استيراده."
        }
        stored = normalize(stored)
        if (stored != (store.read() ?: StoredOnDevice.EMPTY)) store.write(stored)
        return S(stored, restState(stored), message = note)
    }

    private fun restState(st: StoredOnDevice) = when {
        st.model == null -> OnDeviceState.NOT_SELECTED
        st.model.imported == null -> OnDeviceState.FILE_SELECTED
        else -> OnDeviceState.READY
    }

    private fun normalize(st: StoredOnDevice): StoredOnDevice {
        val p = st.params.normalized()
        val withParams = st.copy(params = p)
        val verified = withParams.verifiedFingerprint != null && withParams.verifiedFingerprint == withParams.fingerprint()
        return withParams.copy(
            enabled = withParams.enabled && verified,
            verifiedFingerprint = if (verified) withParams.verifiedFingerprint else null
        )
    }

    private fun snapshotOf(x: S) = OnDeviceSnapshot(
        state = x.state,
        model = x.stored.model,
        params = x.stored.params,
        enabled = x.stored.enabled,
        verified = x.stored.verifiedFingerprint != null && x.stored.verifiedFingerprint == x.stored.fingerprint(),
        importCopiedBytes = x.importCopied,
        importTotalBytes = x.importTotal,
        loadReport = x.loadReport,
        testReport = x.testReport,
        message = x.message,
        errorMessage = x.error
    )

    private fun commit(persist: Boolean = false, f: (S) -> S) {
        synchronized(lock) {
            val next = f(s)
            s = next
            if (persist) store.write(next.stored)
            _state.value = snapshotOf(next)
        }
    }

    private val cur: S get() = synchronized(lock) { s }

    private suspend fun <T> exclusive(busy: T, block: suspend () -> T): T {
        if (!opMutex.tryLock()) {
            commit { it.copy(message = "عملية أخرى قيد التنفيذ؛ انتظر انتهاءها أو ألغِها.") }
            return busy
        }
        opJob = currentCoroutineContext()[Job]
        try {
            return block()
        } finally {
            opJob = null
            opMutex.unlock()
        }
    }

    /** Stops the running import / load / test / inference. Safe from any thread. */
    fun cancelCurrent() {
        runtime.cancel()
        opJob?.cancel()
    }

    val isBusy: Boolean get() = opMutex.isLocked

    // ---------------------------------------------------------------- select / import

    /** Reads a picked document's name, size and GGUF header. Replaces the previous selection on success. */
    suspend fun selectFile(uri: String): Boolean = exclusive(false) {
        when (val r = gateway.inspect(uri)) {
            is ProviderResult.Err -> {
                commit { it.copy(error = r.failure.message, message = null) }
                audit("اختيار ملف النموذج: فشل (${r.failure.kind})")
                false
            }
            is ProviderResult.Ok -> {
                val insp = r.value
                unloadLocked(keepEnabled = false)
                val old = cur.stored.model?.imported
                if (old != null) gateway.deleteImported(old)
                val model = SelectedModel(uri, insp.file.displayName, insp.file.sizeBytes ?: 0L, insp.gguf, imported = null)
                val stored = StoredOnDevice(model, cur.stored.params, enabled = false, verifiedFingerprint = null)
                commit(persist = true) {
                    S(stored, OnDeviceState.FILE_SELECTED, message = "تم اختيار «${insp.file.displayName}». استورده ثم حمّله.")
                }
                audit("تم اختيار ملف نموذج (GGUF ${insp.gguf.architecture})")
                true
            }
        }
    }

    suspend fun importSelected(): Boolean = exclusive(false) {
        val model = cur.stored.model
        val ok = model != null && model.imported == null &&
            (cur.state == OnDeviceState.FILE_SELECTED || cur.state == OnDeviceState.ERROR)
        if (!ok || model == null) {
            commit { it.copy(error = "اختر ملف النموذج أولاً", message = null) }
            return@exclusive false
        }
        commit { it.copy(state = OnDeviceState.IMPORTING, importCopied = 0, importTotal = model.sizeBytes, error = null, message = null) }
        var lastReported = 0L
        val file = PickedFile(model.uri, model.displayName, model.sizeBytes.takeIf { it > 0 })
        try {
            when (val r = gateway.import(file) { copied, total ->
                if (copied - lastReported >= PROGRESS_STEP || copied == total) {
                    lastReported = copied
                    commit { it.copy(importCopied = copied, importTotal = if (total > 0) total else it.importTotal) }
                }
            }) {
                is ProviderResult.Err -> {
                    commit { it.copy(state = OnDeviceState.ERROR, error = r.failure.message) }
                    audit("استيراد النموذج: فشل (${r.failure.kind})")
                    false
                }
                is ProviderResult.Ok -> {
                    val stored = cur.stored.copy(model = model.copy(imported = r.value), enabled = false, verifiedFingerprint = null)
                    commit(persist = true) {
                        it.copy(stored = stored, state = OnDeviceState.READY, importCopied = r.value.sizeBytes,
                            importTotal = r.value.sizeBytes, message = "تم الاستيراد. حمّل النموذج ثم اختبر الاستدلال.", error = null)
                    }
                    audit("اكتمل استيراد النموذج (${r.value.sizeBytes / (1024 * 1024)} MB)")
                    true
                }
            }
        } catch (e: CancellationException) {
            commit { it.copy(state = OnDeviceState.FILE_SELECTED, importCopied = 0, message = "أُلغي الاستيراد ولم يُترك ملف جزئي.", error = null) }
            audit("أُلغي استيراد النموذج")
            throw e
        }
    }

    // ---------------------------------------------------------------- load / unload

    suspend fun load(): Boolean = exclusive(false) { loadLocked() }

    private suspend fun loadLocked(): Boolean {
        val st = cur
        val imported = st.stored.model?.imported
        if (st.state == OnDeviceState.LOADED) return true
        if (imported == null || (st.state != OnDeviceState.READY && st.state != OnDeviceState.ERROR)) {
            commit { it.copy(error = "استورد ملف النموذج أولاً", message = null) }
            return false
        }
        val path = gateway.resolvePath(imported)
        if (path == null) {
            val stored = st.stored.copy(model = st.stored.model.copy(imported = null), enabled = false, verifiedFingerprint = null)
            commit(persist = true) {
                it.copy(stored = stored, state = OnDeviceState.FILE_SELECTED, loadReport = null,
                    error = "الملف المستورد لم يعد موجوداً؛ أعد الاستيراد.", message = null)
            }
            audit("تحميل النموذج: الملف المستورد مفقود")
            return false
        }
        val before = gateway.memory()
        when (val g = MemoryGuard.check(imported.sizeBytes, before)) {
            is MemoryGuard.Verdict.Refuse -> {
                commit { it.copy(state = OnDeviceState.ERROR, error = g.message, message = null) }
                audit("تحميل النموذج: رُفض لنقص الذاكرة المتاحة")
                return false
            }
            is MemoryGuard.Verdict.Warn -> commit { it.copy(message = g.message) }
            MemoryGuard.Verdict.Ok -> Unit
        }
        commit { it.copy(state = OnDeviceState.LOADING, error = null, testReport = null) }
        val t0 = nanoTime()
        return try {
            when (val r = runtime.load(path, st.stored.params)) {
                is ProviderResult.Err -> {
                    withContext(NonCancellable) { runtime.unload() }
                    val dropEnable = r.failure.kind == FailureKind.INVALID_MODEL_FILE ||
                        r.failure.kind == FailureKind.RUNTIME_UNAVAILABLE || r.failure.kind == FailureKind.OUT_OF_MEMORY
                    val stored = if (dropEnable) cur.stored.copy(enabled = false, verifiedFingerprint = null) else cur.stored
                    commit(persist = dropEnable) { it.copy(stored = stored, state = OnDeviceState.ERROR, error = r.failure.message, loadReport = null) }
                    audit("تحميل النموذج: فشل (${r.failure.kind})")
                    false
                }
                is ProviderResult.Ok -> {
                    val ms = (nanoTime() - t0) / 1_000_000
                    val report = LoadReport(r.value, ms, before, gateway.memory())
                    commit { it.copy(state = OnDeviceState.LOADED, loadReport = report, error = null, message = "تم تحميل النموذج خلال $ms ms.") }
                    audit("تم تحميل النموذج ($ms ms)")
                    true
                }
            }
        } catch (e: CancellationException) {
            withContext(NonCancellable) { runtime.unload() }
            commit { it.copy(state = OnDeviceState.READY, loadReport = null, message = "أُلغي التحميل.", error = null) }
            audit("أُلغي تحميل النموذج")
            throw e
        }
    }

    /** User-requested unload: also turns the model off (it stays configured and verified). */
    suspend fun unload() {
        runtime.cancel() // let a running inference end quickly so the lock is released
        opMutex.withLock {
            opJob = currentCoroutineContext()[Job]
            try { unloadLocked(keepEnabled = false) } finally { opJob = null }
        }
    }

    /**
     * Memory-pressure / background policy: free the RAM now, stay enabled, reload lazily on next use.
     * The app calls this from onTrimMemory; see docs/ON_DEVICE_AI_REPORT.md for the exact levels.
     */
    suspend fun onMemoryPressure() {
        if (cur.state != OnDeviceState.LOADED && cur.state != OnDeviceState.TESTING) return
        runtime.cancel()
        opMutex.withLock {
            opJob = currentCoroutineContext()[Job]
            try { unloadLocked(keepEnabled = true, note = "فُرّغ النموذج لتحرير الذاكرة؛ سيُعاد تحميله عند الحاجة.") } finally { opJob = null }
        }
    }

    private suspend fun unloadLocked(keepEnabled: Boolean, note: String? = null) {
        val st = cur
        if (st.state != OnDeviceState.LOADED && st.state != OnDeviceState.ERROR && st.state != OnDeviceState.LOADING &&
            st.state != OnDeviceState.TESTING
        ) {
            if (!keepEnabled && st.stored.enabled) {
                commit(persist = true) { it.copy(stored = it.stored.copy(enabled = false), message = "تم تعطيل النموذج.") }
            }
            return
        }
        commit { it.copy(state = OnDeviceState.UNLOADING) }
        withContext(NonCancellable) { runtime.unload() }
        val stored = if (keepEnabled) st.stored else st.stored.copy(enabled = false)
        commit(persist = !keepEnabled) {
            it.copy(stored = stored, state = restState(stored), loadReport = null,
                message = note ?: "تم تفريغ النموذج من الذاكرة.", error = null)
        }
        audit("تم تفريغ النموذج من الذاكرة")
    }

    // ---------------------------------------------------------------- inference test / enable

    /** Runs a REAL generation with the loaded model (loading it first if needed). Success means the model itself replied. */
    suspend fun testInference(): String = exclusive("عملية أخرى قيد التنفيذ") {
        if (cur.stored.model?.imported == null) return@exclusive "استورد ملف النموذج أولاً"
        if (cur.state != OnDeviceState.LOADED && !loadLocked()) return@exclusive cur.error ?: "تعذّر تحميل النموذج"
        // A test result belongs to one configuration: invalidate first, then set only on success.
        commit(persist = true) {
            it.copy(stored = it.stored.copy(enabled = false, verifiedFingerprint = null), state = OnDeviceState.TESTING,
                error = null, testReport = null)
        }
        val prompt = ChatPrompt("Answer in as few words as possible.", InferenceTester.PROBE_QUESTION, maxTokens = InferenceTester.PROBE_MAX_TOKENS)
        val t0 = nanoTime()
        try {
            when (val r = runtime.complete(prompt, inferenceTimeoutMs)) {
                is ProviderResult.Err -> {
                    val f = r.failure
                    audit("اختبار الاستدلال على الجهاز: فشل (${f.kind})")
                    if (f.kind == FailureKind.OUT_OF_MEMORY || f.kind == FailureKind.RUNTIME_UNAVAILABLE) {
                        withContext(NonCancellable) { runtime.unload() }
                        commit { it.copy(state = OnDeviceState.ERROR, loadReport = null, error = f.message) }
                    } else {
                        commit { it.copy(state = OnDeviceState.LOADED, error = f.message) }
                    }
                    "فشل اختبار الاستدلال: ${f.message}"
                }
                is ProviderResult.Ok -> {
                    val ms = (nanoTime() - t0) / 1_000_000
                    val text = ModelOutputSanitizer.clean(r.value.text)
                    val passed = text.isNotEmpty() && InferenceTester.PROBE_EXPECTED.any { text.contains(it, ignoreCase = true) }
                    val report = TestReport(text.take(160), ms, passed)
                    if (passed) {
                        val st = cur.stored
                        val stored = st.copy(verifiedFingerprint = st.fingerprint())
                        commit(persist = true) {
                            it.copy(stored = stored, state = OnDeviceState.LOADED, testReport = report,
                                message = "نجح اختبار الاستدلال: النموذج المحلي نفسه أنتج الرد خلال $ms ms. يمكنك تفعيله الآن.", error = null)
                        }
                        audit("نجح اختبار الاستدلال على الجهاز ($ms ms)")
                        "نجح اختبار الاستدلال ($ms ms). الرد: «${text.take(80)}»"
                    } else {
                        val why = if (text.isEmpty()) "الرد فارغ" else "الإجابة لا تطابق المتوقع"
                        commit { it.copy(state = OnDeviceState.LOADED, testReport = report, error = why) }
                        audit("اختبار الاستدلال على الجهاز: $why")
                        "أنتج النموذج رداً لكنه لم يجتز الاختبار ($why). الرد: «${text.take(80)}»"
                    }
                }
            }
        } catch (e: CancellationException) {
            commit { it.copy(state = OnDeviceState.LOADED, message = "أُلغي الاختبار.", error = null) }
            throw e
        }
    }

    /** Returns null on success, or the reason the model cannot be enabled. */
    fun enable(): String? {
        if (opMutex.isLocked) return "انتظر انتهاء العملية الجارية"
        val st = cur.stored
        if (st.model?.imported == null) return "استورد ملف النموذج أولاً"
        if (st.verifiedFingerprint == null || st.verifiedFingerprint != st.fingerprint()) {
            return "شغّل اختبار الاستدلال بنجاح لهذا الملف وهذه الإعدادات قبل التفعيل"
        }
        commit(persist = true) { it.copy(stored = it.stored.copy(enabled = true), message = "تم تفعيل النموذج على الجهاز.", error = null) }
        audit("تم تفعيل النموذج على الجهاز")
        return null
    }

    /** Stops using the model and frees its memory. Configuration and verification are kept. */
    suspend fun disable() {
        commit(persist = true) { it.copy(stored = it.stored.copy(enabled = false)) }
        unload()
    }

    /** Changing context length or threads invalidates the inference test (the fingerprint changes). */
    suspend fun changeParams(params: RuntimeParams): Boolean = exclusive(false) {
        val p = params.normalized()
        if (p == cur.stored.params) return@exclusive true
        unloadLocked(keepEnabled = false)
        val stored = cur.stored.copy(params = p, enabled = false, verifiedFingerprint = null)
        commit(persist = true) {
            it.copy(stored = stored, state = restState(stored), loadReport = null, testReport = null,
                message = "تغيّرت الإعدادات؛ أعد اختبار الاستدلال قبل التفعيل.", error = null)
        }
        audit("تغيّرت إعدادات الاستدلال على الجهاز")
        true
    }

    /** Removes the model selection, the private copy and all stored settings. The original file is untouched. */
    suspend fun clear() {
        runtime.cancel()
        opMutex.withLock {
            opJob = currentCoroutineContext()[Job]
            try {
                unloadLocked(keepEnabled = false)
                cur.stored.model?.imported?.let { gateway.deleteImported(it) }
                commit(persist = false) { S(StoredOnDevice.EMPTY, OnDeviceState.NOT_SELECTED, message = "تم حذف النموذج المستورد وإعداداته.") }
                store.write(null)
                audit("تم مسح نموذج الجهاز")
            } finally { opJob = null }
        }
    }

    // ---------------------------------------------------------------- use by the assistant

    private val usable: Boolean
        get() {
            val st = cur.stored
            return st.enabled && st.verifiedFingerprint != null && st.verifiedFingerprint == st.fingerprint()
        }

    /** The provider VENEX should use now, or null (rules only). */
    fun activeIntentProvider(): AiProvider? {
        if (!usable) return null
        return ModelIntentProvider(this, "model:ON_DEVICE", audit, { f -> reportRuntimeFailure(f) }, maxTokens = ON_DEVICE_MAX_TOKENS)
    }

    fun reportRuntimeFailure(f: ProviderFailure) {
        if (f.kind == FailureKind.NOT_READY) return
        commit { it.copy(error = "خطأ أثناء الاستخدام: ${f.message}") }
    }

    /** At app start: if the model was enabled, load it in the background so the first command is not slow. */
    suspend fun restoreIfEnabled() {
        if (usable) ensureLoaded()
    }

    private suspend fun ensureLoaded(): Boolean {
        if (cur.state == OnDeviceState.LOADED) return true
        if (!usable) return false
        val d = synchronized(lock) {
            loadJob?.takeIf { it.isActive } ?: scope.async { load() }.also { loadJob = it }
        }
        return d.await()
    }

    override suspend fun complete(prompt: ChatPrompt): ProviderResult<Completion> {
        if (!usable) return notReady("النموذج على الجهاز غير مفعّل")
        if (!ensureLoaded()) return notReady("النموذج على الجهاز غير محمّل بعد")
        return opMutex.withLock {
            if (cur.state != OnDeviceState.LOADED || !usable) return@withLock notReady("النموذج على الجهاز غير جاهز")
            val r = runtime.complete(prompt, inferenceTimeoutMs)
            if (r is ProviderResult.Err && r.failure.kind == FailureKind.OUT_OF_MEMORY) {
                withContext(NonCancellable) { runtime.unload() }
                val stored = cur.stored.copy(enabled = false)
                commit(persist = true) {
                    it.copy(stored = stored, state = restState(stored), loadReport = null,
                        error = "نفدت الذاكرة أثناء الاستدلال؛ عُطّل النموذج.")
                }
                audit("نفدت الذاكرة أثناء استدلال الجهاز؛ عُطّل النموذج")
            }
            r
        }
    }

    private fun notReady(msg: String) = ProviderResult.Err(ProviderFailure(FailureKind.NOT_READY, msg))

    companion object {
        private const val PROGRESS_STEP = 8L * 1024 * 1024
        /** A reply is one short JSON object; a small cap bounds the worst case on a slow phone. */
        const val ON_DEVICE_MAX_TOKENS = 96
    }
}
