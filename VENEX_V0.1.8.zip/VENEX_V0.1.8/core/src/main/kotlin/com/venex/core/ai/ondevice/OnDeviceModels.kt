package com.venex.core.ai.ondevice

import com.venex.core.ai.ChatPrompt
import com.venex.core.ai.Completion
import com.venex.core.ai.ProviderResult

/** Lifecycle of the on-device model. Transient states (importing, loading, ...) are never persisted. */
enum class OnDeviceState(val arabic: String) {
    NOT_SELECTED("لم يُحدَّد ملف نموذج"),
    FILE_SELECTED("تم اختيار الملف (لم يُستورد بعد)"),
    IMPORTING("جارٍ استيراد الملف"),
    READY("الملف جاهز (غير محمّل)"),
    LOADING("جارٍ تحميل النموذج"),
    LOADED("النموذج محمّل في الذاكرة"),
    TESTING("جارٍ اختبار الاستدلال"),
    UNLOADING("جارٍ التفريغ"),
    ERROR("خطأ")
}

/** Settings that the user may change. Values are clamped by [normalized]; they are conservative on purpose. */
data class RuntimeParams(val contextLength: Int = DEFAULT_CONTEXT, val threads: Int = DEFAULT_THREADS) {
    fun normalized(): RuntimeParams = RuntimeParams(
        contextLength = if (contextLength in CONTEXT_OPTIONS) contextLength else DEFAULT_CONTEXT,
        threads = threads.coerceIn(1, MAX_THREADS)
    )

    companion object {
        /** Prompts are short (system prompt + a command of at most 300 chars), so a small window is enough. */
        val CONTEXT_OPTIONS = listOf(512, 1024, 2048, 4096)
        const val DEFAULT_CONTEXT = 1024
        const val DEFAULT_THREADS = 4
        const val MAX_THREADS = 8

        /** A conservative default: leave cores for the rest of the system, between 2 and 4 threads. */
        fun forCpuCount(cores: Int) = RuntimeParams(DEFAULT_CONTEXT, (cores / 2).coerceIn(2, 4))
    }
}

/** A file the user picked (before it is imported). [sizeBytes] is null when the provider does not report it. */
data class PickedFile(val uri: String, val displayName: String, val sizeBytes: Long?)

/** A private copy of the model inside the app's own storage. The original is never touched. */
data class ImportedModel(val fileName: String, val sizeBytes: Long, val sha256: String)

data class SelectedModel(
    val uri: String,
    val displayName: String,
    val sizeBytes: Long,
    val gguf: GgufSummary,
    val imported: ImportedModel?
)

/** What is persisted for the on-device mode. There is NO path outside the app's private directory. */
data class StoredOnDevice(
    val model: SelectedModel?,
    val params: RuntimeParams,
    val enabled: Boolean,
    val verifiedFingerprint: String?
) {
    /** Binds a passed inference test to this exact file content AND these settings. */
    fun fingerprint(): String? {
        val m = model?.imported ?: return null
        return listOf("ondevice", m.sha256, m.sizeBytes, params.contextLength, params.threads).joinToString("|")
    }

    companion object {
        val EMPTY = StoredOnDevice(null, RuntimeParams(), false, null)
    }
}

interface OnDeviceStore {
    fun read(): StoredOnDevice?
    fun write(settings: StoredOnDevice?)
}

data class MemorySample(val availableBytes: Long, val totalBytes: Long, val lowMemory: Boolean)

data class LoadedInfo(
    val description: String,
    /** Bytes of model tensors as reported by the runtime. This is NOT the RAM used during inference. */
    val tensorBytes: Long,
    val parameters: Long,
    val trainedContext: Int,
    val allocatedContext: Int,
    val threads: Int
)

/** What the controller remembers about the last load, for honest display. Only measured values. */
data class LoadReport(
    val info: LoadedInfo,
    val loadMs: Long,
    val memoryBefore: MemorySample?,
    val memoryAfter: MemorySample?
)

data class TestReport(val answer: String, val latencyMs: Long, val passed: Boolean)

/**
 * The native runtime (llama.cpp via JNI on Android). All methods are coroutine-friendly and must
 * never run native code on the main thread. [cancel] may be called from any thread at any time.
 */
interface LlmRuntime {
    suspend fun load(path: String, params: RuntimeParams): ProviderResult<LoadedInfo>
    suspend fun complete(prompt: ChatPrompt, timeoutMs: Long): ProviderResult<Completion>
    fun cancel()
    suspend fun unload()
}

data class InspectedFile(val file: PickedFile, val gguf: GgufSummary)

/** Android storage access (Storage Access Framework). Everything here may fail for ordinary reasons. */
interface ModelFileGateway {
    /** Reads name, size and the GGUF header of a picked document. Does not copy it. */
    suspend fun inspect(uri: String): ProviderResult<InspectedFile>

    /**
     * Copies the document into private storage: checks free space first, reports progress, writes to a
     * temporary file and renames it only when complete, and removes the partial file on failure or
     * cancellation. Never deletes or modifies the source.
     */
    suspend fun import(file: PickedFile, onProgress: (copied: Long, total: Long) -> Unit): ProviderResult<ImportedModel>

    /** Absolute path of the imported copy if it still exists with the recorded size, otherwise null. */
    fun resolvePath(imported: ImportedModel): String?

    suspend fun deleteImported(imported: ImportedModel)

    fun memory(): MemorySample?
}

data class OnDeviceSnapshot(
    val state: OnDeviceState,
    val model: SelectedModel?,
    val params: RuntimeParams,
    val enabled: Boolean,
    val verified: Boolean,
    val importCopiedBytes: Long,
    val importTotalBytes: Long,
    val loadReport: LoadReport?,
    val testReport: TestReport?,
    val message: String?,
    val errorMessage: String?
)

/**
 * One honest line for the combined state. A model that is merely loaded is never reported as working:
 * "working" needs a passed inference test for the current file and settings AND the enabled flag.
 */
val OnDeviceSnapshot.readiness: String
    get() = when {
        state == OnDeviceState.ERROR -> "خطأ — النموذج لا يعمل"
        model == null -> "لا يوجد نموذج"
        state == OnDeviceState.IMPORTING || state == OnDeviceState.LOADING ||
            state == OnDeviceState.TESTING || state == OnDeviceState.UNLOADING -> state.arabic
        enabled && verified && state == OnDeviceState.LOADED -> "يعمل: النموذج محمّل، واجتاز اختبار الاستدلال، ومفعّل"
        enabled && verified -> "مفعّل واجتاز الاختبار — غير محمّل الآن، ويُحمَّل عند أول أمر يحتاجه"
        enabled -> "مفعّل لكن الاختبار لم يُجتز لهذه الإعدادات — لن يُستخدم"
        verified -> "اجتاز اختبار الاستدلال لكنه غير مفعّل — لا يُستخدم بعد"
        state == OnDeviceState.LOADED -> "محمّل في الذاكرة، لكن لم يثبت بعد أنه يجيب (اختبار الاستدلال لم يُجتز) — غير مفعّل"
        else -> "غير جاهز: لم يُحمَّل ولم يُختبر — غير مفعّل"
    }
