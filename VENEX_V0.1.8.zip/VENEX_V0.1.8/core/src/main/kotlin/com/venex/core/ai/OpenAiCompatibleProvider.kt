package com.venex.core.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Adapter for OpenAI-style servers: GET /v1/models and POST /v1/chat/completions.
 * Works with servers such as LM Studio, llama.cpp's server and vLLM, which differ in details;
 * anything that does not match the documented shape is reported as INVALID_RESPONSE.
 */
class OpenAiCompatibleProvider : ModelProvider {

    override val type: ProviderType = ProviderType.OPENAI_COMPATIBLE

    override suspend fun listModels(spec: ConnectionSpec): ProviderResult<List<ModelInfo>> =
        withContext(Dispatchers.IO) {
            guarded {
                val started = System.nanoTime()
                val reply = Http.send(Urls.join(spec.baseUrl, "/v1/models"), "GET", null, spec)
                if (reply.code != 200) return@guarded Http.statusFailure(reply.code)
                val root = MiniJson.parse(reply.body) as? Map<*, *> ?: return@guarded Http.invalid()
                val data = root["data"] as? List<*> ?: return@guarded Http.invalid()
                val models = data.mapNotNull { item -> (item as? Map<*, *>)?.get("id") as? String }
                ProviderResult.Ok(models.map { ModelInfo(it) }, Http.elapsedMs(started))
            }
        }

    override suspend fun complete(
        spec: ConnectionSpec,
        modelId: String,
        prompt: ChatPrompt
    ): ProviderResult<Completion> = withContext(Dispatchers.IO) {
        guarded {
            val started = System.nanoTime()
            val payload = MiniJson.encode(
                mapOf(
                    "model" to modelId,
                    "messages" to listOf(
                        mapOf("role" to "system", "content" to prompt.system),
                        mapOf("role" to "user", "content" to prompt.user)
                    ),
                    "max_tokens" to prompt.maxTokens,
                    "temperature" to 0,
                    "stream" to false
                )
            )
            val reply = Http.send(Urls.join(spec.baseUrl, "/v1/chat/completions"), "POST", payload, spec)
            if (reply.code == 404) {
                return@guarded ProviderResult.Err(
                    ProviderFailure(
                        FailureKind.MODEL_NOT_FOUND,
                        "الخادم لم يجد المسار أو النموذج «$modelId» (HTTP 404)"
                    )
                )
            }
            if (reply.code != 200) return@guarded Http.statusFailure(reply.code)

            val root = MiniJson.parse(reply.body) as? Map<*, *> ?: return@guarded Http.invalid()
            val first = (root["choices"] as? List<*>)?.firstOrNull() as? Map<*, *>
                ?: return@guarded Http.invalid()
            val text = ((first["message"] as? Map<*, *>)?.get("content") as? String)
                ?: (first["text"] as? String)
                ?: return@guarded Http.invalid()
            if (text.isBlank()) return@guarded Http.empty()
            ProviderResult.Ok(Completion(text.trim(), root["model"] as? String), Http.elapsedMs(started))
        }
    }
}
