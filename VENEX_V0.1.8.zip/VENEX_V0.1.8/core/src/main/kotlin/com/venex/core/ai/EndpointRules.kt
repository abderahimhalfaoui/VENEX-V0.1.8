package com.venex.core.ai

import java.net.URI
import java.net.URISyntaxException

/** Validates the address the user typed for a local model server. */
object EndpointRules {

    data class ValidatedEndpoint(val baseUrl: String, val loopbackOnly: Boolean, val warnings: List<String>)

    sealed interface Result {
        data class Ok(val endpoint: ValidatedEndpoint) : Result
        data class Rejected(val reason: String) : Result
    }

    private const val MAX_LENGTH = 300

    fun validate(raw: String): Result {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return Result.Rejected("أدخل عنوان الخادم")
        if (trimmed.length > MAX_LENGTH) return Result.Rejected("العنوان طويل جداً")

        val uri = try {
            URI(trimmed)
        } catch (e: URISyntaxException) {
            return Result.Rejected("العنوان غير صالح")
        }
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") {
            return Result.Rejected("يجب أن يبدأ العنوان بـ http:// أو https://")
        }
        val host = uri.host ?: return Result.Rejected("لم يُحدَّد اسم المضيف أو عنوان IP")
        if (uri.rawUserInfo != null) {
            return Result.Rejected("لا تضع بيانات الدخول داخل العنوان؛ استخدم حقل المفتاح")
        }
        if (uri.rawQuery != null || uri.rawFragment != null) {
            return Result.Rejected("أدخل المسار الأساسي فقط، بلا استعلام أو جزء بعد #")
        }
        if (uri.port != -1 && uri.port !in 1..65535) return Result.Rejected("رقم المنفذ غير صالح")

        val loopback = isLoopback(host)
        val warnings = buildList {
            if (!loopback) {
                add("الخادم على جهاز آخر: الاتصال يمر عبر الشبكة. عنوان IP المحلي لا يعني أن المزوّد آمن.")
            }
            if (scheme == "http" && !loopback) add("الاتصال غير مشفّر (HTTP) عبر الشبكة.")
        }
        return Result.Ok(ValidatedEndpoint(trimmed.trimEnd('/'), loopback, warnings))
    }

    /**
     * Cloud endpoints must be HTTPS and must not be a loopback address (localhost / 127.x / ::1): a key
     * is being sent, so cleartext is never acceptable, and "cloud" means a remote provider.
     */
    fun validateCloud(raw: String): Result {
        val base = validate(raw)
        if (base !is Result.Ok) return base
        val uri = URI(base.endpoint.baseUrl)
        if (uri.scheme?.lowercase() != "https") {
            return Result.Rejected("المزوّد السحابي يتطلب HTTPS (لن يُرسل المفتاح عبر اتصال غير مشفّر)")
        }
        if (isLoopback(uri.host)) {
            return Result.Rejected("العنوان محلي؛ لخادم على جهازك استخدم وضع «خادم محلي» بدل السحابي")
        }
        return Result.Ok(base.endpoint.copy(warnings = emptyList()))
    }

    fun hostOf(baseUrl: String): String? = try { URI(baseUrl).host } catch (e: URISyntaxException) { null }

    fun isLoopback(host: String): Boolean {
        val h = host.lowercase().removePrefix("[").removeSuffix("]")
        return h == "localhost" || h == "::1" || h == "127.0.0.1" || h.startsWith("127.")
    }
}
