package com.venex.core.ai.ondevice

/**
 * Pre-flight memory check before loading. GGUF file size is NOT the RAM used while running
 * (weights are memory-mapped, plus a KV cache and compute buffers), so this is only a conservative
 * refusal of loads that are clearly hopeless; it is not a prediction. Thresholds are constants that
 * should be tuned from real device measurements (see docs/ON_DEVICE_AI_REPORT.md, "Not tested").
 */
object MemoryGuard {
    /** Weights are memory-mapped, but the working set must still fit: require this share of file size to be free. */
    const val REQUIRED_FRACTION_OF_FILE = 0.85
    /** Extra room for the KV cache, compute buffers and the app itself. */
    const val OVERHEAD_BYTES = 192L * 1024 * 1024

    sealed interface Verdict {
        data object Ok : Verdict
        data class Refuse(val message: String) : Verdict
        data class Warn(val message: String) : Verdict
    }

    fun check(fileBytes: Long, sample: MemorySample?): Verdict {
        if (sample == null) return Verdict.Warn("تعذّر قياس الذاكرة المتاحة؛ سيُحاوَل التحميل دون فحص مسبق.")
        val need = (fileBytes * REQUIRED_FRACTION_OF_FILE).toLong() + OVERHEAD_BYTES
        if (sample.availableBytes < need) {
            return Verdict.Refuse(
                "الذاكرة المتاحة حالياً (${mb(sample.availableBytes)} MB) أقل من الحد الأدنى المحافظ لهذا النموذج " +
                    "(≈${mb(need)} MB). أغلق تطبيقات أخرى أو اختر نموذجاً أصغر."
            )
        }
        if (sample.lowMemory) return Verdict.Warn("النظام يبلغ عن ذاكرة منخفضة؛ قد يُغلَق التطبيق أثناء الاستدلال.")
        return Verdict.Ok
    }

    private fun mb(b: Long) = b / (1024 * 1024)
}
