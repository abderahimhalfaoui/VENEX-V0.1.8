package com.venex.core.goal

import com.venex.core.adaptive.ExecutionMethod
import com.venex.core.device.Channel
import com.venex.core.safety.ApprovalBinding
import com.venex.core.safety.RiskAssessment
import com.venex.core.verify.Check

enum class GoalFamily(val arabicLabel: String) {
    DESCRIBE_SCREEN("وصف الشاشة"),
    TAP("نقر عنصر"),
    ENTER_TEXT("إدخال نص"),
    SEARCH_IN_APP("بحث داخل تطبيق"),
    CREATE_POST("نشر منشور"),
    SEND_MESSAGE("إرسال رسالة"),
    DELETE_ITEM("حذف عنصر"),
    PAYMENT("دفع/شراء/تحويل")
}

enum class SlotName(val arabicLabel: String) {
    APP("التطبيق"), TARGET("العنصر المستهدف"), TEXT("النص"), FIELD("الحقل"), QUERY("عبارة البحث"), RECIPIENT("المستلم")
}

enum class SlotStatus {
    /** The owner wrote it. */
    EXPLICIT,

    /** VENEX concluded it from context; it must stay visible as an inference. */
    INFERRED,

    /** Needed and absent. */
    MISSING,

    /** The owner pointed at it ("the text I gave you") but it was not supplied. */
    REFERENCED_BUT_ABSENT
}

data class Slot(val name: SlotName, val value: String?, val status: SlotStatus, val note: String? = null) {
    val usable: Boolean get() = value != null && (status == SlotStatus.EXPLICIT || status == SlotStatus.INFERRED)
}

/** Where a statement about the task comes from — kept apart so the owner can see what was said and what was assumed. */
enum class Origin { OWNER_EXPLICIT, SYSTEM_INFERRED, UNKNOWN, NEEDS_OWNER }

data class Statement(val text: String, val origin: Origin)

data class Clarification(val slot: SlotName, val question: String)

/**
 * The owner's goal as a typed structure: what outcome is wanted, what is needed to reach it, what is known, assumed,
 * unknown or has to be asked, how it will be verified and how risky it is. It is built by deterministic rules (no
 * model is needed) and is the only thing the planner consumes.
 */
data class StructuredGoal(
    val rawText: String,
    val family: GoalFamily,
    val desiredOutcome: String,
    val slots: List<Slot>,
    val preconditions: List<String>,
    val requiredPermissions: Set<Channel>,
    val constraints: List<String>,
    val possiblePaths: List<ExecutionMethod>,
    val expectedFinalState: String,
    /** Declarative conditions the Verifier will evaluate at the end. */
    val verification: List<Check>,
    val risk: RiskAssessment,
    val statements: List<Statement>,
    val clarifications: List<Clarification>
) {
    fun slot(name: SlotName): Slot? = slots.firstOrNull { it.name == name }
    fun value(name: SlotName): String? = slot(name)?.takeIf { it.usable }?.value

    val needsClarification: Boolean get() = clarifications.isNotEmpty()

    /** Identity of the goal for approvals: the same family with the same slot values. Content is included by digest. */
    val fingerprint: String
        get() = ApprovalBinding.sha256(
            family.name + "|" + slots.sortedBy { it.name.ordinal }.joinToString("|") { "${it.name}=${it.value ?: ""}:${it.status}" }
        ).take(32)

    fun statementsOf(origin: Origin): List<String> = statements.filter { it.origin == origin }.map { it.text }
}

/** What the interpreter concluded about a command. */
sealed interface Interpretation {
    /** Understood, nothing is missing. */
    data class Ready(val goal: StructuredGoal) : Interpretation

    /** Understood in part: the owner must supply [StructuredGoal.clarifications] first. VENEX invents nothing. */
    data class NeedsClarification(val goal: StructuredGoal) : Interpretation

    /** Understood, but refused by policy (for example payments). */
    data class Refused(val goal: StructuredGoal, val reason: String) : Interpretation

    /** Not understood. */
    data class Unsupported(val rawText: String, val reason: String) : Interpretation
}
