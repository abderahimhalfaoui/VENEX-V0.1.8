package com.venex.core.memory

import com.venex.core.adaptive.LabelHints
import com.venex.core.ai.MiniJson
import com.venex.core.intent.TextNormalizer
import java.io.File
import java.math.BigDecimal

/**
 * Decides what must never be kept in memory. Memory holds names of controls ("Post", "نشر"), nothing the owner typed,
 * and nothing that looks like a credential, a token, a code, an address or a number that identifies someone.
 */
object SecretGuard {
    private val WORDS = listOf(
        "password", "passwd", "passcode", "token", "secret", "api key", "apikey", "bearer", "otp", "cookie", "session id", "private key",
        "كلمه المرور", "كلمة المرور", "رمز", "مفتاح", "سر", "كوكي"
    ).map(TextNormalizer::normalize)
    private val LONG_DIGITS = Regex("\\d{6,}")
    private val TOKENISH = Regex("[A-Za-z0-9_\\-+/=]{20,}")

    fun looksSecret(s: String): Boolean {
        val t = s.trim()
        if (t.isEmpty() || t.length > MAX_LABEL_CHARS) return true
        val n = TextNormalizer.normalize(t)
        if (t.contains('@') || t.contains("://") || t.contains('\n')) return true
        if (LONG_DIGITS.containsMatchIn(n) || TOKENISH.containsMatchIn(t)) return true
        if (t.startsWith("sk-") || t.startsWith("ghp_") || t.startsWith("eyJ")) return true
        return WORDS.any { w -> n.split(' ').any { it == w } || (w.contains(' ') && n.contains(w)) }
    }

    const val MAX_LABEL_CHARS = 40
}

/** One remembered fact: in [appPackage], the control that does [role] has been seen labelled [label]. */
data class ExperienceEntry(
    val appPackage: String,
    val role: String,
    val label: String,
    val successes: Int,
    val failures: Int,
    val lastSeenMillis: Long
)

interface KnowledgeStore {
    fun loadAll(): List<ExperienceEntry>
    fun saveAll(entries: List<ExperienceEntry>)
}

class InMemoryKnowledgeStore : KnowledgeStore {
    private var data: List<ExperienceEntry> = emptyList()
    @Synchronized override fun loadAll(): List<ExperienceEntry> = data
    @Synchronized override fun saveAll(entries: List<ExperienceEntry>) { data = entries }
}

/** Local JSONL, one entry per line; unreadable lines are skipped. Never leaves the device. */
class FileKnowledgeStore(private val file: File) : KnowledgeStore {
    private val lock = Any()

    override fun loadAll(): List<ExperienceEntry> = synchronized(lock) {
        if (!file.exists()) return emptyList()
        val out = ArrayList<ExperienceEntry>()
        try {
            file.readLines(Charsets.UTF_8).forEach { l ->
                if (l.isBlank() || l.length > 2_000) return@forEach
                try {
                    val m = MiniJson.parse(l) as? Map<*, *> ?: return@forEach
                    out += ExperienceEntry(
                        m["p"] as String, m["r"] as String, m["l"] as String,
                        (m["s"] as BigDecimal).toInt(), (m["f"] as BigDecimal).toInt(), (m["t"] as BigDecimal).toLong()
                    )
                } catch (_: Exception) {
                }
            }
        } catch (_: Exception) {
        }
        out
    }

    override fun saveAll(entries: List<ExperienceEntry>) = synchronized(lock) {
        try {
            file.parentFile?.mkdirs()
            val tmp = File(file.path + ".tmp")
            tmp.writeText(
                entries.joinToString("") { e -> MiniJson.encode(mapOf("p" to e.appPackage, "r" to e.role, "l" to e.label, "s" to e.successes, "f" to e.failures, "t" to e.lastSeenMillis)) + "\n" },
                Charsets.UTF_8
            )
            if (!tmp.renameTo(file)) { file.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8); tmp.delete() }
        } catch (_: Exception) {
            // losing a memory write must never break a task
        }
    }
}

/**
 * What VENEX has learned about how apps label their controls, from tasks that were VERIFIED. It is only ever a hint:
 *  - a label is offered only after at least [minNetSuccesses] more successes than failures (one success is no proof);
 *  - entries expire after [ttlMs] without being seen again;
 *  - the element still has to be found on the live screen, so a stale entry cannot make VENEX press anything;
 *  - a miss or a contradiction lowers the score, and an entry whose failures catch up with its successes is removed;
 *  - anything that looks secret is refused, and only control names are stored, never typed text;
 *  - the owner can forget an app, an entry, or everything.
 */
class ExperienceMemory(
    private val store: KnowledgeStore = InMemoryKnowledgeStore(),
    private val clock: () -> Long = System::currentTimeMillis,
    private val ttlMs: Long = 30L * 24 * 60 * 60 * 1000,
    private val minNetSuccesses: Int = 2,
    private val maxEntries: Int = 500
) : LabelHints {

    @Synchronized
    fun recordSuccess(appPackage: String?, role: String, label: String?): Boolean {
        if (appPackage.isNullOrBlank() || label == null || SecretGuard.looksSecret(label)) return false
        val all = store.loadAll().toMutableList()
        val key = key(label)
        val i = all.indexOfFirst { it.appPackage == appPackage && it.role == role && key(it.label) == key }
        val now = clock()
        if (i >= 0) all[i] = all[i].copy(successes = all[i].successes + 1, lastSeenMillis = now)
        else all += ExperienceEntry(appPackage, role, label.trim(), 1, 0, now)
        store.saveAll(trim(all))
        return true
    }

    @Synchronized
    fun recordFailure(appPackage: String?, role: String, label: String) {
        if (appPackage.isNullOrBlank()) return
        val all = store.loadAll().toMutableList()
        val key = key(label)
        val i = all.indexOfFirst { it.appPackage == appPackage && it.role == role && key(it.label) == key }
        if (i < 0) return
        val e = all[i].copy(failures = all[i].failures + 1)
        if (e.failures >= e.successes) all.removeAt(i) else all[i] = e
        store.saveAll(all)
    }

    @Synchronized
    override fun labelsFor(appPackage: String?, role: String): List<String> {
        if (appPackage.isNullOrBlank()) return emptyList()
        val now = clock()
        return store.loadAll()
            .filter { it.appPackage == appPackage && it.role == role && it.successes - it.failures >= minNetSuccesses && now - it.lastSeenMillis <= ttlMs }
            .sortedByDescending { it.successes - it.failures }
            .map { it.label }
    }

    @Synchronized fun entries(): List<ExperienceEntry> = store.loadAll()

    /** The owner's control: forget everything about one app (or all apps when [appPackage] is null). Returns how many were removed. */
    @Synchronized
    fun forget(appPackage: String? = null): Int {
        val all = store.loadAll()
        val keep = if (appPackage == null) emptyList() else all.filter { it.appPackage != appPackage }
        store.saveAll(keep)
        return all.size - keep.size
    }

    @Synchronized
    fun forgetEntry(appPackage: String, role: String, label: String): Boolean {
        val all = store.loadAll()
        val keep = all.filterNot { it.appPackage == appPackage && it.role == role && key(it.label) == key(label) }
        store.saveAll(keep)
        return keep.size != all.size
    }

    /** Drops expired entries. Called on write paths; cheap. */
    @Synchronized
    fun expire(): Int {
        val now = clock()
        val all = store.loadAll()
        val keep = all.filter { now - it.lastSeenMillis <= ttlMs }
        if (keep.size != all.size) store.saveAll(keep)
        return all.size - keep.size
    }

    @Synchronized
    fun describe(): String {
        val all = store.loadAll()
        if (all.isEmpty()) return "لا أحتفظ بأي خبرة عن واجهات التطبيقات."
        return "خبرات محفوظة محلياً على جهازك (${all.size}): " +
            all.take(10).joinToString("؛ ") { "${it.appPackage} / ${it.role} = «${it.label}» (نجاح ${it.successes}، فشل ${it.failures})" }
    }

    private fun key(label: String) = TextNormalizer.normalize(label)

    private fun trim(all: MutableList<ExperienceEntry>): List<ExperienceEntry> =
        if (all.size <= maxEntries) all else all.sortedByDescending { it.lastSeenMillis }.take(maxEntries)
}
