package com.venex.core.model

import java.math.BigDecimal
import java.math.MathContext

/** Arithmetic operators supported by the calculator task. */
enum class MathOp(val symbol: String) {
    ADD("+"),
    SUBTRACT("−"),
    MULTIPLY("×"),
    DIVIDE("÷");

    /** Returns the exact result, or null when undefined (division by zero). */
    fun apply(a: BigDecimal, b: BigDecimal): BigDecimal? = when (this) {
        ADD -> a.add(b)
        SUBTRACT -> a.subtract(b)
        MULTIPLY -> a.multiply(b)
        DIVIDE -> if (b.signum() == 0) null else a.divide(b, MathContext.DECIMAL64)
    }
}

enum class NavTarget { HOME, BACK }

enum class ScrollDirection { UP, DOWN }

/** Categories of actions that always require explicit user approval and are never auto-executed. */
enum class RestrictedCategory(val arabicLabel: String) {
    SEND("إرسال"),
    POST("نشر"),
    DELETE("حذف"),
    PAYMENT("دفع أو شراء")
}

/** A structured objective extracted from the user's natural-language command. */
sealed interface Goal {
    val rawText: String
}

data class OpenAppGoal(val appName: String, override val rawText: String) : Goal

/** "Open <app> and search for <query>". Executed only for apps with a known search address (see SearchServices). */
data class SearchInAppGoal(val appName: String, val query: String, override val rawText: String) : Goal

data class CalculateGoal(
    val left: BigDecimal,
    val op: MathOp,
    val right: BigDecimal,
    override val rawText: String
) : Goal {
    /** The mathematically expected result, or null if undefined. */
    fun expected(): BigDecimal? = op.apply(left, right)
}

data class NavigateGoal(val target: NavTarget, override val rawText: String) : Goal

data class ScrollGoal(val direction: ScrollDirection, override val rawText: String) : Goal

/** Send / post / delete / pay requests. V0.1 refuses to execute them (see SafetyPolicy). */
data class RestrictedGoal(val category: RestrictedCategory, override val rawText: String) : Goal

data class UnknownGoal(override val rawText: String) : Goal
