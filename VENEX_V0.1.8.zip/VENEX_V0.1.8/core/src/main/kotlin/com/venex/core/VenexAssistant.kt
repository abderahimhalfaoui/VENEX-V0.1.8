package com.venex.core

import com.venex.core.adaptive.AdaptiveCoordinator
import com.venex.core.audit.AuditLevel
import com.venex.core.audit.AuditLog
import com.venex.core.device.DeviceController
import com.venex.core.engine.ConfirmationHandler
import com.venex.core.engine.ExecutionEngine
import com.venex.core.intent.IntentParser
import com.venex.core.goal.Interpretation
import com.venex.core.model.Action
import com.venex.core.model.AdaptiveGoal
import com.venex.core.model.Goal
import com.venex.core.model.OpenAppGoal
import com.venex.core.model.Plan
import com.venex.core.model.RestrictedCategory
import com.venex.core.model.RestrictedGoal
import com.venex.core.model.SearchInAppGoal
import com.venex.core.model.Step
import com.venex.core.model.StepResult
import com.venex.core.model.TaskReport
import com.venex.core.model.TaskStatus
import com.venex.core.model.UnknownGoal
import com.venex.core.planner.SearchServices
import com.venex.core.planner.TaskPlanner

/**
 * Facade wiring Intent Understanding -> Task Planner -> Execution Engine.
 * The engine itself stays independent of the parser and of any UI.
 *
 * V0.1.8: with [adaptive] = null (the default) this behaves exactly as in V0.1.7. With a coordinator, commands that
 * V0.1.7 could not carry out (unknown, send/post/delete, "open X and <do something>", search in an app without a
 * known search address) are offered to the adaptive layer first; everything V0.1.7 handled still goes the V0.1.7 way.
 */
class VenexAssistant(
    private val parser: IntentParser,
    private val planner: TaskPlanner,
    private val device: DeviceController,
    private val audit: AuditLog,
    private val confirmations: ConfirmationHandler,
    private val settleDelayMs: Long = 150,
    private val adaptive: AdaptiveCoordinator? = null
) {
    /** Builds the plan without executing it (the UI can show it first). */
    suspend fun plan(command: String): Plan {
        val a = adaptive
        if (a != null && a.hasResumable() && a.isResumeCommand(command)) {
            audit.record(AuditLevel.INFO, "الهدف: استئناف مهمة متوقفة")
            return Plan(AdaptiveGoal(null, true, command), listOf(placeholder("resume", "استئناف المهمة المتوقفة")), null)
        }
        val goal = parser.parse(command)
        audit.record(AuditLevel.INFO, "الهدف: ${goal::class.simpleName}")
        if (a != null) adaptivePlan(a, goal, command)?.let { return it }
        return planner.plan(goal)
    }

    /** The adaptive layer's plan for [goal], or null when V0.1.7 should handle it exactly as before. */
    private suspend fun adaptivePlan(a: AdaptiveCoordinator, goal: Goal, command: String): Plan? {
        val eligible = when (goal) {
            is UnknownGoal, is OpenAppGoal -> true
            is RestrictedGoal -> goal.category != RestrictedCategory.PAYMENT
            is SearchInAppGoal -> SearchServices.forApp(goal.appName) == null
            else -> false
        }
        if (!eligible) return null
        return when (val r = a.interpret(command)) {
            is Interpretation.Unsupported -> null
            is Interpretation.Refused -> Plan(AdaptiveGoal(r.goal, false, command), emptyList(), r.reason)
            is Interpretation.NeedsClarification ->
                Plan(AdaptiveGoal(r.goal, false, command), emptyList(), r.goal.clarifications.joinToString("\n") { it.question })
            is Interpretation.Ready -> {
                audit.record(AuditLevel.INFO, "الهدف التكيفي: ${r.goal.family.name}")
                val p = a.plan(r.goal)
                if (p.blockedReason != null) Plan(AdaptiveGoal(r.goal, false, command), emptyList(), p.blockedReason)
                else Plan(AdaptiveGoal(r.goal, false, command), p.steps.map { placeholder(it.id, it.description) }, null)
            }
        }
    }

    // Display-only: the adaptive layer re-plans against the live screen when it runs, so these never execute.
    private fun placeholder(id: String, description: String) = Step(id, description, Action.ReadScreen)

    suspend fun run(plan: Plan, onProgress: (StepResult) -> Unit = {}): TaskReport {
        val g = plan.goal
        val a = adaptive
        // A blocked adaptive plan (a question, a refusal) still goes through the engine so it is audited like any outcome.
        if (a != null && g is AdaptiveGoal && plan.blockedReason == null) {
            val structured = g.structured
            return when {
                g.resume -> a.resume(onProgress)
                structured != null -> a.run(structured, onProgress)
                else -> TaskReport(g, TaskStatus.NOT_EXECUTED, "طلب تكيفي بلا هدف.", emptyList())
            }
        }
        return ExecutionEngine(device, audit, confirmations, settleDelayMs, onProgress).execute(plan)
    }

    suspend fun handle(command: String, onProgress: (StepResult) -> Unit = {}): TaskReport =
        run(plan(command), onProgress)
}
