package com.venex.core.device

import com.venex.core.intent.TextNormalizer

/**
 * Maps a spoken/typed app name (Arabic or English) to an installed app.
 * Pure logic: the Android layer supplies the installed-app list.
 */
class AppResolver(private val apps: List<InstalledApp>) {

    fun resolve(query: String): AppResolution {
        val q = stripFiller(TextNormalizer.normalize(query))
        if (q.length < 2) return AppResolution.NotFound

        val synonymGroup = SYNONYMS.firstOrNull { group -> group.any { it == q } }

        val scored = apps.mapNotNull { app ->
            val label = TextNormalizer.normalize(app.label)
            val pkg = app.packageName.lowercase()
            val score = when {
                label == q -> 100
                synonymGroup != null && synonymGroup.any { it == label } -> 90
                // Audit fix: match whole package segments only. Substring matching let "calc"
                // or "phone" hit unrelated packages such as "com.example.calcrypto".
                synonymGroup != null && synonymGroup.any { it.length >= 4 && pkg.split('.').contains(it) } -> 80
                label.startsWith(q) -> 60
                q.length >= 3 && label.contains(q) -> 40
                label.length >= 3 && q.contains(label) -> 30
                else -> 0
            }
            if (score > 0) app to score else null
        }
        if (scored.isEmpty()) return AppResolution.NotFound

        val best = scored.maxOf { it.second }
        var top = scored.filter { it.second == best }.map { it.first }
        if (top.size > 1) {
            val system = top.filter { it.isSystem }
            if (system.size == 1) top = system
        }
        return if (top.size == 1) AppResolution.Found(top.first()) else AppResolution.Ambiguous(top)
    }

    private fun stripFiller(q: String): String =
        q.removePrefix("تطبيق ").removePrefix("برنامج ").removePrefix("app ").trim()

    companion object {
        // Entries are already in TextNormalizer's normalized form.
        private val SYNONYMS: List<List<String>> = listOf(
            listOf("الاله الحاسبه", "الحاسبه", "اله حاسبه", "حاسبه", "calculator", "calc"),
            // "calculator" is listed so that package segments named "calculator" also match.
            listOf("الساعه", "ساعه", "clock"),
            listOf("الكاميرا", "كاميرا", "camera"),
            listOf("الاعدادات", "اعدادات", "settings"),
            listOf("الهاتف", "الاتصال", "dialer", "phone"),
            listOf("المعرض", "الصور", "gallery", "photos"),
            // "youtube" is also the package segment (com.google.android.youtube).
            listOf("يوتيوب", "youtube")
        )
    }
}
