package com.venex.core.device

import com.venex.core.model.ScrollDirection
import com.venex.core.model.GlobalKey
import com.venex.core.model.Selector

data class Bounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
}

/** Platform-independent view of one accessibility node. Password field text is never captured. */
data class UiNode(
    val text: String? = null,
    val contentDescription: String? = null,
    val viewId: String? = null,
    val className: String? = null,
    val clickable: Boolean = false,
    val editable: Boolean = false,
    val scrollable: Boolean = false,
    val password: Boolean = false,
    val enabled: Boolean = true,
    val bounds: Bounds? = null,
    // ---- V0.1.8: richer, backward-compatible fields. Every one has a default, so V0.1.7 callers and fakes compile
    // unchanged. A source that cannot provide them leaves the defaults, and the environment model then reports the
    // hierarchy (depth == -1) as UNKNOWN instead of pretending the screen is flat by design.
    val checkable: Boolean = false,
    val checked: Boolean = false,
    val selected: Boolean = false,
    val focused: Boolean = false,
    /** True when [text] is only the field's placeholder (hint), not something typed. */
    val showingHint: Boolean = false,
    /** Depth below the window root (root = 0). -1 = the source did not report the hierarchy. */
    val depth: Int = -1,
    /** Index, in [ScreenSnapshot.nodes], of the nearest captured ancestor. -1 = no captured parent / unknown. */
    val parentIndex: Int = -1
)

data class ScreenSnapshot(val packageName: String?, val nodes: List<UiNode>) {
    /** All visible text and descriptions, for verification and safety checks. */
    fun allText(): List<String> = nodes.flatMap { listOfNotNull(it.text, it.contentDescription) }
}

/** Ways VENEX can act on the device. The router picks the most appropriate available one. */
enum class Channel {
    INTENT,
    DEEP_LINK,
    OFFICIAL_API,
    ACCESSIBILITY,

    /** Reserved: screen understanding via vision. Not implemented in V0.1. */
    VISION
}

data class ActionResult(val success: Boolean, val message: String, val evidence: String? = null) {
    companion object {
        fun ok(message: String, evidence: String? = null) = ActionResult(true, message, evidence)
        fun fail(message: String) = ActionResult(false, message)
    }
}

data class InstalledApp(
    val label: String,
    val packageName: String,
    val isSystem: Boolean = false
)

sealed interface AppResolution {
    data class Found(val app: InstalledApp) : AppResolution
    data class Ambiguous(val candidates: List<InstalledApp>) : AppResolution
    data object NotFound : AppResolution
}

/**
 * The only way the execution engine touches the outside world. The Android module provides the
 * real implementation; tests provide fakes. Implementations must never claim success they did
 * not observe.
 */
interface DeviceController {
    fun capabilities(): Set<Channel>

    suspend fun resolveApp(query: String): AppResolution
    suspend fun launchApp(app: InstalledApp): ActionResult
    suspend fun openDeepLink(uri: String): ActionResult

    /** Null when the screen cannot be read (Accessibility not enabled / no active window). */
    suspend fun snapshot(): ScreenSnapshot?

    suspend fun click(selector: Selector): ActionResult
    suspend fun typeText(selector: Selector?, text: String): ActionResult
    suspend fun scroll(direction: ScrollDirection): ActionResult
    suspend fun press(key: GlobalKey): ActionResult
}

/**
 * Extension point for future vision-based screen understanding (screenshots + model).
 * Intentionally has no implementation in V0.1; Channel.VISION is never advertised.
 */
interface VisualScreenUnderstanding {
    suspend fun describeScreen(): String?
}
