package com.venex.core.adaptive

import com.venex.core.env.TargetSpec
import com.venex.core.goal.StructuredGoal
import com.venex.core.model.GlobalKey
import com.venex.core.model.ScrollDirection
import com.venex.core.safety.RiskAssessment
import com.venex.core.verify.Check
import com.venex.core.verify.VerificationCondition

/**
 * What a step wants done, in terms of the app's ELEMENTS ("the Post button"), never selectors or coordinates. The
 * runner resolves the element against the live screen at the moment it acts, so the plan survives a changed layout.
 */
sealed interface StepIntent {
    data class OpenApp(val appName: String, val packageName: String?) : StepIntent
    data class OpenLink(val uri: String) : StepIntent
    data class Tap(val target: TargetSpec) : StepIntent
    data class Type(val target: TargetSpec, val text: String) : StepIntent
    data class Scroll(val direction: ScrollDirection) : StepIntent
    data class PressKey(val key: GlobalKey) : StepIntent
    data object Observe : StepIntent
}

/** Names of the control roles the experience memory can attach label hints to. */
object Roles {
    const val COMPOSE = "compose"
    const val COMPOSER_FIELD = "composer_field"
    const val SUBMIT_POST = "submit_post"
    const val SEARCH_AFFORDANCE = "search_affordance"
    const val SEARCH_FIELD = "search_field"
    const val SEARCH_SUBMIT = "search_submit"
    const val MESSAGE_FIELD = "message_field"
    const val SEND_BUTTON = "send_button"
    const val DELETE_BUTTON = "delete_button"
    const val CONFIRM_DELETE = "confirm_delete"
}

/** Extra labels learned from earlier VERIFIED successes in the same app. Hints only: the element must still exist on the live screen. */
fun interface LabelHints {
    fun labelsFor(appPackage: String?, role: String): List<String>

    companion object {
        val NONE = LabelHints { _, _ -> emptyList() }
    }
}

data class AdaptiveStep(
    val id: String,
    val description: String,
    val intent: StepIntent,
    /** Memory role of the control this step uses, if any. */
    val role: String? = null,
    /** If ALL hold on the live screen the step is already satisfied and is skipped (this makes plans idempotent). */
    val skipWhen: List<VerificationCondition> = emptyList(),
    /** What must be observable afterwards; judged by the evidence verifier. Empty = the step claims nothing. */
    val expect: List<Check> = emptyList(),
    /** True when the expectation being already true BEFORE the step makes its evidence ambiguous (an identical earlier post). */
    val ambiguousIfAlreadyTrue: Boolean = false,
    /** The step that makes the goal's sensitive effect happen (press "Post", "Send", "Delete"). Never repeated automatically. */
    val commit: Boolean = false,
    /** Risk declared by the plan. The runner ALSO classifies the control it is really about to press and takes the higher. */
    val risk: RiskAssessment = RiskAssessment.SAFE,
    /** Content the approval is bound to (the post/message text). */
    val content: String? = null,
    /** Recipient / item the approval is bound to. */
    val approvalTarget: String? = null,
    val optional: Boolean = false,
    /** The step is the one that is EXPECTED to meet a dialog (a delete confirmation), so a dialog is not an interruption. */
    val expectsDialog: Boolean = false,
    val method: ExecutionMethod? = null
)

data class AdaptivePlan(
    val goal: StructuredGoal,
    val steps: List<AdaptiveStep>,
    /** Non-null when the goal cannot or must not run now; [steps] is then empty. May be a question for the owner. */
    val blockedReason: String? = null,
    val appPackage: String? = null,
    val appLabel: String? = null,
    /** Why each method was chosen or rejected (shown on request; nothing here is hidden). */
    val methodNotes: List<String> = emptyList()
)
