package com.venex.core.safety

import com.venex.core.engine.ConfirmationHandler
import com.venex.core.env.UiStateKind
import com.venex.core.intent.TextNormalizer
import com.venex.core.model.Action
import com.venex.core.model.Step
import java.security.MessageDigest

enum class RiskLevel { LOW, HIGH, BLOCKED }

/** Operations whose effect leaves the device, touches other people or cannot be undone. */
enum class SensitiveCategory(val arabicLabel: String) {
    SEND("إرسال"),
    POST("نشر"),
    DELETE("حذف"),
    PAYMENT("دفع/شراء/تحويل"),
    ACCOUNT_SETTINGS("تغيير إعدادات الحساب"),
    SHARE_DATA("مشاركة بيانات"),
    PERMISSION_GRANT("منح صلاحية")
}

data class RiskAssessment(
    val level: RiskLevel,
    val categories: Set<SensitiveCategory>,
    val reversible: Boolean,
    val affectsOthers: Boolean,
    val reasons: List<String>
) {
    /** Needs the owner's explicit, content-bound approval before it may run. */
    val requiresApproval: Boolean get() = level == RiskLevel.HIGH
    val blocked: Boolean get() = level == RiskLevel.BLOCKED

    companion object {
        val SAFE = RiskAssessment(RiskLevel.LOW, emptySet(), reversible = true, affectsOthers = false, reasons = emptyList())
    }
}

/**
 * Classifies what a control or a goal would DO, from its label and context — not from where the plan came from.
 * Whatever the planner or any model claims, the runner asks this class about the element it is really about to press.
 * Matching is word-based on normalised text so "Send" matches but "Sender name" and "Sandbox" do not.
 */
object ActionRiskClassifier {

    private fun words(vararg w: String): Set<String> = w.map(TextNormalizer::normalize).toSet()
    private fun phrases(vararg p: String): List<String> = p.map(TextNormalizer::normalize)

    private val SEND = words("send", "submit", "reply", "ارسال", "ارسل", "رد", "send")
    private val POST = words("post", "publish", "tweet", "نشر", "انشر", "تغريد", "تدوين", "posting")
    private val DELETE = words("delete", "remove", "erase", "discard", "clear", "حذف", "احذف", "مسح", "امسح", "ازاله")
    private val PAYMENT = words("pay", "buy", "purchase", "checkout", "transfer", "donate", "subscribe", "دفع", "ادفع", "شراء", "اشتر", "اشتري", "تحويل", "تبرع", "اشتراك", "اشترك")
    private val PAYMENT_PHRASES = phrases("place order", "buy now", "pay now", "confirm payment", "تاكيد الطلب", "اطلب الان", "ادفع الان")
    private val SHARE = words("share", "upload", "export", "invite", "مشاركه", "شارك", "رفع", "ارفع", "تصدير", "صدر", "دعوه", "ادع")
    private val ACCOUNT_PHRASES = phrases(
        "change password", "تغيير كلمه المرور", "log out", "logout", "sign out", "تسجيل الخروج", "delete account", "حذف الحساب",
        "deactivate", "تعطيل الحساب", "remove account", "change email", "تغيير البريد", "change phone", "تغيير رقم الهاتف"
    )
    private val PERMISSION_ALLOW = words("allow", "grant", "السماح", "سماح", "اسمح")
    private val PERMISSION_ALLOW_PHRASES = phrases("while using the app", "اثناء استخدام التطبيق", "only this time", "هذه المره فقط")
    private val PERMISSION_DENY = words("deny", "don't", "dont", "رفض", "عدم")

    /** Controls that only OPEN an editor ("Create post", "New message"). They publish and send nothing. */
    private val OPENER_PHRASES = phrases(
        "create post", "new post", "write a post", "add a post", "create a post", "compose", "new message", "write a message", "compose message",
        "منشور جديد", "انشاء منشور", "كتابه منشور", "اضافه منشور", "رساله جديده", "كتابه رساله", "اكتب رساله", "اكتب منشورا"
    )

    private fun tokens(label: String): Set<String> {
        val n = TextNormalizer.normalize(label)
        val raw = n.split(Regex("[^\\p{L}\\p{N}']+")).filter { it.isNotEmpty() }
        // Arabic definite article: "الحذف" should match "حذف".
        return raw.flatMap { t -> if (t.startsWith("ال") && t.length > 3) listOf(t, t.removePrefix("ال")) else listOf(t) }.toSet()
    }

    /** What pressing a control with this [label] would do. [state] adds context (a permission prompt). */
    fun assessLabel(label: String?, state: UiStateKind? = null): RiskAssessment {
        val cats = LinkedHashSet<SensitiveCategory>()
        val reasons = ArrayList<String>()
        if (!label.isNullOrBlank()) {
            val n = TextNormalizer.normalize(label)
            val t = tokens(label)
            fun hit(set: Set<String>) = t.any { it in set }
            if (PAYMENT_PHRASES.any { n.contains(it) } || hit(PAYMENT)) cats += SensitiveCategory.PAYMENT
            if (ACCOUNT_PHRASES.any { n.contains(it) }) cats += SensitiveCategory.ACCOUNT_SETTINGS
            if (hit(DELETE)) cats += SensitiveCategory.DELETE
            val opener = OPENER_PHRASES.any { n.contains(it) }
            if (hit(POST) && !opener) cats += SensitiveCategory.POST
            if (hit(SEND) && !opener) cats += SensitiveCategory.SEND
            if (hit(SHARE)) cats += SensitiveCategory.SHARE_DATA
            if (hit(PERMISSION_ALLOW) || PERMISSION_ALLOW_PHRASES.any { n.contains(it) }) {
                if (!(hit(PERMISSION_DENY))) cats += SensitiveCategory.PERMISSION_GRANT
            }
        }
        if (state == UiStateKind.PERMISSION_PROMPT && SensitiveCategory.PERMISSION_GRANT !in cats && !label.isNullOrBlank()) {
            if (tokens(label).none { it in PERMISSION_DENY }) cats += SensitiveCategory.PERMISSION_GRANT
        }
        if (cats.isEmpty()) return RiskAssessment.SAFE
        cats.forEach { reasons += "«${label ?: ""}» يوحي بعملية ${it.arabicLabel}" }
        return fromCategories(cats, reasons)
    }

    /** Risk of the goal itself (its family), independent of any control label. */
    fun assessCategories(categories: Set<SensitiveCategory>, reason: String): RiskAssessment =
        if (categories.isEmpty()) RiskAssessment.SAFE else fromCategories(categories, listOf(reason))

    private fun fromCategories(cats: Set<SensitiveCategory>, reasons: List<String>): RiskAssessment {
        val level = if (SensitiveCategory.PAYMENT in cats) RiskLevel.BLOCKED else RiskLevel.HIGH
        return RiskAssessment(
            level = level, categories = cats,
            reversible = cats.all { it == SensitiveCategory.PERMISSION_GRANT },
            affectsOthers = cats.any { it == SensitiveCategory.SEND || it == SensitiveCategory.POST || it == SensitiveCategory.SHARE_DATA },
            reasons = reasons
        )
    }
}

/**
 * Everything an approval is bound to. If ANY of these changes the approval no longer applies and a new one is needed:
 * the operation, the goal, the exact content, the app, the account, the target and the data that will be sent.
 * The content is bound by digest so the binding itself never stores the text.
 */
data class ApprovalBinding(
    val operation: String,
    val goalFingerprint: String,
    val contentDigest: String?,
    val appPackage: String?,
    /** The account as observed on screen; null means unknown (and the owner is told it is unknown). */
    val account: String?,
    /** Who or what receives the effect: recipient, item to delete, destination. */
    val target: String?,
    /** The control that will be pressed. */
    val control: String?,
    val dataSummary: String
) {
    fun key(): String = sha256(
        listOf(operation, goalFingerprint, contentDigest, appPackage, account, target, control, dataSummary)
            .joinToString("\u0000") { it ?: "\u0001null" }
    )

    companion object {
        fun sha256(s: String): String =
            MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

        fun digestOf(content: String?): String? = content?.let { sha256(it) }
    }
}

/** What the owner is shown. [lines] state each bound element, with "غير معروف" where something could not be observed. */
data class ApprovalRequest(val binding: ApprovalBinding, val summary: String, val lines: List<String>)

fun interface ApprovalHandler {
    suspend fun request(request: ApprovalRequest): Boolean
}

/** Never approves. The default: approval must be a conscious wiring choice. */
object DenyAllApprovals : ApprovalHandler {
    override suspend fun request(request: ApprovalRequest): Boolean = false
}

/** Reuses the existing confirmation dialog: the request summary is shown as the step description. */
class ConfirmationApprovalHandler(private val confirmations: ConfirmationHandler) : ApprovalHandler {
    override suspend fun request(request: ApprovalRequest): Boolean = confirmations.confirm(
        Step(id = "approval", description = request.summary, action = Action.ReadScreen, needsConfirmation = true)
    )
}

/**
 * Single-use, expiring grants keyed by [ApprovalBinding.key]. A grant for one binding can never satisfy another, so a
 * changed text, recipient, app or account needs a fresh approval, and an approval cannot be replayed (no double send).
 */
class ApprovalLedger(private val clock: () -> Long = System::currentTimeMillis, private val ttlMs: Long = 120_000) {
    private val grants = HashMap<String, Long>()

    @Synchronized
    fun grant(binding: ApprovalBinding) {
        grants[binding.key()] = clock() + ttlMs
    }

    /** Atomically checks and consumes the grant for exactly this binding. */
    @Synchronized
    fun consume(binding: ApprovalBinding): Boolean {
        val exp = grants.remove(binding.key()) ?: return false
        return clock() <= exp
    }

    @Synchronized
    fun revokeAll() = grants.clear()

    @Synchronized
    fun pending(): Int = grants.size
}

sealed interface ApprovalOutcome {
    data class Approved(val reusedGrant: Boolean) : ApprovalOutcome
    data object Denied : ApprovalOutcome
}

class ApprovalGate(private val handler: ApprovalHandler, val ledger: ApprovalLedger) {
    /** A matching unexpired grant is consumed; otherwise the owner is asked. A "no" is final for this request. */
    suspend fun authorize(request: ApprovalRequest): ApprovalOutcome {
        if (ledger.consume(request.binding)) return ApprovalOutcome.Approved(reusedGrant = true)
        return if (handler.request(request)) ApprovalOutcome.Approved(reusedGrant = false) else ApprovalOutcome.Denied
    }
}

object ApprovalRequests {
    private const val SHOWN_CONTENT_CHARS = 200

    /** Builds the request from facts that were OBSERVED right before the action (never from the plan alone). */
    fun build(
        categories: Set<SensitiveCategory>,
        goalFingerprint: String,
        content: String?,
        appPackage: String?,
        appLabel: String?,
        account: String?,
        target: String?,
        control: String?
    ): ApprovalRequest {
        val op = categories.map { it.name }.sorted().joinToString("+")
        val dataSummary = when {
            content != null -> "نص من ${content.length} حرفاً"
            else -> "لا نص؛ نقرة على عنصر"
        }
        val binding = ApprovalBinding(op, goalFingerprint, ApprovalBinding.digestOf(content), appPackage, account, target, control, dataSummary)
        val opLabel = categories.joinToString(" + ") { it.arabicLabel }
        val shown = content?.let { if (it.length > SHOWN_CONTENT_CHARS) it.take(SHOWN_CONTENT_CHARS) + "…" else it }
        val lines = buildList {
            add("العملية: $opLabel")
            add("التطبيق: ${appLabel ?: appPackage ?: "غير معروف"}")
            add("الحساب: ${account ?: "غير معروف"}")
            add("الجهة/الهدف: ${target ?: "غير محدد"}")
            add("الزر الذي سأضغطه: ${control ?: "غير معروف"}")
            add(if (content != null && shown != null) "المحتوى (${content.length} حرفاً): «$shown»" else "المحتوى: لا يوجد نص")
        }
        val summary = "$opLabel — " + lines.drop(1).joinToString(" | ")
        return ApprovalRequest(binding, summary, lines)
    }
}
