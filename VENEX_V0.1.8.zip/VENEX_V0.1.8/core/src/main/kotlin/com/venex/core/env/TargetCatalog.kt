package com.venex.core.env

/**
 * Generic vocabularies for the controls that nearly every app labels in similar words ("Search", "Post", "Send",
 * "بحث", "نشر"...). These are NOT per-app integrations: there is no package name or layout of a specific app here.
 * A spec only finds an element when the live screen really contains such a label or view id; otherwise the plan
 * reports "not found" and recovers or asks the owner.
 */
object TargetCatalog {

    val SEARCH_AFFORDANCE = TargetSpec(
        "زر/أيقونة البحث",
        labels = listOf("Search", "بحث", "ابحث", "Find", "بحث…", "Search…"),
        idHints = listOf("search"),
        kind = TargetKind.CLICKABLE
    )

    val SEARCH_FIELD = TargetSpec(
        "حقل البحث",
        labels = listOf("Search", "بحث", "ابحث", "Search…", "بحث…", "ابحث…"),
        labelContains = listOf("search", "بحث"),
        idHints = listOf("search", "query"),
        kind = TargetKind.INPUT
    )

    val SEARCH_SUBMIT = TargetSpec(
        "زر تنفيذ البحث",
        labels = listOf("Search", "بحث", "ابحث", "Go", "Submit search"),
        idHints = listOf("search_go", "search_btn", "search_button", "submit"),
        kind = TargetKind.CLICKABLE
    )

    val COMPOSE = TargetSpec(
        "زر إنشاء منشور",
        labels = listOf(
            "Create post", "New post", "Compose", "Write a post", "Tweet", "What's on your mind?", "Write something...",
            "منشور جديد", "إنشاء منشور", "انشاء منشور", "كتابة منشور", "ما الذي يدور في ذهنك؟", "بماذا تفكر؟", "+"
        ),
        labelContains = listOf("new post", "compose", "create post", "what's on your mind", "منشور", "ذهنك"),
        idHints = listOf("compose", "fab", "new_post", "create_post", "composer"),
        kind = TargetKind.CLICKABLE
    )

    val COMPOSER_FIELD = TargetSpec(
        "حقل كتابة المنشور",
        labelContains = listOf("what's on your mind", "write", "say something", "منشور", "اكتب", "ذهنك"),
        idHints = listOf("compose", "post", "status", "body"),
        kind = TargetKind.INPUT
    )

    val SUBMIT_POST = TargetSpec(
        "زر النشر",
        labels = listOf("Post", "Publish", "Tweet", "Share now", "Share", "نشر", "انشر", "نشر الآن", "مشاركة", "شارك"),
        idHints = listOf("post_button", "publish", "submit_post"),
        kind = TargetKind.CLICKABLE
    )

    val MESSAGE_FIELD = TargetSpec(
        "حقل كتابة الرسالة",
        labels = listOf("Message", "Type a message", "Write a message", "رسالة", "اكتب رسالة"),
        labelContains = listOf("message", "رساله", "رسالة"),
        idHints = listOf("message", "input", "compose", "chat"),
        kind = TargetKind.INPUT
    )

    val SEND_BUTTON = TargetSpec(
        "زر الإرسال",
        labels = listOf("Send", "Send message", "إرسال", "ارسال", "ارسل"),
        idHints = listOf("send"),
        kind = TargetKind.CLICKABLE
    )

    val DELETE_BUTTON = TargetSpec(
        "زر الحذف",
        labels = listOf("Delete", "Remove", "Trash", "حذف", "إزالة", "سلة المهملات"),
        idHints = listOf("delete", "trash", "remove"),
        kind = TargetKind.CLICKABLE
    )

    val CONFIRM_DELETE = TargetSpec(
        "تأكيد الحذف",
        labels = listOf("Delete", "حذف", "Confirm", "تأكيد", "OK", "موافق", "Yes", "نعم"),
        idHints = listOf("button1", "confirm", "positive"),
        kind = TargetKind.CLICKABLE
    )

    /** Buttons that close an unexpected popup without granting, accepting or buying anything. */
    val SAFE_DISMISS = TargetSpec(
        "زر إغلاق النافذة",
        labels = listOf("Close", "Dismiss", "Not now", "Later", "No thanks", "Skip", "Cancel", "إغلاق", "إلغاء", "لاحقا", "لاحقاً", "ليس الآن", "تخطي", "لا شكرا", "لا، شكراً"),
        idHints = listOf("close", "dismiss", "not_now", "skip"),
        kind = TargetKind.CLICKABLE
    )

    /** Words that identify a "not now / cancel" choice, used to avoid pressing the other button of a dialog. */
    val SAFE_DISMISS_WORDS = SAFE_DISMISS.labels.map(::normLabel).toSet()
}
