package com.venex.core.adaptive

import com.venex.core.audit.AuditLevel
import com.venex.core.audit.AuditLog
import com.venex.core.device.DeviceController
import com.venex.core.engine.ExecutionEngine
import com.venex.core.env.EnvironmentModel
import com.venex.core.env.EnvironmentUnderstandingEngine
import com.venex.core.env.ScreenDiffer
import com.venex.core.env.TargetResolution
import com.venex.core.env.TargetResolver
import com.venex.core.goal.GoalFamily
import com.venex.core.goal.StructuredGoal
import com.venex.core.memory.ExperienceMemory
import com.venex.core.model.Action
import com.venex.core.model.Step
import com.venex.core.model.StepStatus
import com.venex.core.safety.ActionRiskClassifier
import com.venex.core.safety.ApprovalGate
import com.venex.core.safety.ApprovalOutcome
import com.venex.core.safety.ApprovalRequests
import com.venex.core.safety.RiskAssessment
import com.venex.core.safety.RiskLevel
import com.venex.core.safety.SensitiveCategory
import com.venex.core.verify.Check
import com.venex.core.verify.CheckResult
import com.venex.core.verify.EvidenceInput
import com.venex.core.verify.EvidenceVerdict
import com.venex.core.verify.EvidenceVerifier
import com.venex.core.verify.TextScope
import com.venex.core.verify.VerificationCondition
import com.venex.core.verify.VerificationReport
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.cancellation.CancellationException
import kotlin.coroutines.coroutineContext

enum class StepOutcome { DONE, SKIPPED, FAILED, NEEDS_OWNER, DENIED }

data class AdaptiveStepResult(
    val stepId: String,
    val description: String,
    val outcome: StepOutcome,
    val message: String,
    /** What the evidence verifier concluded for this step; null when the step claims nothing. */
    val verdict: EvidenceVerdict? = null,
    val evidence: List<String> = emptyList(),
    val recoveries: Int = 0
)

enum class RunStatus { COMPLETED, NEEDS_OWNER, CANCELLED, FAILED, NOT_EXECUTED }

data class AdaptiveResult(
    val goal: StructuredGoal,
    val taskId: String,
    val status: RunStatus,
    /** The final, goal-level verdict. Null when the run did not get as far as verifying. */
    val verdict: EvidenceVerdict?,
    val report: VerificationReport?,
    val steps: List<AdaptiveStepResult>,
    val summary: String,
    val executedActions: Int
)

/** Pause / resume / cancel for one running task. Checked between steps, never in the middle of a press. */
class TaskControl {
    @Volatile var cancelled = false
        private set
    @Volatile private var gate: CompletableDeferred<Unit>? = null

    fun cancel() { cancelled = true; gate?.complete(Unit) }
    fun pause() { if (gate == null) gate = CompletableDeferred() }
    fun resume() { gate?.complete(Unit); gate = null }
    val paused: Boolean get() = gate != null && !cancelled

    /** Returns false when the task was cancelled. Suspends while paused. */
    suspend fun checkpoint(onPause: () -> Unit = {}): Boolean {
        coroutineContext.ensureActive()
        val g = gate
        if (g != null && !cancelled) { onPause(); g.await() }
        coroutineContext.ensureActive()
        return !cancelled
    }
}

/**
 * Runs an [AdaptivePlan] against the live device: Observe → Understand → Plan(step) → Act → Adapt → Verify → Learn,
 * one step at a time. Rules that hold for every step:
 *  - it looks at the screen right before acting and resolves the element from that screen (no stale selectors);
 *  - every action goes through [ExecutionEngine.executeStep], i.e. V0.1.7's safety, channel routing and audit;
 *  - the control about to be pressed is classified by its REAL label; a sensitive one needs an approval bound to this
 *    operation, content, app and target, and a payment-like control is never pressed;
 *  - a sensitive step is written down before it is pressed and is never repeated automatically;
 *  - recovery is bounded ([RunLimits]) and only takes harmless steps (wait, dismiss with "Not now", scroll, re-open);
 *  - CAPTCHA, login, permission prompts and opaque screens stop the task and hand it back to the owner;
 *  - success is whatever [EvidenceVerifier] can show, not what the step reported.
 */
class AdaptiveRunner(
    private val device: DeviceController,
    private val audit: AuditLog,
    private val engine: ExecutionEngine,
    private val understanding: EnvironmentUnderstandingEngine,
    private val approvals: ApprovalGate,
    private val store: TaskStateStore,
    private val memory: ExperienceMemory? = null,
    private val limits: RunLimits = RunLimits(),
    private val clock: () -> Long = System::currentTimeMillis,
    private val settleDelayMs: Long = 150
) {

    private class Flow(val result: AdaptiveStepResult, val stop: Boolean, val runStatus: RunStatus? = null, val phase: TaskPhase? = null)

    suspend fun run(
        plan: AdaptivePlan,
        taskId: String,
        resumeFrom: TaskState? = null,
        control: TaskControl = TaskControl(),
        onStep: (AdaptiveStepResult) -> Unit = {}
    ): AdaptiveResult {
        val goal = plan.goal
        plan.blockedReason?.let { return AdaptiveResult(goal, taskId, RunStatus.NOT_EXECUTED, null, null, emptyList(), it, 0) }

        val started = clock()
        val ledger = RecoveryLedger(limits)
        val results = ArrayList<AdaptiveStepResult>()
        var executed = 0
        // Actions an earlier attempt of THIS task already carried out (a resumed task did act, even if this run presses nothing).
        val priorActions = resumeFrom?.steps?.values?.count { it == StepMark.DONE || it == StepMark.SENSITIVE_STARTED } ?: 0
        var launched: String? = null
        var state = resumeFrom?.copy(phase = TaskPhase.RUNNING, updatedAtMillis = started)
            ?: TaskState(taskId, goal.family, goal.slots, plan.appPackage, TaskPhase.RUNNING, emptyMap(), null, started, started)
        store.save(state)
        audit.record(AuditLevel.INFO, "بدء مهمة تكيفية (${goal.family.name}) — ${plan.steps.size} خطوة")

        fun mark(id: String, m: StepMark) {
            state = state.copy(steps = state.steps + (id to m), updatedAtMillis = clock())
            store.save(state)
        }
        fun emit(r: AdaptiveStepResult) {
            results += r
            try { onStep(r) } catch (_: Exception) { /* a UI listener must not affect execution */ }
        }
        fun finish(status: RunStatus, phase: TaskPhase, summary: String, verdict: EvidenceVerdict? = null, report: VerificationReport? = null): AdaptiveResult {
            state = state.copy(phase = phase, note = summary.take(200), updatedAtMillis = clock())
            store.save(state)
            audit.record(if (status == RunStatus.COMPLETED && verdict == EvidenceVerdict.VERIFIED) AuditLevel.INFO else AuditLevel.WARN, "انتهت المهمة التكيفية: $status — $summary")
            return AdaptiveResult(goal, taskId, status, verdict, report, results, summary, executed + priorActions)
        }

        try {
            val initial = understanding.refresh().model
            var lastModel = initial

            for (step in plan.steps) {
                if (!control.checkpoint { state = state.copy(phase = TaskPhase.PAUSED, updatedAtMillis = clock()); store.save(state) }) {
                    return finish(RunStatus.CANCELLED, TaskPhase.CANCELLED, "أُلغيت المهمة بناءً على طلبك.")
                }
                if (state.phase == TaskPhase.PAUSED) { state = state.copy(phase = TaskPhase.RUNNING); store.save(state) }
                if (clock() - started > limits.maxDurationMs) {
                    return finish(RunStatus.FAILED, TaskPhase.FAILED, "تجاوزتُ المدة القصوى للمهمة (${limits.maxDurationMs / 1000} ثانية) فتوقفت.")
                }
                if (executed >= limits.maxStepsExecuted) {
                    return finish(RunStatus.FAILED, TaskPhase.FAILED, "تجاوزتُ العدد الأقصى للإجراءات (${limits.maxStepsExecuted}) فتوقفت.")
                }

                val prior = state.steps[step.id]
                if (prior == StepMark.DONE || prior == StepMark.SKIPPED) {
                    emit(AdaptiveStepResult(step.id, step.description, StepOutcome.SKIPPED, "تمّت في محاولة سابقة"))
                    continue
                }

                val flow = if (prior == StepMark.SENSITIVE_STARTED) {
                    verifyInterrupted(step, launched)
                } else {
                    runStep(plan, step, goal, ledger, control, launched, ::mark) { n -> executed += n; if (step.intent is StepIntent.OpenApp) launched = plan.appPackage }
                }
                lastModel = understanding.current ?: lastModel
                emit(flow.result)
                if (flow.stop) {
                    val summary = flow.result.message
                    return finish(flow.runStatus ?: RunStatus.FAILED, flow.phase ?: TaskPhase.FAILED, summary)
                }
            }

            // ---- goal-level verification, against the state before the task started
            if (goal.family == GoalFamily.DESCRIBE_SCREEN) {
                val m = understanding.refresh().model
                return finish(RunStatus.COMPLETED, TaskPhase.DONE, understanding.describe(m), EvidenceVerdict.VERIFIED)
            }
            val (finalModel, stable) = settle()
            val report = EvidenceVerifier.verify(
                goal.verification,
                EvidenceInput(
                    commandSent = true, actionExecuted = executed + priorActions > 0, before = initial, after = finalModel,
                    diff = ScreenDiffer.diff(initial, finalModel), stable = stable, launchedPackage = launched ?: plan.appPackage
                )
            )
            var verdict = report.verdict
            val notes = ArrayList<String>(report.limitations)
            if (executed + priorActions == 0) {
                verdict = EvidenceVerdict.UNVERIFIED
                notes += "لم أنفّذ أي إجراء: كانت كل الخطوات متحققة أصلاً على الشاشة. لا أنسب النتيجة إلى عمل قمتُ به."
            } else if (verdict == EvidenceVerdict.VERIFIED) {
                val before = EvidenceVerifier.verify(goal.verification, EvidenceInput(true, true, null, initial, null, true, plan.appPackage))
                val req = goal.verification.indices.filter { goal.verification[it].required }
                if (req.isNotEmpty() && req.all { before.evidence.getOrNull(it)?.result == CheckResult.SATISFIED }) {
                    verdict = EvidenceVerdict.PARTIALLY_VERIFIED
                    notes += "كانت شروط التحقق متحققة قبل بدء المهمة، فلا أستطيع نسب النتيجة إلى إجراءاتي بيقين."
                }
            }
            val summary = buildString {
                append(
                    when (verdict) {
                        EvidenceVerdict.VERIFIED -> "تحقق الهدف بدليل مرصود. "
                        EvidenceVerdict.PARTIALLY_VERIFIED -> "تحقق جزء من الهدف بدليل مرصود، والباقي لا أستطيع تأكيده. "
                        EvidenceVerdict.UNVERIFIED -> "نُفّذت الخطوات لكنني لا أستطيع تأكيد تحقق الهدف. "
                        EvidenceVerdict.FAILED -> "لم يتحقق الهدف. "
                    }
                )
                append(report.summary)
                notes.distinct().forEach { append(" • ").append(it) }
            }.trim()
            val phase = if (verdict == EvidenceVerdict.FAILED) TaskPhase.FAILED else TaskPhase.DONE
            learn(plan, results, verdict)
            return finish(if (verdict == EvidenceVerdict.FAILED) RunStatus.FAILED else RunStatus.COMPLETED, phase, summary, verdict, report)
        } catch (e: CancellationException) {
            state = state.copy(phase = TaskPhase.CANCELLED, note = "أُلغيت", updatedAtMillis = clock())
            store.save(state)
            audit.record(AuditLevel.WARN, "أُلغيت المهمة التكيفية")
            throw e
        }
    }

    // ---------------------------------------------------------------------------------------------------------------

    private suspend fun runStep(
        plan: AdaptivePlan,
        step: AdaptiveStep,
        goal: StructuredGoal,
        ledger: RecoveryLedger,
        control: TaskControl,
        launchedIn: String?,
        mark: (String, StepMark) -> Unit,
        executedDelta: (Int) -> Unit
    ): Flow {
        var launched = launchedIn
        var waitPolls = 0
        var sensitiveStarted = false

        fun result(o: StepOutcome, msg: String, v: EvidenceVerdict? = null, ev: List<String> = emptyList()) =
            AdaptiveStepResult(step.id, step.description, o, msg, v, ev, ledger.used(step.id))
        fun stop(o: StepOutcome, msg: String, status: RunStatus, phase: TaskPhase, mk: StepMark? = null): Flow {
            if (mk != null) mark(step.id, mk)
            return Flow(result(o, msg), true, status, phase)
        }

        while (true) {
            if (!control.checkpoint()) return stop(StepOutcome.FAILED, "أُلغيت المهمة بناءً على طلبك.", RunStatus.CANCELLED, TaskPhase.CANCELLED)

            val model = understanding.refresh().model

            // ---- 1. what is the screen, and is it fit for this step?
            when (val a = StateMonitor.assess(model, step, plan.appPackage)) {
                StateAssessment.Ready -> Unit
                StateAssessment.Loading -> {
                    if (++waitPolls > limits.maxWaitPolls) {
                        return stop(StepOutcome.NEEDS_OWNER, "الشاشة ما زالت تُحمَّل ولا تستقر. أعد المحاولة بعد أن تكتمل.", RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER)
                    }
                    delay(limits.pollIntervalMs)
                    continue
                }
                is StateAssessment.Blocked ->
                    return stop(StepOutcome.NEEDS_OWNER, a.message, RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER)
                is StateAssessment.Interrupted -> {
                    when (val r = RecoveryEngine.decide(step, false, Situation.Interrupted(a.dismiss), ledger)) {
                        is Recovery.Dismiss -> {
                            audit.record(AuditLevel.WARN, "نافذة غير متوقعة: أغلقها بزر «${r.element.label}»", step.id)
                            val sel = r.element.selector
                            if (sel != null) engine.executeStep(Step("dismiss-${step.id}", "إغلاق نافذة غير متوقعة", Action.Click(sel)))
                            delay(settleDelayMs)
                            continue
                        }
                        is Recovery.AskOwner -> return stop(StepOutcome.NEEDS_OWNER, r.reason, RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER)
                        else -> return stop(StepOutcome.FAILED, "نافذة غير متوقعة: ${a.dialogText}", RunStatus.FAILED, TaskPhase.FAILED)
                    }
                }
                is StateAssessment.WrongApp -> {
                    val open = plan.steps.firstOrNull { it.intent is StepIntent.OpenApp }?.intent as? StepIntent.OpenApp
                    when (val r = RecoveryEngine.decide(step, false, Situation.WrongApp, ledger)) {
                        Recovery.ReopenApp -> if (open != null) {
                            audit.record(AuditLevel.WARN, "التطبيق ليس في المقدمة (${a.actual}); أعيد فتحه", step.id)
                            engine.executeStep(Step("reopen-${step.id}", "إعادة فتح «${open.appName}»", Action.OpenApp(open.appName)))
                            delay(settleDelayMs)
                            continue
                        } else return stop(StepOutcome.NEEDS_OWNER, "خرجتُ من التطبيق (الظاهر الآن ${a.actual ?: "غير معروف"}). افتحه بنفسك ثم قل لي «استأنف».", RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER)
                        is Recovery.AskOwner -> return stop(StepOutcome.NEEDS_OWNER, r.reason, RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER)
                        else -> return stop(StepOutcome.FAILED, "التطبيق المطلوب ليس في المقدمة.", RunStatus.FAILED, TaskPhase.FAILED)
                    }
                }
            }

            // ---- 2. already satisfied? (this is what makes a plan safe to run again)
            if (step.skipWhen.isNotEmpty() && step.skipWhen.all { satisfied(it, model, launched ?: plan.appPackage) }) {
                mark(step.id, StepMark.SKIPPED)
                return Flow(result(StepOutcome.SKIPPED, "متحققة أصلاً على الشاشة؛ لا حاجة لتنفيذها"), false)
            }

            // ---- 3. find the element on THIS screen
            val intent = step.intent
            var action: Action? = null
            var controlLabel: String? = null
            when (intent) {
                is StepIntent.OpenApp -> action = Action.OpenApp(intent.appName)
                is StepIntent.OpenLink -> action = Action.OpenDeepLink(intent.uri)
                is StepIntent.Scroll -> action = Action.Scroll(intent.direction)
                is StepIntent.PressKey -> action = Action.Press(intent.key)
                StepIntent.Observe -> action = Action.ReadScreen
                is StepIntent.Tap, is StepIntent.Type -> {
                    val spec = if (intent is StepIntent.Tap) intent.target else (intent as StepIntent.Type).target
                    val screen = model.screen ?: return stop(StepOutcome.NEEDS_OWNER, "لا أستطيع قراءة الشاشة الآن.", RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER)
                    when (val r = TargetResolver.resolve(spec, screen)) {
                        is TargetResolution.Found -> {
                            controlLabel = r.element.label ?: spec.description
                            action = if (intent is StepIntent.Tap) {
                                val sel = r.selector ?: return stop(StepOutcome.FAILED, "العنصر «${spec.description}» لا يمكن تحديده دون إحداثيات.", RunStatus.FAILED, TaskPhase.FAILED)
                                Action.Click(sel)
                            } else Action.TypeText(r.selector, (intent as StepIntent.Type).text)
                        }
                        is TargetResolution.Ambiguous -> {
                            val labels = r.candidates.map { it.label ?: "بلا اسم" }
                            val rec = RecoveryEngine.decide(step, false, Situation.Ambiguous(labels), ledger) as Recovery.AskOwner
                            return stop(StepOutcome.NEEDS_OWNER, rec.reason, RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER)
                        }
                        is TargetResolution.NotAddressable ->
                            return stop(StepOutcome.FAILED, "وجدتُ «${spec.description}» لكن لا أستطيع الوصول إليه إلا بالإحداثيات، ولا أتصرف بها وحدها.", RunStatus.FAILED, TaskPhase.FAILED)
                        TargetResolution.NotFound -> {
                            if (step.optional) {
                                mark(step.id, StepMark.SKIPPED)
                                return Flow(result(StepOutcome.SKIPPED, "لم يظهر «${spec.description}»؛ خطوة اختيارية فتخطّيتها"), false)
                            }
                            when (val rec = RecoveryEngine.decide(step, false, Situation.NotFound(spec.description), ledger)) {
                                is Recovery.ScrollToFind -> {
                                    audit.record(AuditLevel.INFO, "لم أجد «${spec.description}»؛ أمرّر الشاشة للبحث", step.id)
                                    engine.executeStep(Step("scroll-${step.id}", "تمرير للبحث عن «${spec.description}»", Action.Scroll(rec.direction)))
                                    delay(settleDelayMs)
                                    continue
                                }
                                is Recovery.AskOwner -> {
                                    memoryMiss(plan, step)
                                    return stop(StepOutcome.NEEDS_OWNER, rec.reason, RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER)
                                }
                                else -> return stop(StepOutcome.FAILED, "لم أجد «${spec.description}».", RunStatus.FAILED, TaskPhase.FAILED)
                            }
                        }
                    }
                }
            }
            val act: Action = action

            // ---- 4. the REAL risk of what is about to be pressed
            var sensitive = false
            if (intent is StepIntent.Tap) {
                val real = ActionRiskClassifier.assessLabel(controlLabel, model.state.kind)
                val eff = maxRisk(step.risk, real)
                if (eff.blocked) {
                    audit.record(AuditLevel.WARN, "رفضتُ الضغط على «$controlLabel»: عملية دفع/شراء محظورة", step.id)
                    return stop(StepOutcome.FAILED, "رفضتُ الضغط على «$controlLabel» لأنه يوحي بعملية دفع أو شراء أو تحويل، وهي محظورة في VENEX.", RunStatus.FAILED, TaskPhase.FAILED, StepMark.FAILED)
                }
                sensitive = eff.requiresApproval || step.commit
                if (sensitive) {
                    val cats = if (eff.categories.isNotEmpty()) eff.categories else goal.risk.categories
                    val targetNote = step.approvalTarget?.let { t ->
                        if (SensitiveCategory.SEND in cats) {
                            val seen = satisfied(VerificationCondition.TextVisible(t, TextScope.NON_INPUT), model, launched)
                            "$t " + if (seen) "(ظاهر على الشاشة)" else "(لم أرصده على الشاشة)"
                        } else t
                    }
                    val request = ApprovalRequests.build(
                        categories = cats, goalFingerprint = goal.fingerprint, content = step.content,
                        appPackage = model.packageName, appLabel = model.app?.label, account = null,
                        target = targetNote, control = controlLabel
                    )
                    when (approvals.authorize(request)) {
                        ApprovalOutcome.Denied -> {
                            audit.record(AuditLevel.INFO, "لم يوافق المالك على الخطوة الحساسة", step.id)
                            return Flow(result(StepOutcome.DENIED, "لم توافق على «${step.description}»، فلم أنفّذها."), true, RunStatus.CANCELLED, TaskPhase.CANCELLED)
                        }
                        is ApprovalOutcome.Approved -> audit.record(AuditLevel.INFO, "وافق المالك على خطوة حساسة مرتبطة بالعملية", step.id)
                    }
                    // Written BEFORE the press: if the process dies now, a resumed task knows it may have happened.
                    mark(step.id, StepMark.SENSITIVE_STARTED)
                    sensitiveStarted = true
                }
            }

            // ---- 5. act, through the same engine and safety as V0.1.7
            val (res, _) = engine.executeStep(Step(step.id, step.description, act, maxAttempts = 1, expectation = null))
            if (res.status == StepStatus.FAILED) {
                if (sensitiveStarted) mark(step.id, StepMark.FAILED) // nothing was pressed: the engine refused or the device reported failure
                when (val rec = RecoveryEngine.decide(step, false, Situation.NotExecuted(res.message), ledger)) {
                    Recovery.RetryStep -> { sensitiveStarted = false; delay(settleDelayMs); continue }
                    else -> {
                        if (step.optional) return Flow(result(StepOutcome.SKIPPED, "خطوة اختيارية لم تُنفَّذ: ${res.message}"), false)
                        val why = (rec as? Recovery.GiveUp)?.reason ?: res.message
                        return stop(StepOutcome.FAILED, why, RunStatus.FAILED, TaskPhase.FAILED, StepMark.FAILED)
                    }
                }
            }
            executedDelta(1)
            if (intent is StepIntent.OpenApp) launched = plan.appPackage
            audit.record(AuditLevel.INFO, "نُفِّذت الخطوة: ${step.description}", step.id)
            if (intent == StepIntent.Observe) { mark(step.id, StepMark.DONE); return Flow(result(StepOutcome.DONE, "قُرئت الشاشة"), false) }

            // ---- 6. look again and judge by evidence
            val (after, stable) = settle()
            if (step.expect.isEmpty()) {
                mark(step.id, StepMark.DONE)
                return Flow(result(StepOutcome.DONE, "نُفِّذت (لا تدّعي نتيجة محدّدة)"), false)
            }
            val report = EvidenceVerifier.verify(
                step.expect,
                EvidenceInput(true, true, model, after, ScreenDiffer.diff(model, after), stable, launched ?: plan.appPackage)
            )
            var verdict = report.verdict
            val notes = ArrayList(report.limitations)
            if (step.ambiguousIfAlreadyTrue && verdict == EvidenceVerdict.VERIFIED &&
                step.expect.filter { it.required }.all { satisfied(it.condition, model, launched ?: plan.appPackage) }
            ) {
                verdict = EvidenceVerdict.PARTIALLY_VERIFIED
                notes += "النتيجة المتوقعة كانت ظاهرة أصلاً قبل الضغط، فالدليل ملتبس."
            }
            val ev = report.evidence.map { "${it.condition}: ${it.result.name} — ${it.detail}" } + notes

            return when (verdict) {
                EvidenceVerdict.FAILED -> {
                    val rec = RecoveryEngine.decide(step, sensitive, Situation.ExecutedButContradicted(report.summary), ledger)
                    if (rec == Recovery.RetryStep) {
                        audit.record(AuditLevel.WARN, "لم تتحقق نتيجة الخطوة؛ أعيد المحاولة مرة (آمنة لأنها تتحقق من نفسها)", step.id)
                        continue
                    }
                    if (step.optional) Flow(result(StepOutcome.SKIPPED, "خطوة اختيارية لم تُثمر: ${report.summary}", verdict, ev), false)
                    else stop(StepOutcome.FAILED, (rec as? Recovery.GiveUp)?.reason ?: report.summary, RunStatus.FAILED, TaskPhase.FAILED, if (sensitive) StepMark.SENSITIVE_STARTED else StepMark.FAILED)
                }
                else -> {
                    mark(step.id, StepMark.DONE)
                    if (verdict == EvidenceVerdict.VERIFIED) rememberSuccess(plan, step, controlLabel)
                    Flow(result(StepOutcome.DONE, report.summary, verdict, ev), false)
                }
            }
        }
    }

    /**
     * A sensitive step whose press may have happened before the process stopped. It is NOT pressed again: only
     * the evidence on screen decides, and without it the owner is asked.
     */
    private suspend fun verifyInterrupted(step: AdaptiveStep, launched: String?): Flow {
        val model = understanding.refresh().model
        val report = EvidenceVerifier.verify(step.expect, EvidenceInput(true, true, null, model, null, true, launched))
        val ok = step.expect.isNotEmpty() && report.verdict == EvidenceVerdict.VERIFIED
        return if (ok) {
            Flow(AdaptiveStepResult(step.id, step.description, StepOutcome.DONE, "رُصد أثر الخطوة الحساسة على الشاشة؛ لم أكرّرها.", report.verdict, listOf(report.summary)), false)
        } else {
            Flow(
                AdaptiveStepResult(
                    step.id, step.description, StepOutcome.NEEDS_OWNER,
                    "ربما نُفِّذت خطوة حساسة («${step.description}») قبل أن تتوقف المهمة ولم أرصد نتيجتها. لن أكرّرها تلقائياً؛ تحقق بنفسك ثم أخبرني كيف أتابع.",
                    report.verdict, listOf(report.summary)
                ),
                true, RunStatus.NEEDS_OWNER, TaskPhase.WAITING_OWNER
            )
        }
    }

    // ---------------------------------------------------------------------------------------------------------------

    private fun satisfied(c: VerificationCondition, model: EnvironmentModel, launched: String?): Boolean =
        EvidenceVerifier.verify(listOf(Check(c)), EvidenceInput(true, true, null, model, null, true, launched))
            .evidence.firstOrNull()?.result == CheckResult.SATISFIED

    /** Reads the screen until two consecutive readings agree (or a few tries pass). */
    private suspend fun settle(): Pair<EnvironmentModel, Boolean> {
        var prev: String? = null
        var model = understanding.current ?: understanding.refresh().model
        repeat(5) {
            delay(settleDelayMs)
            model = understanding.refresh().model
            val id = model.screen?.contentId
            if (id != null && id == prev) return model to true
            prev = id
        }
        return model to false
    }

    private fun maxRisk(a: RiskAssessment, b: RiskAssessment): RiskAssessment {
        val level = if (a.level.ordinal >= b.level.ordinal) a.level else b.level
        return RiskAssessment(level, a.categories + b.categories, a.reversible && b.reversible, a.affectsOthers || b.affectsOthers, a.reasons + b.reasons)
    }

    private fun rememberSuccess(plan: AdaptivePlan, step: AdaptiveStep, label: String?) {
        val role = step.role ?: return
        // Only the names of buttons are learned. A field's "label" can be the text someone typed into it, so fields never are.
        if (step.intent !is StepIntent.Tap) return
        try { memory?.recordSuccess(plan.appPackage, role, label) } catch (_: Exception) { /* learning must never break a task */ }
    }

    private fun memoryMiss(plan: AdaptivePlan, step: AdaptiveStep) {
        val role = step.role ?: return
        val mem = memory ?: return
        try { mem.labelsFor(plan.appPackage, role).forEach { mem.recordFailure(plan.appPackage, role, it) } } catch (_: Exception) { }
    }

    /** After a finished task: nothing is learned from a failed or contradicted one. (Successes were recorded per VERIFIED step.) */
    private fun learn(plan: AdaptivePlan, results: List<AdaptiveStepResult>, verdict: EvidenceVerdict) {
        if (verdict == EvidenceVerdict.FAILED) results.filter { it.outcome == StepOutcome.FAILED }.forEach { r ->
            plan.steps.firstOrNull { it.id == r.stepId }?.let { memoryMiss(plan, it) }
        }
    }

    /** Convenience for callers that only care whether a risk level needs the owner. */
    internal fun needsOwner(r: RiskAssessment) = r.level != RiskLevel.LOW
}
