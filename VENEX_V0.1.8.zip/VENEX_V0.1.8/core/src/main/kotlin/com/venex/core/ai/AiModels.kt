package com.venex.core.ai

/** Which wire protocol a provider adapter speaks. New adapters add a value here and a class. */
enum class ProviderType(val arabicName: String, val defaultBaseUrl: String) {
    OPENAI_COMPATIBLE("خادم متوافق مع OpenAI (مثل LM Studio أو llama.cpp server أو vLLM)", "http://127.0.0.1:8080"),
    OLLAMA("Ollama", "http://127.0.0.1:11434")
}

enum class FailureKind {
    UNREACHABLE,
    TIMEOUT,
    HTTP_ERROR,
    UNAUTHORIZED,
    WRONG_PROVIDER,
    MODEL_NOT_FOUND,
    INVALID_RESPONSE,
    EMPTY_RESPONSE,

    // --- Added in V0.1.2 (on-device runtime and file handling) ---
    /** The on-device model is not loaded (yet) or not enabled. Callers fall back to the rules. */
    NOT_READY,
    CANCELLED,
    OUT_OF_MEMORY,
    /** The native runtime could not be loaded or initialised on this device (e.g. unsupported ABI). */
    RUNTIME_UNAVAILABLE,
    /** The file is not a usable GGUF model, or the runtime refused it. */
    INVALID_MODEL_FILE,
    NO_SPACE,
    /** The file cannot be opened or read (moved, deleted, permission revoked). */
    FILE_ACCESS,
    /** The prompt does not fit the configured context length. */
    PROMPT_TOO_LONG
}

/** A failure whose [message] is safe to show the user: it never contains prompts, replies or secrets. */
data class ProviderFailure(val kind: FailureKind, val message: String)

sealed interface ProviderResult<out T> {
    data class Ok<out T>(val value: T, val latencyMs: Long) : ProviderResult<T>
    data class Err(val failure: ProviderFailure) : ProviderResult<Nothing>
}

/**
 * Where and how to reach a provider. The bearer token lives only in memory; it is never persisted
 * and never printed (see [toString]).
 */
class ConnectionSpec(val baseUrl: String, val timeoutMs: Int = 15_000, val bearer: String? = null) {
    override fun toString(): String = "ConnectionSpec(baseUrl=$baseUrl, timeoutMs=$timeoutMs)"
}

data class ModelInfo(val id: String)

data class ChatPrompt(val system: String, val user: String, val maxTokens: Int = 96)

data class Completion(val text: String, val servedModel: String?)

/** Protocol adapter. The engine and the planner never see this interface. */
interface ModelProvider {
    val type: ProviderType

    /** Model discovery. An empty list is a valid answer, not an error. */
    suspend fun listModels(spec: ConnectionSpec): ProviderResult<List<ModelInfo>>

    /** One chat completion with deterministic settings (temperature 0). */
    suspend fun complete(spec: ConnectionSpec, modelId: String, prompt: ChatPrompt): ProviderResult<Completion>
}

internal object Urls {
    /** Joins a base URL and an API path without producing "/v1/v1" when the base already ends in "/v1". */
    fun join(base: String, path: String): String {
        val b = base.trimEnd('/')
        val versionedBase = b.endsWith("/v1") || b.endsWith("/v1beta/openai")
        return if (versionedBase && path.startsWith("/v1/")) b + path.removePrefix("/v1") else b + path
    }
}

/** Transport-level failure, converted to a [ProviderFailure] by [guarded]. */
internal class ProviderIo(val kind: FailureKind, message: String) : Exception(message)

internal inline fun <T> guarded(block: () -> ProviderResult<T>): ProviderResult<T> = try {
    block()
} catch (e: ProviderIo) {
    ProviderResult.Err(ProviderFailure(e.kind, e.message ?: "خطأ في الاتصال"))
} catch (e: MiniJson.JsonException) {
    ProviderResult.Err(ProviderFailure(FailureKind.INVALID_RESPONSE, "الرد ليس بصيغة JSON صالحة"))
}
