package com.venex.core.ai

import com.venex.core.intent.AiProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class LocalModelConfig(
    val type: ProviderType,
    val baseUrl: String,
    val modelId: String,
    val timeoutMs: Int = 15_000
) {
    fun fingerprint(): String = listOf(type.name, baseUrl, modelId, timeoutMs).joinToString("|")

    override fun toString(): String = "LocalModelConfig(type=$type, baseUrl=$baseUrl, modelId=$modelId, timeoutMs=$timeoutMs)"
}

enum class AiStage(val arabic: String) {
    NO_MODEL_CONFIGURED("لا يوجد نموذج مُعدّ"),
    CONFIGURED("مُعدّ ولم يُختبر بعد"),
    CONNECTION_OK("تم الاتصال بالخادم، لم يُختبر الاستدلال بعد"),
    INFERENCE_OK("نجح اختبار الاستدلال، غير مُفعّل بعد"),
    ENABLED("مُفعّل ويستخدمه VENEX"),
    CONNECTION_FAILED("فشل الاتصال"),
    INFERENCE_FAILED("فشل الاستدلال"),
    MODEL_UNAVAILABLE("النموذج غير متاح على الخادم"),
    DISCONNECTED("مفصول")
}

/** What is persisted. Deliberately has NO field for an API key or bearer token. */
data class StoredAiSettings(
    val config: LocalModelConfig?,
    val enabled: Boolean,
    val verifiedFingerprint: String?,
    val stage: AiStage
)

interface AiSettingsStore {
    fun read(): StoredAiSettings?
    fun write(settings: StoredAiSettings?)
}

data class AiSnapshot(
    val stage: AiStage,
    val config: LocalModelConfig?,
    val enabled: Boolean,
    val discoveredModels: List<String>,
    val connectionMessage: String?,
    val inferenceMessage: String?,
    val errorMessage: String?,
    val warnings: List<String>,
    /** True when an API key is stored (cloud). The key itself is never exposed. */
    val hasApiKey: Boolean = false
)

sealed interface SaveResult {
    data class Saved(val warnings: List<String>) : SaveResult
    data class Rejected(val reason: String) : SaveResult
}

/**
 * Owns the local-model setup and its state machine. Rules:
 *  - saving or changing the configuration disables the model and clears its verification;
 *  - the model can be enabled only after an INFERENCE test passed for the same configuration;
 *  - any connection test that fails disables the model;
 *  - when disabled or unset, VENEX uses the offline rule parser (no AI needed).
 *
 * Suspending tests are serialized through [gate]. Other methods are called from one UI context.
 */
class AiSettingsController(
    private val store: AiSettingsStore,
    private val registry: ProviderRegistry,
    private val connectionTester: ConnectionTester,
    private val inferenceTester: InferenceTester,
    private val catalog: ModelCatalog,
    /** Wording used in audit lines ("النموذج المحلي" for servers, "المزوّد السحابي" for cloud). */
    private val label: String = "النموذج المحلي",
    /** Address validation. Cloud passes [EndpointRules.validateCloud] (HTTPS only, no loopback). */
    private val endpointValidator: (String) -> EndpointRules.Result = EndpointRules::validate,
    /** When set, the bearer token / API key comes from here (encrypted at rest) instead of memory only. */
    private val secrets: SecretStore? = null,
    private val secretAlias: String = "api_key",
    // Keep `audit` LAST: V0.1.1 callers pass it as a trailing lambda.
    private val audit: (String) -> Unit = {}
) {
    private val gate = Mutex()

    private var stored: StoredAiSettings = normalize(store.read())
    private var bearer: String? = null
    private var discovered: List<String> = emptyList()
    private var connectionMessage: String? = null
    private var inferenceMessage: String? = null
    private var errorMessage: String? = null
    private var warnings: List<String> = emptyList()

    private val _state = MutableStateFlow(snapshot())
    val state: StateFlow<AiSnapshot> = _state.asStateFlow()

    fun saveConfig(type: ProviderType, rawUrl: String, modelId: String, timeoutMs: Int = 15_000): SaveResult {
        val endpoint = when (val r = endpointValidator(rawUrl)) {
            is EndpointRules.Result.Rejected -> return SaveResult.Rejected(r.reason)
            is EndpointRules.Result.Ok -> r.endpoint
        }
        val model = modelId.trim()
        if (model.isEmpty()) return SaveResult.Rejected("أدخل اسم النموذج أو اختره من القائمة")
        if (model.length > 120 || model.any { it == '\n' || it == '\r' }) return SaveResult.Rejected("اسم النموذج غير صالح")

        val config = LocalModelConfig(type, endpoint.baseUrl, model, timeoutMs.coerceIn(1_000, 120_000))
        val sameAsBefore = stored.config?.fingerprint() == config.fingerprint()
        stored = normalize(
            StoredAiSettings(
                config = config,
                enabled = false,
                verifiedFingerprint = if (sameAsBefore) stored.verifiedFingerprint else null,
                stage = AiStage.CONFIGURED
            )
        )
        if (!sameAsBefore) {
            discovered = emptyList()
            connectionMessage = null
            inferenceMessage = null
        }
        errorMessage = null
        warnings = endpoint.warnings
        persist()
        publish()
        audit("تم حفظ إعداد $label (${type.name})")
        return SaveResult.Saved(endpoint.warnings)
    }

    /** Session-only credential. Never written to storage, never shown in state. */
    fun setSessionBearer(token: String?) {
        bearer = token?.trim()?.takeIf { it.isNotEmpty() }
    }

    /**
     * Stores the API key in the [SecretStore] (encrypted at rest). Changing the key disables the model
     * and clears its verification, because the previous test was made with another credential.
     */
    fun saveApiKey(key: String): String? {
        val store = secrets ?: return "تخزين المفاتيح غير متاح"
        val k = key.trim()
        if (k.isEmpty()) return "أدخل المفتاح"
        if (k.length > 512 || k.any { it.isWhitespace() || it.isISOControl() }) return "المفتاح يحتوي على محارف غير صالحة"
        try {
            store.put(secretAlias, k)
        } catch (e: Exception) {
            // Never include the key or the exception text (it could echo input) in the message.
            return "تعذّر حفظ المفتاح بأمان على هذا الجهاز"
        }
        invalidateAfterCredentialChange()
        audit("تم حفظ مفتاح API لـ $label")
        return null
    }

    fun deleteApiKey() {
        secrets?.delete(secretAlias)
        invalidateAfterCredentialChange()
        audit("تم حذف مفتاح API لـ $label")
    }

    fun hasApiKey(): Boolean = secrets?.has(secretAlias) == true

    private fun invalidateAfterCredentialChange() {
        val c = stored.config
        stored = if (c == null) stored else normalize(
            StoredAiSettings(c, enabled = false, verifiedFingerprint = null, stage = AiStage.CONFIGURED)
        )
        inferenceMessage = null
        connectionMessage = null
        persist()
        publish()
    }

    suspend fun discoverModels(): String = gate.withLock {
        val c = stored.config ?: return@withLock "احفظ إعدادات الاتصال أولاً"
        when (val r = catalog.discover(c.type, spec(c))) {
            is ProviderResult.Err -> {
                errorMessage = r.failure.message
                publish()
                r.failure.message
            }
            is ProviderResult.Ok -> {
                discovered = r.value.map { it.id }
                errorMessage = null
                publish()
                if (discovered.isEmpty()) "الخادم لم يُرجع أي نموذج؛ أدخل الاسم يدوياً"
                else "تم العثور على ${discovered.size} نموذج"
            }
        }
    }

    suspend fun testConnection(): String = gate.withLock {
        val c = stored.config ?: return@withLock "احفظ إعدادات الاتصال أولاً"
        val message = when (val o = connectionTester.test(c.type, spec(c), c.modelId)) {
            is ConnectionOutcome.Failed -> {
                stored = stored.copy(enabled = false, verifiedFingerprint = null, stage = AiStage.CONNECTION_FAILED)
                errorMessage = o.failure.message
                connectionMessage = null
                inferenceMessage = null
                audit("$label: فشل اختبار الاتصال (${o.failure.kind})")
                "تعذر الاتصال: ${o.failure.message}"
            }
            is ConnectionOutcome.Connected -> {
                if (o.selectedModelListed == false) {
                    stored = stored.copy(enabled = false, verifiedFingerprint = null, stage = AiStage.MODEL_UNAVAILABLE)
                    errorMessage = "النموذج «${c.modelId}» غير مدرج على الخادم"
                    val text = "الخادم متصل لكن النموذج غير متاح"
                    connectionMessage = text
                    text
                } else {
                    stored = stored.copy(enabled = false, verifiedFingerprint = null, stage = AiStage.CONNECTION_OK)
                    errorMessage = null
                    val text = "تم الاتصال بالخادم بنجاح، لكن لم يتم اختبار استدلال النموذج بعد"
                    connectionMessage = text
                    text
                }
            }
        }
        persist()
        publish()
        message
    }

    suspend fun testInference(): String = gate.withLock {
        val c = stored.config ?: return@withLock "احفظ إعدادات الاتصال أولاً"
        val message = when (val o = inferenceTester.test(c.type, spec(c), c.modelId)) {
            is InferenceOutcome.Passed -> {
                stored = stored.copy(enabled = false, verifiedFingerprint = c.fingerprint(), stage = AiStage.INFERENCE_OK)
                errorMessage = null
                val text = "نجح اختبار الاستدلال. النموذج استجاب فعلياً، ويمكن لـ VENEX التواصل معه " +
                    "(${o.latencyMs} ms). الرد: «${o.answer.take(80)}»"
                inferenceMessage = text
                text
            }
            is InferenceOutcome.UnexpectedAnswer -> {
                stored = stored.copy(enabled = false, verifiedFingerprint = null, stage = AiStage.INFERENCE_FAILED)
                errorMessage = "الإجابة غير متوقعة"
                val text = "استجاب النموذج، لكن الإجابة لا تطابق المتوقع، فلم يُعتبر الاختبار ناجحاً. الرد: «${o.answer.take(80)}»"
                inferenceMessage = text
                text
            }
            is InferenceOutcome.Failed -> {
                val stage = if (o.failure.kind == FailureKind.MODEL_NOT_FOUND) AiStage.MODEL_UNAVAILABLE else AiStage.INFERENCE_FAILED
                stored = stored.copy(enabled = false, verifiedFingerprint = null, stage = stage)
                errorMessage = o.failure.message
                inferenceMessage = null
                audit("$label: فشل اختبار الاستدلال (${o.failure.kind})")
                "فشل اختبار الاستدلال: ${o.failure.message}"
            }
        }
        persist()
        publish()
        message
    }

    /** Returns null on success, or the reason the model cannot be enabled yet. */
    fun enable(): String? {
        val c = stored.config ?: return "لا يوجد نموذج مُعدّ"
        if (stored.verifiedFingerprint != c.fingerprint()) return "شغّل اختبار الاستدلال بنجاح لهذا الإعداد قبل التفعيل"
        stored = stored.copy(enabled = true, stage = AiStage.ENABLED)
        persist()
        publish()
        audit("تم تفعيل $label")
        return null
    }

    /** Stops using the model; the configuration is kept. */
    fun disable() {
        val c = stored.config ?: return
        val verified = stored.verifiedFingerprint == c.fingerprint()
        stored = stored.copy(enabled = false, stage = if (verified) AiStage.INFERENCE_OK else AiStage.CONFIGURED)
        persist()
        publish()
        audit("تم تعطيل $label؛ يعمل VENEX بالمحلل المحلي")
    }

    /** Disables the model, drops the session credential and the discovered list; keeps the configuration. */
    fun disconnect() {
        stored = stored.copy(enabled = false, stage = AiStage.DISCONNECTED)
        bearer = null
        discovered = emptyList()
        persist()
        publish()
        audit("تم فصل $label")
    }

    /** Removes every stored setting. */
    fun clearSettings() {
        secrets?.delete(secretAlias)
        stored = StoredAiSettings(null, false, null, AiStage.NO_MODEL_CONFIGURED)
        bearer = null
        discovered = emptyList()
        connectionMessage = null
        inferenceMessage = null
        errorMessage = null
        warnings = emptyList()
        persist()
        publish()
        audit("تم مسح إعدادات $label")
    }

    /** The provider VENEX should use right now, or null to use the rule-based parser. */
    fun activeIntentProvider(): AiProvider? {
        if (!stored.enabled) return null
        val c = stored.config ?: return null
        if (stored.verifiedFingerprint != c.fingerprint()) return null
        return ModelIntentProvider(
            provider = registry.get(c.type),
            spec = spec(c),
            modelId = c.modelId,
            audit = audit,
            onRuntimeFailure = { f -> reportRuntimeFailure(f) }
        )
    }

    /** Called when a model call fails during normal use. Shown in the UI; rule parsing still works. */
    fun reportRuntimeFailure(f: ProviderFailure) {
        _state.update { it.copy(errorMessage = "خطأ أثناء الاستخدام: ${f.message}") }
    }

    private fun spec(c: LocalModelConfig) = ConnectionSpec(c.baseUrl, c.timeoutMs, bearer ?: secrets?.get(secretAlias))

    private fun persist() = store.write(stored)

    private fun publish() {
        _state.value = snapshot()
    }

    private fun snapshot(): AiSnapshot {
        val restartNote = if (stored.stage == AiStage.ENABLED && inferenceMessage == null) {
            "أُعيد تحميل الإعداد؛ آخر اختبار استدلال نجح قبل إعادة التشغيل"
        } else inferenceMessage
        return AiSnapshot(
            stage = stored.stage,
            config = stored.config,
            enabled = stored.enabled,
            discoveredModels = discovered,
            connectionMessage = connectionMessage,
            inferenceMessage = restartNote,
            errorMessage = errorMessage,
            warnings = warnings,
            hasApiKey = hasApiKey()
        )
    }

    companion object {
        /** Repairs a loaded or freshly built state so that it is internally consistent. */
        internal fun normalize(s: StoredAiSettings?): StoredAiSettings {
            if (s == null || s.config == null) {
                return StoredAiSettings(null, false, null, AiStage.NO_MODEL_CONFIGURED)
            }
            val verified = s.verifiedFingerprint == s.config.fingerprint()
            val enabled = s.enabled && verified
            val stage = when {
                enabled -> AiStage.ENABLED
                s.stage == AiStage.DISCONNECTED -> AiStage.DISCONNECTED
                verified -> AiStage.INFERENCE_OK
                else -> AiStage.CONFIGURED
            }
            return StoredAiSettings(s.config, enabled, if (verified) s.verifiedFingerprint else null, stage)
        }
    }
}
