#!/usr/bin/env bash
# Fetches the llama.cpp commit pinned in third_party/llama.cpp.version into third_party/llama.cpp
# and verifies that the checkout is exactly that commit. Safe to run repeatedly.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck disable=SC1091
source <(grep -E '^(TAG|COMMIT)=' "$ROOT/third_party/llama.cpp.version")
DEST="$ROOT/third_party/llama.cpp"

if [ -d "$DEST/.git" ] && [ "$(git -C "$DEST" rev-parse HEAD 2>/dev/null)" = "$COMMIT" ]; then
  echo "llama.cpp already at $TAG ($COMMIT)"
  exit 0
fi

rm -rf "$DEST"
mkdir -p "$DEST"
git -C "$DEST" init -q
git -C "$DEST" remote add origin https://github.com/ggml-org/llama.cpp.git
git -C "$DEST" fetch -q --depth 1 origin "$COMMIT"
git -C "$DEST" checkout -q FETCH_HEAD

ACTUAL="$(git -C "$DEST" rev-parse HEAD)"
if [ "$ACTUAL" != "$COMMIT" ]; then
  echo "ERROR: expected llama.cpp $COMMIT but got $ACTUAL" >&2
  exit 1
fi
echo "llama.cpp $TAG ($ACTUAL) ready at $DEST"
