#include <cstdio>
#include <thread>
#include <chrono>
#include "venex_llm.h"
using namespace venex;
#define CHECK(c) do { if(!(c)) { printf("FAIL line %d: %s | last=%s\n", __LINE__, #c, last_error().c_str()); return 1; } } while(0)
int main(int argc, char** argv) {
    const char* path = argv[1];
    CHECK(init("") == ERR_NONE);
    printf("sysinfo: %s\n", system_info().c_str());
    // 1. complete without model
    std::string out; CompletionStats st;
    CHECK(complete("s","u",16,out,st) == ERR_NOT_LOADED);
    // 2. bad file
    CHECK(load("/nonexistent.gguf", 512, 2) == ERR_LOAD_FAILED);
    { std::string bad = std::string(path) + ".bad"; FILE* f = fopen(bad.c_str(), "wb"); fwrite("not a gguf", 1, 10, f); fclose(f); CHECK(load(bad.c_str(), 512, 2) == ERR_LOAD_FAILED); remove(bad.c_str()); }
    CHECK(!is_loaded());
    // 3. load good
    CHECK(load(path, 512, 2) == ERR_NONE);
    CHECK(is_loaded());
    auto mi = model_info(); printf("model: %s size=%llu params=%llu ctx_train=%d ctx=%d thr=%d\n", mi.description.c_str(), (unsigned long long)mi.size_bytes, (unsigned long long)mi.n_params, mi.n_ctx_train, mi.n_ctx, mi.n_threads);
    CHECK(load(path, 512, 2) == ERR_BUSY);
    // 4. completion produces output and is deterministic
    CHECK(complete("You are a test.", "hello world", 12, out, st) == ERR_NONE);
    printf("out(%zu bytes) prompt_tok=%d gen_tok=%d\n", out.size(), st.prompt_tokens, st.generated_tokens);
    CHECK(st.prompt_tokens > 0 && st.generated_tokens > 0);
    std::string out2; CHECK(complete("You are a test.", "hello world", 12, out2, st) == ERR_NONE);
    CHECK(out == out2);
    // 5. prompt too long
    std::string big(5000, 'a'); 
    CHECK(complete("s", big, 8, out, st) == ERR_PROMPT_TOO_LONG);
    // 6. cancel mid-generation
    clear_cancel();
    std::thread t([]{ std::this_thread::sleep_for(std::chrono::milliseconds(5)); cancel(); });
    int rc = complete("s", "hello", 400, out, st);
    t.join();
    printf("cancel rc=%d code=%d gen=%d\n", rc, last_error_code(), st.generated_tokens);
    CHECK(rc == ERR_CANCELLED || rc == ERR_NONE);
    clear_cancel();
    // cancelled-before-start wins
    cancel(); CHECK(complete("s","u",8,out,st) == ERR_CANCELLED); clear_cancel();
    CHECK(complete("s","u",8,out,st) == ERR_NONE);
    // 7. unload / reload / double unload
    unload(); CHECK(!is_loaded()); unload();
    CHECK(complete("s","u",8,out,st) == ERR_NOT_LOADED);
    CHECK(load(path, 512, 1) == ERR_NONE);
    CHECK(complete("s","u",8,out,st) == ERR_NONE);
    // 8. cancel during load of a model is covered by progress cb; cancel flag set before load is cleared by load
    unload();
    cancel(); CHECK(load(path, 512, 1) == ERR_NONE); unload();

    // 9. Pure prompt helper (no model): Qwen3 templates get the empty think block, others are untouched.
    const std::string qwen_tmpl = "{%- if enable_thinking is defined and enable_thinking is false %}<think>{%- endif %}";
    const std::string chatml_tmpl = "{% for m in messages %}<|im_start|>{{m['role']}}{% endfor %}<|im_start|>assistant\n";
    const std::string ends_at_assistant = "<|im_start|>system\nS<|im_end|>\n<|im_start|>user\nQ<|im_end|>\n<|im_start|>assistant\n";
    CHECK(finalize_prompt(ends_at_assistant, qwen_tmpl) == ends_at_assistant + "<think>\n\n</think>\n\n");
    CHECK(finalize_prompt(ends_at_assistant, chatml_tmpl) == ends_at_assistant);          // no Qwen3 marker
    CHECK(finalize_prompt("plain text", qwen_tmpl) == "plain text");                      // not at an assistant turn
    CHECK(finalize_prompt(ends_at_assistant + "x", qwen_tmpl) == ends_at_assistant + "x");
    printf("finalize_prompt: qwen3 and chatml cases OK\n");

    // 10. Truncation flag: with a budget of 3 tokens, a reply that is still going is reported as truncated,
    //     and a reply that ended before the budget is not. The invariant is checked, not the random text.
    CHECK(load(path, 512, 2) == ERR_NONE);
    CHECK(complete("s", "hello", 3, out, st) == ERR_NONE);
    CHECK(st.truncated == (st.generated_tokens == 3));
    printf("truncation flag: gen=%d truncated=%d\n", st.generated_tokens, st.truncated ? 1 : 0);
    unload();

    // 11. Qwen3-style template model: the engine loads it and completes with the thinking switch applied.
    if (argc > 2) {
        // Same input through the plain ChatML model and the Qwen3-marked one: the Qwen3 prompt must carry
        // the extra empty think block, which shows the engine detected the template (not just that it loads).
        CHECK(load(path, 512, 2) == ERR_NONE);
        CHECK(complete("s", "hello", 1, out, st) == ERR_NONE);
        const int32_t plain_prompt_tokens = st.prompt_tokens;
        unload();
        CHECK(load(argv[2], 512, 2) == ERR_NONE);
        CHECK(complete("s", "hello", 8, out, st) == ERR_NONE);
        CHECK(st.prompt_tokens > 0);
        printf("qwen3-style model: prompt_tok=%d (plain %d) gen_tok=%d truncated=%d\n", st.prompt_tokens, plain_prompt_tokens, st.generated_tokens, st.truncated ? 1 : 0);
        CHECK(st.prompt_tokens > plain_prompt_tokens);
        unload();
    }
    shutdown();
    printf("ALL HOST NATIVE CHECKS PASSED\n");
    return 0;
}
