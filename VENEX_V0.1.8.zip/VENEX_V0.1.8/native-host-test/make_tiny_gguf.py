import sys, numpy as np
import os; sys.path.insert(0, os.path.join(os.environ.get("LLAMA_DIR", "third_party/llama.cpp"), "gguf-py"))
import gguf
w = gguf.GGUFWriter(sys.argv[1] if len(sys.argv) > 1 else "tiny.gguf", "llama")
nE, nH, nFF, nL, nCtx = 64, 4, 128, 1, 2048
tokens, scores, types = [], [], []
for t in ["<unk>", "<s>", "</s>"]:
    tokens.append(t.encode()); scores.append(0.0)
    types.append(gguf.TokenType.UNKNOWN if t=="<unk>" else gguf.TokenType.CONTROL)
for i in range(256):
    tokens.append(f"<0x{i:02X}>".encode()); scores.append(0.0); types.append(gguf.TokenType.BYTE)
for c in "▁abcdefghijklmnopqrstuvwxyz":
    tokens.append(c.encode()); scores.append(-1.0); types.append(gguf.TokenType.NORMAL)
n = len(tokens)
w.add_name("venex-tiny-random"); w.add_context_length(nCtx); w.add_embedding_length(nE)
w.add_block_count(nL); w.add_feed_forward_length(nFF); w.add_head_count(nH); w.add_head_count_kv(nH)
w.add_layer_norm_rms_eps(1e-5); w.add_rope_dimension_count(nE//nH); w.add_file_type(0)
w.add_tokenizer_model("llama"); w.add_token_list(tokens); w.add_token_scores(scores); w.add_token_types(types)
w.add_bos_token_id(1); w.add_eos_token_id(2); w.add_unk_token_id(0); w.add_add_bos_token(True)
# "qwen3" variant: the template carries Qwen3's enable_thinking switch, so the engine's Qwen3 handling runs.
QWEN3 = len(sys.argv) > 2 and sys.argv[2] == "qwen3"
if QWEN3:
    w.add_chat_template("{%- if enable_thinking is defined and enable_thinking is false %}{{- '<think>\\n\\n</think>\\n\\n' }}{%- endif %}"
                        "{% for m in messages %}<|im_start|>{{m['role']}}\n{{m['content']}}<|im_end|>\n{% endfor %}<|im_start|>assistant\n")
else:
    w.add_chat_template("{% for m in messages %}<|im_start|>{{m['role']}}\n{{m['content']}}<|im_end|>\n{% endfor %}<|im_start|>assistant\n")
rng = np.random.default_rng(0)
def r(*s): return (rng.standard_normal(s)*0.05).astype(np.float32)
w.add_tensor("token_embd.weight", r(n, nE)); w.add_tensor("output_norm.weight", np.ones(nE, np.float32))
w.add_tensor("output.weight", r(n, nE))
for i in range(nL):
    p=f"blk.{i}."
    w.add_tensor(p+"attn_norm.weight", np.ones(nE,np.float32))
    for k in ["attn_q","attn_k","attn_v","attn_output"]: w.add_tensor(p+k+".weight", r(nE,nE))
    w.add_tensor(p+"ffn_norm.weight", np.ones(nE,np.float32))
    w.add_tensor(p+"ffn_gate.weight", r(nFF,nE)); w.add_tensor(p+"ffn_up.weight", r(nFF,nE)); w.add_tensor(p+"ffn_down.weight", r(nE,nFF))
w.write_header_to_file(); w.write_kv_data_to_file(); w.write_tensors_to_file(); w.close()
print("ok", n)
