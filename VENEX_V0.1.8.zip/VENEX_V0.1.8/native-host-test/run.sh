#!/usr/bin/env bash
# Real-model smoke test of the native engine on the host machine.
# Needs: git, cmake (>=3.22), a C++17 compiler (+ ninja or make), python3 with numpy, pyyaml, tqdm, requests (gguf-py deps).
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$HERE/.."
"$ROOT/scripts/fetch-llama-cpp.sh"
BUILD="$HERE/build"
mkdir -p "$BUILD"
export LLAMA_DIR="$ROOT/third_party/llama.cpp"
python3 "$HERE/make_tiny_gguf.py" "$BUILD/tiny.gguf"
python3 "$HERE/make_tiny_gguf.py" "$BUILD/tiny_qwen3.gguf" qwen3
cmake -S "$HERE" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD" --target venex_host_test -j"$(nproc)"
"$BUILD/venex_host_test" "$BUILD/tiny.gguf" "$BUILD/tiny_qwen3.gguf"
