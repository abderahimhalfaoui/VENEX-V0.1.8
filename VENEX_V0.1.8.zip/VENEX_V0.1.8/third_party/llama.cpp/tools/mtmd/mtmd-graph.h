#pragma once

#include "ggml.h"
#include "ggml-cpp.h"
#include "mtmd-subcontext.h"
#include "mtmd-impl.h"
#include "mtmd-model.h"

#include <vector>
#include <functional>

#define DEFAULT_INTERPOLATION_MODE (GGML_SCALE_MODE_BILINEAR | GGML_SCALE_FLAG_ANTIALIAS)

struct build_vit_opts {
    ggml_tensor * attn_mask = nullptr;
    // TODO @ngxson : merge attn_mask and attn_mask_layers into one call
    std::vector<ggml_tensor *> attn_mask_layers; // one per layer

    // hook at layer output embeddings
    std::function<void(ggml_tensor * cur, int il)> callback_layer_out = nullptr;

    // whether to skip the automatic post-layernorm (model.post_ln_w) applied at the end
    bool skip_post_ln = false;
};

struct mtmd_graph {
    const mtmd_model & model;
    const mtmd_hparams & hparams;
    projector_type proj_type;

    const mtmd_image_f32 & img; // for backward compat
    const mtmd_image_f32_batch * img_batch = nullptr;

    const int patch_size;
    const int n_patches_x;
    const int n_patches_y;
    const int n_patches;
    const int n_embd;
    const int n_head;
    const int n_head_kv;
    const int d_head;
    const int n_layer;
    const int n_mmproj_embd;
    const float eps;
    float kq_scale; // TODO: maybe move this to hparams
    const mtmd_flash_attn_type flash_attn_type;

    // TODO [QWEN_VIDEO]: improve this in the future
    int n_batch = 1;

    ggml_context_ptr ctx0_ptr;
    ggml_context * ctx0;
    ggml_cgraph * gf;

    mtmd_graph(mtmd_subcontext * ctx, const mtmd_image_f32 & img);

    // build sub-graph, reuse buf from parent
    mtmd_graph(const mtmd_graph & parent);

    virtual ~mtmd_graph() = default;
    virtual ggml_cgraph * build() = 0;

    // wrapper around ggml_mul_mat, allow hooking (e.g. LoRA, clamping) depending on the model
    // tensor w should be the weight matrix, and tensor x should be the input
    virtual ggml_tensor * build_mm(ggml_tensor * w, ggml_tensor * x) const;
    // TODO: build_mm(w, b, x) to support bias

    virtual bool support_batch() const {
        return false;
    }

    //
    // utility functions
    //
    void cb(ggml_tensor * cur0, const char * name, int il) const;

    const mtmd_image_f32 & get_img(size_t idx) const {
        GGML_ASSERT(img_batch);
        GGML_ASSERT(idx < img_batch->entries.size());
        return img_batch->entries[idx];
    }

    // siglip2 naflex
    ggml_tensor * resize_position_embeddings(uint32_t interpolation_mode = DEFAULT_INTERPOLATION_MODE);

    // build vision transformer (ViT) cgraph
    // this function should cover most of the models
    // if your model has specific features, you should probably duplicate this function
    ggml_tensor * build_vit(
                ggml_tensor * inp,
                int64_t n_pos,
                norm_type norm_t,
                ffn_op_type ffn_t,
                ggml_tensor * learned_pos_embd,
                std::function<ggml_tensor *(ggml_tensor *, const mtmd_layer &)> add_pos,
                const build_vit_opts & opts = {});

    // build the input after conv2d (inp_raw --> patches)
    // returns tensor with shape [n_embd, n_patches]
    ggml_tensor * build_inp();

    ggml_tensor * build_inp_raw(int channels = 3);

    // qwen-vl style temporal merge, handles n_batch == 1 (image) or n_batch == 2 (2 video frames)
    // requires patch_embeddings_0 and patch_embeddings_1; returns tensor with shape [w, h, n_embd, 1]
    ggml_tensor * build_inp_temporal_merge();

    // f16 if flash attn is enabled, set it with set_input_attn_mask()
    // idx is only needed when the graph has more than one mask
    ggml_tensor * build_inp_attn_mask(int64_t n_kv, int64_t n_q, int idx = 0);

    ggml_tensor * build_norm(
            ggml_tensor * cur,
            ggml_tensor * mw,
            ggml_tensor * mb,
            norm_type type,
            float norm_eps,
            int il) const;

    ggml_tensor * build_ffn(
            ggml_tensor * cur,
            ggml_tensor * up,
            ggml_tensor * up_b,
            ggml_tensor * gate,
            ggml_tensor * gate_b,
            ggml_tensor * down,
            ggml_tensor * down_b,
            ffn_op_type type_op,
            int il) const;

    ggml_tensor * build_moe_ffn(
            ggml_tensor * cur,
            const mtmd_layer & layer,
            ffn_op_type type_op,
            int il) const;

    ggml_tensor * build_attn(
            ggml_tensor * wo,
            ggml_tensor * wo_b,
            ggml_tensor * q_cur,
            ggml_tensor * k_cur,
            ggml_tensor * v_cur,
            ggml_tensor * kq_mask,
            float kq_scale,
            int il,
            ggml_tensor * sinks = nullptr) const;

    // implementation of the 2D RoPE using two ggml_rope_ext calls
    //
    // unlike GGML_ROPE_TYPE_VISION which forces NEOX ordering, this rotates adjacent pairs (normal ordering)
    //
    // example:
    //  given a single head with size = 8 --> [00000000]
    //  dims [0, 4) rotate with pos_a, dims [4, 8) rotate with pos_b --> [aaaabbbb]
    //  interleave_freq = false --> both halves use the same inv_freq set (like GGML_ROPE_TYPE_VISION)
    //  interleave_freq = true  --> first half uses even inv_freq, second half uses odd inv_freq (used by pixtral)
    ggml_tensor * build_rope_2d(
        ggml_context * ctx0,
        ggml_tensor * cur,
        ggml_tensor * pos_a, // first half
        ggml_tensor * pos_b, // second half
        const float freq_base,
        const bool interleave_freq
    );

    // aka pixel_shuffle / pixel_unshuffle / patch_merger (Kimi-VL)
    // support dynamic resolution
    ggml_tensor * build_patch_merge_permute(ggml_tensor * cur, int scale_factor);

    // Generic function to stack frames for audio processing
    // Abstracts out the StackAudioFrames logic used by ultravox
    ggml_tensor * build_stack(ggml_tensor * cur, int32_t stack_factor, int32_t n_embed);

    // append the separators of img.suffix_type after the image tokens
    ggml_tensor * build_suffix(ggml_tensor * cur);
};

static inline std::string get_attn_mask_name(int idx) {
    return idx == 0 ? "attn_mask" : "attn_mask_" + std::to_string(idx);
}

// create the graph builder of the subcontext's projector, params is only needed by encode()
std::unique_ptr<mtmd_graph> mtmd_get_graph_builder(mtmd_subcontext * ctx, const mtmd_image_f32_batch & imgs,
                                                   const mtmd_subctx_encode_params * params = nullptr);
