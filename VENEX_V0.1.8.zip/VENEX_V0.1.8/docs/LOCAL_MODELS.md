# Local AI models in VENEX

VENEX can use a model **you** control, to interpret commands the offline rules do not understand.
It is optional and off by default. Without a model VENEX works exactly as before.

Since V0.1.2 there are three ways, and only one is active at a time (AI settings → panels
**داخل الهاتف** / **سحابي (API)** / **خادم**; the button «إيقاف الذكاء الاصطناعي» returns to rules only):

| Path | What runs the model | Needs | Leaves the phone? |
|---|---|---|---|
| On-device (V0.1.2, experimental) | llama.cpp inside VENEX, on a `.gguf` file you pick | the file only | no |
| Server (V0.1.1) | Ollama / OpenAI-compatible server you run | a reachable server | yes, to your server |
| Cloud (V0.1.2) | a hosted OpenAI-compatible API with your key | internet + key — see [`CLOUD_API.md`](CLOUD_API.md) | yes, to the provider |

The rest of this file describes the **server** path first, then the **on-device** path (below).
Upgrading from V0.1.1: a server model that was enabled stays enabled as the active mode «خادم».

## What is supported

| Provider | Protocol | Model list | Chat | Tested here |
|---|---|---|---|---|
| **Ollama** | native API: `GET /api/tags`, `POST /api/chat` (non-streaming) | yes | yes | against a local HTTP server that implements these shapes |
| **OpenAI-compatible** (LM Studio, llama.cpp server, vLLM, …) | `GET /v1/models`, `POST /v1/chat/completions` | yes | yes | same, for the OpenAI shapes |

Differences between servers in the OpenAI family are not all covered. If a server returns a shape
that does not match, VENEX reports *invalid response* instead of guessing.

Loading a `.gguf` file inside VENEX is the separate **on-device** path, described under "On-device
models (GGUF)" below; the server path itself still only talks to a server that is already running.

## Setting it up (server path)

1. Start a model server:
   - **Ollama** (on a PC on your network, or on the phone itself if you run it there): `ollama pull <model>` then `ollama serve`. Default port 11434. Running on the phone itself is not tested here.
   - **LM Studio / llama.cpp / vLLM**: start the OpenAI-compatible server. Default port depends on the tool (llama.cpp uses 8080).
2. In VENEX, open **الذكاء الاصطناعي** (AI settings).
3. Choose the provider type.
4. Enter the **Base URL**, e.g. `http://127.0.0.1:11434`.
   - Enter only the base address. No `?`, no `#`, no credentials inside the URL. `http://user:pass@host` is rejected.
   - For OpenAI-type servers enter the address **without** `/v1`. VENEX appends `/v1/models` and `/v1/chat/completions` itself, so `http://127.0.0.1:1234/v1` would produce a wrong path.
5. Enter the **model name** manually, or press **اكتشاف النماذج** and tap one.
6. Optional: enter an access key if your server requires one. It is kept **only for this session**; it is never saved.
7. Press **حفظ الإعداد**.
8. Press **اختبار الاتصال** (connection test). It checks reachability, the protocol and whether the model is listed. A success message says explicitly that inference has **not** been tested yet.
9. Press **اختبار الاستدلال** (inference test). VENEX sends the question «أجب بكلمة واحدة: ما عاصمة الجزائر؟» to the model and checks that the answer contains *الجزائر* (or *Algiers*). A different answer is reported as a failure.
10. Press **تفعيل النموذج لـ VENEX**. This is refused until step 9 has passed for the current settings.

## How a command is handled with a model enabled (all paths)

1. Restricted-action detection (send, post, delete, pay). Refused **before** any model sees the text.
2. Offline rules. Simple known commands never reach the model.
3. The model, under a timeout (15 s in the stored default setting for server/cloud; on-device inference is limited to 35 s and the whole AI step to 40 s; the call is cancelled when it expires). It must return one JSON object from a closed list:
   `open_app`, `calculate`, `navigate`, `scroll`. Anything else (including `unsupported`) is discarded.
4. The result becomes a goal, then goes through the planner, SafetyPolicy and the execution engine exactly like a rule-based goal.

The model never runs code and never produces actions. Its reply is parsed as data.

## Disabling, disconnecting, clearing

| Button | Effect |
|---|---|
| تعطيل واستخدام المحلل المحلي | Stops using the model. Keeps the setup. |
| فصل الاتصال | Disables the model and forgets the session key. Keeps the setup. |
| حذف إعدادات الاتصال | Removes the saved address, model name and flags. |

Changing the address, model name or timeout disables the model and requires new tests.

## Limits you should know about

- **Network exposure.** A model server on another machine is reached over your network. An IP address in the local range is **not** proof that the server is secure. Use a server you trust, on a network you trust. Prefer HTTPS when the server supports it.
- **Cleartext HTTP.** In release builds, cleartext HTTP is allowed only to `localhost` / `127.0.0.1`. Other hosts need HTTPS. Debug builds allow HTTP to any host so you can test a PC server; that overlay is not in release builds.
- **Quality.** A small local model can misread commands. The model only proposes; the rules, the planner, the safety policy and the verification still decide what runs. A wrong proposal can still open the wrong app if the app name is ambiguous, so keep the model off if you do not trust its output.
- **Speed.** Responses depend entirely on your hardware and model size. A slow reply hits the timeout and falls back to the rules.
- **Logs.** The audit log records that a model was called and the failure kind. It does not record the command, the reply, or the access key.

## On-device models (GGUF) — V0.1.2, experimental (fixed for Qwen3-style models in V0.1.3)

A GGUF model file that **you** downloaded runs inside VENEX through llama.cpp (pinned tag `b12627`, MIT
license). It needs no internet, no Ollama, no server, no helper app, no root and no API key. VENEX ships
**no model**: you bring the file. Runtime details, build configuration and the verification status are in
[`ON_DEVICE_AI_REPORT.md`](ON_DEVICE_AI_REPORT.md).

### Choosing a model

- Use a small **instruct/chat** model in GGUF format, single file (for example a 0.5–3 B model quantised to
  Q4). Split files named `…-00001-of-0000N.gguf` are not supported.
- The **file size is not the RAM it needs**. The weights are memory-mapped, and the context (KV cache) and
  compute buffers come on top. A model that does not fit may be slow, or the system may close VENEX.
- Quality in Arabic depends entirely on the model. Nothing about any model's speed or accuracy on a specific
  phone was measured by this project.

### Steps

1. **داخل الهاتف** → «اختيار ملف GGUF من الهاتف». The system file picker opens; VENEX asks for **no** storage
   permission. VENEX checks the name, the size and the GGUF header (not just the extension) and shows a clear
   message if the file is not usable.
2. «استيراد إلى مساحة التطبيق». The file is **copied** into the app's private storage (progress and cancel
   available; free space is checked first, `file size + 256 MB`; a cancelled or failed copy leaves no partial
   file). The original is never modified or deleted. The copy doubles the storage used for the model; it can
   be removed with «حذف النموذج المستورد وإعداداته».
3. Settings (conservative defaults): context 1024 (512 / 1024 / 2048 / 4096) and a thread count suggested for
   this phone (half the cores, between 2 and 4). A larger context uses more memory; commands are short.
4. «تحميل» loads the model. Before loading, VENEX compares the measured available RAM with a conservative
   estimate (`0.85 × file size + 192 MB`) and refuses if it is clearly too little. The estimate is a guess, not
   a guarantee in either direction. After loading, the screen shows the engine's description and the measured
   load time. Available system memory before and after is shown only as a rough system measurement.
5. «اختبار الاستدلال» sends the question «أجب بكلمة واحدة: ما عاصمة الجزائر؟» to the **local model** and checks
   that the answer contains *الجزائر* (or *Algiers*). The model really generates the answer; there is no canned
   reply. This test is strict: a small model may run and still fail it, and then it cannot be enabled.
6. «تفعيل النموذج الداخلي لـ VENEX». Refused until the test passed **for the current file, context and thread
   count** (a fingerprint of SHA-256 + size + context + threads). Changing any of them disables the model and
   requires a new test.

### Behaviour while enabled

- Only commands the offline rules did not understand reach the model, after the restricted-action check. It can
  only return one intent from the closed list. Replies are capped at 96 tokens, greedy decoding.
- If the model was enabled when VENEX starts, it is loaded in the background. If it is unloaded later (memory pressure), it is reloaded on the first command that needs it, and that load counts against the AI timeout.
- Only one model can be loaded, and load / test / import / settings changes never run at the same time (a
  second request is refused with a message).
- «تفريغ» unloads the model **and** disables it. If the system reports memory pressure (or low memory) the model
  is unloaded but stays enabled and reloads on demand. If inference fails because the device ran out of memory,
  the model is unloaded and **disabled** with the reason shown. Any other runtime failure or timeout is
  shown in the settings screen and that command is handled by the rules; the model stays loaded and enabled.
- Cancelling a command or hitting the timeout stops the native generation through a cancel flag.
- The audit log records state changes and failure kinds, never the command or the reply.

### Qwen3 and other "thinking" models (V0.1.3)

Qwen3 chat templates switch on a *thinking* mode by default: the model first writes `<think> … </think>` and only
then the answer. With the small token budgets VENEX uses (96 for a command, 48 for the test) the thinking used
the whole budget, so replies were cut and the inference test failed (V0.1.2 on a phone). From V0.1.3:

- for a template that contains `enable_thinking` or `<think>`, VENEX appends an empty think block to the prompt
  (`<think>` + blank line + `</think>` + blank line), which is what the template itself produces with thinking
  disabled, so the model answers directly;
- anything that still looks like reasoning (`<think>…</think>`, an unclosed `<think>…`, control tokens) is removed
  before the reply is parsed or tested; if nothing is left, it is a failure;
- a reply that stopped because it reached the token budget is a **failure** («توقّف الرد قبل اكتماله»), never
  shown as an answer.

This was derived from reading the code and templates and is covered by PC tests (a tiny Qwen3-style GGUF, unit
tests). **It has not been run with a real Qwen3 model or on a phone.** If the test still fails on your phone,
the screen shows the failure kind; please send it (never the model file or any key).

The screen's status line is deliberately strict: «محمّل في الذاكرة» only means the file was loaded;
«اجتاز الاختبار» means the model produced the expected answer; «يعمل» appears only when it passed the test, is
enabled **and** is loaded.

### What can go wrong

| Message / situation | Meaning |
|---|---|
| Not a GGUF / truncated file / unsupported version | The header check failed. Re-download the file. |
| Not enough free space | Needs `file size + 256 MB` free in app storage. Free space or pick a smaller model. |
| Not enough memory | The pre-check refused. Pick a smaller model or a smaller context, or close other apps. |
| Runtime could not start | The native library could not be loaded on this device (for example an unsupported ABI; only `arm64-v8a` is built by default). |
| Inference test failed | The model ran but did not give the expected fact, or it timed out. Try another model. |
| Original file moved / deleted / access revoked | The private copy keeps working; only a **new** import needs the original. |

### Cloud API path

See [`CLOUD_API.md`](CLOUD_API.md). Short version: your own key (stored encrypted with the Android Keystore),
HTTPS only, an explicit acknowledgement per host, and the text of commands the rules did not understand goes to
the provider you chose.

## Running VENEX without AI

Do nothing. The model is off by default, and every basic command (open an app, calculate, back/home,
scroll) works with the rules alone. If a model server, the cloud provider or the on-device model fails,
VENEX reports the failure in the settings screen and keeps working with the rules.

## Troubleshooting

| Message | Meaning and what to check |
|---|---|
| الخادم غير متاح أو المنفذ مغلق | Server not running, wrong address or port, or a firewall. |
| انتهت مهلة الانتظار | Server too slow or unreachable on the network. Try a smaller model or raise the timeout. |
| الخادم لا يستجيب كـ Ollama | The address points to a different kind of server. Choose the other provider type. |
| النموذج … غير موجود | Pull the model (`ollama pull`) or load it in your server. Use **اكتشاف النماذج**. |
| الخادم رفض بيانات الدخول | Enter the access key in the field, for this session. |
| الإجابة غير متوقعة | The server answered but the model did not give the expected fact. Try another model. |
| الخادم غير متاح أو المنفذ مغلق (on a release build with a LAN address over plain HTTP) | Android blocks cleartext HTTP to non-loopback hosts in release builds, so the request fails as unreachable. Use HTTPS, or a debug build for testing on a LAN. |
