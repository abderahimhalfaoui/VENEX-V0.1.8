# Tool & dependency versions (V0.1.3; unchanged from V0.1.2)

Declared in `gradle/libs.versions.toml` (single source of truth). The AI features add **no new
JVM/Maven dependencies**: HTTP uses `HttpURLConnection`, JSON uses the in-repo `MiniJson`, and the API key
store uses the platform Keystore. V0.1.2 adds a **native** toolchain and one pinned C++ library (below).

| Item | Version | Note |
|---|---|---|
| Gradle (wrapper) | 8.7 | minimum for AGP 8.5 |
| Android Gradle Plugin | 8.5.2 | |
| Kotlin | 1.9.24 | |
| Compose compiler | 1.5.14 | matches Kotlin 1.9.24 |
| Compose BOM | 2024.06.00 | Material 3 1.2.x |
| kotlinx-coroutines | 1.8.1 | |
| AndroidX Core KTX | 1.13.1 | |
| Lifecycle | 2.8.3 | |
| Activity Compose | 1.9.0 | |
| JUnit | 4.13.2 | |
| JDK | 17 | CI uses Temurin 17 |
| compileSdk / targetSdk | 34 | |
| minSdk | 26 | Android 8.0; primary target Android 11 (API 30), Xiaomi Redmi Note 8 Pro |
| Android NDK | 29.0.14206865 | `app/build.gradle.kts` (`ndkVersion`); installed in CI with `sdkmanager` |
| CMake | 3.22.1 | `app/build.gradle.kts`; installed in CI with `sdkmanager` |
| C++ | C++17, STL `c++_shared` | |
| llama.cpp | tag `b12627`, commit `225a5345bbb0e0c70859af5441ba922beb666fcf` | `third_party/llama.cpp.version`; MIT; not vendored, fetched and hash-checked by `scripts/fetch-llama-cpp.sh` |
| Native ABI | `arm64-v8a` (default) | `-Pvenex.abis=…` adds more; CPU only, no GPU backend |
| Native build type | Release (-O3), also for debug APKs | |
| Host smoke test deps | Python 3, `numpy pyyaml tqdm requests` | only for `native-host-test/` and its CI job (gguf-py) |

## Verification status

- **Core**: 207 unit tests pass (`core/src/test`): the 140 V0.1.1 tests (files unchanged) and 67 new ones, including real HTTP tests against a local server on 127.0.0.1. They ran with a local Kotlin compiler (2.0.21) and kotlinx-coroutines 1.6.4 taken from a Gradle distribution, because Gradle could not download plugins in the build environment. The project pins Kotlin 1.9.24 and coroutines 1.8.1; a difference between those versions would only show up in CI.
- **App**: `LlamaCppRuntimeTest` (13 tests, JVM, fake bridge) passed locally. `AppLayerTest` (3 V0.1.1 tests) exists and was not run locally. The rest of the app module (Compose, SAF, Keystore, JNI declarations) was **not compiled** here (no Android SDK).
- **Native**: the same `venex_llm.cpp` engine was built on a PC against the pinned llama.cpp and run on a generated tiny GGUF (`native-host-test/run.sh`): load, tokenise, generate, cancel, unload, error codes. **Not built with the NDK, not run on Android.**
- **Gradle, AGP, Compose, NDK 29 and CMake 3.22.1 interplay**: **not resolved or built here (no network)**. If Gradle reports a conflict, upgrade AGP, Kotlin and the Compose compiler together. NDK 29 with AGP 8.5.2 is a combination nobody checked here.
- **CI** (`.github/workflows/android.yml`) runs the host native test, the core tests, the app unit tests and a debug build with native libraries, verifies the native libraries/ABIs inside the APK, and saves reports and the APK. Its first run is the real check of the build; it has **not run yet**.

## V0.1.8
No version of any tool, library or dependency changed. Only `versionCode = 8` / `versionName = "0.1.8"` in `app/build.gradle.kts`
(and the matching APK check in `.github/workflows/android.yml`). Local verification used Gradle's bundled Kotlin compiler 2.0.21 at
`-language-version 1.9` — a harness, not the project toolchain (Kotlin 1.9.24).
