# VENEX V0.1.2 — On-device AI report (Experimental)

> **Superseded in part by V0.1.3.** The real-phone test of V0.1.2 failed with Qwen3 (see [`V0.1.3_REPORT.md`](V0.1.3_REPORT.md)). Sections below that say the inference test "passes" describe the PC/host results only; they never covered a Qwen3-style thinking model.

Status of this document: written by the code author **without** an Android SDK, without a phone and
without network access to Gradle/Maven repositories. Every claim below is labelled with how (and
whether) it was verified. **No APK was built and nothing was run on a device.** Where something could
only be checked on a PC, it says so. "NOT TESTED" means exactly that, not "probably works".

## 1. What was built

V0.1.2 adds a second, independent way to answer commands the offline rules do not understand:

| Mode | What it is | Needs |
|---|---|---|
| OFF (default) | Rules only. Nothing leaves the phone, no model is loaded. | nothing |
| SERVER | Ollama / OpenAI-compatible server you run (V0.1.1 behaviour, unchanged). | a reachable server |
| ON_DEVICE (new) | A GGUF model file you picked, run inside VENEX by llama.cpp (JNI/NDK). | the model file; **no** internet, server, helper app, root or API key |
| CLOUD (new) | A hosted OpenAI-compatible API with **your** API key. | internet + your key; see `CLOUD_API.md` |

Exactly one mode is active at a time (`AiModeRouter`). Switching away from a mode disables it. The
model (any mode) only sees commands the rules did not understand, may only propose one intent from
the closed list (`open_app`, `calculate`, `navigate`, `scroll`), and cannot issue actions. Restricted
actions are refused before any parser; planner, SafetyPolicy, ExecutionEngine and Verifier are
unchanged.

## 2. Runtime: llama.cpp

| Item | Value |
|---|---|
| Runtime | llama.cpp (with its ggml library), https://github.com/ggml-org/llama.cpp |
| Pinned tag / commit | `b12627` / `225a5345bbb0e0c70859af5441ba922beb666fcf` (`third_party/llama.cpp.version`) |
| License | MIT (`app/src/main/assets/licenses/llama.cpp-LICENSE.txt`, `THIRD_PARTY_NOTICES.md`) |
| How it is obtained | Not vendored. `scripts/fetch-llama-cpp.sh` fetches exactly that commit and **fails if the hash differs**. CI runs it before building. |
| Why this runtime | GGUF is the file format you asked for, and llama.cpp is its reference implementation, actively maintained, MIT-licensed, with an official Android CPU build path (ARM CPU variants, NDK CI). It needs no server and no extra app. |
| Not evaluated in depth | Other on-device stacks (for example MediaPipe LLM Inference, ExecuTorch, MLC LLM). They use other model formats or tooling; they were not benchmarked or compared here. |
| Caveat | The native glue (`venex_llm.cpp`) is written against this exact commit's C API (`llama_batch_ext_*`, `llama_process`, `llama_memory_clear`, `mparams.load_mode`). llama.cpp's C API changes often, so moving the pin to another tag is not a one-line change: the glue must be re-checked and the host test re-run. The pinned commit has no field history inside VENEX. |

### Build configuration (`app/src/main/cpp/CMakeLists.txt`)

- NDK `29.0.14206865` (the version llama.cpp's own Android CI uses), CMake `3.22.1`, STL `c++_shared`, `ANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON` (16 KB page-size devices).
- Native code is always built `Release` (-O3), also for the debug APK; unoptimised inference is unusably slow.
- CPU only. `GGML_BACKEND_DL=ON` + `GGML_CPU_ALL_VARIANTS=ON`: several CPU variants are built (for arm64: `android_armv8.0_1` as the baseline, then ARMv8.2 (dot-product, optionally FP16), ARMv8.6 (i8mm) and ARMv9 variants) and ggml picks the best one the phone supports **at run time**. The baseline is plain ARMv8.0, so older CPUs are not excluded.
- Off: GPU/Vulkan/OpenCL, OpenMP, KleidiAI, llamafile, native tuning (`GGML_NATIVE=OFF`), and the llama.cpp common library, tools, tests, examples, server, curl and OpenSSL.
- `extractNativeLibs="true"` + `useLegacyPackaging = true`: ggml's CPU variants are shared libraries found by scanning `nativeLibraryDir`, so they must exist on disk. This makes the installed app larger on disk than a compressed-in-APK layout.
- ABIs: `arm64-v8a` only by default. `-Pvenex.abis=arm64-v8a,x86_64` (or the workflow input `abis`) adds others. Other ABIs are not part of any check here.
- Selected variant and CPU features are reported by the runtime (`system_info`) and shown in the settings screen; whether the variant that gets selected on a Redmi Note 8 Pro is a good one is **not tested**.

## 3. Architecture

```
core (pure JVM, no Android/JNI)                      app (Android)
─────────────────────────────────                    ─────────────────────────────
CompletionBackend ◄─ ModelProvider adapters          LlamaCppRuntime ──► JniLlamaBridge ──► libvenex_llm.so
        ▲            (Ollama/OpenAI/Cloud)                 ▲                 (JNI)             └► libllama / libggml*
        │                                                  │ implements LlmRuntime
OnDeviceController ──► LlmRuntime (interface)        AndroidModelFileGateway (SAF, import, free space)
   state machine,     ModelFileGateway (interface)   KeystoreSecretStore (AES-GCM, Android Keystore)
   fingerprint,       OnDeviceStore / AiModeStore    SharedPrefs*Store (settings, mode, on-device)
   memory policy      SecretStore                    AiSettingsActivity/Screen (three panels)
        ▲
AiModeRouter ─► DelegatingAiProvider ─► LayeredIntentParser (rules → model; unchanged)
```

- `core` owns every decision (states, gating, fingerprint, memory refusal, GGUF header check, import logic). It knows the Android layer only through small interfaces, so all of it runs under plain JVM tests with fakes.
- `app` owns everything that touches Android: SAF, Keystore, SharedPreferences, JNI, Compose.
- On-device is **not** modelled as a server `ProviderType` with a fake URL. Its settings (`StoredOnDevice`) are separate from `LocalModelConfig`, so a URL and a file can never be mixed.
- The same system prompt and the same `ModelReplyParser` serve all providers (`ModelIntentProvider` takes any `CompletionBackend`), so on-device output is parsed with exactly the rules that apply to server output. On-device replies are capped at 96 tokens (`ON_DEVICE_MAX_TOKENS`); the inference timeout is 35 s and the overall AI timeout 40 s (`LayeredIntentParser`). These values are **estimates, not measurements**.

### Native layer (`app/src/main/cpp`)

- `venex_llm.cpp`: one engine, one mutex (no concurrent load or completion), an atomic cancel flag (checked by llama.cpp's abort callback and the model-load progress callback), chat template from the GGUF (with a plain-text fallback), tokenisation, chunked prompt decode, greedy sampling, 8-token headroom, all C++ exceptions caught, explicit error codes (`ERR_*`, mirrored by `NativeError` in Kotlin).
- `venex_llm_jni.cpp`: thin JNI glue (`JniLlamaBridge`), UTF-8 returned as bytes (avoids Java modified-UTF-8 problems), llama.cpp logs go to logcat. Prompts and replies are **not** logged.
- `LlamaCppRuntime` (Kotlin) runs every native call on a dedicated background dispatcher (never on Main), turns cancellation into the native cancel flag, and maps native errors to `FailureKind`.

## 4. Choosing and importing the GGUF file

1. The owner taps «اختيار ملف GGUF من الهاتف» (panel «داخل الهاتف»). The app uses the Storage Access Framework (`ActivityResultContracts.OpenDocument`, i.e. `ACTION_OPEN_DOCUMENT`). **No storage permission is requested.**
2. The app takes a persistable read grant when the provider allows it (failure is tolerated).
3. Pre-checks: file name ends with `.gguf` (a split file named `*-00001-of-0000N.gguf` is rejected with an explanation), size known and > 0, readable, then the **GGUF header is parsed** (magic, version 2–3, bounded counts and string sizes, arrays skipped, architecture/name/context length/file type read when present). The extension alone is never trusted; a non-GGUF or truncated file produces a specific Arabic message.
4. Import (copy). Free space is checked first (`file size + 256 MB`), then the file is streamed to `filesDir/models/model.gguf.part` with progress, SHA-256 computed while copying, and atomically renamed on success. Cancel or failure deletes the partial file. **The original is never modified or deleted.** Choosing a new file removes the previous private copy. No absolute path of the original or of the copy is persisted — only the SAF URI string and the file name; the private copy is located by its fixed name.
5. Memory pre-check at load (`MemoryGuard`): refuse if measured available RAM is below `0.85 × file size + 192 MB` (a conservative guess, **not** a prediction), warn if the system reports low memory, warn (not block) when it cannot measure. The settings screen says explicitly that the GGUF size is **not** the RAM used while running (the weights are memory-mapped; the KV cache and compute buffers come on top).

**Deviation from requirement 4 (decision for you).** The task prefers reading directly from the URI/descriptor when the runtime supports it. The pinned llama.cpp does have `llama_model_load_from_file_ptr(FILE*)`, so a `dup`'d SAF file descriptor wrapped in a `FILE*` might avoid the copy. It was **not implemented**, because it cannot be verified here and has real unknowns: SAF providers can return non-seekable or non-mmap-able descriptors, the URI permission can be revoked or the file moved between launches, and mmap needs 32-byte data alignment. The copy is deterministic and testable but **doubles the storage used and takes time for multi-GB models** (the progress bar and the free-space check exist for that reason). If you want the direct path, it is a contained change (`AndroidModelFileGateway` + one native entry point) that should be proven on your phone first.

## 5. Lifecycle, states and memory policy

States: `NOT_SELECTED → FILE_SELECTED → IMPORTING → READY → LOADING → LOADED → TESTING`, plus `UNLOADING` and `ERROR`. Transient states are never persisted.

- **No concurrent heavy operations.** Select, import, load, test, change settings and clear are mutually exclusive (`tryLock`; a second request is refused with a message, not queued). Only one model can ever be loaded.
- **Gating.** Enabling is refused unless a **real inference test passed for the current fingerprint** = SHA-256 of the imported file + its size + context length + threads. Changing the file, context or threads invalidates the test and disables the model. The test sends the same Arabic probe as server modes («أجب بكلمة واحدة: ما عاصمة الجزائر؟») to the loaded model and checks the answer; a model that does not know the answer fails the test even though it ran. This is strict on purpose and may reject small models that run fine.
- **Loading.** If the model was enabled at app start it is loaded in the background (`restoreIfEnabled`). When it is enabled but unloaded (after memory pressure), it is loaded on the first command that needs it (inside the AI timeout). A cancelled or timed-out command cancels native work through the cancel flag.
- **Unload policy.** Owner taps unload → model unloaded **and disabled**. System memory pressure (`TRIM_MEMORY_RUNNING_CRITICAL`, `TRIM_MEMORY_BACKGROUND` and above, `onLowMemory`) → unloaded but **stays enabled** and reloads lazily. Inference failing with out-of-memory → unloaded and **disabled** with the reason shown. Any other runtime failure or timeout is shown in the settings screen and that command falls back to the rules; the model stays enabled. The app does not unload merely because its screen is hidden (VENEX works on other apps in the background).
- **Defaults are conservative.** Context 1024 (options 512/1024/2048/4096), threads `clamp(cores/2, 2, 4)` (user max 8). Greedy decoding, short replies.
- **Failure never crashes the command path.** Runtime error, timeout, not-ready, out-of-memory → the rules' result (`UnknownGoal`) with a visible message; verified by JVM tests with a fake runtime.

## 6. Cloud mode (summary)

Full details: `CLOUD_API.md`. Key points: OpenAI-compatible `/v1/chat/completions` only; HTTPS required, loopback rejected; API key stored with AES-256-GCM under an Android Keystore key (`venex_api_keys_v1`), never shown, logged, audited, exported or sent anywhere except the chosen provider; sending requires an explicit acknowledgement naming the host («أوافق على إرسال الأوامر غير المفهومة محلياً إلى <host> عبر الإنترنت»); the settings screen states what is sent (the text of commands the rules did not understand plus a fixed system prompt) and what is not; deleting or replacing the key is available at any time.

## 7. What was actually run, and what it proves

Environment: Linux container, JDK 17, no Android SDK, **no access to Google/Maven repositories** (so the real Gradle/AGP build could not run), g++/cmake/Python available.

| Check | Result | What it proves | What it does not prove |
|---|---|---|---|
| Core unit tests: **207 tests** (the 140 V0.1.1 core tests, in files byte-identical to V0.1.1, plus 67 new ones for on-device states, gating, fingerprint, GGUF parser, importer, memory guard, router, migration and cloud key handling) | all passed (re-run at the end of this work) | Core logic under JVM with fakes and local HTTP servers | Real inference; Android behaviour |
| App-module unit tests for `LlamaCppRuntime`: **13 tests** (fake bridge: dispatcher, cancellation, error mapping, UTF-8, timeouts) | all passed (re-run at the end). `AppLayerTest` (3 V0.1.1 tests, file unchanged) was **not** run locally because it sits in the Android module; CI runs it | Kotlin wrapper logic | Real JNI/native behaviour |
| Native host test (`native-host-test/run.sh`): fetches the pinned llama.cpp, builds the **same** `venex_llm.cpp` on the PC, generates a tiny random-weight GGUF, loads it, tokenises, generates tokens, cancels mid-generation, unloads, and checks error codes | passed (`ALL HOST NATIVE CHECKS PASSED`) | The engine logic works against the pinned llama.cpp API with a real GGUF file (real load/decode/sample/cancel code paths) | Android NDK build, ARM variants, JNI glue, phone performance. The model has random weights: it proves the pipeline, **not** language ability |
| JNI glue `venex_llm_jni.cpp`: syntax-only compile (`g++ -fsyntax-only -Wall -Wextra`) on the PC against the JDK's real `jni.h`, the pinned llama.cpp headers and a stub `android/log.h`; also compared by inspection (not by script): all 11 `Java_com_venex_app_llm_JniLlamaBridge_*` exports match the `external fun` declarations in `LlamaBridge.kt` (names and parameter/return types) | passed, no warnings | The JNI file parses and its symbols match the Kotlin side | An NDK build, linking, or running on Android |
| Kotlin compile of `app` module | **NOT RUN** (no SDK) | — | Compose/Android API usage was reviewed by reading only; compile errors are possible and would show up in the first CI run |

The local Kotlin harness used for the two JVM suites compiled with Kotlin 2.0.21 and coroutines 1.6.4 (Gradle's bundled jars), whereas the project pins Kotlin 1.9.24 and coroutines 1.8.1 (`libs.versions.toml`). A source incompatibility between those versions would only appear in CI.

## 8. CI (`.github/workflows/android.yml`) — what it will do

Job **native-host-test** (ubuntu): installs the Python deps for the test model, runs `native-host-test/run.sh`, writes the key lines to the run summary, uploads the log.

Job **build-and-test** (ubuntu): JDK 17 → wrapper validation → install `ndk;29.0.14206865` and `cmake;3.22.1` through `sdkmanager` → `scripts/fetch-llama-cpp.sh` (hash-verified) → `./gradlew :core:test` → `./gradlew :app:testDebugUnitTest` → `./gradlew :app:assembleDebug -Pvenex.abis=<abis>` (log kept) → **APK check**: fails the job unless `lib/<abi>/` contains `libvenex_llm.so`, `libllama.so`, `libggml.so`, `libggml-base.so`, `libc++_shared.so` and at least one `libggml-cpu-*.so`, unless an ABI that was not requested is present, or if any `.gguf/.ggml/.safetensors` file, or any non-library file over 50 MB, is inside the APK → test summary table → uploads: `venex-debug-apk`, `native-build-summary` (build log + native library list), `test-reports`, `native-host-test-log`.

**None of this has run yet.** The first run is the real test of: Gradle/AGP/Kotlin/Compose version compatibility, the Compose/Android code, NDK 29 + CMake 3.22.1 + llama.cpp b12627 for arm64, APK size and build time. Expect that a first run may need fixes.

## 9. Acceptance criteria

Rule used for the **Status** column: a criterion is **PASS** only if everything it demands was actually
demonstrated by something that ran (named in *Evidence*). If any part needs the Android build or a phone,
the criterion is **NOT TESTED** and the evidence column says which parts *were* proven (always on a JVM or on
a PC, never on Android). **FAIL** = known not met. Nothing here is marked PASS on the strength of code
review alone.

| # | Criterion (task file) | Status | Evidence / what is missing |
|---|---|---|---|
| 1 | Local runtime inside the APK; runtime / tag / license / why / build documented | NOT TESTED | Implemented (llama.cpp `b12627` via JNI) and documented in this file. The APK was not built. The engine ran on a PC only (section 7) |
| 2 | Separate, clear "on-device" mode in the AI settings | NOT TESTED | Three panels («داخل الهاتف» / «سحابي (API)» / «خادم») and a mode line written in Compose; never compiled or displayed |
| 3 | File chosen via SAF, no broad storage permission | NOT TESTED | `ActivityResultContracts.OpenDocument`; the manifest requests only `INTERNET`. Not run |
| 4 | Persistable URI; copy with free-space check, progress, cancel, no partial file, original untouched; avoid unnecessary copy | NOT TESTED | Importer logic proven on JVM (free space, progress, cancel cleanup, atomic rename, SHA-256, original unchanged). SAF/real streams not run. **Deviation:** the copy is always made (section 4) |
| 5 | File pre-checks incl. GGUF header; clear errors | PASS | JVM tests: bad magic, truncated file, absurd counts/sizes, unsupported version, split-file names, wrong extension, missing size, unreadable file. Messages are Arabic strings in `core` |
| 6 | States; no concurrent heavy operations; one loaded model | PASS | JVM tests with a fake runtime: state transitions, exclusive operations (second request refused), single load |
| 7 | Real inference test, not a mock, before enabling | NOT TESTED | The gate (test required for the current fingerprint) is proven on JVM with a **fake** runtime. The real engine generated tokens on a PC from a random-weight GGUF only. No real model, no Android |
| 8 | Enable only after a passing test for the same file+settings; model sees only unknown commands; OFF by default | PASS | JVM tests: refusal before test, invalidation on file/context/threads change, default OFF, router never consults a provider for commands the rules understand |
| 9 | Integrated with `LayeredIntentParser`; closed intent list, safety policy, planner, verifier unchanged; model cannot act | PASS | `diff` against V0.1.1: packages `intent`, `planner`, `engine`, `verify`, `safety`, `device`, `audit`, `model` are byte-identical; `ModelReplyParser` body unchanged; all 140 V0.1.1 core tests (identical files) pass; JVM integration tests with the on-device and cloud providers |
| 10 | Ollama / OpenAI-compatible still work; V0.1.1 settings still load; cloud added | PASS (local servers only) | The V0.1.1 provider/adapter tests pass unchanged against local HTTP test servers; JVM migration tests (enabled V0.1.1 server config → SERVER mode). No real Ollama, LM Studio or cloud provider was contacted |
| 11 | On-device mode works with no internet / server / helper app / root / API key | NOT TESTED | By construction the on-device path has no network code. Never run on a phone |
| 12a | No model or key in Git | PASS | Source tree contains no `.gguf`/key files (`find`); `.gitignore` excludes `*.gguf`, `*.safetensors`, keystores, `secrets.properties`; secret scan of the ZIP found nothing |
| 12b | No model or key in the APK | NOT TESTED | The APK was not built. The CI job fails the build if it finds `.gguf`/`.ggml`/`.safetensors` or a non-library file > 50 MB (the size check was tested on a synthetic zip); not run in CI yet |
| 13 | API keys in Keystore-backed storage, hidden, never logged/audited/exported; delete/change | NOT TESTED | `KeystoreSecretStore` was never run. JVM tests with a fake `SecretStore` prove the controller keeps the key out of snapshots, audit lines, errors and `toString`, and that change/delete invalidate the verification |
| 14 | User is told when data goes to the cloud; nothing sent unless the owner chose and enabled it | PASS for behaviour / NOT TESTED for UI | JVM tests: no request without CLOUD mode + host acknowledgement + key + passing test. The disclosure texts exist in the Compose code but were never rendered |
| 15 | UI shows runtime state, file name, size, memory info only when measured, failures; no unmeasured claims | NOT TESTED | Written in Compose, not displayed. No benchmark number appears anywhere in code or docs; memory figures shown come from the system's measured available memory |
| 16 | Settings persisted safely; commands not in audit; lifecycle; cancel stops work; native resources freed; unload policy | NOT TESTED | JVM: cancel, unload, memory-pressure policy, audit content, persistence of enabled/verified state. PC host test: cancel mid-generation, unload, error codes. Android lifecycle (`onTrimMemory`) not run |
| 17 | CPU baseline, no GPU requirement, arm64-v8a, no raised CPU requirement | NOT TESTED | CMake options reviewed (ARMv8.0 baseline variant + runtime-selected faster variants); no NDK build, no APK inspection |
| 18 | Conservative context/threads; explains that GGUF size is not RAM | NOT TESTED | Defaults (ctx 1024, threads `clamp(cores/2,2,4)`) and limits are covered by JVM tests; the explanatory text is in the Compose code, not rendered |
| 19 | Philosophy unchanged (local-first, owner control, verification) | PASS | Same evidence as 9: untouched packages are byte-identical; AI is off by default; every cloud/on-device path is opt-in |
| A1 | `core` stays pure JVM (no Android/JNI) | PASS | `grep` finds no `android.*` import or `loadLibrary` in `core/src/main`; core tests run on a plain JVM |
| A2 | Coroutine-friendly runtime manager; no inference on Main | NOT TESTED | `LlamaCppRuntime` dispatcher/cancel logic proven by 13 JVM tests with a fake bridge; real JNI calls not run |
| A3 | Provider chosen through a registry/router; on-device is not a fake-URL server | PASS | `AiModeRouter` + separate `StoredOnDevice` settings; JVM router tests |
| A4 | Separate on-device settings; V0.1.1 migration | PASS | JVM tests (settings round trip, migration of an enabled V0.1.1 config) |
| A5 | No trusted absolute paths; moved / deleted / revoked files handled | NOT TESTED | JVM gateway fakes cover missing/unreadable files and the private copy; real SAF revocation not run |
| B1 | minSdk 26 kept | PASS (config) | Unchanged in `app/build.gradle.kts`; not run on Android 8 |
| B2 | Practical performance on Android 11 / Redmi Note 8 Pro | NOT TESTED | No device; **no performance claim is made anywhere** |
| B3 | CI installs NDK/CMake, builds the APK, runs old + new tests, verifies native libs/ABI, keeps logs | NOT TESTED | Workflow written and parsed as valid YAML; it has not run |
| B4 | Runtime and dependencies pinned | PASS | llama.cpp tag + commit with hash check in the fetch script; NDK `29.0.14206865`, CMake `3.22.1`, Gradle/AGP/Kotlin pinned. (Whether the pinned set builds together is NOT TESTED, see B5) |
| B5 | APK size, build time, toolchain compatibility, licenses / NOTICE | NOT TESTED | License text and `THIRD_PARTY_NOTICES.md` added. Size, build time and compatibility unknown until the first CI run |
| T1 | Unit tests for states, gating, parser limits, fallbacks, Ollama/OpenAI, migration | PASS | 207 core tests + 13 `LlamaCppRuntime` tests passed locally, re-run at the end of this work (with different Kotlin/coroutines versions than the project's, section 7) |
| T2 | `:core:test`, `:app:testDebugUnitTest`, `:app:assembleDebug`, native libs / ABI verified | NOT TESTED | None of the three Gradle tasks ran here; defined in CI |
| T3 | Device validation list and results | NOT TESTED | Guide and log template in section 11; no device available |

## 10. Known limits

- Copy-import doubles storage and takes time for big files (section 4).
- Split GGUF files (`-0000N-of-0000N`) are not supported.
- The Arabic probe is strict. A small model may run correctly yet answer in a form the probe rejects; then it cannot be enabled. The check is not relaxed because it is the only gate between "the file runs" and "VENEX may use it".
- A small model can propose a valid but wrong intent. Planner/safety/verification still decide, but the wrong app can still be opened.
- Time and memory limits (35 s inference, 40 s overall, 96 tokens, memory guard thresholds) are tuned by reasoning, not measured on a phone.
- The native build is CPU only; speed on a Redmi Note 8 Pro (Helio G90T) with a 1–3 B model may be slow. Nothing is claimed.
- `libggml-cpu-*` variants and `extractNativeLibs=true` increase installed size.
- Debug builds allow cleartext HTTP to any host (pre-existing V0.1.1 debug-only overlay; release allows it for loopback only); cloud mode rejects non-HTTPS regardless.
- Cloud provider presets (OpenAI `https://api.openai.com`, OpenRouter `https://openrouter.ai/api`, Groq `https://api.groq.com/openai`) were checked against each provider's public documentation on 2026-11-22 (their documented base URLs end in `/v1`, which VENEX appends itself). No request was ever sent to any of them.

## 11. Device validation guide (to be run by you)

Do these on the Redmi Note 8 Pro (Android 11) with the CI-built APK. Do not paste commands, prompts or keys into the log.

1. Install the `venex-debug-apk` artifact. Open VENEX → AI settings → on-device panel.
2. Pick a small GGUF (for example a 0.5–1.5 B Q4 instruct model) from Downloads. Expected: name/size shown, header summary shown, no permission prompt.
3. Import. Expected: progress; free-space refusal if there is not enough space; cancel leaves no `.part` file.
4. Load. Expected: state LOADED, runtime info shown, measured available memory shown.
5. Run the inference test. Expected: either pass, or a clear failure with the reason. Record it.
6. Enable. Send a command the rules do not know (for example a paraphrase of «افتح الآلة الحاسبة»). Expected: the step report shows the model as the intent source and the action is verified as usual. Send a restricted command; expected: refused before any model.
7. Interrupt a running inference (send another command or cancel). Expected: no crash; state returns to LOADED or READY.
8. Unload. Expected: state READY, model disabled.
9. Negative cases: a corrupt/truncated GGUF, a non-GGUF file, cancelling the picker, a file larger than free space, a model that does not fit in RAM.
10. Revoke access / move / delete the original; reopen the app. Expected: the private copy still works.

Record (fill in; this table is the only evidence to put in the repo):

| Field | Value |
|---|---|
| Date / VENEX build (CI run id) | |
| Device / Android / free RAM before load | |
| Model name, parameters, quantisation, file size | |
| Selected CPU variant (from runtime info) | |
| Import time | |
| Load time | |
| Inference test: pass/fail, time | |
| Latency of a typical command; tokens/s if you measured it | |
| Approx. RAM during use (how measured) | |
| Temperature / stability notes | |
| Failures seen (messages only) | |

## 12. Unresolved decisions and risks

1. **Copy vs direct descriptor** (section 4): decide whether the storage cost is acceptable, or ask for the direct path.
2. **First CI run** can fail for reasons not visible here (Kotlin 1.9.24 vs the harness's 2.0.21, AGP/NDK 29/CMake interplay, `ndk;29.0.14206865` availability in the runner image, llama.cpp b12627 being brand new).
3. **Strict Arabic probe** may reject capable small models.
4. **Memory guard thresholds and the 35 s / 40 s timeouts** are untuned guesses.
5. **Cloud**: privacy depends on the provider you choose. Data sent = the text of commands the rules did not understand plus the fixed system prompt. The acknowledgement is stored per host; individual requests are not written to the audit log (and neither are their contents).
6. **Model quality** (Arabic understanding) is unknown until you run it.
7. **App size**: ARM CPU variants + `c++_shared` + `libllama` add tens of MB. Unmeasured.
