# VENEX V0.1.3 — Cloud API mode (your own API key)

> Cloud behaviour is unchanged in V0.1.3 except: the key field now really uses the password keyboard type, and the settings screen states that both tests contact the provider.

Optional. Off by default. It is the fourth AI mode, next to OFF, SERVER (your own Ollama/OpenAI-compatible
server) and ON_DEVICE (a GGUF model inside VENEX). Only one mode is active at a time.

**This path sends data to a third party.** When it is active, the text of commands the offline rules did not
understand leaves your phone and goes to the provider you chose. Read "What is sent" before enabling it.

## What it is

An OpenAI-compatible hosted API: VENEX calls `POST {base}/v1/chat/completions` (and `GET {base}/v1/models`
for model discovery) with `Authorization: Bearer <your key>`. You supply the base address, the model name and
your own API key. VENEX has no account, no key and no server of its own.

## What is sent, and what is not

| Sent to the provider | Never sent |
|---|---|
| The text of a command **that the offline rules did not understand** (at most 300 characters), together with a fixed system prompt that lists the four allowed intents. | Commands the rules understand (they never reach any model). |
| When you press **اختبار الاتصال**: a model-list request, with your key. | Commands refused as restricted (send / post / delete / pay): refused before any model. |
| When you press **اختبار الاستدلال**: the fixed question «أجب بكلمة واحدة: ما عاصمة الجزائر؟». | Screen contents, accessibility trees, app lists, the audit log, your files or contacts. |
| Your API key (as the bearer token, over HTTPS, to the host you entered only). | Anything at all while the mode is not CLOUD, or before you acknowledged the host. |

The provider's own retention, logging and pricing rules apply to what it receives. VENEX cannot change them
and does not check them. Use a provider and plan whose policy you accept. Usage may cost money.

## Setting it up

1. AI settings → **سحابي (API)**.
2. Pick a preset or choose **مخصص** and type the base address. HTTPS only. Enter the address **without** `/v1`
   (VENEX appends `/v1/chat/completions` itself).
3. Enter the model name (or press **اكتشاف النماذج** after saving the key).
4. Enter your API key. It is hidden as you type; after saving, the field is cleared and the screen only says
   «محفوظ (مخفي)».
5. **حفظ**, then **اختبار الاتصال**, then **اختبار الاستدلال**. Both tests contact the provider.
6. Tick the acknowledgement «أوافق على إرسال الأوامر غير المفهومة محلياً إلى <host> عبر الإنترنت» and press
   **تفعيل المزوّد السحابي**. This is refused unless: the settings are saved, an API key exists, the inference test
   passed for the current address + model + key, and the acknowledgement was given for **this** host.

Switching to another mode disables the cloud provider. Changing the address, the model name or the key
disables it and requires new tests. The acknowledgement is stored for one host only; it does not carry over to another address.

### Presets

| Preset | Base address entered | Final chat URL |
|---|---|---|
| OpenAI | `https://api.openai.com` | `https://api.openai.com/v1/chat/completions` |
| OpenRouter | `https://openrouter.ai/api` | `https://openrouter.ai/api/v1/chat/completions` |
| Groq | `https://api.groq.com/openai` | `https://api.groq.com/openai/v1/chat/completions` |

The addresses were compared with each provider's public documentation on 2026-11-22. **No request has ever been
sent to any of them from this project**; they were not tested with a real key. Providers change their API
paths and model names; if a test fails, check the provider's documentation. The address stays editable.

## How the key is stored

- Encrypted with AES-256-GCM using a key held in the **Android Keystore** (alias `venex_api_keys_v1`; the key material
  never leaves the Keystore, and whether it is hardware-backed depends on the device, which was not checked here). The ciphertext sits in app-private SharedPreferences `venex_secrets`;
  the entry name is bound to the encryption as associated data.
- The key is never shown again, never written to logs, the audit file, crash text, error messages or any
  export, and is not part of `toString()` of any settings object. The audit log only records that a key was
  saved or deleted.
- `allowBackup="false"`, so the encrypted value is not copied to cloud backups. If you uninstall the app or the
  Keystore key is lost (for example after some OS restores), the key must be entered again.
- **حذف المفتاح** removes only the key. **حذف الإعداد والمفتاح** removes the key, the address, the model name and
  the acknowledgement.
- If the Keystore write fails, VENEX refuses to save the key (generic message, no detail) instead of falling back to plain text. A stored value that cannot be decrypted is dropped, and you enter the key again.

The key field uses the password keyboard type (so the keyboard should not suggest or learn it; that is a request to the keyboard app, not a guarantee). A key you paste is still visible to clipboard apps on your phone while it is on the clipboard. Prefer a
key restricted by the provider (spending limit, single project) and revoke it at the provider if the phone is lost.

## Rules that always apply

- HTTPS only; loopback addresses are rejected; redirects are not followed; replies are capped at 1 MB;
  an address may not contain credentials, a query or a fragment (`EndpointRules.validateCloud`).
- The model only returns one JSON object from the closed intent list. It cannot issue actions. The planner,
  SafetyPolicy, ExecutionEngine and Verifier are the same as for rule-based goals.
- If the provider is unreachable, slow, fails with an HTTP error (including rate limits), rejects the key or answers badly, the command is handled
  by the offline rules' result (`UnknownGoal`) and the settings screen shows the failure kind. Nothing is retried
  silently and nothing is guessed.

## Not verified

- No real provider, key or network call was exercised. Tests use a local HTTP server that implements the
  documented wire shapes, and a fake key store.
- `KeystoreSecretStore` was not run on a device (no Android SDK here).
- Behaviour of each provider's model names, error codes and rate limits.
