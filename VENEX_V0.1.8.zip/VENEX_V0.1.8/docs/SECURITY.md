# VENEX V0.1.3 — Security & control

| Rule | How it is enforced |
|---|---|
| No Root | No root APIs. Public SDK only. |
| No self-granted permissions | The app only opens system Settings; the user enables Accessibility. Permissions requested: `INTERNET` (only to reach a model server or cloud API that **you** configured; the on-device mode needs no network). The GGUF file is chosen with the system file picker (SAF), so **no storage permission** is requested. No dangerous runtime permissions. |
| No send / post / delete / pay without explicit approval | `RestrictedActionDetector` runs before any parser, including the model. Restricted goals yield no steps and the engine reports `NOT_EXECUTED`. Steps marked `needsConfirmation` wait for the user; the default handler denies. |
| No login / CAPTCHA bypass | `SafetyPolicy` stops the task when CAPTCHA or "not a robot" markers appear. No code solves or skips them. |
| No secret extraction | Password field text is never read into snapshots and is never typed into. Typed text is never written to the audit log (only its length). |
| Safe links | Deep links limited to `https`, `http`, `geo`, `mailto`. `intent:`, `file:`, `content:`, `javascript:` are refused. |
| No false success | `SUCCESS` only with verified evidence. See `ARCHITECTURE.md`. |
| Model isolation | The model returns data, not code or actions. Its output is restricted to a closed vocabulary and re-screened by the restricted detector. It cannot skip safety checks, planning, or confirmation. |
| Local model (server) credentials | The session key is held in memory only. It is never written to preferences, the audit log, or error messages. `ConnectionSpec.toString()` hides it. Settings are stored without it. |
| Cloud API key (V0.1.2) | Encrypted with AES-256-GCM under a key in the **Android Keystore** (`venex_api_keys_v1`); only `iv‖ciphertext` is stored (private prefs `venex_secrets`), with the entry name bound as associated data. Typed in a hidden field, cleared after saving, never displayed again, never in logs, audit, errors, state objects or exports. Saving fails (no plain-text fallback) if the Keystore write fails. Deletable at any time. Not in the APK or in Git. |
| Cloud data flow (V0.1.2) | Nothing is sent unless the mode is CLOUD **and** the owner acknowledged this exact host **and** a key exists **and** the inference test passed. Only the text of commands the rules did not understand (≤ 300 characters) plus a fixed system prompt is sent. Restricted commands and commands the rules understand are never sent. The UI states this. Switching mode, or changing address / model / key, disables the provider. HTTPS only; loopback rejected. |
| On-device model (V0.1.2) | The model file is user-supplied, never bundled. It is read only by the llama.cpp parser after a bounded GGUF header check (versions 2–3; limits on entries, tensors, strings, header size; arrays skipped). The runtime has no network code on the on-device path and no way to produce actions. A native crash would still take the app down (see residual risks). |
| Model files and keys in the repo / APK | `.gitignore` excludes `*.gguf`, `*.safetensors`, keystores and `secrets.properties`. The CI job fails if the APK contains `.gguf`, `.ggml` or `.safetensors` files, or any non-library file larger than 50 MB. (The CI job has not run yet.) |
| Local model network | Redirects are not followed. Responses are capped at 1 MB. Base addresses may not contain credentials, query, or fragment. |
| Cleartext HTTP | Release builds allow cleartext only to `localhost` and `127.0.0.1` (`app/src/main/res/xml/network_security_config.xml`). A debug-only overlay allows HTTP on a LAN for development; it is not packaged in release builds. |
| Error messages | Server bodies are never echoed into error messages. |
| Audit content | The audit log records outcomes, failure kinds, model call events and on-device state changes (import / load / unload / enable / disable). It does not record commands, model replies, model file paths, or keys. It records that an API key was saved or deleted, not the key. |
| Data locality | App-private files only: `filesDir/audit.jsonl` (rotated at about 512 KB), `filesDir/models/` (the imported GGUF copy), and SharedPreferences `venex_ai_settings`, `venex_ai_cloud_settings`, `venex_ai_mode`, `venex_on_device`, `venex_secrets`. `allowBackup="false"`. No analytics, no telemetry. The persisted on-device settings keep the file name and SAF URI string, never an absolute path of the original. |
| Package visibility | `<queries>` for launcher activities instead of `QUERY_ALL_PACKAGES`. |
| Exported components | Recognition service requires `BIND_RECOGNITION_SERVICE`. Settings activity is not exported. |

## Residual risks

- Accessibility is a powerful capability. Enable it only when needed and only in builds you trust.
- The rule-based detector is keyword-based (Arabic and English). It errs toward refusing, but it is not a complete safety classifier.
- A model on a non-loopback address is reached over your network. Any device on that network that can reach the server can also use it. Use a server you trust, and prefer HTTPS.
- A model can propose a valid but wrong command (for example, an app that does not match the user's intent). The planner and verification still apply, but the wrong app can be opened.
- Audit entries may contain on-screen text (for example a calculator result) as evidence. Clear the log when needed.
- A cloud provider receives the text of the commands sent to it and applies its own retention and privacy policy. VENEX cannot control or verify that. Use a restricted key and revoke it if the phone is lost.
- The key is visible to the on-screen keyboard and any clipboard manager while you type or paste it. The Keystore protects it at rest, not while it is being entered or while it is in memory for a request.
- A malformed GGUF is parsed by native code (llama.cpp). VENEX checks the header first, but a crafted model file could still crash the app or, in the worst case, exploit a bug in the runtime. Only import models from sources you trust.
- The imported model copy is app-private, but it is not encrypted.
- Nothing in this package has been tested on a real device, with a real model, or with a real cloud provider. `KeystoreSecretStore` and the SAF code were never run. Security claims about Accessibility behaviour on MIUI are unverified.
