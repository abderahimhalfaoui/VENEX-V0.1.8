# VENEX V0.1.3 — Architecture

Two Gradle modules. `core` is pure Kotlin/JVM with no Android dependency, so most behaviour is
tested on the JVM. `app` is the Android layer: Compose UI, Accessibility service, Intents, storage.

```
user text
  │
  ▼
RestrictedActionDetector ──► refused (RestrictedGoal) — before ANY parser, including the model
  │
  ▼
RuleBasedIntentParser ──► Goal (known commands)
  │ unknown
  ▼
AiModeRouter ──► exactly one provider: OFF | SERVER | CLOUD | ON_DEVICE (optional, only when enabled and verified) — under timeout
  │ invalid / timeout / error → UnknownGoal (never a guess)
  ▼
TaskPlanner ──► Plan (steps with dependsOn and Expectation)
  │
  ▼
SafetyPolicy (per step, per screen)
  │
  ▼
ExecutionEngine ──► ChannelRouter ──► DeviceController (Intent / Deep link / Accessibility)
  │                                        │
  │                                        ▼
  │                                   Verifier (Verified / Failed / Unverifiable)
  ▼
TaskReport ──► AuditLog (JSONL, app-private, rotated)
```

## Layers

| Layer | Location | Responsibility |
|---|---|---|
| Intent understanding | `core/.../intent` | Restricted detection → rules → optional model. Output is always a `Goal`. |
| Local models | `core/.../ai` | Provider adapters, connection and inference tests, settings state machine, `AiModeRouter`. |
| On-device model | `core/.../ai/ondevice` (logic) · `app/.../llm`, `app/src/main/cpp` (llama.cpp + JNI) | GGUF header parsing, import, state machine, memory policy; native runtime behind the `LlmRuntime` interface. |
| Planner | `core/.../planner` | Goal → ordered steps with dependencies and expected outcomes. |
| Engine | `core/.../engine` | Runs steps in order. Skips steps whose dependencies failed. Re-runs only after a reported failure. Confirmation-gated steps wait for approval. |
| Device | `core/.../device`, `app/.../device` | `DeviceController` abstracts the phone. `AndroidDeviceController` implements it with Intents and Accessibility. |
| Verification | `core/.../verify` | Compares evidence with each step's expectation. A clickable key is not a display value. |
| Safety | `core/.../safety` | Screen checks (CAPTCHA, password fields), link allow-list, typing restrictions. |
| Audit | `core/.../audit` | Structured log. Records outcomes and failure kinds, not content. |
| UI | `app/.../ui` | Chat (Arabic RTL), confirmation dialog, AI settings screen. |

## Core rules that must hold

- **No false success.** A step is `SUCCESS` only with verified evidence. Otherwise `UNVERIFIED` or `FAILED`.
- **Refusal before parsing.** Restricted actions (send, post, delete, pay) are refused before any parser, including the model.
- **The model proposes, never acts.** `ModelReplyParser` accepts one JSON object from `open_app`, `calculate`, `navigate`, `scroll`. Numbers are range-checked. App names pass through the restricted detector. Anything else becomes `UnknownGoal`.
- **Fallback.** The model is used only when enabled, verified for the current settings, and answering in time. Otherwise the rules decide.
- **One AI path at a time.** `AiModeRouter` picks OFF / SERVER / CLOUD / ON_DEVICE. Activating one deactivates the others. CLOUD is routed only if the owner acknowledged that exact host and an API key exists.
- **`core` stays pure JVM.** Nothing in `core` imports Android or JNI. The native runtime, SAF, Keystore and SharedPreferences sit behind interfaces (`LlmRuntime`, `ModelFileGateway`, `SecretStore`, `OnDeviceStore`, `AiModeStore`) that `app` implements and tests replace with fakes.
- **Bounded work.** Accessibility tree walks stop at depth 40 and 1500 nodes. Model replies are capped at 1 MB; model prompts are capped at 300 characters of command text.

## Local model integration

| Component | File | Role |
|---|---|---|
| `ModelProvider` | `ai/AiModels.kt` | Interface: `listModels(spec)`, `complete(spec, model, prompt)`. Returns `ProviderResult.Ok` or `Err(ProviderFailure(kind))`. |
| `OpenAiCompatibleProvider` | `ai/OpenAiCompatibleProvider.kt` | `GET /v1/models`, `POST /v1/chat/completions`. |
| `OllamaProvider` | `ai/OllamaProvider.kt` | `GET /api/tags`, `POST /api/chat` (non-streaming). |
| `Http` | `ai/Http.kt` | `HttpURLConnection`, redirects off, body cap, timeouts, failure mapping. Bearer header only when a session key exists. |
| `EndpointRules` | `ai/EndpointRules.kt` | Validates the base address. Rejects credentials, query, fragment, bad scheme or port. |
| `MiniJson` | `ai/MiniJson.kt` | Small JSON parser/encoder with depth and input limits. |
| `ConnectionTester` | `ai/ConnectionTester.kt` | Reachability, protocol, whether the chosen model is listed. |
| `InferenceTester` | `ai/InferenceTester.kt` | Asks a fixed factual question and checks the answer. |
| `AiSettingsController` | `ai/AiSettingsController.kt` | State machine (`AiStage`). A mutex serialises actions. Enabling requires a passing inference test for the current configuration fingerprint. |
| `ModelIntentProvider` / `DelegatingAiProvider` | `ai/ModelIntentProvider.kt` | Adapts a provider into an `AiProvider` for `LayeredIntentParser`. The active provider is read at each command. |
| `SharedPrefsAiSettingsStore` | `app/.../data` | Saves address, model name, timeout and flags. Never saves the session key. |

### Adding a provider

Implement `ModelProvider`, add a `ProviderType` value, and register it in `ProviderRegistry`. The
settings screen, testers and parser need no change. A provider that cannot be verified against a
real server must say so in the documentation.

## V0.1.2: hybrid AI

```
                    ┌───────────────────────────── core (pure JVM) ──────────────────────────────┐
LayeredIntentParser │  DelegatingAiProvider { router.activeIntentProvider() }                    │
   (rules → model)  │            │                                                               │
                    │      AiModeRouter ── mode store (AiModeStore) ── cloud consent (per host) │
                    │       │        │             │                  │                          │
                    │     OFF     SERVER         CLOUD            ON_DEVICE                      │
                    │            AiSettingsController ×2   OnDeviceController                    │
                    │            (Ollama/OpenAI adapters)   state machine · fingerprint · memory │
                    │            CompletionBackend          LlmRuntime · ModelFileGateway        │
                    └────────────────────────────────────────────┬───────────────────────────────┘
                                                                 │ implemented by
                    app:  KeystoreSecretStore · SharedPrefs*Store · AndroidModelFileGateway (SAF)
                          LlamaCppRuntime ─► JniLlamaBridge ─► libvenex_llm.so ─► libllama / libggml*
```

| Component | File | Role |
|---|---|---|
| `AiModeRouter` | `ai/AiModeRouter.kt` | Persists the mode; `activate(target, cloudConsent)` returns a refusal reason or null; `activeIntentProvider()` returns the one provider that is currently usable. Migrates V0.1.1: an enabled server config becomes SERVER. |
| `CompletionBackend` | `ai/CompletionBackend.kt` | `complete(prompt)` — the common shape of "something that answers a prompt". `ServerCompletionBackend` (server/cloud adapters) and the on-device controller implement it, so `ModelIntentProvider` and `ModelReplyParser` are shared. |
| `AiSettingsController` | `ai/AiSettingsController.kt` | One instance for SERVER, one for CLOUD. The cloud instance uses HTTPS-only endpoint validation and a `SecretStore` for the API key. |
| `SecretStore` | `ai/CompletionBackend.kt` | `put/get/has/delete(alias)`. `KeystoreSecretStore` (AES-256-GCM, Android Keystore) implements it. |
| `OnDeviceController` | `ai/ondevice/OnDeviceController.kt` | States `NOT_SELECTED → FILE_SELECTED → IMPORTING → READY → LOADING → LOADED → TESTING` (+ `UNLOADING`, `ERROR`). One exclusive long operation at a time (`tryLock`). Enabling requires a passing inference test for the current fingerprint. |
| `GgufParser` | `ai/ondevice/GgufParser.kt` | Bounded header reader (versions 2–3; limits on entries, tensors, string size, header size, array nesting). |
| `StreamImporter` | `ai/ondevice/StreamImporter.kt` | Free-space check, `.part` file, atomic rename, SHA-256, cancel cleanup. |
| `MemoryGuard` | `ai/ondevice/MemoryGuard.kt` | Conservative refusal before loading (`0.85 × file + 192 MB`). |
| `LlmRuntime`, `ModelFileGateway`, `OnDeviceStore` | `ai/ondevice/OnDeviceModels.kt` | Interfaces to the native engine (load, unload, complete, cancel, info), to file access (pick, import, delete) and to on-device settings storage. |
| `LlamaCppRuntime` | `app/.../llm` | Android implementation; every native call on its own background dispatcher; cancellation → native cancel flag; native error codes → `FailureKind`. |
| `venex_llm.cpp` / `venex_llm_jni.cpp` | `app/src/main/cpp` | One engine, one mutex; chat template or plain fallback; chunked prompt decode; greedy sampling; JNI glue returning UTF-8 bytes. |
| `AndroidModelFileGateway` | `app/.../data` | `ACTION_OPEN_DOCUMENT` picker, persistable URI grant, metadata, streaming read for import, private storage `filesDir/models/`. |

### Why on-device is not "just another server provider"

A server adapter is a `(url, model, key)` triple over HTTP. An on-device model is a file, a native
library, memory and a lifecycle. Modelling it as a fake `http://` URL would mix two kinds of
settings, hide the memory and file states, and invite a stale URL pointing at nothing. The two meet
only at `CompletionBackend`, where "answer this prompt" is the same question.

### Build layout

`app/src/main/cpp/CMakeLists.txt` builds `libvenex_llm.so` and, as sub-builds, the pinned llama.cpp
(`third_party/llama.cpp`, fetched by `scripts/fetch-llama-cpp.sh`) as shared libraries with
runtime-selected CPU variants (`GGML_BACKEND_DL`, `GGML_CPU_ALL_VARIANTS`). A Gradle task
(`checkLlamaCppSources`) fails early with an explanation if the sources were not fetched.
`extractNativeLibs` is on so ggml can find its CPU-variant libraries on disk. Default ABI:
`arm64-v8a`.

## V0.1.3: what changed in the pipeline

- **Prompt finalisation (native, `finalize_prompt`)**: if the model's chat template is a Qwen3-style thinking template (contains `enable_thinking` or `<think>`) and the rendered prompt ends with `<|im_start|>assistant\n`, `<think>\n\n</think>\n\n` is appended: exactly what that template itself emits when thinking is disabled. Other templates are untouched.
- **Output sanitizer (`ModelOutputSanitizer`, core)**: removes `<think>…</think>`, an unclosed `<think>…`, a dangling `</think>` and chat control tokens before any parsing or probe check. It is a safety net, not the fix.
- **Truncation**: the engine returns `truncated` (generation ended without an end-of-generation token). `LlamaCppRuntime` maps it to `INVALID_RESPONSE`; a cut reply is never shown as an answer.
- **Readiness line** (`OnDeviceSnapshot.readiness`): derived from verified / enabled / loaded so the UI cannot say "works" for a merely loaded file.
- **Search goal**: `SearchInAppGoal` → `TaskPlanner.planSearch` → `OpenDeepLink(https://www.youtube.com/results?search_query=…)` with `Expectation.ScreenContainsText(query)`. Nothing types into search fields.

## Accessibility

- Reads only `rootInActiveWindow`.
- Every node obtained from the framework is released through `withTree` / `walk`, including on failure. On API 33+ the system recycles nodes itself, so explicit recycling is limited to API 26–32.
- Password fields: text is omitted from snapshots and never typed into.
- Gesture fallback for taps uses an internal marker prefix. This is a known refactor candidate.

## Known gaps

- Speech recognition is not implemented.
- Only the active window is read.
- Runtime failures of an enabled server/cloud model do not automatically disable it; the rules take over for each command and the settings screen shows the last failure. The on-device model is disabled automatically only when inference runs out of memory.
- After an app restart, a SERVER model shows as enabled with a note that the last test passed earlier. The session key of a server is not restored, so servers that need a key require re-entry. (The cloud key is stored encrypted and is restored.)
- On-device: the model is copied (not read in place) from the picked file; the native layer was only exercised on a PC with a tiny random-weight GGUF, never on Android; CPU only.
