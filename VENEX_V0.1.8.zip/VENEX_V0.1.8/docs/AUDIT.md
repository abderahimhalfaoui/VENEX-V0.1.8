# VENEX V0.1.3 — Engineering audit

The V0.1.1 table below is unchanged except for finding 11. V0.1.2 findings are in the second table.

Scope: every source, resource and workflow file in the V0.1 package, including Gradle, Manifest,
Accessibility, the assistant services, the planner, the engine, verification, safety, audit, tests,
CI and documentation. Priority: **Critical** (breaks a feature or safety), **High** (wrong behaviour
or resource failure), **Medium** (risk or misleading state), **Low** (quality).

## Findings and status

| # | Priority | Area | Finding | Status |
|---|---|---|---|---|
| 1 | Critical | Manifest | No `INTERNET` permission. Any network call (needed for a local model) would fail. | **Fixed** |
| 2 | High | Accessibility | `AccessibilityNodeInfo` objects were never recycled. On API 26–32 each screen read leaked native nodes. | **Fixed**: every operation runs in `withTree`, which releases all nodes it obtained, including after failures. |
| 3 | High | Intent | `2 + 3 + 4` was silently executed as `2 + 3`. A partial result was presented without warning. | **Fixed**: more than two numbers → refused. Regression test added. |
| 4 | Medium | App resolver | Synonym matching used substring of the **package name** (`calc` matched `com.example.calcrypto`), which can open a wrong app. | **Fixed**: whole package segments only. Regression test added. |
| 5 | Medium | Intent | «لو سمحت», «من فضلك», «لي» were kept in app names, so the app was not found. | **Fixed**, with tests. |
| 6 | Medium | Manifest | `VenexRecognitionService` was exported without `BIND_RECOGNITION_SERVICE`. | **Fixed** |
| 7 | Medium | Audit | A user cancel left no entry in the execution log. | **Fixed** |
| 8 | Medium | CI | `gradlew` executability was assumed, and there was no check for a broken wrapper or a missing test summary. | **Fixed**: wrapper validation, executable check, test summary, always-on report upload. |
| 9 | Medium | Accessibility | The app-name prefix search can still choose a label that merely *starts with* the query (e.g. `calc` → "Calcrypto Wallet"). Ambiguity is raised only for equal scores. | **Open (documented)**. Mitigation: exact and synonym matches outrank prefixes; a wrong pick is visible in the step report. |
| 10 | Medium | Restricted detector | Keyword «حول» (transfer) also means "about" in Arabic, so some harmless commands are refused. | **Open (documented)**: refusing is the safe direction. |
| 11 | Medium | Build | The Android module is **not compiled in the environment that produced this package** (no Android SDK and no network). | **Open** (still true for V0.1.2, now including the native build): must be verified by `./gradlew :app:assembleDebug` or by CI. |
| 12 | Low | Code | `URL(String)` constructor is deprecated in favour of `URI(...).toURL()`. | **Fixed** in the new HTTP client |
| 13 | Low | Accessibility | Only the active window is read. Multi-window dialogs and split-screen are not handled. | **Open (limitation)** |
| 14 | Low | Assistant | Speech recognition is not implemented; the service answers with an explicit error. | **Documented** |

## V0.1.2 findings

| # | Priority | Area | Finding | Status |
|---|---|---|---|---|
| 15 | Critical | Build | `settings.gradle.kts` in V0.1.1 did not `include(":app")`, so Gradle never saw the Android module and `:app:assembleDebug` / `:app:testDebugUnitTest` (used by the V0.1.1 CI and README) could not run. | **Fixed** (found by reading the files; no Gradle run was possible here) |
| 16 | High | Build | The root `build.gradle.kts` did not declare the `android-application` and `kotlin-android` plugin aliases that `app/build.gradle.kts` needs. | **Fixed** (same note) |
| 17 | Medium | Core | A hardcoded assumption that the only providers are HTTP servers: `ModelIntentProvider` was tied to `ModelProvider`. | **Fixed**: it now takes a `CompletionBackend`; server, cloud and on-device share the prompt and `ModelReplyParser`. V0.1.1 tests unchanged and passing. |
| 18 | Medium | Docs | `EndpointRules` comment said "loopback or private-network" while the cloud check rejects loopback only. | **Fixed** (comment) |
| 19 | Medium | Cloud | The preset base addresses for OpenAI / OpenRouter / Groq were compared with each provider's public docs but never exercised with a real request or key. | **Open**: labelled in the UI and docs as untested; the address stays editable. |
| 20 | Medium | On-device | The GGUF is copied into app storage instead of being read from the picked descriptor (doubles storage, slow for big files). | **Open (decision)**: see `ON_DEVICE_AI_REPORT.md` §4. |
| 21 | Medium | On-device | The pinned llama.cpp commit's C API is used directly (`llama_batch_ext_*`, `llama_process`); upgrading the pin needs the glue re-checked. | **Open (documented)**. Host test re-run required on any change. |
| 22 | Medium | On-device | The Arabic inference probe is strict and may reject capable small models. | **Open (by design)** |
| 23 | Medium | Build | The Android module, NDK 29 + CMake 3.22.1 + llama.cpp native build, and the APK ABI contents were **not built or checked** here. The Kotlin/coroutines versions of the local test harness differ from the project's. | **Open**: the CI job verifies libraries and ABIs inside the APK; it has not run yet. |
| 24 | Low | On-device | `AppLayerTest` and all Compose/SAF/Keystore code have not run. | **Open** |

## V0.1.3 findings

Found after the V0.1.2 real-phone test failed. "Found by" says how each root cause was established; none was
reproduced with a real Qwen3 model (none is available here).

| # | Priority | Area | Finding | Status |
|---|---|---|---|---|
| 25 | Critical | On-device | Qwen3 chat templates default to *thinking* mode: the model starts with `<think>`. `<think>` is not a special token, so it was rendered as text, and the token budgets (96 intent / 32 probe) were spent on thinking. Result: replies cut before the answer, the inference probe failing, and "think" visible in the reply. *Found by:* reading the template/prompt/budget code and the failure description. | **Fixed (code)**: empty think block appended to the prompt, output sanitizer, truncation reported as failure. **Not verified on a phone or with a real Qwen3.** |
| 26 | High | On-device | A reply that reached the token budget was returned as if complete. | **Fixed**: the engine reports `truncated`; the runtime turns it into `INVALID_RESPONSE`. |
| 27 | High | UI | The settings screen could read "model loaded" as if it meant "model works". | **Fixed**: one readiness line derived from verified + enabled + loaded; "يعمل" requires all three. |
| 28 | High | Planner | "open YouTube and search for X" had no goal: the rules read it as an app named "youtube and search for X". | **Fixed (planner/parser tests only)**: opens the results URL, verifies the query text is on screen. Not run on a device. |
| 29 | Medium | Tests | `ModelIntegrationTest` failed 4 cases in CI but not locally. No CI log was available. *Hypothesis (unconfirmed):* the tests run real HTTP through `LayeredIntentParser`'s wall-clock `withTimeoutOrNull` inside `runTest`, whose virtual time makes the outcome scheduling-dependent. | **Mitigated, not confirmed**: converted to `runBlocking` (real time). The CI log of the next run decides. |
| 30 | Medium | CI | `cmd \| tee log` steps ran without `pipefail`, so a failing host test or Gradle build could show as green. | **Fixed**: `defaults.run.shell: bash` (pipefail), host-test pass marker required, APK version check. |
| 31 | Medium | Docs/code | V0.1.2 docs said the API key field uses the password keyboard type; the code did not set it. | **Fixed** in code. |
| 32 | Medium | On-device | No conversation memory: every request clears the KV cache and the prompt holds one command. Follow-up questions are therefore not answered in context. | **Open (not implemented by decision)**: new feature, not part of the fix. |
| 33 | Medium | On-device | `MemoryGuard` refuses a model when available RAM < 0.85 × file + 192 MB. For Qwen3-1.7B Q4_K_M (~1.1 GB) this may refuse on low-RAM phones; not measured. | **Open** |

## Checked and found correct

- Planner dependency order, the skip-on-failure rule and optional steps (`clear`).
- ExecutionEngine: `SUCCESS` only with verified evidence; re-runs happen only after a reported failure, so key presses are not duplicated; confirmation-gated steps never run without approval.
- Verifier: a clickable key is not accepted as a display value; non-terminating results compare at displayed precision.
- Safety: password fields are never read (text omitted from snapshots) and never typed into; CAPTCHA screens stop the task; link schemes are allow-listed.
- Restricted commands are detected **before** any parser, including the model.
- The model cannot create a goal outside the closed vocabulary (see `docs/LOCAL_MODELS.md`).

## Not verifiable here

- Behaviour on a real Redmi Note 8 Pro under MIUI (assistant selection, long-press Home, calculator button labels, Accessibility restrictions).
- Real local models. Tests use a real local HTTP server that implements the documented wire shapes; no genuine model was run through the server path.
- A real language model on a phone (speed, RAM, heat, Arabic quality): the on-device engine was run only on a PC, with a tiny random-weight GGUF.
- Real cloud providers and the Android Keystore.
