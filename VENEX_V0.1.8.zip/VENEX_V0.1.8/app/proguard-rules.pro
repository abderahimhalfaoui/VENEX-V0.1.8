# VENEX V0.1 ships with minification disabled. Add keep rules here if you enable R8.

# JNI: the native library looks these methods up by name; never rename or strip them if R8 is enabled.
-keep class com.venex.app.llm.JniLlamaBridge { native <methods>; }
