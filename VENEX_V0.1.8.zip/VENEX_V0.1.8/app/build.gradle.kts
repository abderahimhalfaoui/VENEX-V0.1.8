plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

// llama.cpp is fetched (not vendored) by scripts/fetch-llama-cpp.sh at the commit pinned in
// third_party/llama.cpp.version. Native builds fail early with a clear message when it is missing.
val llamaCppDir = rootProject.file("third_party/llama.cpp")

// ABIs to build. Default arm64-v8a only (the target phones). For an x86_64 emulator pass
// -Pvenex.abis=arm64-v8a,x86_64. Every added ABI increases build time and APK size.
val venexAbis = (providers.gradleProperty("venex.abis").orNull ?: "arm64-v8a").split(",").map { it.trim() }.filter { it.isNotEmpty() }

android {
    namespace = "com.venex.app"
    compileSdk = 34
    // Pinned NDK (the one llama.cpp's own Android CI uses). Installed by CI through sdkmanager.
    ndkVersion = "29.0.14206865"

    defaultConfig {
        applicationId = "com.venex.app"
        minSdk = 26 // Android 8.0; the primary target device runs Android 11 (API 30)
        targetSdk = 34
        versionCode = 8
        versionName = "0.1.8"

        ndk {
            abiFilters += venexAbis
        }
        externalNativeBuild {
            cmake {
                arguments += listOf(
                    "-DANDROID_STL=c++_shared",
                    "-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON",
                    "-DVENEX_LLAMA_DIR=${llamaCppDir.absolutePath}"
                )
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // No signing config is committed. Provide your own keystore locally / in CI secrets.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = libs.versions.composeCompiler.get()
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        // ggml loads its CPU-variant backends (libggml-cpu-*.so) by scanning nativeLibraryDir, so the
        // native libraries must be extracted to disk at install time (also set in the manifest).
        jniLibs {
            useLegacyPackaging = true
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    implementation(project(":core"))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(libs.kotlinx.coroutines.android)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui.tooling.preview)
    debugImplementation(libs.androidx.compose.ui.tooling)

    testImplementation(libs.junit)
    testImplementation(kotlin("test"))
    testImplementation(libs.kotlinx.coroutines.test)
}

// Fail early and clearly when the pinned llama.cpp checkout is missing (native tasks only; the JVM
// unit tests do not need it).
val checkLlamaCpp = tasks.register("checkLlamaCppSources") {
    val marker = llamaCppDir.resolve("CMakeLists.txt")
    doFirst {
        if (!marker.isFile) {
            throw GradleException(
                "llama.cpp sources not found at ${llamaCppDir}. Run scripts/fetch-llama-cpp.sh " +
                    "(it checks out the commit pinned in third_party/llama.cpp.version)."
            )
        }
    }
}
tasks.configureEach {
    if (name.startsWith("configureCMake") || name.startsWith("buildCMake") || name.startsWith("generateJsonModel")) {
        dependsOn(checkLlamaCpp)
    }
}
