// JNI glue for com.venex.app.llm.JniLlamaBridge. All logic lives in venex_llm.cpp.
#include <android/log.h>
#include <jni.h>

#include <string>

#include "llama.h"
#include "venex_llm.h"

#define TAG "VenexLlm"

namespace {

// Routes llama.cpp logs to logcat, ERROR/WARN/INFO only; DEBUG and continuation lines are dropped.
// VENEX itself never logs prompt or reply text. In the pinned llama.cpp commit the tokenizer lines that
// print input text are compiled out (PRETOKENIZERDEBUG is not defined); the remaining INFO output is
// model/loader/context information. Not every llama.cpp log line was audited, so a version bump of the
// pin must re-check this.
void log_cb(ggml_log_level level, const char *text, void *) {
    int prio;
    if (level == GGML_LOG_LEVEL_ERROR) prio = ANDROID_LOG_ERROR;
    else if (level == GGML_LOG_LEVEL_WARN) prio = ANDROID_LOG_WARN;
    else if (level == GGML_LOG_LEVEL_INFO) prio = ANDROID_LOG_INFO;
    else return;
    __android_log_write(prio, TAG, text);
}

std::string to_std(JNIEnv *env, jstring s) {
    if (s == nullptr) return "";
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

jstring to_jstring(JNIEnv *env, const std::string &s) {
    // NewStringUTF needs modified UTF-8; anything we return here is ASCII diagnostics.
    return env->NewStringUTF(s.c_str());
}

}  // namespace

extern "C" {

JNIEXPORT jint JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeInit(JNIEnv *env, jobject, jstring dir) {
    llama_log_set(log_cb, nullptr);
    return venex::init(to_std(env, dir));
}

JNIEXPORT jint JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeLoad(JNIEnv *env, jobject, jstring path, jint nCtx, jint nThreads) {
    return venex::load(to_std(env, path), nCtx, nThreads);
}

JNIEXPORT void JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeUnload(JNIEnv *, jobject) { venex::unload(); }

JNIEXPORT jboolean JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeIsLoaded(JNIEnv *, jobject) {
    return venex::is_loaded() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeCancel(JNIEnv *, jobject) { venex::cancel(); }

JNIEXPORT void JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeClearCancel(JNIEnv *, jobject) { venex::clear_cancel(); }

// Returns the reply as UTF-8 bytes (so 4-byte sequences survive), or null on failure
// (see nativeLastErrorCode). stats = [promptTokens, generatedTokens, promptMs, generateMs, truncated(0|1)].
JNIEXPORT jbyteArray JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeComplete(
        JNIEnv *env, jobject, jstring system, jstring user, jint maxTokens, jlongArray stats) {
    std::string out;
    venex::CompletionStats st;
    const int rc = venex::complete(to_std(env, system), to_std(env, user), maxTokens, out, st);
    if (stats != nullptr && env->GetArrayLength(stats) >= 5) {
        jlong v[5] = {st.prompt_tokens, st.generated_tokens, st.prompt_ms, st.generate_ms, st.truncated ? 1 : 0};
        env->SetLongArrayRegion(stats, 0, 5, v);
    }
    if (rc != venex::ERR_NONE) return nullptr;
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(out.size()));
    if (arr == nullptr) return nullptr;
    env->SetByteArrayRegion(arr, 0, static_cast<jsize>(out.size()), reinterpret_cast<const jbyte *>(out.data()));
    return arr;
}

JNIEXPORT jint JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeLastErrorCode(JNIEnv *, jobject) {
    return venex::last_error_code();
}

JNIEXPORT jstring JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeLastError(JNIEnv *env, jobject) {
    return to_jstring(env, venex::last_error());
}

// "description|sizeBytes|nParams|nCtxTrain|nCtx|nThreads"
JNIEXPORT jstring JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeModelInfo(JNIEnv *env, jobject) {
    const venex::ModelInfo m = venex::model_info();
    std::string d = m.description;
    for (char &c : d) if (c == '|') c = '/';
    return to_jstring(env, d + "|" + std::to_string(m.size_bytes) + "|" + std::to_string(m.n_params) + "|" +
                               std::to_string(m.n_ctx_train) + "|" + std::to_string(m.n_ctx) + "|" +
                               std::to_string(m.n_threads));
}

JNIEXPORT jstring JNICALL Java_com_venex_app_llm_JniLlamaBridge_nativeSystemInfo(JNIEnv *env, jobject) {
    return to_jstring(env, venex::system_info());
}

}  // extern "C"
