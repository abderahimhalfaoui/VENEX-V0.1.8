// VENEX on-device inference engine: a thin, JNI-free C++ layer over llama.cpp's C API.
// JNI glue lives in venex_llm_jni.cpp; this file can be (and is) compiled and exercised on a host
// machine against a real GGUF file, independent of Android.
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace venex {

// Stable error codes shared with the Kotlin side (see LlamaBridge.kt).
enum ErrorCode : int {
    ERR_NONE = 0,
    ERR_CANCELLED = 1,
    ERR_NOT_LOADED = 2,
    ERR_LOAD_FAILED = 3,
    ERR_CONTEXT_FAILED = 4,
    ERR_PROMPT_TOO_LONG = 5,
    ERR_DECODE_FAILED = 6,
    ERR_OUT_OF_MEMORY = 7,
    ERR_TOKENIZE_FAILED = 8,
    ERR_NO_BACKEND = 9,
    ERR_BUSY = 10,
    ERR_INTERNAL = 11,
};

struct CompletionStats {
    int32_t prompt_tokens = 0;
    int32_t generated_tokens = 0;
    int64_t prompt_ms = 0;
    int64_t generate_ms = 0;
    // True when generation stopped because the token budget ran out, not because the model ended its
    // reply. A truncated reply is never a complete answer; the caller must treat it as a failure.
    bool truncated = false;
};

struct ModelInfo {
    std::string description;
    uint64_t size_bytes = 0;   // bytes of tensors reported by llama_model_size()
    uint64_t n_params = 0;
    int32_t n_ctx_train = 0;
    int32_t n_ctx = 0;         // the context actually allocated
    int32_t n_threads = 0;
};

// Process-wide init. `backend_dir` is where libggml-cpu-*.so live (may be empty for static builds).
// Returns ERR_NONE, or ERR_NO_BACKEND when no CPU backend could be registered.
int init(const std::string &backend_dir);
void shutdown();

// Loads a model and creates a context. Only one model can be loaded at a time (ERR_BUSY otherwise).
// n_gpu_layers is always 0: CPU is the baseline and GPU offload is not used in V0.1.3.
int load(const std::string &path, int n_ctx, int n_threads);
void unload();
bool is_loaded();

// Pure helper (no model needed), exposed for host tests. Qwen3 chat templates contain `enable_thinking`;
// with thinking enabled the model spends its whole token budget on `<think>` text. When the rendered
// prompt ends at an assistant turn of such a template, this appends the same empty think block that the
// template itself emits for enable_thinking=false. Any other prompt is returned unchanged.
std::string finalize_prompt(const std::string &rendered, const std::string &template_text);

// Runs one chat completion (system + user), greedy sampling. Blocking; call from one thread at a time.
// On success returns ERR_NONE and fills `out` with UTF-8 bytes.
int complete(const std::string &system, const std::string &user, int max_tokens,
             std::string &out, CompletionStats &stats);

// Thread-safe. Aborts a running load or completion as soon as possible.
void cancel();
void clear_cancel();

ModelInfo model_info();
std::string last_error();
int last_error_code();
std::string system_info();

}  // namespace venex
