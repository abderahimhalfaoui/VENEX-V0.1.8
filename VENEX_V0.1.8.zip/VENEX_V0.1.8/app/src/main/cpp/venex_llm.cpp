#include "venex_llm.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <exception>
#include <mutex>
#include <new>

#include "llama.h"

namespace venex {
namespace {

std::mutex g_mutex;  // guards the engine state below; complete() holds it for its whole duration
std::atomic<bool> g_cancel{false};

llama_model *g_model = nullptr;
llama_context *g_ctx = nullptr;
llama_sampler *g_sampler = nullptr;
llama_batch_ext *g_batch = nullptr;
ModelInfo g_info;
bool g_backend_ready = false;

std::string g_last_error;
std::atomic<int> g_last_code{ERR_NONE};

int fail(int code, const std::string &msg) {
    g_last_error = msg;
    g_last_code.store(code);
    return code;
}

int64_t now_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

bool abort_cb(void *) { return g_cancel.load(); }

bool progress_cb(float, void *) { return !g_cancel.load(); }  // false aborts the load

void free_engine_locked() {
    if (g_batch) { llama_batch_ext_free(g_batch); g_batch = nullptr; }
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_info = ModelInfo();
}

std::string token_piece(const llama_vocab *vocab, llama_token t) {
    char buf[256];
    int n = llama_token_to_piece(vocab, t, buf, sizeof(buf), 0, false);
    if (n < 0) {
        std::vector<char> big(static_cast<size_t>(-n));
        n = llama_token_to_piece(vocab, t, big.data(), static_cast<int32_t>(big.size()), 0, false);
        if (n < 0) return "";
        return std::string(big.data(), static_cast<size_t>(n));
    }
    return std::string(buf, static_cast<size_t>(n));
}

bool ends_with(const std::string &s, const std::string &suffix) {
    return s.size() >= suffix.size() && s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0;
}

// Builds the prompt text. Uses the model's own chat template when llama.cpp can apply it; otherwise
// falls back to a plain-text layout so that any instruction-tuned GGUF still gets a usable prompt.
std::string build_prompt(const std::string &system, const std::string &user) {
    const char *tmpl = llama_model_chat_template(g_model, nullptr);
    if (tmpl != nullptr) {
        llama_chat_message msgs[2] = {{"system", system.c_str()}, {"user", user.c_str()}};
        std::vector<char> buf(std::max<size_t>(1024, (system.size() + user.size()) * 2 + 256));
        int32_t n = llama_chat_apply_template(tmpl, msgs, 2, true, buf.data(), static_cast<int32_t>(buf.size()));
        if (n > static_cast<int32_t>(buf.size())) {
            buf.resize(static_cast<size_t>(n));
            n = llama_chat_apply_template(tmpl, msgs, 2, true, buf.data(), static_cast<int32_t>(buf.size()));
        }
        if (n > 0) return finalize_prompt(std::string(buf.data(), static_cast<size_t>(n)), tmpl);
    }
    return system + "\n\n" + user + "\n\nAnswer:";
}

}  // namespace

std::string finalize_prompt(const std::string &rendered, const std::string &template_text) {
    const bool qwen3_thinking_template =
        template_text.find("enable_thinking") != std::string::npos || template_text.find("<think>") != std::string::npos;
    if (qwen3_thinking_template && ends_with(rendered, "<|im_start|>assistant\n")) {
        return rendered + "<think>\n\n</think>\n\n";
    }
    return rendered;
}

int init(const std::string &backend_dir) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_backend_ready) return ERR_NONE;
    try {
        if (!backend_dir.empty()) ggml_backend_load_all_from_path(backend_dir.c_str());
        llama_backend_init();
        if (ggml_backend_dev_count() == 0) {
            return fail(ERR_NO_BACKEND, "no ggml backend could be registered (CPU backend library missing?)");
        }
        g_backend_ready = true;
        return ERR_NONE;
    } catch (const std::exception &e) {
        return fail(ERR_INTERNAL, std::string("init failed: ") + e.what());
    }
}

void shutdown() {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_engine_locked();
    if (g_backend_ready) { llama_backend_free(); g_backend_ready = false; }
}

int load(const std::string &path, int n_ctx, int n_threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    try {
        if (!g_backend_ready) return fail(ERR_NO_BACKEND, "backend not initialised");
        if (g_model != nullptr) return fail(ERR_BUSY, "a model is already loaded; unload it first");
        g_last_error.clear();
        g_last_code.store(ERR_NONE);
        // A cancel requested before this call is stale; each operation begins with a clean flag.
        g_cancel.store(false);

        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;  // CPU baseline
        mp.load_mode = LLAMA_LOAD_MODE_MMAP;
        mp.progress_callback = progress_cb;
        mp.progress_callback_user_data = nullptr;
        g_model = llama_model_load_from_file(path.c_str(), mp);
        if (g_model == nullptr) {
            if (g_cancel.load()) return fail(ERR_CANCELLED, "load cancelled");
            return fail(ERR_LOAD_FAILED, "llama.cpp could not load the model (unsupported or corrupt GGUF, or not enough memory)");
        }

        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = static_cast<uint32_t>(std::max(256, n_ctx));
        cp.n_batch = std::min<uint32_t>(cp.n_ctx, 256);
        cp.n_ubatch = cp.n_batch;
        cp.n_threads = std::max(1, n_threads);
        cp.n_threads_batch = cp.n_threads;
        cp.no_perf = true;
        cp.abort_callback = abort_cb;
        cp.abort_callback_data = nullptr;
        g_ctx = llama_init_from_model(g_model, cp);
        if (g_ctx == nullptr) {
            free_engine_locked();
            return fail(ERR_CONTEXT_FAILED, "could not create the inference context (try a smaller context length)");
        }

        llama_sampler_chain_params sp = llama_sampler_chain_default_params();
        sp.no_perf = true;
        g_sampler = llama_sampler_chain_init(sp);
        llama_sampler_chain_add(g_sampler, llama_sampler_init_greedy());
        g_batch = llama_batch_ext_init(g_ctx);
        if (g_sampler == nullptr || g_batch == nullptr) {
            free_engine_locked();
            return fail(ERR_OUT_OF_MEMORY, "could not allocate sampler or batch");
        }

        char desc[160] = {0};
        llama_model_desc(g_model, desc, sizeof(desc));
        g_info.description = desc;
        g_info.size_bytes = llama_model_size(g_model);
        g_info.n_params = llama_model_n_params(g_model);
        g_info.n_ctx_train = llama_model_n_ctx_train(g_model);
        g_info.n_ctx = static_cast<int32_t>(llama_n_ctx(g_ctx));
        g_info.n_threads = cp.n_threads;
        return ERR_NONE;
    } catch (const std::bad_alloc &) {
        free_engine_locked();
        return fail(ERR_OUT_OF_MEMORY, "out of memory while loading");
    } catch (const std::exception &e) {
        free_engine_locked();
        return fail(ERR_INTERNAL, std::string("load failed: ") + e.what());
    } catch (...) {
        free_engine_locked();
        return fail(ERR_INTERNAL, "load failed: unknown exception");
    }
}

void unload() {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_engine_locked();
}

bool is_loaded() {
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_model != nullptr && g_ctx != nullptr;
}

int complete(const std::string &system, const std::string &user, int max_tokens,
             std::string &out, CompletionStats &stats) {
    std::lock_guard<std::mutex> lock(g_mutex);
    try {
        out.clear();
        stats = CompletionStats();
        if (g_model == nullptr || g_ctx == nullptr) return fail(ERR_NOT_LOADED, "no model is loaded");
        g_last_error.clear();
        g_last_code.store(ERR_NONE);
        // The flag is NOT reset here: a cancel() that raced in before this lock was taken must win.
        if (g_cancel.load()) return fail(ERR_CANCELLED, "cancelled before start");

        const llama_vocab *vocab = llama_model_get_vocab(g_model);
        const std::string text = build_prompt(system, user);

        bool add_special = llama_vocab_get_add_bos(vocab);
        const llama_token bos = llama_vocab_bos(vocab);
        if (add_special && bos != LLAMA_TOKEN_NULL) {
            // Chat templates often emit the BOS text themselves; do not add it twice.
            const std::string bos_text = token_piece(vocab, bos);
            if (!bos_text.empty() && text.rfind(bos_text, 0) == 0) add_special = false;
        }
        std::vector<llama_token> tokens(text.size() + 16);
        int32_t n = llama_tokenize(vocab, text.c_str(), static_cast<int32_t>(text.size()), tokens.data(),
                                   static_cast<int32_t>(tokens.size()), add_special, true);
        if (n < 0) {
            tokens.resize(static_cast<size_t>(-n));
            n = llama_tokenize(vocab, text.c_str(), static_cast<int32_t>(text.size()), tokens.data(),
                               static_cast<int32_t>(tokens.size()), add_special, true);
        }
        if (n <= 0) return fail(ERR_TOKENIZE_FAILED, "tokenization failed");
        tokens.resize(static_cast<size_t>(n));

        const int n_ctx = g_info.n_ctx;
        const int headroom = 8;
        if (n >= n_ctx - headroom) {
            return fail(ERR_PROMPT_TOO_LONG, "the prompt does not fit in the configured context length");
        }
        const int budget = std::max(1, std::min(max_tokens, n_ctx - n - headroom));

        // Every request is independent: start from an empty KV cache.
        llama_memory_clear(llama_get_memory(g_ctx), true);
        llama_sampler_reset(g_sampler);

        const int64_t t0 = now_ms();
        const int chunk = static_cast<int>(llama_n_batch(g_ctx));
        for (int i = 0; i < n; i += chunk) {
            const int cur = std::min(chunk, n - i);
            llama_batch_ext_clear(g_batch);
            for (int j = 0; j < cur; j++) {
                const int idx = llama_batch_ext_add_token(g_batch, 0, tokens[static_cast<size_t>(i + j)]);
                if (idx < 0) return fail(ERR_INTERNAL, "batch add failed");
                llama_pos pos = i + j;
                llama_batch_ext_set_pos(g_batch, idx, &pos);
                llama_batch_ext_set_output_logits(g_batch, idx, (i + j) == n - 1);
            }
            const int rc = llama_process(g_ctx, LLAMA_PROCESS_TYPE_DECODE, g_batch);
            if (g_cancel.load()) return fail(ERR_CANCELLED, "cancelled during prompt processing");
            if (rc != 0) return fail(ERR_DECODE_FAILED, "decode failed while processing the prompt (code " + std::to_string(rc) + ")");
        }
        stats.prompt_tokens = n;
        stats.prompt_ms = now_ms() - t0;

        const int64_t t1 = now_ms();
        int pos = n;
        bool reached_eog = false;
        for (int k = 0; k < budget; k++) {
            if (g_cancel.load()) return fail(ERR_CANCELLED, "cancelled during generation");
            const llama_token tok = llama_sampler_sample(g_sampler, g_ctx, -1);
            if (llama_vocab_is_eog(vocab, tok)) { reached_eog = true; break; }
            out += token_piece(vocab, tok);
            stats.generated_tokens++;
            if (k + 1 >= budget) break;
            llama_batch_ext_clear(g_batch);
            const int idx = llama_batch_ext_add_token(g_batch, 0, tok);
            if (idx < 0) return fail(ERR_INTERNAL, "batch add failed");
            llama_pos p = pos++;
            llama_batch_ext_set_pos(g_batch, idx, &p);
            llama_batch_ext_set_output_logits(g_batch, idx, true);
            const int rc = llama_process(g_ctx, LLAMA_PROCESS_TYPE_DECODE, g_batch);
            if (g_cancel.load()) return fail(ERR_CANCELLED, "cancelled during generation");
            if (rc != 0) return fail(ERR_DECODE_FAILED, "decode failed during generation (code " + std::to_string(rc) + ")");
        }
        // Conservative: hitting the budget right before the end-of-generation token also counts as truncated.
        stats.truncated = !reached_eog;
        stats.generate_ms = now_ms() - t1;
        return ERR_NONE;
    } catch (const std::bad_alloc &) {
        return fail(ERR_OUT_OF_MEMORY, "out of memory during inference");
    } catch (const std::exception &e) {
        return fail(ERR_INTERNAL, std::string("inference failed: ") + e.what());
    } catch (...) {
        return fail(ERR_INTERNAL, "inference failed: unknown exception");
    }
}

void cancel() { g_cancel.store(true); }
void clear_cancel() { g_cancel.store(false); }

ModelInfo model_info() {
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_info;
}

std::string last_error() { return g_last_error; }
int last_error_code() { return g_last_code.load(); }

std::string system_info() {
    const char *s = llama_print_system_info();
    return s ? s : "";
}

}  // namespace venex
