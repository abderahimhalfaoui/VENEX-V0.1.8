cmake_minimum_required(VERSION 3.22.1)

project(venex_llm LANGUAGES C CXX)

# Inference is unusably slow without optimisation, so native code is ALWAYS built as Release (-O3),
# including for the debug APK (AGP would otherwise pass -DCMAKE_BUILD_TYPE=Debug).
if(ANDROID)
    set(CMAKE_BUILD_TYPE "Release" CACHE STRING "" FORCE)
    set(CMAKE_BUILD_TYPE "Release")
endif()

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# llama.cpp is NOT vendored in this repository. scripts/fetch-llama-cpp.sh clones the exact commit
# recorded in third_party/llama.cpp.version into third_party/llama.cpp (CI does this automatically).
set(VENEX_LLAMA_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../third_party/llama.cpp"
    CACHE PATH "Pinned llama.cpp checkout")
if(NOT EXISTS "${VENEX_LLAMA_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "llama.cpp sources not found at ${VENEX_LLAMA_DIR}. Run scripts/fetch-llama-cpp.sh first.")
endif()

# ---- llama.cpp / ggml options (library only; no tools, tests, server, curl, openssl) ----
set(LLAMA_BUILD_COMMON   OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER   OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_APP      OFF CACHE BOOL "" FORCE)
set(LLAMA_OPENSSL        OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL           OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS    ON  CACHE BOOL "" FORCE)

# CPU baseline. GGML_BACKEND_DL + GGML_CPU_ALL_VARIANTS builds several CPU variants and lets ggml
# choose the best one the phone supports at run time, so older CPUs keep working (no raised
# instruction-set requirement) while newer ones (e.g. dot-product, i8mm) are faster.
# No GPU/Vulkan, no OpenMP, no KleidiAI (it is fetched from the network at configure time).
if(ANDROID)
    set(GGML_NATIVE            OFF CACHE BOOL "" FORCE)
    set(GGML_BACKEND_DL        ON  CACHE BOOL "" FORCE)
    set(GGML_CPU_ALL_VARIANTS  ON  CACHE BOOL "" FORCE)
    set(GGML_OPENMP            OFF CACHE BOOL "" FORCE)
    set(GGML_LLAMAFILE         OFF CACHE BOOL "" FORCE)
    set(GGML_CPU_KLEIDIAI      OFF CACHE BOOL "" FORCE)
    set(GGML_VULKAN            OFF CACHE BOOL "" FORCE)
    set(GGML_OPENCL            OFF CACHE BOOL "" FORCE)
endif()

add_subdirectory("${VENEX_LLAMA_DIR}" llama-build)

add_library(venex_llm SHARED venex_llm.cpp venex_llm_jni.cpp)
target_include_directories(venex_llm PRIVATE "${VENEX_LLAMA_DIR}/include" "${VENEX_LLAMA_DIR}/ggml/include")
target_link_libraries(venex_llm PRIVATE llama ggml android log)
