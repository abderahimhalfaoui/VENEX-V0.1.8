package com.venex.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.venex.core.device.InstalledApp

/**
 * Lists launchable apps. Android 11+ package visibility limits what is returned: we declare a
 * <queries> entry for launcher activities in the manifest instead of requesting the broad
 * QUERY_ALL_PACKAGES permission, so only apps with a launcher icon are visible.
 */
class InstalledAppsRepository(private val context: Context) {

    fun list(): List<InstalledApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return infos
            .mapNotNull { ri ->
                val ai = ri.activityInfo ?: return@mapNotNull null
                InstalledApp(
                    label = ri.loadLabel(pm).toString(),
                    packageName = ai.packageName,
                    isSystem = (ai.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }
            .distinctBy { it.packageName }
    }
}
