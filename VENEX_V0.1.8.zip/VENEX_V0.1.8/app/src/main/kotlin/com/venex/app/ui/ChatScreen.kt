package com.venex.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.venex.app.R
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.venex.app.device.VenexAccessibilityService
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import com.venex.app.data.SavedChat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import kotlin.math.min
import com.venex.core.audit.AuditEntry
import kotlin.math.cos
import kotlin.math.sin

// Colours of the reference design (dark, always).
private val Black = Color(0xFF000000)
private val Panel = Color(0xFF1E1E1E)
private val Outline = Color(0xFF3A3A3F)
private val DrawerBg = Color(0xFF121212)
private val SearchBg = Color(0xFF3A3B40)
private val Muted = Color(0xFF9A9AA0)
private val Green = Color(0xFF3CCFA1)
private val White = Color(0xFFF2F2F2)
private val IconSize = 26.dp

@Composable
fun ChatScreen(
    viewModel: MainViewModel,
    onOpenAccessibilitySettings: () -> Unit,
    onOpenAssistantSettings: () -> Unit,
    onOpenAiSettings: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val pending by viewModel.pendingConfirmation.collectAsState()
    val analyser by viewModel.analyserLabel.collectAsState()
    val history by viewModel.history.collectAsState()
    val currentId by viewModel.currentChatId.collectAsState()
    var input by remember { mutableStateOf("") }
    var showAudit by remember { mutableStateOf(false) }
    var thinking by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }

    // Before the first command the screen shows only the logo, as in the reference design.
    val showList = state.messages.any { it.fromUser } || state.liveSteps.isNotEmpty() || showAudit

    val context = LocalContext.current
    var attachments by remember { mutableStateOf<List<Attachment>>(emptyList()) }
    var speechError by remember { mutableStateOf<String?>(null) }
    var bubbleOn by remember { mutableStateOf(VenexAccessibilityService.isBubbleEnabled(context)) }
    val speech = remember { SpeechInput(context) }
    DisposableEffect(Unit) { onDispose { speech.release() } }
    SideEffect {
        speech.onSpeechText = { t -> input = (input + " " + t).trim() }
        speech.onSpeechError = { msg -> speechError = msg }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) attachments = attachments + uris.map { u -> readAttachment(context, u) }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) speech.start() else speechError = "لم يُمنح إذن الميكروفون"
    }
    val onMic: () -> Unit = {
        when {
            speech.listening -> speech.stop()
            !SpeechRecognizer.isRecognitionAvailable(context) ->
                speechError = "خدمة التعرف على الكلام غير متاحة على هذا الجهاز"
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED -> speech.start()
            else -> micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    // Top-left button: toggles the floating bubble; without the accessibility service it opens the settings.
    val onBubble: () -> Unit = {
        if (!state.accessibilityEnabled) {
            onOpenAccessibilitySettings()
        } else {
            val next = !bubbleOn
            VenexAccessibilityService.setBubbleEnabled(context, next)
            bubbleOn = next
            Toast.makeText(
                context,
                if (next) "الأيقونة العائمة مُفعّلة" else "أُخفيت الأيقونة العائمة",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    val send: () -> Unit = {
        val typed = input.trim()
        if ((typed.isNotEmpty() || attachments.isNotEmpty()) && !state.running) {
            viewModel.submit(buildMessage(context, typed, attachments))
            input = ""
            attachments = emptyList()
        }
    }

    // Standard Material drawer: it slides in from the start edge (the right side in RTL),
    // dims the screen, and closes on back or on tapping outside it.
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    fun openDrawer() {
        scope.launch { drawerState.open() }
    }
    fun closeDrawer() {
        scope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DrawerBg,
                drawerContentColor = White,
                drawerShape = RectangleShape
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    ChatDrawer(
                        modifier = Modifier.fillMaxSize(),
                        history = history,
                        currentId = currentId,
                        onNewChat = {
                            viewModel.newChat()
                            closeDrawer()
                        },
                        onOpenChat = { id ->
                            viewModel.openChat(id)
                            closeDrawer()
                        },
                        onDeleteChat = { id -> viewModel.deleteChat(id) },
                        onToggleAudit = {
                            showAudit = !showAudit
                            if (showAudit) viewModel.showAudit()
                            closeDrawer()
                        },
                        onOpenAiSettings = {
                            closeDrawer()
                            onOpenAiSettings()
                        }
                    )
                }
            }
        }
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Black)
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                TopBar(onBubble = onBubble, onMenu = { openDrawer() })

                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    if (showList) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Text(analyser, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(state.messages, key = { it.id }) { MessageBubble(it) }
                                if (state.liveSteps.isNotEmpty()) {
                                    item(key = "steps") { StepsCard(state.liveSteps.map { it.status to it.description + " — " + it.message }) }
                                }
                                if (showAudit) {
                                    item(key = "audit") { AuditCard(state.audit, onClear = viewModel::clearAudit) }
                                }
                            }
                        }
                    } else {
                        Image(
                            painter = painterResource(R.drawable.venex_logo_mark),
                            contentDescription = "شعار VENEX",
                            modifier = Modifier.size(112.dp)
                        )
                    }
                }

                speechError?.let {
                    Text(it, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
                InputCard(
                    input = input,
                    onInputChange = { input = it },
                    running = state.running,
                    thinking = thinking,
                    onToggleThinking = { thinking = !thinking },
                    onSend = send,
                    onStop = viewModel::cancel,
                    attachments = attachments,
                    onRemoveAttachment = { a -> attachments = attachments - a },
                    listening = speech.listening,
                    onMic = onMic,
                    onPickFiles = { pickFiles.launch(PICK_TYPES) }
                )
            }
        }
    }

    pending?.let { step ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { viewModel.answerConfirmation(false) },
                title = { Text("يلزم موافقتك") },
                text = { Text("هل توافق على تنفيذ: «${step.description}»؟") },
                confirmButton = { TextButton(onClick = { viewModel.answerConfirmation(true) }) { Text("موافق") } },
                dismissButton = { TextButton(onClick = { viewModel.answerConfirmation(false) }) { Text("رفض") } }
            )
        }
    }
}

// ---------- Top bar: floating button (top left), title and menu (top right) ----------

@Composable
private fun TopBar(onBubble: () -> Unit, onMenu: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleButton(onClick = onBubble) { FloatingIcon() }
            Spacer(Modifier.weight(1f))
            Text("Venex", color = White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.width(14.dp))
            CircleButton(onClick = onMenu) { MenuIcon() }
        }
    }
}

// ---------- Input card: text field, mic, "تفكير", plus / stop ----------

@Composable
private fun InputCard(
    input: String,
    onInputChange: (String) -> Unit,
    running: Boolean,
    thinking: Boolean,
    onToggleThinking: () -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    attachments: List<Attachment>,
    onRemoveAttachment: (Attachment) -> Unit,
    listening: Boolean,
    onMic: () -> Unit,
    onPickFiles: () -> Unit
) {
    val hasContent = input.isNotBlank() || attachments.isNotEmpty()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Panel)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        if (attachments.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                attachments.forEach { a ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, Outline, RoundedCornerShape(16.dp))
                            .clickable { onRemoveAttachment(a) }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(a.name + "  ✕", color = White, fontSize = 13.sp)
                    }
                }
            }
        }
        TextField(
            value = input,
            onValueChange = onInputChange,
            modifier = Modifier.fillMaxWidth(),
            enabled = !running,
            placeholder = { Text("اسأل Venex...", fontSize = 17.sp) },
            textStyle = TextStyle(fontSize = 17.sp),
            maxLines = 4,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent,
                focusedTextColor = White,
                unfocusedTextColor = White,
                cursorColor = Green,
                focusedPlaceholderColor = Muted,
                unfocusedPlaceholderColor = Muted
            )
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Text or attachments present: the send button replaces the microphone.
                if (hasContent && !running) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Green)
                            .clickable(onClick = onSend),
                        contentAlignment = Alignment.Center
                    ) { ArrowUpIcon() }
                } else {
                    CircleButton(onClick = onMic, size = 52.dp, filled = false) {
                        MicIcon(if (listening) Green else White)
                    }
                }
                Spacer(Modifier.width(10.dp))
                ThinkingPill(active = thinking, onClick = onToggleThinking)
                Spacer(Modifier.weight(1f))
                CircleButton(
                    onClick = if (running) onStop else onPickFiles,
                    size = 52.dp,
                    filled = false
                ) {
                    if (running) StopIcon() else PlusIcon()
                }
            }
        }
    }
}

@Composable
private fun ThinkingPill(active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, Outline, RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("تفكير", color = if (active) Green else White, fontSize = 16.sp)
    }
}

// ---------- Drawer (slides in from the right, 80% of the width) ----------

@Composable
private fun ChatDrawer(
    modifier: Modifier,
    history: List<SavedChat>,
    currentId: String,
    onNewChat: () -> Unit,
    onOpenChat: (String) -> Unit,
    onDeleteChat: (String) -> Unit,
    onToggleAudit: () -> Unit,
    onOpenAiSettings: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val shown = history.filter { query.isBlank() || it.title.contains(query.trim(), ignoreCase = true) }

    Box(modifier = modifier.background(DrawerBg)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                SearchPill(query = query, onQuery = { query = it })
                Spacer(Modifier.height(20.dp))
                DrawerItem(label = "دردشة جديدة", icon = { PencilIcon() }, onClick = onNewChat)
                DrawerItem(label = "الوسائط", icon = { MediaIcon() }, enabled = false)
                DrawerItem(label = "المستندات", icon = { DocsIcon() }, enabled = false)

                Spacer(Modifier.height(16.dp))
                Text("الدردشات", color = Muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 6.dp))
                if (shown.isEmpty()) {
                    Text(
                        if (history.isEmpty()) "ستظهر محادثاتك هنا بعد أول رسالة." else "لا توجد نتائج مطابقة.",
                        color = Muted,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    items(shown, key = { it.id }) { chat ->
                        ChatRow(
                            chat = chat,
                            selected = chat.id == currentId,
                            onOpen = { onOpenChat(chat.id) },
                            onDelete = { onDeleteChat(chat.id) }
                        )
                    }
                }

                HorizontalDivider(color = Outline)
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircleButton(onClick = onToggleAudit) { BellIcon() }
                    Spacer(Modifier.width(24.dp))
                    CircleButton(onClick = onOpenAiSettings) { GearIcon() }
                }
            }
        }
    }
}

@Composable
private fun SearchPill(query: String, onQuery: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(SearchBg)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SearchIcon()
        Spacer(Modifier.width(12.dp))
        BasicTextField(
            value = query,
            onValueChange = onQuery,
            singleLine = true,
            textStyle = TextStyle(color = White, fontSize = 18.sp),
            cursorBrush = SolidColor(Green),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("بحث", color = Muted, fontSize = 18.sp)
                    inner()
                }
            }
        )
    }
}

@Composable
private fun DrawerItem(
    label: String,
    icon: (@Composable () -> Unit)?,
    enabled: Boolean = true,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            icon()
            Spacer(Modifier.width(16.dp))
        }
        Text(label, color = if (enabled) White else Muted, fontSize = 19.sp)
        if (!enabled) {
            Spacer(Modifier.width(10.dp))
            Text("قريباً", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ChatRow(chat: SavedChat, selected: Boolean, onOpen: () -> Unit, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) SearchBg else Color.Transparent)
            .clickable(onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(chat.title, color = White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(formatChatDate(chat.updatedAt), color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .clickable(onClick = onDelete),
            contentAlignment = Alignment.Center
        ) { CloseIcon() }
    }
}

private fun formatChatDate(ms: Long): String =
    java.text.SimpleDateFormat("d MMM  HH:mm", java.util.Locale("ar")).format(java.util.Date(ms))

@Composable
private fun CloseIcon() {
    Canvas(Modifier.size(14.dp)) {
        fLine(Muted, 0.1f, 0.1f, 0.9f, 0.9f)
        fLine(Muted, 0.9f, 0.1f, 0.1f, 0.9f)
    }
}

// ---------- Attachments, message building and speech input ----------

private val PICK_TYPES = arrayOf("image/*", "application/pdf", "text/*", "application/json")
private const val MAX_TEXT_BYTES = 16 * 1024

data class Attachment(val name: String, val uri: Uri, val mime: String?) {
    val isText: Boolean get() = mime?.startsWith("text/") == true || mime == "application/json"
}

private fun readAttachment(context: Context, uri: Uri): Attachment {
    val mime = try { context.contentResolver.getType(uri) } catch (e: Exception) { null }
    var name = uri.lastPathSegment ?: "ملف"
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
    } catch (e: Exception) {
        // Keep the fallback name.
    }
    return Attachment(name, uri, mime)
}

private fun readTextFile(context: Context, uri: Uri): String? = try {
    context.contentResolver.openInputStream(uri)?.use { stream ->
        val bytes = stream.readBytes()
        String(bytes, 0, min(bytes.size, MAX_TEXT_BYTES), Charsets.UTF_8)
    }
} catch (e: Exception) {
    null
}

/** Text files are sent with their content; images and PDFs are only named (not read yet). */
private fun buildMessage(context: Context, typed: String, files: List<Attachment>): String {
    val parts = files.map { f ->
        val text = if (f.isText) readTextFile(context, f.uri) else null
        if (text != null) "[ملف: ${f.name}]\n$text"
        else "[ملف: ${f.name}] (محتوى الصور وملفات PDF لا يُقرأ بعد)"
    }
    return (parts + typed).filter { it.isNotBlank() }.joinToString("\n\n")
}

/** Wraps SpeechRecognizer; every call must happen on the main thread (Compose callbacks do). */
class SpeechInput(private val context: Context) {
    var listening by mutableStateOf(false)
        private set
    var onSpeechText: (String) -> Unit = {}
    var onSpeechError: (String) -> Unit = {}
    private var recognizer: SpeechRecognizer? = null

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            listening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) onSpeechText(text.trim())
        }
        override fun onError(error: Int) {
            listening = false
            if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                onSpeechError("تعذّر التعرّف على الصوت (رمز $error)")
            }
        }
        override fun onReadyForSpeech(params: Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onPartialResults(partialResults: Bundle?) = Unit
        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    fun start() {
        if (listening) return
        try {
            val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(context).also {
                it.setRecognitionListener(listener)
                recognizer = it
            }
            listening = true
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
                }
            )
        } catch (e: Exception) {
            listening = false
            onSpeechError("التعرف على الصوت غير متاح الآن")
        }
    }

    fun stop() {
        recognizer?.stopListening()
        listening = false
    }

    fun release() {
        recognizer?.destroy()
        recognizer = null
        listening = false
    }
}

// ---------- Shared pieces ----------

@Composable
private fun CircleButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 52.dp,
    filled: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .then(if (filled) Modifier.background(Panel) else Modifier.border(1.dp, Outline, CircleShape))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun Banner(text: String, actionLabel: String, onAction: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Panel,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text, fontSize = 13.sp, color = White)
            TextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
private fun MessageBubble(m: ChatMessage) {
    val bg = if (m.fromUser) MaterialTheme.colorScheme.primary else Panel
    val fg = if (m.fromUser) MaterialTheme.colorScheme.onPrimary else White
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (m.fromUser) Alignment.CenterStart else Alignment.CenterEnd
    ) {
        Text(
            text = m.text,
            color = fg,
            modifier = Modifier
                .background(bg, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun StepsCard(rows: List<Pair<com.venex.core.model.StepStatus, String>>) {
    Surface(shape = RoundedCornerShape(12.dp), color = Panel, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("خطوات التنفيذ", fontWeight = FontWeight.Bold, color = White)
            rows.forEach { (status, text) -> Text("${MainViewModel.symbol(status)} $text", fontSize = 13.sp, color = White) }
        }
    }
}

@Composable
private fun AuditCard(entries: List<AuditEntry>, onClear: () -> Unit) {
    Surface(shape = RoundedCornerShape(12.dp), color = Panel, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("سجل التنفيذ (آخر ${entries.size})", fontWeight = FontWeight.Bold, color = White)
            if (entries.isEmpty()) Text("لا توجد سجلات.", fontSize = 12.sp, color = White)
            entries.forEach { e ->
                val step = e.stepId?.let { "[$it] " } ?: ""
                Text("${e.level} $step${e.message}${e.evidence?.let { " — $it" } ?: ""}", fontSize = 11.sp, color = White)
            }
            TextButton(onClick = onClear) { Text("مسح السجل") }
        }
    }
}

// ---------- Icons (drawn with Canvas, so no icon library is needed) ----------

private fun DrawScope.fLine(c: Color, x1: Float, y1: Float, x2: Float, y2: Float) {
    drawLine(
        color = c,
        start = Offset(size.width * x1, size.height * y1),
        end = Offset(size.width * x2, size.height * y2),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
    )
}

private fun DrawScope.fRect(c: Color, x: Float, y: Float, w: Float, h: Float, r: Float, filled: Boolean = false) {
    drawRoundRect(
        color = c,
        topLeft = Offset(size.width * x, size.height * y),
        size = Size(size.width * w, size.height * h),
        cornerRadius = CornerRadius(size.width * r),
        style = if (filled) Fill else Stroke(width = 2.dp.toPx())
    )
}

private fun DrawScope.fCircle(c: Color, cx: Float, cy: Float, r: Float, filled: Boolean = false) {
    drawCircle(
        color = c,
        radius = size.width * r,
        center = Offset(size.width * cx, size.height * cy),
        style = if (filled) Fill else Stroke(width = 2.dp.toPx())
    )
}

private fun DrawScope.fArc(c: Color, x: Float, y: Float, w: Float, h: Float, start: Float, sweep: Float) {
    drawArc(
        color = c,
        startAngle = start,
        sweepAngle = sweep,
        useCenter = false,
        topLeft = Offset(size.width * x, size.height * y),
        size = Size(size.width * w, size.height * h),
        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
    )
}

private fun DrawScope.fPath(c: Color, pts: List<Pair<Float, Float>>, close: Boolean = false) {
    val p = Path()
    pts.forEachIndexed { i, pt ->
        val px = size.width * pt.first
        val py = size.height * pt.second
        if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
    }
    if (close) p.close()
    drawPath(p, c, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
}

@Composable
private fun FloatingIcon() {
    Canvas(Modifier.size(IconSize)) {
        fRect(Green, 0.06f, 0.24f, 0.68f, 0.56f, 0.14f)
        fRect(Green, 0.56f, 0.1f, 0.34f, 0.3f, 0.06f, filled = true)
    }
}

@Composable
private fun MenuIcon() {
    Canvas(Modifier.size(IconSize)) {
        fLine(White, 0.1f, 0.36f, 0.9f, 0.36f)
        fLine(White, 0.1f, 0.64f, 0.9f, 0.64f)
    }
}

@Composable
private fun MicIcon(color: Color = White) {
    Canvas(Modifier.size(IconSize)) {
        fRect(color, 0.36f, 0.06f, 0.28f, 0.5f, 0.14f)
        fArc(color, 0.2f, 0.28f, 0.6f, 0.46f, 0f, 180f)
        fLine(color, 0.5f, 0.74f, 0.5f, 0.92f)
    }
}

@Composable
private fun PlusIcon() {
    Canvas(Modifier.size(IconSize)) {
        fLine(White, 0.5f, 0.2f, 0.5f, 0.8f)
        fLine(White, 0.2f, 0.5f, 0.8f, 0.5f)
    }
}

@Composable
private fun ArrowUpIcon() {
    Canvas(Modifier.size(IconSize)) {
        fLine(Black, 0.5f, 0.2f, 0.5f, 0.8f)
        fLine(Black, 0.22f, 0.48f, 0.5f, 0.2f)
        fLine(Black, 0.78f, 0.48f, 0.5f, 0.2f)
    }
}

@Composable
private fun StopIcon() {
    Canvas(Modifier.size(IconSize)) {
        fRect(White, 0.28f, 0.28f, 0.44f, 0.44f, 0.06f, filled = true)
    }
}

@Composable
private fun SearchIcon() {
    Canvas(Modifier.size(IconSize)) {
        fCircle(Muted, 0.42f, 0.42f, 0.3f)
        fLine(Muted, 0.64f, 0.64f, 0.9f, 0.9f)
    }
}

@Composable
private fun ChatLockIcon() {
    Canvas(Modifier.size(IconSize)) {
        fRect(White, 0.04f, 0.08f, 0.9f, 0.62f, 0.28f)
        fArc(White, 0.62f, 0.4f, 0.24f, 0.24f, 180f, 180f)
        fRect(White, 0.56f, 0.56f, 0.36f, 0.34f, 0.06f, filled = true)
    }
}

@Composable
private fun PencilIcon() {
    Canvas(Modifier.size(IconSize)) {
        fRect(White, 0.08f, 0.14f, 0.8f, 0.8f, 0.2f)
        fLine(White, 0.4f, 0.6f, 0.84f, 0.16f)
    }
}

@Composable
private fun MediaIcon() {
    Canvas(Modifier.size(IconSize)) {
        fRect(White, 0.06f, 0.14f, 0.88f, 0.72f, 0.12f)
        fCircle(White, 0.3f, 0.36f, 0.08f, filled = true)
        fPath(White, listOf(0.14f to 0.8f, 0.42f to 0.5f, 0.56f to 0.64f, 0.66f to 0.54f, 0.86f to 0.8f))
    }
}

@Composable
private fun DocsIcon() {
    Canvas(Modifier.size(IconSize)) {
        fPath(White, listOf(0.28f to 0.06f, 0.5f to 0.28f, 0.28f to 0.5f, 0.06f to 0.28f), close = true)
        fPath(White, listOf(0.72f to 0.06f, 0.94f to 0.5f, 0.5f to 0.5f), close = true)
        fCircle(White, 0.28f, 0.74f, 0.2f)
        fRect(White, 0.56f, 0.56f, 0.38f, 0.38f, 0.06f)
    }
}

@Composable
private fun BellIcon() {
    Canvas(Modifier.size(IconSize)) {
        fPath(White, listOf(0.22f to 0.72f, 0.22f to 0.44f, 0.3f to 0.22f, 0.5f to 0.14f, 0.7f to 0.22f, 0.78f to 0.44f, 0.78f to 0.72f))
        fLine(White, 0.14f, 0.74f, 0.86f, 0.74f)
        fArc(White, 0.4f, 0.74f, 0.2f, 0.2f, 0f, 180f)
    }
}

@Composable
private fun GearIcon() {
    // A real gear: eight teeth around a ring, with a hole in the middle.
    Canvas(Modifier.size(IconSize)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val rOuter = size.width * 0.48f
        val rInner = size.width * 0.36f
        val rHole = size.width * 0.16f
        val teeth = 8
        val step = 2 * Math.PI / teeth
        val path = Path()
        for (t in 0 until teeth) {
            val a0 = t * step
            val profile = listOf(0.0 to rInner, 0.14 to rOuter, 0.46 to rOuter, 0.6 to rInner)
            profile.forEachIndexed { k, (fraction, r) ->
                val a = a0 + fraction * step
                val x = (cx + r * cos(a)).toFloat()
                val y = (cy + r * sin(a)).toFloat()
                if (t == 0 && k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
        }
        path.close()
        drawPath(path, White)
        drawCircle(Panel, radius = rHole, center = Offset(cx, cy))
    }
}
