package com.venex.app.device

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.venex.app.data.InstalledAppsRepository
import com.venex.core.device.ActionResult
import com.venex.core.device.AppResolution
import com.venex.core.device.AppResolver
import com.venex.core.device.Channel
import com.venex.core.device.DeviceController
import com.venex.core.device.InstalledApp
import com.venex.core.device.ScreenSnapshot
import com.venex.core.model.GlobalKey
import com.venex.core.model.ScrollDirection
import com.venex.core.model.Selector
import kotlinx.coroutines.delay

/**
 * Android implementation of the Interaction Layer.
 *  - INTENT / DEEP_LINK: official launch intents (always available);
 *  - ACCESSIBILITY: only while the user-enabled service is connected;
 *  - OFFICIAL_API and VISION: not implemented in V0.1, so they are never advertised.
 */
class AndroidDeviceController(
    private val context: Context,
    private val apps: InstalledAppsRepository = InstalledAppsRepository(context)
) : DeviceController {

    override fun capabilities(): Set<Channel> = buildSet {
        add(Channel.INTENT)
        add(Channel.DEEP_LINK)
        if (VenexAccessibilityService.isRunning()) add(Channel.ACCESSIBILITY)
    }

    override suspend fun resolveApp(query: String): AppResolution =
        AppResolver(apps.list()).resolve(query)

    override suspend fun launchApp(app: InstalledApp): ActionResult {
        val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            ?: return ActionResult.fail("لا يوجد نشاط إطلاق للتطبيق ${app.label}")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            return ActionResult.fail("تعذّر إطلاق ${app.label}: ${e.javaClass.simpleName}")
        }
        waitForForeground(app.packageName)
        return ActionResult.ok("تم إطلاق ${app.label}")
    }

    /** Best-effort wait so the next step does not race the app start; the engine still verifies. */
    private suspend fun waitForForeground(pkg: String) {
        val service = VenexAccessibilityService.instance ?: return
        repeat(25) {
            if (service.snapshot()?.packageName == pkg) return
            delay(200)
        }
    }

    override suspend fun openDeepLink(uri: String): ActionResult {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ActionResult.ok("تم فتح الرابط")
        } catch (e: ActivityNotFoundException) {
            ActionResult.fail("لا يوجد تطبيق يتعامل مع هذا الرابط")
        } catch (e: Exception) {
            ActionResult.fail("تعذّر فتح الرابط: ${e.javaClass.simpleName}")
        }
    }

    override suspend fun snapshot(): ScreenSnapshot? = VenexAccessibilityService.instance?.snapshot()

    override suspend fun click(selector: Selector): ActionResult =
        VenexAccessibilityService.instance?.click(selector) ?: notEnabled()

    override suspend fun typeText(selector: Selector?, text: String): ActionResult =
        VenexAccessibilityService.instance?.typeText(selector, text) ?: notEnabled()

    override suspend fun scroll(direction: ScrollDirection): ActionResult =
        VenexAccessibilityService.instance?.scroll(direction) ?: notEnabled()

    override suspend fun press(key: GlobalKey): ActionResult =
        VenexAccessibilityService.instance?.press(key) ?: notEnabled()

    private fun notEnabled() = ActionResult.fail("خدمة إمكانية الوصول غير مفعّلة")
}
