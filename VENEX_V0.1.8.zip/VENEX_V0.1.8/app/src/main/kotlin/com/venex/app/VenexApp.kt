package com.venex.app

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.Context
import com.venex.app.data.AndroidModelFileGateway
import com.venex.app.data.FileAuditSink
import com.venex.app.data.KeystoreSecretStore
import com.venex.app.data.SharedPrefsAiModeStore
import com.venex.app.data.SharedPrefsAiSettingsStore
import com.venex.app.data.SharedPrefsOnDeviceStore
import com.venex.app.device.AndroidDeviceController
import com.venex.app.llm.JniLlamaBridge
import com.venex.app.llm.LlamaCppRuntime
import com.venex.app.ui.ConfirmationBridge
import com.venex.core.VenexAssistant
import com.venex.core.adaptive.AdaptiveCoordinator
import com.venex.core.adaptive.FileTaskStateStore
import com.venex.core.ai.AiModeRouter
import com.venex.core.ai.AiSettingsController
import com.venex.core.ai.ConnectionTester
import com.venex.core.ai.DelegatingAiProvider
import com.venex.core.ai.EndpointRules
import com.venex.core.ai.InferenceTester
import com.venex.core.ai.ModelCatalog
import com.venex.core.ai.ProviderRegistry
import com.venex.core.ai.ondevice.OnDeviceController
import com.venex.core.audit.AuditLevel
import com.venex.core.audit.AuditLog
import com.venex.core.intent.LayeredIntentParser
import com.venex.core.memory.ExperienceMemory
import com.venex.core.memory.FileKnowledgeStore
import com.venex.core.planner.TaskPlanner
import com.venex.core.safety.ConfirmationApprovalHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.Executors

/** Manual dependency wiring (no DI framework needed at this size). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    /** Long-lived work that must outlive any screen: model loading, imports, memory-pressure unloads. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val audit = AuditLog(sinks = listOf(FileAuditSink(File(appContext.filesDir, "audit.jsonl"))))
    val device = AndroidDeviceController(appContext)
    val confirmations = ConfirmationBridge()

    val providers = ProviderRegistry()
    private val record: (String) -> Unit = { msg -> audit.record(AuditLevel.INFO, msg) }

    /** Path 1: a model server the owner runs (Ollama / OpenAI-compatible). Unchanged from V0.1.1. */
    val aiSettings = AiSettingsController(
        store = SharedPrefsAiSettingsStore(appContext),
        registry = providers,
        connectionTester = ConnectionTester(providers),
        inferenceTester = InferenceTester(providers),
        catalog = ModelCatalog(providers),
        audit = record
    )

    /** Path 2: a cloud provider with the owner's API key (HTTPS only; key encrypted with the Android Keystore). */
    val secrets = KeystoreSecretStore(appContext)
    val cloudSettings = AiSettingsController(
        store = SharedPrefsAiSettingsStore(appContext, SharedPrefsAiSettingsStore.CLOUD_FILE),
        registry = providers,
        connectionTester = ConnectionTester(providers),
        inferenceTester = InferenceTester(providers),
        catalog = ModelCatalog(providers),
        label = "المزوّد السحابي",
        endpointValidator = EndpointRules::validateCloud,
        secrets = secrets,
        secretAlias = "cloud_api_key",
        audit = record
    )

    /** Path 3: a GGUF model run inside VENEX with llama.cpp (JNI). Works offline. */
    val onDevice = OnDeviceController(
        store = SharedPrefsOnDeviceStore(appContext),
        gateway = AndroidModelFileGateway(appContext),
        runtime = LlamaCppRuntime(
            bridgeFactory = { JniLlamaBridge() },
            nativeLibDir = appContext.applicationInfo.nativeLibraryDir,
            // One dedicated background thread for every native call; never the main thread.
            dispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "venex-llm").apply { priority = Thread.NORM_PRIORITY - 1 } }
                .asCoroutineDispatcher()
        ),
        scope = appScope,
        audit = record
    )

    /** The owner's choice between OFF / SERVER / CLOUD / ON_DEVICE. Exactly one is active. */
    val aiRouter = AiModeRouter(SharedPrefsAiModeStore(appContext), aiSettings, cloudSettings, onDevice, record)

    /**
     * V0.1.8 adaptive layer (General Digital Environment Mastery). Everything stays on the phone: task state and the
     * learned control names are plain files in the app's private storage; nothing here needs a network or a model.
     * Approvals reuse the existing confirmation dialog, so nothing sensitive is ever approved automatically.
     */
    val experience = ExperienceMemory(FileKnowledgeStore(File(appContext.filesDir, "experience.jsonl")))
    val adaptive = AdaptiveCoordinator(
        device = device,
        audit = audit,
        approvals = ConfirmationApprovalHandler(confirmations),
        store = FileTaskStateStore(File(appContext.filesDir, "tasks.jsonl")),
        memory = experience,
        selfPackage = appContext.packageName,
        settleDelayMs = 300
    )

    /**
     * Intent understanding: restricted-action detector first, then the offline rules, and only for commands
     * the rules do not understand, the ACTIVE provider (if any) under a timeout. The model path is unchanged:
     * closed intent list, ModelReplyParser validation, planner, verifier and confirmations still apply.
     * 40 s covers a slow phone running a local model; each backend also enforces its own shorter limit.
     */
    val assistant = VenexAssistant(
        parser = LayeredIntentParser(ai = DelegatingAiProvider { aiRouter.activeIntentProvider() }, aiTimeoutMs = 40_000),
        planner = TaskPlanner(),
        device = device,
        audit = audit,
        confirmations = confirmations,
        settleDelayMs = 300,
        adaptive = adaptive
    )

    init {
        // If the owner enabled the on-device model, load it in the background so the first command is not slow.
        appScope.launch { onDevice.restoreIfEnabled() }
    }
}

class VenexApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }

    /**
     * Memory policy for the on-device model: free it when the system is short of memory, keep it enabled,
     * and reload lazily on the next command. Going to the background alone (TRIM_MEMORY_UI_HIDDEN) does NOT
     * unload: VENEX works on other apps while its own screen is hidden.
     */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL || level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) {
            if (::container.isInitialized) container.appScope.launch { container.onDevice.onMemoryPressure() }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        if (::container.isInitialized) container.appScope.launch { container.onDevice.onMemoryPressure() }
    }
}
