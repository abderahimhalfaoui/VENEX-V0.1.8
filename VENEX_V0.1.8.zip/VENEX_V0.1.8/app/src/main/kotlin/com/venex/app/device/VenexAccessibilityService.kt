package com.venex.app.device

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import com.venex.app.R
import com.venex.app.ui.MainActivity
import kotlin.math.abs
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.venex.core.device.ActionResult
import com.venex.core.device.Bounds
import com.venex.core.device.ScreenSnapshot
import com.venex.core.device.SelectorMatcher
import com.venex.core.device.UiNode
import com.venex.core.model.GlobalKey
import com.venex.core.model.ScrollDirection
import com.venex.core.model.Selector
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * The only component that reads or touches other apps' UI. It runs only after the USER enables it
 * in system settings; VENEX never grants itself this permission.
 *
 * Safety rules enforced here (in addition to SafetyPolicy in :core):
 *  - the text of password fields is never copied into a snapshot;
 *  - no text is typed into password fields;
 *  - the tree walk is bounded so a pathological screen cannot hang the service.
 *
 * Resource rule (audit fix): on API 26–32, every AccessibilityNodeInfo obtained from
 * rootInActiveWindow, getChild() or parent must be recycled. Each public operation therefore
 * runs inside [withTree], which releases every node it obtained, even when an action fails.
 */
class VenexAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        if (isBubbleEnabled(this)) showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit // the tree is read on demand

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideBubble()
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideBubble()
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** A portable node plus the live platform node it came from (valid only inside [withTree]). */
    private class Captured(val ui: UiNode, val info: AccessibilityNodeInfo)

    /**
     * Captures the active window, runs [block] on it, then recycles every node. Returns null when
     * there is no active window.
     */
    private inline fun <T> withTree(block: (nodes: List<Captured>, packageName: String?) -> T): T? {
        val root = rootInActiveWindow ?: return null
        val out = ArrayList<Captured>()
        try {
            walk(root, 0, -1, out)
            return block(out, root.packageName?.toString())
        } finally {
            out.forEach { recycle(it.info) }
            // The root is recycled by walk() when it is not kept, or here through `out` when it is.
        }
    }

    /**
     * Visits [node] and its children. Ownership: this function takes the node and either keeps it
     * in [out] (recycled later by withTree) or recycles it itself. Children are obtained and owned
     * the same way.
     */
    private fun walk(node: AccessibilityNodeInfo, depth: Int, parentIndex: Int, out: MutableList<Captured>) {
        var kept = false
        // V0.1.8: children inherit the nearest *captured* ancestor, so the hierarchy survives skipped (invisible) nodes.
        var myIndex = parentIndex
        if (depth <= MAX_DEPTH && out.size < MAX_NODES && node.isVisibleToUser) {
            val rect = Rect().also { node.getBoundsInScreen(it) }
            val password = node.isPassword
            myIndex = out.size
            out += Captured(
                UiNode(
                    text = if (password) null else node.text?.toString(),
                    contentDescription = if (password) null else node.contentDescription?.toString(),
                    viewId = node.viewIdResourceName,
                    className = node.className?.toString(),
                    clickable = node.isClickable,
                    editable = node.isEditable,
                    scrollable = node.isScrollable,
                    password = password,
                    enabled = node.isEnabled,
                    bounds = Bounds(rect.left, rect.top, rect.right, rect.bottom),
                    checkable = node.isCheckable,
                    checked = node.isChecked,
                    selected = node.isSelected,
                    focused = node.isFocused,
                    showingHint = !password && node.isShowingHintText,
                    depth = depth,
                    parentIndex = parentIndex
                ),
                node
            )
            kept = true
        }
        if (depth < MAX_DEPTH) {
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                walk(child, depth + 1, myIndex, out)
            }
        }
        if (!kept) recycle(node)
    }

    fun snapshot(): ScreenSnapshot? = withTree { nodes, pkg ->
        ScreenSnapshot(pkg, nodes.map { it.ui })
    }

    suspend fun click(selector: Selector): ActionResult {
        val result = withTree { nodes, _ ->
            val target = SelectorMatcher.findBest(nodes.map { it.ui }, selector)
                ?: return@withTree ActionResult.fail("لم أجد العنصر «${selector.describe()}» على الشاشة")
            val captured = nodes.first { it.ui === target }
            if (clickSelfOrAncestor(captured.info)) {
                return@withTree ActionResult.ok("تم النقر على «${selector.describe()}»")
            }
            // Pending gesture: returned to the caller below, outside the tree scope.
            ActionResult.fail(PENDING_TAP_PREFIX + (target.bounds?.let { "${it.centerX},${it.centerY}" } ?: ""))
        } ?: return ActionResult.fail("لا توجد نافذة نشطة لقراءتها")

        if (!result.success && result.message.startsWith(PENDING_TAP_PREFIX)) {
            val coords = result.message.removePrefix(PENDING_TAP_PREFIX).split(',')
            if (coords.size == 2 && coords[0].isNotEmpty()) {
                val x = coords[0].toFloat()
                val y = coords[1].toFloat()
                return if (tap(x, y)) ActionResult.ok("تم النقر (إيماءة) على «${selector.describe()}»")
                else ActionResult.fail("تعذّر تنفيذ النقر على «${selector.describe()}»")
            }
            return ActionResult.fail("العنصر «${selector.describe()}» غير قابل للنقر")
        }
        return result
    }

    fun typeText(selector: Selector?, text: String): ActionResult =
        withTree { nodes, _ ->
            val ui = nodes.map { it.ui }
            val targetUi = selector?.let { SelectorMatcher.findBest(ui, it) }
                ?: ui.firstOrNull { it.editable && !it.password }
                ?: return@withTree ActionResult.fail("لا يوجد حقل نصي لإدخال النص")
            if (targetUi.password) return@withTree ActionResult.fail("لا يكتب VENEX في حقول كلمات المرور")
            if (!targetUi.editable) return@withTree ActionResult.fail("العنصر المحدد ليس حقلاً نصياً")

            val info = nodes.first { it.ui === targetUi }.info
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            if (info.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                // Only the length is reported; the text itself is never logged.
                ActionResult.ok("تم إدخال نص (${text.length} حرف)")
            } else {
                ActionResult.fail("رفض التطبيق إدخال النص")
            }
        } ?: ActionResult.fail("لا توجد نافذة نشطة")

    fun scroll(direction: ScrollDirection): ActionResult =
        withTree { nodes, _ ->
            val scrollable = nodes.firstOrNull { it.ui.scrollable && it.ui.enabled }
                ?: return@withTree ActionResult.fail("لا يوجد عنصر قابل للتمرير على الشاشة")
            val action = if (direction == ScrollDirection.DOWN) {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            }
            if (scrollable.info.performAction(action)) ActionResult.ok("تم التمرير")
            else ActionResult.fail("لم يستجب العنصر لأمر التمرير (ربما وصل إلى النهاية)")
        } ?: ActionResult.fail("لا توجد نافذة نشطة")

    fun press(key: GlobalKey): ActionResult {
        val ok = performGlobalAction(if (key == GlobalKey.HOME) GLOBAL_ACTION_HOME else GLOBAL_ACTION_BACK)
        return if (ok) ActionResult.ok("تم تنفيذ $key") else ActionResult.fail("رفض النظام تنفيذ $key")
    }

    /** Clicks the node or the nearest clickable ancestor (at most 6 hops). Releases every node it obtains. */
    private fun clickSelfOrAncestor(info: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo = info
        var owned = false
        try {
            repeat(6) {
                if (current.isClickable && current.isEnabled && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
                val parent = current.parent ?: return false
                if (owned) recycle(current)
                current = parent
                owned = true
            }
            return false
        } finally {
            if (owned) recycle(current)
        }
    }

    private suspend fun tap(x: Float, y: Float): Boolean = suspendCancellableCoroutine { cont ->
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        val dispatched = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    if (cont.isActive) cont.resume(true)
                }

                override fun onCancelled(g: GestureDescription?) {
                    if (cont.isActive) cont.resume(false)
                }
            },
            null
        )
        if (!dispatched && cont.isActive) cont.resume(false)
    }

    // ---------- Floating bubble: drawn with the accessibility overlay, so no "display over apps" permission ----------

    private var bubble: View? = null

    private fun showBubble() {
        if (bubble != null) return
        val density = resources.displayMetrics.density
        val size = (56 * density).toInt()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = ImageView(this).apply {
            setImageResource(R.drawable.venex_logo_mark)
            val pad = (size * 0.2f).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1E1E1E.toInt())
            }
            contentDescription = "فتح VENEX"
        }
        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (16 * density).toInt()
            y = (120 * density).toInt()
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    lp.x = startX - dx.toInt() // gravity END: x grows toward the left edge
                    lp.y = startY + dy.toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) openVenex()
                }
            }
            true
        }
        try {
            wm.addView(view, lp)
            bubble = view
        } catch (e: Exception) {
            // The system refused the overlay; the bubble simply stays hidden.
        }
    }

    private fun hideBubble() {
        val view = bubble ?: return
        bubble = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view)
        } catch (e: Exception) {
            // Already detached.
        }
    }

    private fun openVenex() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    companion object {
        private const val PREFS = "venex_ui"
        private const val KEY_BUBBLE = "bubble_enabled"
        private const val MAX_DEPTH = 40
        private const val MAX_NODES = 1500
        private const val PENDING_TAP_PREFIX = "__tap__:"

        @Volatile
        var instance: VenexAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null

        fun isBubbleEnabled(context: Context): Boolean = try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_BUBBLE, false)
        } catch (e: Exception) {
            false
        }

        /** Saves the choice, then shows or hides the bubble now if the service is connected. */
        fun setBubbleEnabled(context: Context, enabled: Boolean) {
            try {
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_BUBBLE, enabled).apply()
            } catch (e: Exception) {
                // Storage unavailable: the choice applies to this session only.
            }
            instance?.let { if (enabled) it.showBubble() else it.hideBubble() }
        }

        /** Releases a node on platforms that still require it (recycle() is a no-op from API 33). */
        @Suppress("DEPRECATION")
        private fun recycle(node: AccessibilityNodeInfo) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) node.recycle()
        }
    }
}
