package com.venex.app.ui

import com.venex.core.engine.ConfirmationHandler
import com.venex.core.model.Step
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Connects the engine's confirmation requests to the UI. The engine suspends until the user taps
 * approve or decline; nothing is ever approved automatically.
 */
class ConfirmationBridge : ConfirmationHandler {

    private val _pending = MutableStateFlow<Step?>(null)
    val pending: StateFlow<Step?> = _pending

    private var waiter: CompletableDeferred<Boolean>? = null

    override suspend fun confirm(step: Step): Boolean {
        val deferred = CompletableDeferred<Boolean>()
        waiter = deferred
        _pending.value = step
        return try {
            deferred.await()
        } finally {
            _pending.value = null
            waiter = null
        }
    }

    fun answer(approved: Boolean) {
        waiter?.complete(approved)
    }
}
