package com.venex.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.venex.core.ai.AiMode
import com.venex.core.ai.AiSnapshot
import com.venex.core.ai.AiStage
import com.venex.core.ai.ProviderType
import com.venex.core.ai.ondevice.OnDeviceSnapshot
import com.venex.core.ai.ondevice.OnDeviceState
import com.venex.core.ai.ondevice.RuntimeParams
import com.venex.core.ai.ondevice.readiness

// Settings palette: matches the chat screen (black background, dark cards, one green accent).
private val Bg = Color(0xFF0B0B0C)
private val Card = Color(0xFF161618)
private val CardHi = Color(0xFF1F1F23)
private val Line = Color(0xFF2A2A2E)
private val Accent = Color(0xFF3CCFA1)
private val OnAccent = Color(0xFF04211A)
private val Ink = Color(0xFFF2F2F2)
private val Sub = Color(0xFF9A9AA0)
private val Warn = Color(0xFFE8B04B)
private val Bad = Color(0xFFE5736B)

private enum class Panel(val label: String) {
    ON_DEVICE("داخل الهاتف"),
    CLOUD("سحابي"),
    SERVER("خادم")
}

@Composable
fun AiSettingsScreen(
    viewModel: AiSettingsViewModel,
    onBack: () -> Unit,
    accessibilityOn: Boolean = true,
    onOpenAccessibility: () -> Unit = {}
) {
    val mode by viewModel.modeState.collectAsState()
    val notice by viewModel.notice.collectAsState()
    // Observed so the active-mode card and the panels refresh when any provider changes.
    val serverSnap by viewModel.serverState.collectAsState()
    val cloudSnap by viewModel.cloudState.collectAsState()
    val deviceSnap by viewModel.onDeviceState.collectAsState()
    var panel by remember { mutableStateOf(Panel.ON_DEVICE) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Bg)
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SettingsHeader(onBack = onBack)

            ModeCard(
                mode = mode.mode,
                description = viewModel.describeMode(),
                onStop = viewModel::useRulesOnly
            )
            notice?.let { Text(it, color = Accent, fontSize = 13.sp) }

            Section(
                title = "مصدر الذكاء الاصطناعي",
                hint = "اختر مساراً واحداً. يعمل VENEX بالقواعد المحلية حتى تُفعّل أحدها."
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Panel.values().forEach { p ->
                        Choice(
                            label = p.label,
                            selected = panel == p,
                            modifier = Modifier.weight(1f),
                            onClick = { panel = p }
                        )
                    }
                }
            }

            when (panel) {
                Panel.ON_DEVICE -> OnDevicePanel(viewModel, deviceSnap, activeMode = mode.mode)
                Panel.CLOUD -> CloudPanel(viewModel, cloudSnap, activeMode = mode.mode)
                Panel.SERVER -> ServerPanel(viewModel, serverSnap, activeMode = mode.mode)
            }

            Section(title = "إمكانية الوصول", hint = "تسمح لـ VENEX بقراءة الشاشة والنقر والتحقق من النتائج داخل التطبيقات، وهي مطلوبة للأيقونة العائمة.") {
                StatusLine(
                    label = "الحالة",
                    value = if (accessibilityOn) "مُفعّلة" else "غير مُفعّلة",
                    tone = if (accessibilityOn) Accent else Warn
                )
                if (!accessibilityOn) {
                    PrimaryButton(
                        text = "تفعيل من إعدادات الهاتف",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenAccessibility
                    )
                }
            }

            Section(title = "التفضيلات") {
                ComingSoonRow("المظهر", "الوضع الفاتح والألوان")
                Divider()
                ComingSoonRow("الإشعارات", "تنبيه عند انتهاء مهمة")
                Divider()
                ComingSoonRow("سجل المحادثات", "حفظ الأوامر السابقة على الجهاز")
            }

            Section(title = "حول") {
                StatusLine(label = "الإصدار", value = "0.1.8")
                Divider()
                StatusLine(label = "الخصوصية", value = "لا يُرسل شيء إلا بعد موافقتك")
            }

            GhostButton(
                text = "رجوع إلى المحادثة",
                modifier = Modifier.fillMaxWidth(),
                onClick = onBack
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ====================================================================== shared pieces

@Composable
private fun SettingsHeader(onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Card)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) {
            // In RTL the back arrow points to the right.
            Canvas(Modifier.size(18.dp)) {
                val w = 2.dp.toPx()
                drawLine(Ink, Offset(size.width * 0.62f, size.height * 0.18f), Offset(size.width * 0.36f, size.height * 0.5f), w, StrokeCap.Round)
                drawLine(Ink, Offset(size.width * 0.36f, size.height * 0.5f), Offset(size.width * 0.62f, size.height * 0.82f), w, StrokeCap.Round)
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("الإعدادات", color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("الذكاء الاصطناعي والاتصال والصلاحيات", color = Sub, fontSize = 13.sp)
        }
    }
}

@Composable
private fun ModeCard(mode: AiMode, description: String, onStop: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Card)
            .border(1.dp, Line, RoundedCornerShape(20.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(if (mode == AiMode.OFF) Sub else Accent)
            )
            Spacer(Modifier.width(8.dp))
            Text("المسار النشط", color = Sub, fontSize = 13.sp)
        }
        Text(mode.arabic, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(description, color = Sub, fontSize = 13.sp)
        if (mode != AiMode.OFF) {
            GhostButton(
                text = "إيقاف الذكاء الاصطناعي (القواعد المحلية فقط)",
                modifier = Modifier.fillMaxWidth(),
                onClick = onStop
            )
        }
    }
}

@Composable
private fun Section(title: String, hint: String? = null, content: @Composable () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 4.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Card)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            hint?.let { Text(it, color = Sub, fontSize = 13.sp) }
            content()
        }
    }
}

@Composable
private fun Divider() {
    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Line))
}

@Composable
private fun Badge(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(percent = 50))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.16f) else CardHi)
            .border(1.dp, if (selected) Accent else Line, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Accent else if (enabled) Ink else Sub,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Accent,
            contentColor = OnAccent,
            disabledContainerColor = CardHi,
            disabledContentColor = Sub
        )
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun GhostButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, danger: Boolean = false, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Line),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = if (danger) Bad else Ink,
            disabledContentColor = Sub
        )
    ) { Text(text) }
}

@Composable
private fun SettingsField(
    value: String,
    onValue: (String) -> Unit,
    label: String,
    placeholder: String? = null,
    secret: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(label) },
        placeholder = { if (placeholder != null) Text(placeholder) },
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Ink,
            unfocusedTextColor = Ink,
            focusedBorderColor = Accent,
            unfocusedBorderColor = Line,
            focusedLabelColor = Accent,
            unfocusedLabelColor = Sub,
            cursorColor = Accent,
            focusedContainerColor = CardHi,
            unfocusedContainerColor = CardHi
        )
    )
}

@Composable
private fun StatusLine(label: String, value: String, tone: Color = Ink) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Sub, fontSize = 13.sp)
        Spacer(Modifier.width(12.dp))
        Text(value, color = tone, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Note(text: String, tone: Color = Sub) {
    Text(text, color = tone, fontSize = 13.sp, lineHeight = 20.sp)
}

@Composable
private fun ComingSoonRow(title: String, subtitle: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 15.sp)
            Text(subtitle, color = Sub, fontSize = 12.sp)
        }
        Badge("قريباً", Sub)
    }
}

@Composable
private fun ButtonRow(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

// ====================================================================== on-device

@Composable
private fun OnDevicePanel(vm: AiSettingsViewModel, snap: OnDeviceSnapshot, activeMode: AiMode) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        vm.onFilePicked(uri?.toString())
    }
    val busyStates = setOf(OnDeviceState.IMPORTING, OnDeviceState.LOADING, OnDeviceState.TESTING, OnDeviceState.UNLOADING)
    val busy = snap.state in busyStates
    val model = snap.model
    val imported = model?.imported
    val canImport = !busy && model != null && imported == null
    val canLoad = !busy && imported != null && snap.state != OnDeviceState.LOADED

    Section(
        title = "النموذج داخل الهاتف",
        hint = "نموذج GGUF تنزّله أنت، ويعمل داخل VENEX عبر llama.cpp: بلا إنترنت، وبلا خادم، وبلا مفتاح. التطبيق لا يحتوي على أي نموذج."
    ) {
        StatusLine(
            label = "الحالة",
            value = snap.readiness,
            tone = if (snap.enabled) Accent else Ink
        )
        StatusLine(label = "الملف", value = model?.displayName ?: "لم يُحدَّد")
        model?.let { m ->
            if (m.sizeBytes > 0) StatusLine(label = "الحجم", value = "${m.sizeBytes / (1024 * 1024)} MB")
            StatusLine(
                label = "المعمارية",
                value = (m.gguf.architecture ?: "؟") + (m.gguf.quantization?.let { " • $it" } ?: "")
            )
            StatusLine(label = "نسخة التطبيق", value = if (imported != null) "جاهزة (الأصل لم يُمسّ)" else "لم تُستورد بعد")
        }
        StatusLine(label = "مرحلة الملف", value = snap.state.arabic)

        if (snap.state == OnDeviceState.IMPORTING) {
            val total = snap.importTotalBytes
            if (total > 0) {
                LinearProgressIndicator(
                    progress = { (snap.importCopiedBytes.toFloat() / total).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = Accent
                )
                Note("${snap.importCopiedBytes / (1024 * 1024)} / ${total / (1024 * 1024)} MB")
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Accent)
                Note("${snap.importCopiedBytes / (1024 * 1024)} MB")
            }
        }

        snap.loadReport?.let { r ->
            StatusLine(label = "المحرك", value = r.info.description)
            StatusLine(label = "زمن التحميل", value = "${r.loadMs} ms")
            val b = r.memoryBefore
            val a = r.memoryAfter
            if (b != null && a != null) {
                Note(
                    "ذاكرة النظام المتاحة: ${b.availableBytes / (1024 * 1024)} MB قبل التحميل و${a.availableBytes / (1024 * 1024)} MB بعده (قياس تقريبي من النظام)."
                )
            }
        }

        snap.testReport?.let { t ->
            StatusLine(
                label = "آخر اختبار استدلال",
                value = if (t.passed) "نجح" else "لم ينجح",
                tone = if (t.passed) Accent else Bad
            )
            Note("الرد: «${t.answer}» خلال ${t.latencyMs} ms")
        }

        snap.message?.let { Note(it, Ink) }
        snap.errorMessage?.let { Note("الخطأ: $it", Bad) }
        Note("حجم الملف ليس هو استهلاك الذاكرة أثناء التشغيل. النماذج الكبيرة قد تكون بطيئة على هاتف محدود الذاكرة.")
    }

    Section(title = "١ · اختيار النموذج") {
        ButtonRow {
            GhostButton(
                text = "اختيار ملف GGUF",
                enabled = !busy,
                modifier = Modifier.weight(1f),
                onClick = { picker.launch(arrayOf("*/*")) }
            )
            PrimaryButton(
                text = "استيراد",
                enabled = canImport,
                modifier = Modifier.weight(1f),
                onClick = vm::importModel
            )
        }
    }

    Section(title = "٢ · الإعدادات", hint = "قيم محافظة لمعظم الهواتف. السياق الأكبر يستهلك ذاكرة أكثر.") {
        Note("طول السياق")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RuntimeParams.CONTEXT_OPTIONS.forEach { c ->
                Choice(
                    label = "$c",
                    selected = snap.params.contextLength == c,
                    modifier = Modifier.weight(1f),
                    enabled = !busy
                ) { vm.setParams(c, snap.params.threads) }
            }
        }
        Note("عدد الخيوط (المقترح لهذا الجهاز: ${vm.defaultParams().threads})")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(1, 2, 3, 4, 6, 8).forEach { t ->
                Choice(
                    label = "$t",
                    selected = snap.params.threads == t,
                    modifier = Modifier.weight(1f),
                    enabled = !busy
                ) { vm.setParams(snap.params.contextLength, t) }
            }
        }
    }

    Section(title = "٣ · التحميل والاختبار", hint = "الاختبار الحقيقي: النموذج نفسه يولّد الرد على سؤال ثابت.") {
        ButtonRow {
            GhostButton(text = "تحميل", enabled = canLoad, modifier = Modifier.weight(1f), onClick = vm::loadModel)
            GhostButton(
                text = "اختبار",
                enabled = !busy && imported != null,
                modifier = Modifier.weight(1f),
                onClick = vm::testOnDevice
            )
            GhostButton(
                text = "تفريغ",
                enabled = !busy && snap.state == OnDeviceState.LOADED,
                modifier = Modifier.weight(1f),
                onClick = vm::unloadModel
            )
        }
        if (busy) {
            GhostButton(text = "إلغاء العملية الجارية", modifier = Modifier.fillMaxWidth(), onClick = vm::cancelOnDevice)
        }
    }

    Section(title = "٤ · التفعيل", hint = "يبقى مُطفأً حتى ينجح الاختبار. عند التفعيل يستقبل النموذج الأوامر التي لا تفهمها القواعد فقط، ولا يرسل ولا يكتب ولا يحذف ولا يدفع.") {
        PrimaryButton(
            text = "تفعيل النموذج الداخلي",
            modifier = Modifier.fillMaxWidth(),
            enabled = !busy && snap.verified && !(snap.enabled && activeMode == AiMode.ON_DEVICE),
            onClick = { vm.activate(AiMode.ON_DEVICE) }
        )
        GhostButton(
            text = "حذف النموذج المستورد وإعداداته",
            danger = true,
            modifier = Modifier.fillMaxWidth(),
            enabled = !busy && model != null,
            onClick = vm::clearOnDevice
        )
        Note("الأصل الذي اخترته يبقى في مكانه؛ الحذف يخص النسخة الداخلية فقط.")
    }
}

// ====================================================================== cloud

private data class CloudPreset(val label: String, val baseUrl: String)

private val CLOUD_PRESETS = listOf(
    CloudPreset("OpenAI", "https://api.openai.com"),
    CloudPreset("OpenRouter", "https://openrouter.ai/api"),
    CloudPreset("Groq", "https://api.groq.com/openai"),
    CloudPreset("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai"),
    CloudPreset("مخصص", "")
)

@Composable
private fun CloudPanel(vm: AiSettingsViewModel, snap: AiSnapshot, activeMode: AiMode) {
    val busy by vm.busy.collectAsState()
    var url by remember { mutableStateOf(snap.config?.baseUrl ?: "") }
    var model by remember { mutableStateOf(snap.config?.modelId ?: "") }
    var apiKey by remember { mutableStateOf("") }
    var consent by remember { mutableStateOf(false) }
    val host = vm.cloudHost()

    Section(
        title = "المزوّد السحابي",
        hint = "عند تفعيله، الأوامر التي لا تفهمها القواعد (نصها فقط) تُرسل عبر الإنترنت إلى المزوّد الذي تحدده بمفتاحك. الأوامر التي تفهمها القواعد والأوامر المحظورة لا تُرسل إطلاقاً. المفتاح مشفّر بـ Android Keystore ولا يظهر في الواجهة."
    ) {
        StatusLine(label = "الحالة", value = snap.stage.arabic, tone = if (snap.stage == AiStage.INFERENCE_OK) Accent else Ink)
        snap.config?.let {
            StatusLine(label = "العنوان", value = it.baseUrl)
            StatusLine(label = "النموذج", value = it.modelId)
        } ?: Note("لم يُحدَّد مزوّد بعد.")
        StatusLine(label = "مفتاح API", value = if (snap.hasApiKey) "محفوظ (مخفي)" else "غير محفوظ")
        snap.connectionMessage?.let { Note("اتصال: $it") }
        snap.inferenceMessage?.let { Note("استدلال: $it") }
        snap.errorMessage?.let { Note("الخطأ: $it", Bad) }
    }

    Section(title = "١ · الإعداد") {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CLOUD_PRESETS.forEach { p ->
                Choice(
                    label = p.label,
                    selected = p.baseUrl.isNotEmpty() && url == p.baseUrl
                ) { url = p.baseUrl }
            }
        }
        SettingsField(value = url, onValue = { url = it }, label = "عنوان API (https فقط)", placeholder = "https://api.example.com")
        SettingsField(value = model, onValue = { model = it }, label = "اسم النموذج")
        SettingsField(
            value = apiKey,
            onValue = { apiKey = it },
            label = if (snap.hasApiKey) "مفتاح جديد (اتركه فارغاً للإبقاء على المحفوظ)" else "مفتاح API",
            secret = true
        )
        ButtonRow {
            PrimaryButton(
                text = "حفظ",
                enabled = !busy,
                modifier = Modifier.weight(1f),
                onClick = { vm.saveCloud(url, model, apiKey); apiKey = "" }
            )
            GhostButton(
                text = "اكتشاف النماذج",
                enabled = !busy && snap.config != null,
                modifier = Modifier.weight(1f),
                onClick = vm::discoverCloud
            )
        }
        if (snap.discoveredModels.isNotEmpty()) {
            Note("النماذج المتاحة")
            snap.discoveredModels.take(30).forEach { id ->
                Choice(label = if (model == id) "✓  $id" else id, selected = model == id, modifier = Modifier.fillMaxWidth()) { model = id }
            }
        }
    }

    Section(title = "٢ · الاختبار", hint = "يرسل طلباً حقيقياً إلى المزوّد بمفتاحك، وقد يُحتسب عليك.") {
        ButtonRow {
            GhostButton(
                text = "اختبار الاتصال",
                enabled = !busy && snap.config != null,
                modifier = Modifier.weight(1f),
                onClick = vm::testCloudConnection
            )
            GhostButton(
                text = "اختبار الاستدلال",
                enabled = !busy && snap.config != null,
                modifier = Modifier.weight(1f),
                onClick = vm::testCloudInference
            )
        }
    }

    Section(title = "٣ · الموافقة والتفعيل") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = consent,
                onCheckedChange = { consent = it },
                colors = CheckboxDefaults.colors(checkedColor = Accent, uncheckedColor = Sub, checkmarkColor = OnAccent)
            )
            Spacer(Modifier.width(6.dp))
            Text("أوافق على إرسال الأوامر غير المفهومة محلياً إلى ${host ?: "المزوّد"} عبر الإنترنت", color = Ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
        }
        PrimaryButton(
            text = "تفعيل المزوّد السحابي",
            modifier = Modifier.fillMaxWidth(),
            enabled = !busy && (snap.stage == AiStage.INFERENCE_OK || (snap.enabled && activeMode != AiMode.CLOUD)),
            onClick = { vm.activate(AiMode.CLOUD, cloudConsent = consent) }
        )
        ButtonRow {
            GhostButton(text = "حذف المفتاح", enabled = snap.hasApiKey, modifier = Modifier.weight(1f), danger = true, onClick = vm::deleteCloudKey)
            GhostButton(
                text = "حذف الإعداد والمفتاح",
                enabled = snap.config != null || snap.hasApiKey,
                modifier = Modifier.weight(1f),
                danger = true,
                onClick = vm::clearCloud
            )
        }
        Note("أي تغيير في العنوان أو النموذج أو المفتاح يوقف التفعيل ويتطلب إعادة اختبار الاستدلال والموافقة على المضيف الجديد.")
    }
}

// ====================================================================== server

@Composable
private fun ServerPanel(vm: AiSettingsViewModel, snap: AiSnapshot, activeMode: AiMode) {
    val busy by vm.busy.collectAsState()
    var type by remember { mutableStateOf(snap.config?.type ?: ProviderType.OLLAMA) }
    var url by remember { mutableStateOf(snap.config?.baseUrl ?: type.defaultBaseUrl) }
    var model by remember { mutableStateOf(snap.config?.modelId ?: "") }
    var bearer by remember { mutableStateOf("") }

    Section(
        title = "خادم النموذج",
        hint = "خادم تشغّله أنت على هاتفك (مثل Termux) أو على جهاز في شبكتك. عند التفعيل تُرسل الأوامر غير المفهومة إلى هذا الخادم فقط."
    ) {
        StatusLine(
            label = "الحالة",
            value = snap.stage.arabic + if (busy) " (جارٍ الاختبار…)" else "",
            tone = if (snap.stage == AiStage.INFERENCE_OK) Accent else Ink
        )
        snap.config?.let {
            StatusLine(label = "المزوّد", value = it.type.arabicName)
            StatusLine(label = "النموذج", value = it.modelId)
            StatusLine(label = "العنوان", value = it.baseUrl)
        } ?: Note("لم يُحدَّد نموذج بعد.")
        snap.connectionMessage?.let { Note("اتصال: $it") }
        snap.inferenceMessage?.let { Note("استدلال: $it") }
        snap.errorMessage?.let { Note("الخطأ: $it", Bad) }
        snap.warnings.forEach { Note("⚠ $it", Warn) }
    }

    Section(title = "١ · الإعداد") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProviderType.values().forEach { t ->
                Choice(
                    label = if (t == ProviderType.OLLAMA) "Ollama" else "متوافق مع OpenAI",
                    selected = type == t,
                    modifier = Modifier.weight(1f)
                ) {
                    val previous = type
                    type = t
                    if (url.isBlank() || url == previous.defaultBaseUrl) url = t.defaultBaseUrl
                }
            }
        }
        Note(type.arabicName)
        SettingsField(value = url, onValue = { url = it }, label = "عنوان الخادم", placeholder = type.defaultBaseUrl)
        SettingsField(value = model, onValue = { model = it }, label = "اسم النموذج")
        SettingsField(value = bearer, onValue = { bearer = it }, label = "مفتاح الوصول (اختياري، لا يُحفظ)", secret = true)
        ButtonRow {
            PrimaryButton(
                text = "حفظ الإعداد",
                enabled = !busy,
                modifier = Modifier.weight(1f),
                onClick = { vm.saveServer(type, url, model, bearer) }
            )
            GhostButton(
                text = "اكتشاف النماذج",
                enabled = !busy,
                modifier = Modifier.weight(1f),
                onClick = { vm.discoverServer(bearer) }
            )
        }
        if (snap.discoveredModels.isNotEmpty()) {
            Note("النماذج المتاحة على الخادم")
            snap.discoveredModels.forEach { id ->
                Choice(label = if (model == id) "✓  $id" else id, selected = model == id, modifier = Modifier.fillMaxWidth()) { model = id }
            }
        }
    }

    Section(title = "٢ · الاختبار", hint = "يرسل طلباً حقيقياً إلى الخادم.") {
        ButtonRow {
            GhostButton(
                text = "اختبار الاتصال",
                enabled = !busy,
                modifier = Modifier.weight(1f),
                onClick = { vm.testServerConnection(bearer) }
            )
            GhostButton(
                text = "اختبار الاستدلال",
                enabled = !busy,
                modifier = Modifier.weight(1f),
                onClick = { vm.testServerInference(bearer) }
            )
        }
    }

    Section(title = "٣ · التفعيل", hint = "أي اختبار اتصال أو تعديل للإعداد يوقف التفعيل، ويجب إعادة اختبار الاستدلال قبل تفعيله مجدداً.") {
        PrimaryButton(
            text = "تفعيل الخادم لـ VENEX",
            modifier = Modifier.fillMaxWidth(),
            enabled = !busy && !(snap.enabled && activeMode == AiMode.SERVER),
            onClick = { vm.activate(AiMode.SERVER) }
        )
        ButtonRow {
            GhostButton(text = "فصل الاتصال", enabled = snap.config != null, modifier = Modifier.weight(1f), onClick = vm::disconnectServer)
            GhostButton(text = "حذف الإعدادات", enabled = snap.config != null, modifier = Modifier.weight(1f), danger = true, onClick = vm::clearServer)
        }
    }
}
