package com.venex.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One saved message. Only text is kept; attachments are not stored. */
data class SavedMessage(val fromUser: Boolean, val text: String)

data class SavedChat(
    val id: String,
    val title: String,
    val updatedAt: Long,
    val messages: List<SavedMessage>
)

/**
 * Chat history kept only on this device, in the app's private storage (not included in backups).
 * Stored as one JSON array. Keeps the newest [MAX_CHATS] chats; each keeps its last [MAX_MESSAGES] messages.
 */
class ConversationStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun loadAll(): List<SavedChat> {
        val raw: String? = try {
            prefs.getString(KEY, null)
        } catch (e: Exception) {
            null
        }
        if (raw == null) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i -> fromJson(arr.getJSONObject(i)) }
                .sortedByDescending { it.updatedAt }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(chat: SavedChat) {
        val trimmed = chat.copy(messages = chat.messages.takeLast(MAX_MESSAGES))
        val others = loadAll().filter { it.id != chat.id }
        write((others + trimmed).sortedByDescending { it.updatedAt }.take(MAX_CHATS))
    }

    fun delete(id: String) {
        write(loadAll().filter { it.id != id })
    }

    private fun write(chats: List<SavedChat>) {
        val arr = JSONArray()
        chats.forEach { arr.put(toJson(it)) }
        try {
            prefs.edit().putString(KEY, arr.toString()).apply()
        } catch (e: Exception) {
            // Storage unavailable: the conversation stays in memory for this session only.
        }
    }

    private fun toJson(c: SavedChat): JSONObject {
        val messages = JSONArray()
        c.messages.forEach { m ->
            messages.put(JSONObject().put("fromUser", m.fromUser).put("text", m.text))
        }
        return JSONObject()
            .put("id", c.id)
            .put("title", c.title)
            .put("updatedAt", c.updatedAt)
            .put("messages", messages)
    }

    private fun fromJson(o: JSONObject): SavedChat {
        val msgs = o.getJSONArray("messages")
        return SavedChat(
            id = o.getString("id"),
            title = o.getString("title"),
            updatedAt = o.getLong("updatedAt"),
            messages = (0 until msgs.length()).map { i ->
                val m = msgs.getJSONObject(i)
                SavedMessage(m.getBoolean("fromUser"), m.getString("text"))
            }
        )
    }

    companion object {
        private const val PREFS = "venex_chats"
        private const val KEY = "chats"
        const val MAX_CHATS = 50
        const val MAX_MESSAGES = 200
    }
}
