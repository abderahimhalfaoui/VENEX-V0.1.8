package com.venex.app.data

import android.content.Context
import com.venex.core.ai.AiSettingsStore
import com.venex.core.ai.AiStage
import com.venex.core.ai.LocalModelConfig
import com.venex.core.ai.ProviderType
import com.venex.core.ai.StoredAiSettings

/**
 * Persists the local-model setup in app-private SharedPreferences (excluded from backups by
 * allowBackup="false"). It stores the server address, model name and flags. It NEVER stores an API
 * key or bearer token: for a local server those live only in memory for the current session; for the
 * cloud provider the API key is kept separately, encrypted, by [KeystoreSecretStore].
 *
 * [fileName] lets the cloud provider use its own file; the default keeps V0.1.1 data readable.
 */
class SharedPrefsAiSettingsStore(context: Context, fileName: String = FILE) : AiSettingsStore {

    private val prefs = context.applicationContext.getSharedPreferences(fileName, Context.MODE_PRIVATE)

    override fun read(): StoredAiSettings? {
        return try {
            val typeName = prefs.getString(KEY_TYPE, null) ?: return null
            val type = ProviderType.valueOf(typeName)
            val url = prefs.getString(KEY_URL, null) ?: return null
            val model = prefs.getString(KEY_MODEL, null) ?: return null
            val timeout = prefs.getInt(KEY_TIMEOUT, 15_000)
            val stage = runCatching { AiStage.valueOf(prefs.getString(KEY_STAGE, "").orEmpty()) }
                .getOrDefault(AiStage.CONFIGURED)
            StoredAiSettings(
                config = LocalModelConfig(type, url, model, timeout),
                enabled = prefs.getBoolean(KEY_ENABLED, false),
                verifiedFingerprint = prefs.getString(KEY_VERIFIED, null),
                stage = stage
            )
        } catch (e: Exception) {
            // Corrupt or unknown values: behave as "not configured" rather than crashing.
            null
        }
    }

    override fun write(settings: StoredAiSettings?) {
        try {
            val editor = prefs.edit()
            val c = settings?.config
            if (settings == null || c == null) {
                editor.clear()
            } else {
                editor.putString(KEY_TYPE, c.type.name)
                    .putString(KEY_URL, c.baseUrl)
                    .putString(KEY_MODEL, c.modelId)
                    .putInt(KEY_TIMEOUT, c.timeoutMs)
                    .putBoolean(KEY_ENABLED, settings.enabled)
                    .putString(KEY_VERIFIED, settings.verifiedFingerprint)
                    .putString(KEY_STAGE, settings.stage.name)
            }
            editor.apply()
        } catch (_: Exception) {
            // Storage failure must not break the assistant; the in-memory state still works.
        }
    }

    companion object {
        const val FILE = "venex_ai_settings"
        const val CLOUD_FILE = "venex_ai_cloud_settings"
        private const val KEY_TYPE = "type"
        private const val KEY_URL = "url"
        private const val KEY_MODEL = "model"
        private const val KEY_TIMEOUT = "timeout_ms"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_VERIFIED = "verified_fingerprint"
        private const val KEY_STAGE = "stage"
    }
}
