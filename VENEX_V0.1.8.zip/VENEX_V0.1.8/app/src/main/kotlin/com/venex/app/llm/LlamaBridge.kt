package com.venex.app.llm

/**
 * The narrow surface of the native engine (libvenex_llm.so, see app/src/main/cpp). It exists so that
 * [LlamaCppRuntime] can be unit-tested on a plain JVM with a fake, while production uses [JniLlamaBridge].
 * Error codes mirror `enum ErrorCode` in venex_llm.h.
 */
interface LlamaBridge {
    fun init(nativeLibDir: String): Int
    fun load(path: String, nCtx: Int, nThreads: Int): Int
    fun unload()
    fun isLoaded(): Boolean
    /** Thread-safe: aborts a running load or generation. */
    fun cancel()
    fun clearCancel()
    /** Returns UTF-8 bytes, or null on failure (see [lastErrorCode]). [stats] = promptTok, genTok, promptMs, genMs, truncated(0|1). */
    fun complete(system: String, user: String, maxTokens: Int, stats: LongArray): ByteArray?
    fun lastErrorCode(): Int
    fun lastError(): String
    /** "description|tensorBytes|params|ctxTrain|ctx|threads" */
    fun modelInfo(): String
    fun systemInfo(): String
}

object NativeError {
    const val NONE = 0
    const val CANCELLED = 1
    const val NOT_LOADED = 2
    const val LOAD_FAILED = 3
    const val CONTEXT_FAILED = 4
    const val PROMPT_TOO_LONG = 5
    const val DECODE_FAILED = 6
    const val OUT_OF_MEMORY = 7
    const val TOKENIZE_FAILED = 8
    const val NO_BACKEND = 9
    const val BUSY = 10
    const val INTERNAL = 11
}

/** Production bridge. Constructing it loads the native library; failure throws [UnsatisfiedLinkError]. */
class JniLlamaBridge : LlamaBridge {
    init { System.loadLibrary("venex_llm") }

    private external fun nativeInit(dir: String): Int
    private external fun nativeLoad(path: String, nCtx: Int, nThreads: Int): Int
    private external fun nativeUnload()
    private external fun nativeIsLoaded(): Boolean
    private external fun nativeCancel()
    private external fun nativeClearCancel()
    private external fun nativeComplete(system: String, user: String, maxTokens: Int, stats: LongArray): ByteArray?
    private external fun nativeLastErrorCode(): Int
    private external fun nativeLastError(): String
    private external fun nativeModelInfo(): String
    private external fun nativeSystemInfo(): String

    override fun init(nativeLibDir: String) = nativeInit(nativeLibDir)
    override fun load(path: String, nCtx: Int, nThreads: Int) = nativeLoad(path, nCtx, nThreads)
    override fun unload() = nativeUnload()
    override fun isLoaded() = nativeIsLoaded()
    override fun cancel() = nativeCancel()
    override fun clearCancel() = nativeClearCancel()
    override fun complete(system: String, user: String, maxTokens: Int, stats: LongArray) =
        nativeComplete(system, user, maxTokens, stats)
    override fun lastErrorCode() = nativeLastErrorCode()
    override fun lastError() = nativeLastError()
    override fun modelInfo() = nativeModelInfo()
    override fun systemInfo() = nativeSystemInfo()
}
