package com.venex.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Teal = Color(0xFF3CCFA1) // the official logo green
private val Ink = Color(0xFF101820)

private val DarkColors = darkColorScheme(
    primary = Teal,
    onPrimary = Ink,
    background = Color(0xFF000000),
    surface = Color(0xFF1E1E1E),
    onBackground = Color(0xFFEAF2F5),
    onSurface = Color(0xFFEAF2F5)
)

@Composable
fun VenexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        // The reference design is dark; the app always uses the dark palette.
        colorScheme = DarkColors,
        content = content
    )
}
