package com.venex.app.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import com.venex.app.ui.MainActivity

/**
 * Lets the user choose VENEX as the default digital assistant (Settings > Apps > Default apps >
 * Digital assistant app). The system then invokes it via the assist gesture, e.g. long-press on
 * Home, where the device/ROM allows it. MIUI may restrict or relocate this setting.
 */
class VenexVoiceInteractionService : VoiceInteractionService()

class VenexVoiceInteractionSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = VenexVoiceInteractionSession(this)
}

/** Opens the VENEX chat screen when the assist gesture fires. */
class VenexVoiceInteractionSession(context: Context) : VoiceInteractionSession(context) {

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        startAssistantActivity(Intent(context, MainActivity::class.java))
        hide()
    }
}

/**
 * The assistant framework expects a recognition service to be declared. V0.1 has NO speech
 * recognition: every request is rejected with an error rather than pretending to listen.
 */
class VenexRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onCancel(listener: Callback?) = Unit

    override fun onStopListening(listener: Callback?) = Unit
}
