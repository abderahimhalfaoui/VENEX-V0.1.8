package com.venex.app.ui

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.compose.runtime.mutableStateOf
import com.venex.app.device.VenexAccessibilityService
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.venex.app.VenexApp
import com.venex.core.ai.AiMode
import com.venex.core.ai.AiModeSnapshot
import com.venex.core.ai.AiSettingsController
import com.venex.core.ai.AiSnapshot
import com.venex.core.ai.ProviderType
import com.venex.core.ai.SaveResult
import com.venex.core.ai.ondevice.OnDeviceController
import com.venex.core.ai.ondevice.OnDeviceSnapshot
import com.venex.core.ai.ondevice.RuntimeParams
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AiSettingsActivity : ComponentActivity() {

    private val viewModel: AiSettingsViewModel by viewModels()
    private val accessibilityOn = mutableStateOf(false)

    override fun onResume() {
        super.onResume()
        accessibilityOn.value = VenexAccessibilityService.isRunning()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VenexTheme {
                AiSettingsScreen(
                    viewModel = viewModel,
                    onBack = { finish() },
                    accessibilityOn = accessibilityOn.value,
                    onOpenAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                )
            }
        }
    }
}

/**
 * Runs the settings actions. Long-lived work (importing a model, loading it, testing it) is launched in the
 * application scope, NOT viewModelScope, so leaving or rotating the screen does not silently cancel it;
 * the Cancel button does. Network tests run on Dispatchers.Default; native inference runs on its own thread.
 */
class AiSettingsViewModel(app: Application) : AndroidViewModel(app) {

    private val container = (app as VenexApp).container
    private val server: AiSettingsController = container.aiSettings
    private val cloud: AiSettingsController = container.cloudSettings
    private val onDevice: OnDeviceController = container.onDevice
    private val router = container.aiRouter

    val serverState: StateFlow<AiSnapshot> = server.state
    val cloudState: StateFlow<AiSnapshot> = cloud.state
    val onDeviceState: StateFlow<OnDeviceSnapshot> = onDevice.state
    val modeState: StateFlow<AiModeSnapshot> = router.state

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    fun describeMode(): String = router.describe()
    fun cloudHost(): String? = router.cloudHost()

    // ------------------------------------------------------------ mode

    fun activate(mode: AiMode, cloudConsent: Boolean = false) {
        container.appScope.launch {
            val err = router.activate(mode, cloudConsent)
            _notice.value = err ?: when (mode) {
                AiMode.OFF -> "تم الإيقاف. يعمل VENEX بالمحلل المحلي فقط."
                else -> "تم تفعيل: ${mode.arabic}"
            }
        }
    }

    fun useRulesOnly() = activate(AiMode.OFF)

    // ------------------------------------------------------------ server (V0.1.1 behaviour)

    fun saveServer(type: ProviderType, url: String, model: String, bearer: String) {
        server.setSessionBearer(bearer)
        when (val r = server.saveConfig(type, url, model)) {
            is SaveResult.Rejected -> _notice.value = r.reason
            is SaveResult.Saved -> _notice.value = "تم الحفظ. اختبر الاتصال ثم الاستدلال قبل التفعيل."
        }
    }

    fun discoverServer(bearer: String) = runBusy { server.setSessionBearer(bearer); server.discoverModels() }
    fun testServerConnection(bearer: String) = runBusy { server.setSessionBearer(bearer); server.testConnection() }
    fun testServerInference(bearer: String) = runBusy { server.setSessionBearer(bearer); server.testInference() }
    fun disconnectServer() { server.disconnect(); _notice.value = "تم الفصل." }
    fun clearServer() { server.clearSettings(); _notice.value = "تم مسح إعدادات الخادم." }

    // ------------------------------------------------------------ cloud

    /** Saves the address/model, and the API key if one was typed (an empty field keeps the stored key). */
    fun saveCloud(url: String, model: String, apiKey: String) {
        when (val r = cloud.saveConfig(ProviderType.OPENAI_COMPATIBLE, url, model, timeoutMs = 20_000)) {
            is SaveResult.Rejected -> { _notice.value = r.reason; return }
            is SaveResult.Saved -> Unit
        }
        if (apiKey.isNotBlank()) {
            val err = cloud.saveApiKey(apiKey)
            if (err != null) { _notice.value = err; return }
        }
        _notice.value = "تم الحفظ. اختبر الاتصال ثم الاستدلال، ثم وافق على الإرسال وفعّل المزوّد."
    }

    fun discoverCloud() = runBusy { cloud.discoverModels() }
    fun testCloudConnection() = runBusy { cloud.testConnection() }
    fun testCloudInference() = runBusy { cloud.testInference() }
    fun deleteCloudKey() { cloud.deleteApiKey(); _notice.value = "تم حذف مفتاح API." }
    fun clearCloud() { cloud.clearSettings(); _notice.value = "تم مسح إعدادات المزوّد السحابي ومفتاحه." }

    // ------------------------------------------------------------ on-device

    fun onFilePicked(uri: String?) {
        if (uri == null) { _notice.value = "أُلغي اختيار الملف."; return }   // picker cancelled: nothing changes
        container.appScope.launch { onDevice.selectFile(uri) }
    }

    fun importModel() { container.appScope.launch { onDevice.importSelected() } }
    fun loadModel() { container.appScope.launch { onDevice.load() } }
    fun testOnDevice() { container.appScope.launch { _notice.value = onDevice.testInference() } }
    fun cancelOnDevice() = onDevice.cancelCurrent()
    fun unloadModel() { container.appScope.launch { onDevice.unload() } }
    fun clearOnDevice() { container.appScope.launch { onDevice.clear() } }
    fun setParams(ctx: Int, threads: Int) { container.appScope.launch { onDevice.changeParams(RuntimeParams(ctx, threads)) } }
    fun defaultParams(): RuntimeParams = RuntimeParams.forCpuCount(Runtime.getRuntime().availableProcessors())

    private fun runBusy(block: suspend () -> String) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            try {
                _notice.value = withContext(Dispatchers.Default) { block() }
            } finally {
                _busy.value = false
            }
        }
    }
}
