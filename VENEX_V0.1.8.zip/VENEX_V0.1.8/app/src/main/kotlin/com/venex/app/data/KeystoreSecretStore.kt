package com.venex.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.venex.core.ai.SecretStore
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * API keys, encrypted with AES-256-GCM using a key that lives in the Android Keystore (hardware-backed
 * where the device supports it) and never leaves it. Only `iv || ciphertext` is written to private
 * SharedPreferences. The alias is bound as additional authenticated data, so a value cannot be moved
 * to another alias. Backups are disabled for the app, and the Keystore key is not backed up in any case:
 * after a restore or a wiped key the entry simply fails to decrypt and is dropped (the owner re-enters it).
 *
 * Nothing here logs a key, a ciphertext or an exception message.
 */
class KeystoreSecretStore(context: Context) : SecretStore {

    private val prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    override fun put(alias: String, value: String) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())   // the Keystore generates a fresh random IV
        cipher.updateAAD(alias.toByteArray(Charsets.UTF_8))
        val ct = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val blob = cipher.iv + ct
        // commit(): a secret must be durable before we report success.
        if (!prefs.edit().putString(alias, Base64.encodeToString(blob, Base64.NO_WRAP)).commit()) {
            throw IllegalStateException("write failed")
        }
    }

    override fun get(alias: String): String? {
        val stored = prefs.getString(alias, null) ?: return null
        return try {
            val blob = Base64.decode(stored, Base64.NO_WRAP)
            if (blob.size <= IV_BYTES) return dropCorrupt(alias)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(TAG_BITS, blob, 0, IV_BYTES))
            cipher.updateAAD(alias.toByteArray(Charsets.UTF_8))
            String(cipher.doFinal(blob, IV_BYTES, blob.size - IV_BYTES), Charsets.UTF_8)
        } catch (e: Exception) {
            dropCorrupt(alias)
        }
    }

    private fun dropCorrupt(alias: String): String? {
        prefs.edit().remove(alias).apply()
        return null
    }

    override fun delete(alias: String) {
        prefs.edit().remove(alias).commit()
    }

    override fun has(alias: String): Boolean = prefs.contains(alias) && get(alias) != null

    companion object {
        private const val FILE = "venex_secrets"
        private const val PROVIDER = "AndroidKeyStore"
        private const val KEY_ALIAS = "venex_api_keys_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_BYTES = 12
        private const val TAG_BITS = 128
    }
}
