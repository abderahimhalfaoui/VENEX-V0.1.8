package com.venex.app.data

import android.content.Context
import com.venex.core.ai.AiMode
import com.venex.core.ai.AiModeStore
import com.venex.core.ai.StoredAiMode

/** Which AI path the owner chose, and which cloud host they acknowledged. No secrets, no content. */
class SharedPrefsAiModeStore(context: Context) : AiModeStore {
    private val prefs = context.applicationContext.getSharedPreferences("venex_ai_mode", Context.MODE_PRIVATE)

    override fun read(): StoredAiMode? {
        val name = prefs.getString("mode", null) ?: return null
        val mode = runCatching { AiMode.valueOf(name) }.getOrNull() ?: return null
        return StoredAiMode(mode, prefs.getString("cloud_consent_host", null))
    }

    override fun write(value: StoredAiMode) {
        prefs.edit().putString("mode", value.mode.name).putString("cloud_consent_host", value.cloudConsentHost).apply()
    }
}
