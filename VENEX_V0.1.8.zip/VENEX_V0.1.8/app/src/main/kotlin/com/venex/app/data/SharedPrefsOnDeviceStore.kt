package com.venex.app.data

import android.content.Context
import com.venex.core.ai.ondevice.GgufSummary
import com.venex.core.ai.ondevice.ImportedModel
import com.venex.core.ai.ondevice.OnDeviceStore
import com.venex.core.ai.ondevice.RuntimeParams
import com.venex.core.ai.ondevice.SelectedModel
import com.venex.core.ai.ondevice.StoredOnDevice

/**
 * On-device settings in app-private SharedPreferences. It stores the document URI the owner picked
 * (an opaque string, not a path), the display name, header facts, the name of the private copy (a bare
 * file name inside filesDir/models, never an absolute path), its SHA-256, the chosen parameters and the
 * enabled / verified flags. It stores no prompt, no reply and no command text.
 */
class SharedPrefsOnDeviceStore(context: Context) : OnDeviceStore {
    private val prefs = context.applicationContext.getSharedPreferences("venex_on_device", Context.MODE_PRIVATE)

    override fun read(): StoredOnDevice? = try {
        val uri = prefs.getString("uri", null)
        val params = RuntimeParams(prefs.getInt("ctx", RuntimeParams.DEFAULT_CONTEXT), prefs.getInt("threads", RuntimeParams.DEFAULT_THREADS))
        if (uri == null) {
            null
        } else {
            val gguf = GgufSummary(
                version = prefs.getInt("g_version", 3),
                tensorCount = prefs.getLong("g_tensors", 0),
                metadataCount = prefs.getLong("g_kv", 0),
                architecture = prefs.getString("g_arch", null),
                name = prefs.getString("g_name", null),
                fileType = if (prefs.contains("g_ftype")) prefs.getInt("g_ftype", 0) else null,
                trainedContextLength = if (prefs.contains("g_ctx")) prefs.getLong("g_ctx", 0) else null
            )
            val imported = prefs.getString("i_name", null)?.let {
                ImportedModel(it, prefs.getLong("i_size", 0), prefs.getString("i_sha", "").orEmpty())
            }
            StoredOnDevice(
                model = SelectedModel(uri, prefs.getString("name", "").orEmpty(), prefs.getLong("size", 0), gguf, imported),
                params = params,
                enabled = prefs.getBoolean("enabled", false),
                verifiedFingerprint = prefs.getString("verified", null)
            )
        }
    } catch (e: Exception) {
        null // corrupt values behave as "nothing selected"
    }

    override fun write(settings: StoredOnDevice?) {
        try {
            val ed = prefs.edit().clear()
            val m = settings?.model
            if (settings != null && m != null) {
                ed.putString("uri", m.uri).putString("name", m.displayName).putLong("size", m.sizeBytes)
                    .putInt("g_version", m.gguf.version).putLong("g_tensors", m.gguf.tensorCount).putLong("g_kv", m.gguf.metadataCount)
                    .putString("g_arch", m.gguf.architecture).putString("g_name", m.gguf.name)
                m.gguf.fileType?.let { ed.putInt("g_ftype", it) }
                m.gguf.trainedContextLength?.let { ed.putLong("g_ctx", it) }
                m.imported?.let { ed.putString("i_name", it.fileName).putLong("i_size", it.sizeBytes).putString("i_sha", it.sha256) }
                ed.putInt("ctx", settings.params.contextLength).putInt("threads", settings.params.threads)
                    .putBoolean("enabled", settings.enabled).putString("verified", settings.verifiedFingerprint)
            }
            ed.apply()
        } catch (_: Exception) {
            // Storage failure must not break the assistant.
        }
    }
}
