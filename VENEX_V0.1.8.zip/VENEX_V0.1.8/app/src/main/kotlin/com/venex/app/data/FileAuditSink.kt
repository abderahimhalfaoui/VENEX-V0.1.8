package com.venex.app.data

import com.venex.core.audit.AuditEntry
import com.venex.core.audit.AuditSink
import java.io.File

/**
 * Appends audit entries as JSON lines to app-private storage (never external storage) and rotates
 * the file at ~512 KB so the log cannot grow without bound.
 */
class FileAuditSink(private val file: File, private val maxBytes: Long = 512 * 1024) : AuditSink {

    private val lock = Any()

    override fun write(entry: AuditEntry) {
        synchronized(lock) {
            if (file.exists() && file.length() > maxBytes) {
                val old = File(file.parentFile, file.name + ".1")
                old.delete()
                file.renameTo(old)
            }
            file.appendText(entry.toJsonLine() + "\n", Charsets.UTF_8)
        }
    }
}
