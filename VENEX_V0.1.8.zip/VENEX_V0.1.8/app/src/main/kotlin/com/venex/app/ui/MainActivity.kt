package com.venex.app.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.venex.app.R

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        // The launch theme (Theme.Venex.Splash) draws the logo splash; switch to the normal theme before content.
        setTheme(R.style.Theme_Venex)
        super.onCreate(savedInstanceState)
        setContent {
            VenexTheme {
                ChatScreen(
                    viewModel = viewModel,
                    onOpenAccessibilitySettings = {
                        // The USER must switch the service on; the app cannot (and never tries to).
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    onOpenAssistantSettings = {
                        try {
                            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
                        } catch (e: Exception) {
                            startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                        }
                    },
                    onOpenAiSettings = {
                        startActivity(Intent(this, AiSettingsActivity::class.java))
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshAccessibility()
    }
}
