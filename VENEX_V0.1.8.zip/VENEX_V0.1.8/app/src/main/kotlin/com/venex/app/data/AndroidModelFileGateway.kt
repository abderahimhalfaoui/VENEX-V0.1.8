package com.venex.app.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import com.venex.core.ai.FailureKind
import com.venex.core.ai.ProviderFailure
import com.venex.core.ai.ProviderResult
import com.venex.core.ai.ondevice.GgufFileName
import com.venex.core.ai.ondevice.GgufParseResult
import com.venex.core.ai.ondevice.GgufParser
import com.venex.core.ai.ondevice.ImportedModel
import com.venex.core.ai.ondevice.InspectedFile
import com.venex.core.ai.ondevice.MemorySample
import com.venex.core.ai.ondevice.ModelFileGateway
import com.venex.core.ai.ondevice.PickedFile
import com.venex.core.ai.ondevice.StreamImporter
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException

/**
 * Storage Access Framework access to the GGUF file the owner picked (ACTION_OPEN_DOCUMENT). No storage
 * permission is requested. Because llama.cpp loads from a file path, the document is copied once into
 * `filesDir/models/` (private to VENEX). The original is only read, never modified or deleted.
 */
class AndroidModelFileGateway(
    context: Context,
    private val io: CoroutineDispatcher = Dispatchers.IO
) : ModelFileGateway {

    private val app = context.applicationContext
    private val resolver get() = app.contentResolver
    private val modelsDir = File(app.filesDir, "models")

    override suspend fun inspect(uri: String): ProviderResult<InspectedFile> = withContext(io) {
        val u = try { Uri.parse(uri) } catch (e: Exception) { return@withContext err(FailureKind.FILE_ACCESS, "عنوان الملف غير صالح") }
        // Keep read access across restarts when the provider supports it (not all do; failure is fine).
        try { resolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}

        var name: String? = null
        var size: Long? = null
        try {
            resolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si).takeIf { it > 0 }
                }
            }
        } catch (e: SecurityException) {
            return@withContext err(FailureKind.FILE_ACCESS, "لا توجد صلاحية لقراءة الملف؛ اختره من جديد")
        } catch (e: Exception) {
            return@withContext err(FailureKind.FILE_ACCESS, "تعذّر قراءة معلومات الملف")
        }
        val displayName = (name ?: u.lastPathSegment ?: "model.gguf").take(120)
        GgufFileName.problem(displayName)?.let { return@withContext err(FailureKind.INVALID_MODEL_FILE, it) }
        if (size != null && size!! < MIN_PLAUSIBLE_BYTES) {
            return@withContext err(FailureKind.INVALID_MODEL_FILE, "الملف صغير جداً ليكون نموذجاً (${size} بايت)")
        }
        try {
            val stream = resolver.openInputStream(u)
                ?: return@withContext err(FailureKind.FILE_ACCESS, "تعذّر فتح الملف (مزوّد الملفات رفض الطلب)")
            stream.buffered().use { input ->
                when (val p = GgufParser.parse(input)) {
                    is GgufParseResult.Invalid -> err(FailureKind.INVALID_MODEL_FILE, p.reason)
                    is GgufParseResult.Ok -> ProviderResult.Ok(InspectedFile(PickedFile(uri, displayName, size), p.summary), 0)
                }
            }
        } catch (e: SecurityException) {
            err(FailureKind.FILE_ACCESS, "سُحبت صلاحية قراءة الملف؛ اختره من جديد")
        } catch (e: FileNotFoundException) {
            err(FailureKind.FILE_ACCESS, "الملف لم يعد موجوداً أو نُقل؛ اختره من جديد")
        } catch (e: Exception) {
            err(FailureKind.FILE_ACCESS, "تعذّرت قراءة الملف")
        }
    }

    override suspend fun import(file: PickedFile, onProgress: (Long, Long) -> Unit): ProviderResult<ImportedModel> =
        withContext(io) {
            try {
                val stream = resolver.openInputStream(Uri.parse(file.uri))
                    ?: return@withContext err(FailureKind.FILE_ACCESS, "تعذّر فتح الملف الأصلي")
                stream.use {
                    StreamImporter.copy(it, file.sizeBytes, modelsDir, IMPORTED_NAME, { freeBytes() }, onProgress)
                }
            } catch (e: SecurityException) {
                err(FailureKind.FILE_ACCESS, "سُحبت صلاحية قراءة الملف؛ اختره من جديد")
            } catch (e: FileNotFoundException) {
                err(FailureKind.FILE_ACCESS, "الملف الأصلي لم يعد موجوداً")
            }
        }

    override fun resolvePath(imported: ImportedModel): String? {
        // The name comes from our own store; refuse anything that is not a bare file name.
        if (imported.fileName.contains('/') || imported.fileName.contains("..")) return null
        val f = File(modelsDir, imported.fileName)
        return if (f.isFile && f.length() == imported.sizeBytes) f.absolutePath else null
    }

    override suspend fun deleteImported(imported: ImportedModel) = withContext(io) {
        if (!imported.fileName.contains('/') && !imported.fileName.contains("..")) {
            File(modelsDir, imported.fileName).delete()
            File(modelsDir, imported.fileName + ".part").delete()
        }
        Unit
    }

    override fun memory(): MemorySample? = try {
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        MemorySample(info.availMem, info.totalMem, info.lowMemory)
    } catch (e: Exception) { null }

    private fun freeBytes(): Long {
        modelsDir.mkdirs()
        return StatFs(modelsDir.absolutePath).availableBytes
    }

    private fun err(kind: FailureKind, msg: String) = ProviderResult.Err(ProviderFailure(kind, msg))

    companion object {
        const val IMPORTED_NAME = "model.gguf"
        private const val MIN_PLAUSIBLE_BYTES = 1_000_000L
    }
}
