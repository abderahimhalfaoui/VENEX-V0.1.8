package com.venex.app.llm

import com.venex.core.ai.ChatPrompt
import com.venex.core.ai.Completion
import com.venex.core.ai.FailureKind
import com.venex.core.ai.ProviderFailure
import com.venex.core.ai.ProviderResult
import com.venex.core.ai.ondevice.LlmRuntime
import com.venex.core.ai.ondevice.LoadedInfo
import com.venex.core.ai.ondevice.RuntimeParams
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * [LlmRuntime] backed by llama.cpp through [LlamaBridge].
 *
 *  - All native calls run on [dispatcher], a SINGLE background thread (never the main thread), which also
 *    serialises them. The native layer is additionally mutex-protected.
 *  - Coroutine cancellation and timeouts call the native cancel flag, so a running load or generation
 *    stops within one decode step; the call then returns and resources stay consistent.
 *  - If the native library cannot be loaded (wrong ABI, missing file) every call returns
 *    [FailureKind.RUNTIME_UNAVAILABLE] instead of crashing.
 */
class LlamaCppRuntime(
    private val bridgeFactory: () -> LlamaBridge,
    private val nativeLibDir: String,
    private val dispatcher: CoroutineDispatcher
) : LlmRuntime {

    @Volatile private var bridge: LlamaBridge? = null
    @Volatile private var unavailable: ProviderFailure? = null
    private var initialised = false

    /** Runs on [dispatcher] only. */
    private fun ensureBridge(): ProviderFailure? {
        unavailable?.let { return it }
        if (initialised && bridge != null) return null
        try {
            val b = bridge ?: bridgeFactory().also { bridge = it }
            val rc = b.init(nativeLibDir)
            if (rc != NativeError.NONE) {
                val f = ProviderFailure(
                    FailureKind.RUNTIME_UNAVAILABLE,
                    "تعذّر تهيئة محرك الاستدلال على هذا الجهاز (${b.lastError().ifBlank { "code $rc" }})"
                )
                unavailable = f
                return f
            }
            initialised = true
            return null
        } catch (e: UnsatisfiedLinkError) {
            val f = ProviderFailure(FailureKind.RUNTIME_UNAVAILABLE, "مكتبة الاستدلال الأصلية غير متاحة لهذا الجهاز (ABI غير مدعوم أو ملف مفقود)")
            unavailable = f
            return f
        } catch (e: Throwable) {
            val f = ProviderFailure(FailureKind.RUNTIME_UNAVAILABLE, "تعذّر بدء محرك الاستدلال: ${e.javaClass.simpleName}")
            unavailable = f
            return f
        }
    }

    /** Runs [block] on the native thread. On cancellation the native operation is aborted and awaited. */
    private suspend fun <T> onNativeThread(block: () -> T): T = coroutineScope {
        val job = async(dispatcher) { block() }
        try {
            job.await()
        } catch (e: CancellationException) {
            bridge?.cancel()
            withContext(NonCancellable) { job.join() }
            throw e
        }
    }

    override suspend fun load(path: String, params: RuntimeParams): ProviderResult<LoadedInfo> {
        val started = System.nanoTime()
        return onNativeThread {
            ensureBridge()?.let { return@onNativeThread ProviderResult.Err(it) }
            val b = bridge!!
            b.clearCancel()
            val rc = b.load(path, params.contextLength, params.threads)
            if (rc != NativeError.NONE) return@onNativeThread ProviderResult.Err(mapFailure(rc, b.lastError(), forLoad = true))
            val info = parseInfo(b.modelInfo()) ?: LoadedInfo("unknown", 0, 0, 0, params.contextLength, params.threads)
            ProviderResult.Ok(info, (System.nanoTime() - started) / 1_000_000)
        }
    }

    override suspend fun complete(prompt: ChatPrompt, timeoutMs: Long): ProviderResult<Completion> {
        val started = System.nanoTime()
        val r = withTimeoutOrNull(timeoutMs) {
            onNativeThread {
                val b = bridge ?: return@onNativeThread ProviderResult.Err(ProviderFailure(FailureKind.NOT_READY, "المحرك غير مهيأ"))
                b.clearCancel()
                val stats = LongArray(5)
                val bytes = b.complete(prompt.system, prompt.user, prompt.maxTokens, stats)
                if (bytes == null) {
                    ProviderResult.Err(mapFailure(b.lastErrorCode(), b.lastError(), forLoad = false))
                } else if (stats[4] == 1L) {
                    // The budget ran out before the model ended its reply: the text is incomplete, never an answer.
                    ProviderResult.Err(ProviderFailure(FailureKind.INVALID_RESPONSE, "توقّف الرد قبل اكتماله (بلغ حد الرموز)"))
                } else {
                    // Decode as UTF-8 here so partial multi-byte sequences become replacement chars, not crashes.
                    ProviderResult.Ok(
                        Completion(String(bytes, Charsets.UTF_8), "on-device"),
                        (System.nanoTime() - started) / 1_000_000
                    )
                }
            }
        }
        return r ?: ProviderResult.Err(ProviderFailure(FailureKind.TIMEOUT, "انتهت مهلة الاستدلال على الجهاز (${timeoutMs / 1000}s)؛ سيُستخدم المحلل المحلي"))
    }

    override fun cancel() { bridge?.cancel() }

    override suspend fun unload() {
        withContext(NonCancellable) {
            withContext(dispatcher) { bridge?.takeIf { initialised }?.unload() }
        }
    }

    /** Honest diagnostics (CPU features the runtime chose), for the report. Empty if not initialised. */
    fun systemInfo(): String = if (initialised) bridge?.systemInfo().orEmpty() else ""

    companion object {
        internal fun mapFailure(code: Int, detail: String, forLoad: Boolean): ProviderFailure = when (code) {
            NativeError.CANCELLED -> ProviderFailure(FailureKind.CANCELLED, "أُلغيت العملية")
            NativeError.NOT_LOADED -> ProviderFailure(FailureKind.NOT_READY, "النموذج غير محمّل")
            NativeError.LOAD_FAILED -> ProviderFailure(
                FailureKind.INVALID_MODEL_FILE,
                "تعذّر تحميل النموذج: الملف تالف أو معماريته غير مدعومة في هذا الإصدار من المحرك أو الذاكرة لا تكفي"
            )
            NativeError.CONTEXT_FAILED, NativeError.OUT_OF_MEMORY -> ProviderFailure(
                FailureKind.OUT_OF_MEMORY,
                "نفدت الذاكرة" + if (forLoad) " أثناء التحميل؛ جرّب طول سياق أصغر أو نموذجاً أصغر" else " أثناء الاستدلال"
            )
            NativeError.PROMPT_TOO_LONG -> ProviderFailure(FailureKind.PROMPT_TOO_LONG, "الأمر أطول من طول السياق المضبوط")
            NativeError.NO_BACKEND -> ProviderFailure(FailureKind.RUNTIME_UNAVAILABLE, "لا يوجد backend معالج صالح في مكتبات المحرك")
            else -> ProviderFailure(FailureKind.INVALID_RESPONSE, "فشل المحرك (رمز $code): ${detail.take(120)}")
        }

        internal fun parseInfo(s: String): LoadedInfo? {
            val p = s.split('|')
            if (p.size < 6) return null
            return try {
                LoadedInfo(p[0], p[1].toLong(), p[2].toLong(), p[3].toInt(), p[4].toInt(), p[5].toInt())
            } catch (e: NumberFormatException) { null }
        }
    }
}
