package com.venex.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.venex.app.VenexApp
import com.venex.app.data.ConversationStore
import com.venex.app.data.SavedChat
import com.venex.app.data.SavedMessage
import com.venex.app.device.VenexAccessibilityService
import com.venex.core.audit.AuditEntry
import com.venex.core.audit.AuditLevel
import com.venex.core.ai.AiSnapshot
import com.venex.core.ai.AiStage
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import com.venex.core.model.StepResult
import com.venex.core.model.StepStatus
import com.venex.core.model.TaskStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: Long,
    val fromUser: Boolean,
    val text: String,
    val status: TaskStatus? = null
)

data class UiState(
    val messages: List<ChatMessage> = listOf(
        ChatMessage(
            0, false,
            "أهلاً، أنا VENEX. اكتب أمراً مثل: «افتح تطبيق الآلة الحاسبة واحسب 125 × 8»."
        )
    ),
    val running: Boolean = false,
    val accessibilityEnabled: Boolean = false,
    val liveSteps: List<StepResult> = emptyList(),
    val audit: List<AuditEntry> = emptyList()
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val container = (app as VenexApp).container
    private val assistant = container.assistant

    private val _state = MutableStateFlow(UiState(accessibilityEnabled = VenexAccessibilityService.isRunning()))
    val state: StateFlow<UiState> = _state

    private val store = ConversationStore(app)
    private val _history = MutableStateFlow(store.loadAll())

    /** Saved conversations on this device, newest first. */
    val history: StateFlow<List<SavedChat>> = _history

    private val _currentChatId = MutableStateFlow(newChatId())
    val currentChatId: StateFlow<String> = _currentChatId

    val pendingConfirmation = container.confirmations.pending

    /** One line for the chat screen: which analyser is in use right now. */
    val analyserLabel: StateFlow<String> = combine(
        container.aiRouter.state,
        container.aiSettings.state,
        container.cloudSettings.state,
        container.onDevice.state
    ) { _, _, _, _ -> container.aiRouter.describe() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, container.aiRouter.describe())

    private var job: Job? = null
    private var nextId = 1L

    fun refreshAccessibility() {
        _state.update { it.copy(accessibilityEnabled = VenexAccessibilityService.isRunning()) }
    }

    fun submit(text: String) {
        val command = text.trim()
        if (command.isEmpty() || _state.value.running) return
        append(ChatMessage(nextId++, true, command))
        _state.update { it.copy(running = true, liveSteps = emptyList()) }

        job = viewModelScope.launch(Dispatchers.Default) {
            try {
                val plan = assistant.plan(command)
                if (plan.blockedReason != null) {
                    // Goes through the engine so the refusal is audited like any other outcome.
                    val report = assistant.run(plan)
                    append(ChatMessage(nextId++, false, describe(report.status, report.summary), report.status))
                } else {
                    append(ChatMessage(nextId++, false, "خطة التنفيذ: ${plan.steps.size} خطوة. جارٍ التنفيذ…"))
                    val report = assistant.run(plan) { r ->
                        _state.update { s ->
                            s.copy(liveSteps = s.liveSteps.filter { it.stepId != r.stepId } + r)
                        }
                    }
                    append(ChatMessage(nextId++, false, describe(report.status, report.summary), report.status))
                }
            } catch (e: CancellationException) {
                // Audit fix: a user cancel used to leave no trace in the execution log.
                container.audit.record(AuditLevel.WARN, "أوقف المستخدم المهمة")
                append(ChatMessage(nextId++, false, "أُوقفت المهمة بناءً على طلبك.", TaskStatus.CANCELLED))
                throw e
            } catch (e: Exception) {
                append(ChatMessage(nextId++, false, "حدث خطأ غير متوقع: ${e.javaClass.simpleName}", TaskStatus.FAILED))
            } finally {
                _state.update { it.copy(running = false, audit = container.audit.entries().takeLast(60)) }
            }
        }
    }

    /** Starts a fresh conversation (the greeting only). Not allowed while a task is running. */
    fun newChat() {
        if (_state.value.running) return
        _currentChatId.value = newChatId()
        _state.update { it.copy(messages = UiState().messages, liveSteps = emptyList()) }
    }

    /** Opens a saved conversation and restores its messages. */
    fun openChat(id: String) {
        if (_state.value.running) return
        val chat = _history.value.firstOrNull { it.id == id } ?: return
        _currentChatId.value = id
        val restored = chat.messages.map { m -> ChatMessage(nextId++, m.fromUser, m.text) }
        _state.update { it.copy(messages = restored, liveSteps = emptyList()) }
    }

    /** Deletes a saved conversation. The one currently running cannot be deleted. */
    fun deleteChat(id: String) {
        if (_state.value.running && id == _currentChatId.value) return
        store.delete(id)
        _history.value = store.loadAll()
        if (id == _currentChatId.value) newChat()
    }

    fun cancel() {
        job?.cancel()
        container.confirmations.answer(false)
    }

    fun answerConfirmation(approved: Boolean) = container.confirmations.answer(approved)

    fun clearAudit() {
        container.audit.clear()
        _state.update { it.copy(audit = emptyList()) }
    }

    fun showAudit() {
        _state.update { it.copy(audit = container.audit.entries().takeLast(60)) }
    }

    private fun describe(status: TaskStatus, summary: String): String = when (status) {
        TaskStatus.SUCCESS -> "✅ $summary"
        TaskStatus.UNVERIFIED -> "⚠️ $summary"
        TaskStatus.FAILED -> "❌ $summary"
        TaskStatus.NOT_EXECUTED -> "🚫 $summary"
        TaskStatus.CANCELLED -> "⛔ $summary"
    }

    private fun append(m: ChatMessage) {
        _state.update { it.copy(messages = it.messages + m) }
        persist()
    }

    /** Saves the current conversation once it contains a user message. */
    private fun persist() {
        val messages = _state.value.messages
        if (messages.none { it.fromUser }) return
        val title = messages.first { it.fromUser }.text.trim().take(48).ifEmpty { "محادثة جديدة" }
        val saved = messages.map { SavedMessage(it.fromUser, it.text) }
        store.save(SavedChat(_currentChatId.value, title, System.currentTimeMillis(), saved))
        _history.value = store.loadAll()
    }

    private fun newChatId(): String = java.util.UUID.randomUUID().toString()

    companion object {
        internal fun analyserText(snap: AiSnapshot): String =
            if (snap.enabled && snap.stage == AiStage.ENABLED) {
                "المحلل: نموذج محلي (${snap.config?.modelId.orEmpty()}) مع احتياط محلي"
            } else {
                "المحلل: قواعد محلية (بلا ذكاء اصطناعي)"
            }

        fun symbol(status: StepStatus): String = when (status) {
            StepStatus.VERIFIED -> "✅"
            StepStatus.EXECUTED_UNVERIFIED -> "⚠️"
            StepStatus.FAILED -> "❌"
            StepStatus.SKIPPED -> "⏭️"
            StepStatus.CANCELLED_BY_USER -> "⛔"
            StepStatus.RUNNING -> "⏳"
            StepStatus.PENDING -> "•"
        }
    }
}
