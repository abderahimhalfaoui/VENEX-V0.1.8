package com.venex.app

import com.venex.app.data.FileAuditSink
import com.venex.app.ui.ConfirmationBridge
import com.venex.core.audit.AuditEntry
import com.venex.core.audit.AuditLevel
import com.venex.core.model.Action
import com.venex.core.model.GlobalKey
import com.venex.core.model.Step
import kotlinx.coroutines.async
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.yield
import java.io.File
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

/** JVM-only tests for app-layer classes that do not need the Android framework. */
class AppLayerTest {

    private val step = Step("s", "خطوة", Action.Press(GlobalKey.BACK), needsConfirmation = true)

    @Test
    fun `confirmation bridge returns the users answer and clears pending`() = runTest {
        val bridge = ConfirmationBridge()
        val answer = async { bridge.confirm(step) }
        yield()
        assertEquals(step, bridge.pending.value)
        bridge.answer(true)
        assertTrue(answer.await())
        assertNull(bridge.pending.value)
    }

    @Test
    fun `declining returns false`() = runTest {
        val bridge = ConfirmationBridge()
        val answer = async { bridge.confirm(step) }
        yield()
        bridge.answer(false)
        assertFalse(answer.await())
    }

    @Test
    fun `file audit sink writes jsonl and rotates`() {
        val dir = File(System.getProperty("java.io.tmpdir"), "venex-test-${System.nanoTime()}").apply { mkdirs() }
        try {
            val file = File(dir, "audit.jsonl")
            val sink = FileAuditSink(file, maxBytes = 200)
            repeat(10) { i -> sink.write(AuditEntry(i.toLong(), AuditLevel.INFO, null, "entry number $i with some padding")) }
            assertTrue(file.exists())
            assertTrue(File(dir, "audit.jsonl.1").exists(), "log should have rotated")
            assertTrue(file.readLines().all { it.startsWith("{") && it.endsWith("}") })
        } finally {
            dir.deleteRecursively()
        }
    }
}
