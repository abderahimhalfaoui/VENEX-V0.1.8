package com.venex.app.llm

import com.venex.core.ai.ChatPrompt
import com.venex.core.ai.FailureKind
import com.venex.core.ai.ProviderResult
import com.venex.core.ai.ondevice.RuntimeParams
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertIs
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

/** A scripted bridge. It simulates a native call that blocks until cancelled, like a real generation. */
private class FakeBridge : LlamaBridge {
    var initCode = NativeError.NONE
    var loadCode = NativeError.NONE
    var completeBytes: ByteArray? = "{}".toByteArray()
    var completeCode = NativeError.NONE
    var truncated = false
    var blockInComplete = false
    var blockInLoad = false
    val cancelFlag = AtomicBoolean(false)
    val inComplete = CountDownLatch(1)
    val inLoad = CountDownLatch(1)
    val calls = java.util.Collections.synchronizedList(ArrayList<String>())
    val threadNames = java.util.Collections.synchronizedSet(HashSet<String>())
    var code = NativeError.NONE
    val unloadCount = AtomicInteger(0)

    override fun init(nativeLibDir: String): Int { calls += "init"; threadNames += Thread.currentThread().name; return initCode }
    override fun load(path: String, nCtx: Int, nThreads: Int): Int {
        calls += "load:$nCtx:$nThreads"; threadNames += Thread.currentThread().name
        if (blockInLoad) { inLoad.countDown(); while (!cancelFlag.get()) Thread.sleep(2); code = NativeError.CANCELLED; return NativeError.CANCELLED }
        code = loadCode; return loadCode
    }
    override fun unload() { unloadCount.incrementAndGet() }
    override fun isLoaded() = true
    override fun cancel() { cancelFlag.set(true) }
    override fun clearCancel() { cancelFlag.set(false) }
    override fun complete(system: String, user: String, maxTokens: Int, stats: LongArray): ByteArray? {
        calls += "complete"; threadNames += Thread.currentThread().name
        if (blockInComplete) { inComplete.countDown(); while (!cancelFlag.get()) Thread.sleep(2); code = NativeError.CANCELLED; return null }
        code = completeCode
        if (stats.size >= 5) stats[4] = if (truncated) 1L else 0L
        return if (completeCode == NativeError.NONE) completeBytes else null
    }
    override fun lastErrorCode() = code
    override fun lastError() = "detail"
    override fun modelInfo() = "llama 1B Q4_K_M|700000000|1000000000|4096|1024|2"
    override fun systemInfo() = "CPU : NEON = 1"
}

class LlamaCppRuntimeTest {
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r, "venex-llm-test") }
    private val dispatcher = exec.asCoroutineDispatcher()
    private fun runtime(b: FakeBridge) = LlamaCppRuntime({ b }, "/native", dispatcher)
    private val params = RuntimeParams(1024, 3)

    @Test
    fun `load initialises once, passes ctx and threads, parses model info`(): Unit = runBlocking {
        val b = FakeBridge(); val r = runtime(b)
        val ok = assertIs<ProviderResult.Ok<*>>(r.load("/m.gguf", params))
        assertEquals(listOf("init", "load:1024:3"), b.calls)
        r.unload()
        r.load("/m.gguf", params)
        assertEquals(1, b.calls.count { it == "init" })
        assertNotNull(ok)
    }

    @Test
    fun `native work never runs on the caller or main thread`(): Unit = runBlocking {
        val b = FakeBridge(); val r = runtime(b)
        r.load("/m.gguf", params); r.complete(ChatPrompt("s", "u", 8), 5_000)
        assertTrue(b.threadNames.isNotEmpty() && b.threadNames.all { it.startsWith("venex-llm-test") }, "native work must use dedicated dispatcher")
    }

    @Test
    fun `load failure codes map to clear failure kinds`(): Unit = runBlocking {
        for ((code, kind) in listOf(
            NativeError.LOAD_FAILED to FailureKind.INVALID_MODEL_FILE,
            NativeError.CONTEXT_FAILED to FailureKind.OUT_OF_MEMORY,
            NativeError.OUT_OF_MEMORY to FailureKind.OUT_OF_MEMORY,
            NativeError.NO_BACKEND to FailureKind.RUNTIME_UNAVAILABLE
        )) {
            val b = FakeBridge().apply { loadCode = code }
            val e = assertIs<ProviderResult.Err>(runtime(b).load("/m.gguf", params))
            assertEquals(kind, e.failure.kind, "code $code")
            assertTrue(e.failure.message.isNotBlank())
        }
    }

    @Test
    fun `missing native library is RUNTIME_UNAVAILABLE and never crashes`(): Unit = runBlocking {
        val r = LlamaCppRuntime({ throw UnsatisfiedLinkError("no libvenex_llm.so") }, "/native", dispatcher)
        val e = assertIs<ProviderResult.Err>(r.load("/m.gguf", params))
        assertEquals(FailureKind.RUNTIME_UNAVAILABLE, e.failure.kind)
        val e2 = assertIs<ProviderResult.Err>(r.complete(ChatPrompt("s", "u", 8), 1_000))
        assertEquals(FailureKind.NOT_READY, e2.failure.kind)
        r.unload() // must be safe
    }

    @Test
    fun `backend init failure is reported as RUNTIME_UNAVAILABLE`(): Unit = runBlocking {
        val b = FakeBridge().apply { initCode = NativeError.NO_BACKEND }
        assertEquals(FailureKind.RUNTIME_UNAVAILABLE, assertIs<ProviderResult.Err>(runtime(b).load("/m", params)).failure.kind)
    }

    @Test
    fun `completion decodes UTF-8 Arabic correctly`(): Unit = runBlocking {
        val b = FakeBridge().apply { completeBytes = """{"intent":"open_app","app":"الكاميرا"}""".toByteArray(Charsets.UTF_8) }
        val r = runtime(b); r.load("/m", params)
        val ok = assertIs<ProviderResult.Ok<com.venex.core.ai.Completion>>(r.complete(ChatPrompt("s", "u", 8), 5_000))
        assertTrue(ok.value.text.contains("الكاميرا"))
    }

    @Test
    fun `a reply cut at the token budget is a failure, never an answer`(): Unit = runBlocking {
        val b = FakeBridge().apply { completeBytes = "<think>Alg".toByteArray(); truncated = true }
        val r = runtime(b); r.load("/m", params)
        val err = assertIs<ProviderResult.Err>(r.complete(ChatPrompt("s", "u", 8), 5_000))
        assertEquals(FailureKind.INVALID_RESPONSE, err.failure.kind)
    }

    @Test
    fun `a truncated multi-byte sequence does not crash`(): Unit = runBlocking {
        val full = "ا".toByteArray(Charsets.UTF_8)
        val b = FakeBridge().apply { completeBytes = full.copyOf(1) }
        val r = runtime(b); r.load("/m", params)
        assertIs<ProviderResult.Ok<*>>(r.complete(ChatPrompt("s", "u", 8), 5_000))
    }

    @Test
    fun `timeout cancels the native generation and reports TIMEOUT`(): Unit = runBlocking {
        val b = FakeBridge().apply { blockInComplete = true }
        val r = runtime(b); r.load("/m", params)
        val e = assertIs<ProviderResult.Err>(r.complete(ChatPrompt("s", "u", 8), 200))
        assertEquals(FailureKind.TIMEOUT, e.failure.kind)
        assertTrue(b.cancelFlag.get(), "native cancel flag must have been raised")
    }

    @Test
    fun `coroutine cancellation aborts the native generation`(): Unit = runBlocking {
        val b = FakeBridge().apply { blockInComplete = true }
        val r = runtime(b); r.load("/m", params)
        val job = async(Dispatchers.Default) { r.complete(ChatPrompt("s", "u", 8), 60_000) }
        assertTrue(b.inComplete.await(5, TimeUnit.SECONDS))
        job.cancel()
        runCatching { job.await() }
        assertTrue(job.isCancelled)
        assertTrue(b.cancelFlag.get())
    }

    @Test
    fun `cancel from another thread stops a running load`(): Unit = runBlocking {
        val b = FakeBridge().apply { blockInLoad = true }
        val r = runtime(b)
        val load = async(Dispatchers.Default) { r.load("/m", params) }
        assertTrue(b.inLoad.await(5, TimeUnit.SECONDS))
        r.cancel()
        val e = assertIs<ProviderResult.Err>(load.await())
        assertEquals(FailureKind.CANCELLED, e.failure.kind)
    }

    @Test
    fun `a stale cancel does not poison the next operation`(): Unit = runBlocking {
        val b = FakeBridge(); val r = runtime(b)
        r.load("/m", params)
        r.cancel()                      // nothing running: leaves the flag raised
        assertIs<ProviderResult.Ok<*>>(r.complete(ChatPrompt("s", "u", 8), 5_000))
    }

    @Test
    fun `decode and tokenizer failures map to explicit errors`(): Unit = runBlocking {
        val b = FakeBridge().apply { completeCode = NativeError.PROMPT_TOO_LONG }
        val r = runtime(b); r.load("/m", params)
        assertEquals(FailureKind.PROMPT_TOO_LONG, assertIs<ProviderResult.Err>(r.complete(ChatPrompt("s", "u", 8), 5_000)).failure.kind)
        b.completeCode = NativeError.DECODE_FAILED
        assertEquals(FailureKind.INVALID_RESPONSE, assertIs<ProviderResult.Err>(r.complete(ChatPrompt("s", "u", 8), 5_000)).failure.kind)
        b.completeCode = NativeError.OUT_OF_MEMORY
        assertEquals(FailureKind.OUT_OF_MEMORY, assertIs<ProviderResult.Err>(r.complete(ChatPrompt("s", "u", 8), 5_000)).failure.kind)
    }

    @Test
    fun `model info parsing is defensive`() {
        assertNotNull(LlamaCppRuntime.parseInfo("a|1|2|3|4|5"))
        assertEquals(null, LlamaCppRuntime.parseInfo("garbage"))
        assertEquals(null, LlamaCppRuntime.parseInfo("a|x|2|3|4|5"))
    }
}
